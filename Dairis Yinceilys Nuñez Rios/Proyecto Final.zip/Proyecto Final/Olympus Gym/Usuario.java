public class Socio {
    private String nombre;
    private int documento;
    private String correo;
    private String membresia;
    private int peso;
    private String usuario;
    private String contraseña;

    public Socio() {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getDocumento() {
        return documento;
    }

    public void setDocumento(int documento) {
        this.documento = documento;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getMembresia() {
        return membresia;
    }

    public void setMembresia(String membresia) {
        this.membresia = membresia;

    public int getPeso() {
       return peso;
    }

    public void setPeso(int peso) {
       this.peso = peso;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    @Override
    public String toString() {
        return "Socio{" +
               "nombre='" + nombre +
               ", documento=" + documento + '\'' +
               ", correo='" + correo + '\'' +
               ", membresia=" + membresia +
               ", usuario='" + usuario + '\'' +
               ", contraseña='" + contraseña + '\'' +
               '}';
        }
}
