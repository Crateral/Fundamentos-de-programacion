public class Horario extends Coach{
    private int cod_Horario;
    private date fecha;
    private date hora;

    public Horario(int cod_Horario, date fecha, date hora) {
        this.cod_Horario = cod_Horario;
        this.fecha = fecha;
        this.hora = hora;
    }

    public int getCod_Horario() {
        return cod_Horario;
    }

    public void setCod_Horario(int cod_Horario) {
        this.cod_Horario = cod_Horario;
    }

    public date getFecha() {
        return fecha;
    }

    public void setFecha(date fecha) {
        this.fecha = fecha;
    }

    public date getHora() {
        return hora;
    }

    public void setHora(date hora) {
        this.hora = hora;
    }

    @Override
    public String toString() {
        return "Horario{" +
                "cod_Horario=" + cod_Horario +
                ", fecha=" + fecha +
                ", hora=" + hora +
                '}';
    }
}
