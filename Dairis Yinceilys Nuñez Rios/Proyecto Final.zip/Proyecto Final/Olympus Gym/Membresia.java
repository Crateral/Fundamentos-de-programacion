public class Membresia extends Usuario{
    private String activa;
    private String inactiva;

    public Membresia(String activa, String inactiva) {
        this.activa = activa;
        this.inactiva = inactiva;
    }

    public String getActiva() {
        return activa;
    }

    public void setActiva(String activa) {
        this.activa = activa;
    }

    public String getInactiva() {
        return inactiva;
    }

    public void setInactiva(String inactiva) {
        this.inactiva = inactiva;
    }


    @Override
    public String toString() {
        return "Membresia{" +
                "activa='" + activa + '\'' +
                ", inactiva='" + inactiva + '\'' +
                '}';
    }

    public void estadoMembresia(){
        if (usuario = getUsuario()){
            System.out.println("Membresia activa");
        }else {
            System.out.printl("Membresia inactiva");
        }
    }
}
