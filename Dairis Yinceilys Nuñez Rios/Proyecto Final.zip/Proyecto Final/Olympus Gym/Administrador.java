public class Administrador extends Usuario{
    private int cod_Administrador;
    private String Nombre;

    public Administrador(int cod_Administrador, String nombre) {
        this.cod_Administrador = cod_Administrador;
        Nombre = nombre;
    }

    public int getCod_Administrador() {
        return cod_Administrador;
    }

    public void setCod_Administrador(int cod_Administrador) {
        this.cod_Administrador = cod_Administrador;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    @Override
    public String toString() {
        return "Administrador{" +
                "cod_Administrador=" + cod_Administrador +
                ", Nombre='" + Nombre + '\'' +
                '}';
    }
}
