public class Categoria extends Usuario{
    private String invidual;
    private String grupal,
    private String pareja;

    public Categoria(String invidual, String grupal, String pareja) {
        this.invidual = invidual;
        this.grupal = grupal;
        this.pareja = pareja;
    }

    public String getInvidual() {
        return invidual;
    }

    public void setInvidual(String invidual) {
        this.invidual = invidual;
    }

    public String getGrupal() {
        return grupal;
    }

    public void setGrupal(String grupal) {
        this.grupal = grupal;
    }

    public String getPareja() {
        return pareja;
    }

    public void setPareja(String pareja) {
        this.pareja = pareja;
    }

    @java.lang.Override
    public java.lang.String toString() {
        return "Categoria{" +
                "invidual='" + invidual + '\'' +
                ", grupal='" + grupal + '\'' +
                ", pareja='" + pareja + '\'' +
                '}';
    }
}
