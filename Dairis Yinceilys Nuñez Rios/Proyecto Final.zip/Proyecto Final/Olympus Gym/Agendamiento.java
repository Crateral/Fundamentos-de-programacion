public class Agendamiento extends Usuario{
    private String fecha;
    private string dia;

    public Agendamiento(String fecha, string dia) {
        this.fecha = fecha;
        this.dia = dia;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public string getDia() {
        return dia;
    }

    public void setDia(string dia) {
        this.dia = dia;
    }

    @Override
    public String toString() {
        return "Agendamiento{" +
                "fecha='" + fecha + '\'' +
                ", dia=" + dia +
                '}';
    }
}
