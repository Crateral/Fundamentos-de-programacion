public class Coach extends Usuario{
    private int cod_Instructor;
    private String nombre;
    private String horario;

    public Coach(int cod_Instructor, String nombre, String horario) {
        this.cod_Instructor = cod_Instructor;
        this.nombre = nombre;
        this.horario = horario;
    }

    public int getCod_Instructor() {
        return cod_Instructor;
    }

    public void setCod_Instructor(int cod_Instructor) {
        this.cod_Instructor = cod_Instructor;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    @Override
    public String toString() {
        return "Coach{" +
                "cod_Instructor=" + cod_Instructor +
                ", nombre='" + nombre + '\'' +
                ", horario='" + horario + '\'' +
                '}';
    }
}
