package Login;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class InicioDeSesion {
    private static Register numUser;

    public static void main(String[] args) {
        List<Register> registerUser= new ArrayList<>();
        String user = null;
        Scanner sc= new Scanner(System.in);

        Scanner entry = new Scanner(System.in);
        String name, email, password;
        int opcion=0;
        int User=0;


        while (true) {
            System.out.println("Registrar usuario");
            System.out.println("1.Crear usuario");
            System.out.println("2.Consultar usuario");
            System.out.println("3.Iniciar Sesion");
            System.out.println("4.Cambiar Contraseña");
            System.out.println("5.Recuperar Contraseña");
            System.out.println("6.Logout");
            System.out.println("Digita una opcion");
            opcion = entry.nextInt();

            switch (opcion) {
                case 1:

                    System.out.println("Enter user");
                    System.out.println("Name: ");
                    name = entry.next();


                    System.out.println("Enter email");
                    System.out.println("email: ");
                    email = entry.next();


                    System.out.println("Enter password");
                    System.out.println("password: ");
                    password = entry.next();



                    registerUser.add(numUser);
                    System.out.println("Successful registration");

                    break;

                case 2:
                    if (registerUser.size()!=0) {
                        for (Register regPer : registerUser) {
                            System.out.println(regPer.toString());
                        }
                    } else {
                        System.out.println("Not registered");
                    }

                    break;

                case 3:
                    if (registerUser.size()!=0) {
                        System.out.println("Type your credentials");
                        System.out.print("User: ");
                        email = entry.next();
                        System.out.print("password: ");
                        password = entry.next();

                        for (Register regPers : registerUser) {
                            if (regPers.getEmail().equals(email) && regPers.getPassword().equals(password)) {
                                System.out.println("Welcome");
                            } else {
                                System.out.println("Try again");
                            }
                        }
                    }else {
                        System.out.println("Not registered");
                    }

                    break;

                case 4:
                    if (registerUser.size()!=0) {
                        System.out.print("Type your email: ");
                        email = entry.next();

                        for (Register caPass : registerUser) {
                            if (caPass.getEmail().equals(email)) {
                                int indice = registerUser.indexOf(caPass.getEmail());

                                if (indice != 0) {
                                    System.out.print("Type your password: ");
                                    password = entry.next();
                                    System.out.println("Sure you want to change the password?: Yes [1], No [2]");
                                    int chanPass= entry.nextInt();
                                    if (chanPass == 1) {
                                        caPass.setPassword(password);
                                        System.out.println("password changed successfully 👍");
                                    }else {
                                        System.out.println("password change canceled ❌");
                                    }
                                }
                            }

                        }
                    }else {
                        System.out.println("Not registered");
                    }

                    break;
                case 5:
                    if (registerUser.size()!=0) {
                        System.out.println("Forget your password: Yes[1] No[2] ");
                        int recPass = entry.nextInt();
                        if (recPass == 1) {
                            System.out.print("enter your email: ");
                            email = entry.next();

                            for (Register caPass : registerUser) {
                                if (caPass.getEmail().equals(email)) {
                                    int indice = registerUser.indexOf(caPass.getEmail());

                                    if (indice != 0) {
                                        System.out.print("type new password: ");
                                        password = entry.next();
                                        caPass.setPassword(password);
                                        System.out.println("password changed successfully 👍");
                                    }
                                }
                            }
                        }else{
                            System.out.println("Digita una opcion");
                        }

                    }else {
                        System.out.println("Not registered");
                    }

                    break;
                case 6:
                    System.out.println("Session ended");
                    System.exit(0);

                    break;
                default:
                    System.out.println(" Not valid ");
            }
        }
    }
}
