package CarritoDeCompras;

public class Categorias {

    String Tecnologia, Ropa, Aseo, Granos, Viveres, Lacteos, Frutas_Verduras, Carnes, Papeleria;
}
