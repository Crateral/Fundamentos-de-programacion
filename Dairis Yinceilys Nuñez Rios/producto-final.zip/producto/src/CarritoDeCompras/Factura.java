package CarritoDeCompras;

import java.util.Scanner;

public class Factura {
    public void main(String[] args) {
        Scanner Prod = new Scanner(System.in);
        String nombre;
        double precio;
        int cantidad;
        double subTotal;
        double total;
        double total2;
        double impuesto;
        double iva=0.19;
        double descuento=0.1;
        System.out.println("Que desea comprar?");
        nombre=Prod.next();
        System.out.println("Cual es el precio unitario del producto: "+nombre+"?");
        precio=Prod.nextDouble();
        System.out.println("Cuantas unidades del producto: "+nombre+" desea llevar?");
        cantidad=Prod.nextInt();
        subTotal= precio*cantidad;
        impuesto=(subTotal*iva);
        total= subTotal+impuesto;

        if (total>10000) {
            total2=(total)-total*descuento;

            System.out.println("------------FACTURA------------"
                    + "\nProducto: "+nombre
                    +"\nPrecio: "+precio
                    +"\nCantidad comprada: "+cantidad
                    +"\nSubTotal: "+subTotal
                    +"\nImpuesto: "+impuesto
                    +"\nTotal: "+total
                    +"\nDescuento: "+(total*descuento)
                    +"\nTotal a pagar: "+total2);

        }else{
            System.out.println("------------FACTURA------------"
                    + "\nProducto: "+nombre
                    +"\nPrecio: "+precio
                    +"\nCantidad comprada: "+cantidad
                    +"\nSubTotal: "+subTotal
                    +"\nImpuesto: "+impuesto
                    +"\nTotal: "+total);
        }
    }
}
