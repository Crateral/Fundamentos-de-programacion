package CarritoDeCompras;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Carrito {
    public static void Main(String[] args) {

        System.out.println("Carrito de compras");
        List<Producto> carrito = new ArrayList<>();
        Scanner x = new Scanner(System.in);

        while (true) {
            System.out.println(" Carrito de compras ");
            System.out.println("--------------------");
            System.out.println("1.Añadir producto ");
            System.out.println("2.Consultar producto ");
            System.out.println("3.Consultar por categoria ");
            System.out.println("4.Ordenar productos de menor a mayor precio ");
            System.out.println("5.Ordenar productos de mayor a menor precio ");
            System.out.println("6.Ordenar por categoria ");
            System.out.println("7.Ordenar por nombre ");
            System.out.println("8.Eliminar producto ");
            System.out.println("9.Generar Factura ");
            System.out.println("10.Digita la opcion que deseas realizar ");
            int opcion = x.nextInt();

            do {
                switch (opcion) {
                    case 1:
                        System.out.print("añadir productos");
                        int nuProd = x.nextInt();
                        String nom;
                        String cat = null;
                        int cant = 0;
                        int precio;

                        for (int i = 0; i < nuProd; i++) {
                            Producto aggProd = new Producto();

                            System.out.print("Codigo del producto: ");
                            String cod = x.next();
                            aggProd.setCodigo(aggProd.getCodigo());
                            System.out.println("Nombre del producto: ");
                            x.nextLine();
                            nom = x.nextLine();
                            aggProd.setNombre(nom);
                            System.out.print("Categoria del producto: ");
                            System.out.println("Elegir: " + "  1 Tecnologia " + " 2 Ropa  " + " 3 Aseo "
                                    + " 4. Granos " + " 5. Viveres " + " 6. Lacteos " + " 7. Frutas_Verduras "
                                    + " 8. Carnes " + " 9. Papeleria");
                            aggProd.setCategoria(cat);
                            System.out.println("Cantidad del producto: ");
                            String can = x.next();
                            aggProd.setCantidad(cant);
                            System.out.println("Precio del producto: ");
                            precio = x.nextInt();
                            aggProd.setPrecio(precio);

                            carrito.add(aggProd);
                        }
                        break;

                    case 2:

                        if (carrito.size() != 0) {
                            for (Producto carrCom : carrito) {
                                System.out.println(carrCom.toString());
                            }
                        } else {
                            System.out.println(" No tienes productos en el carrito");
                        }
                        break;

                    case 3:

                        if (carrito.size() != 0) {
                            String buCat;
                            int con = 0;
                            for (Producto carrCom : carrito) {
                                System.out.println("ElegirCategoria: " + carrCom.getCategoria() + " -- " + carrCom.getCategoria(

                                ));
                            }
                            System.out.println("consultar categoria ");
                            buCat = x.next();
                            for (Producto carrCom : carrito) {
                                if (carrCom.getCategoria().equals(buCat)) {
                                    System.out.println("Codigo:" + carrCom.getCodigo + "Nombre: " + carrCom.getNombre() + " Categoria: " + carrCom.getCategoria() +
                                            "Cantidad: " + carrCom.getCantidad() + "Precio: " + carrCom.getPrecio());
                                }
                                con = con + 1;
                            }
                        } else {
                            System.out.println(" No tienes productos en el carrito");
                        }
                        break;

                    case 4:

                        if (carrito.size() != 0) {
                            System.out.println("Ordenar productos de menor a mayor precio...");
                            carrito.sort(Comparator.comparing(Producto::getPrecio).reversed());
                            for (Producto carrCom : carrito) {
                                System.out.println(carrCom.toString());
                            }
                        } else {
                            System.out.println(" No tienes productos en el carrito");
                        }
                        break;

                    case 5:

                        if (carrito.size() != 0) {
                            System.out.println("Ordenando productos de mayor a menor precio...");
                            carrito.sort(Comparator.comparing(Producto::getPrecio));
                            for (Producto carrCom : carrito) {
                                System.out.println(carrCom.toString());
                            }
                        } else {
                            System.out.println(" No tienes productos en el carrito");
                        }
                        break;

                    case 6:

                        if (carrito.size() != 0) {
                            System.out.println("Ordenar por categoria");
                            carrito.sort(Comparator.comparing(Producto::getCategoria));
                            for (Producto carrCom : carrito) {
                                System.out.println(carrCom.toString());
                            }
                        } else {
                            System.out.println(" No tienes productos en el carrito");
                        }

                        break;

                    case 7:
                        if (carrito.size() != 0) {
                            System.out.println("Ordenar por nombre");
                            carrito.sort(Comparator.comparing(Producto::getNombre));
                            for (Producto carrCom : carrito) {
                                System.out.println(carrCom.toString());
                            }
                        } else {
                            System.out.println(" No tienes productos en el carrito");
                        }

                        break;

                    case 8:
                        if (carrito.size() != 0) {
                            System.out.println("Eliminar producto");
                            String EliProd;
                            EliProd = x.next();
                        }
                        break;

                    case 9:
                        if (carrito.size() != 0) {
                            System.out.println("Generar Factura");
                            int Factura = x.nextInt();
                        }

                        break;

                    default:


                        System.out.println("ingresar una opcion valida");


                }


            }
            while (opcion != 10);
        }
    }
}
