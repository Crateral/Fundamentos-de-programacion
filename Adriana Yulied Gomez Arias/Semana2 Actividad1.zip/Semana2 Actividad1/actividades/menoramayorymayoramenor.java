public class MayoraMenoryMenosaMayor{

    //Menor a Mayor

    public static void main(String[] args) {
        int numeros [] = {7,4,2,1,10,5,6};
        Arrays.sort(numeros);
         for (int i = 0; i<numeros.length; i++) {
            System.out.print(""+number[i]);
         }
    //Mayor a Menor
    
         Arrays.sort(numeros);
         for (int i = 0; i<numeros.length-1; i>= 0; i--) {
            System.out.print(""+number[i]);
         }    
    }
}