/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

package punto5;


/**
 *
 * @author 
 */
public class Punto5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        

        Hierba hierva= new Hierba();
        hierva.cacularAltura();
        hierva.crearFlor();
        hierva.crearFruto();
        hierva.tieneflores=false;
         System.out.println(hierva.tieneflores);
        //tiempo de vida que lleva transcurrido y el tiempo de vida promedio
        hierva.calcularTiempodeVida(60, 365);
        
        Arbustos arbusto= new Arbustos();
        arbusto.cacularAltura();
        arbusto.crearFlor();
        arbusto.crearFruto();
        arbusto.tieneflores=false;
         System.out.println(arbusto.tieneflores);
        //tiempo de vida que lleva transcurrido y el tiempo de vida promedio
        arbusto.calcularTiempodeVida(380, 12000);
        
        Matas mata= new Matas();
        mata.cacularAltura();
        mata.crearFlor();
        mata.crearFruto();
        mata.tieneflores=true;
        System.out.println(mata.tieneflores);
        //tiempo de vida que lleva transcurrido y el tiempo de vida promedio
        mata.calcularTiempodeVida(5, 60);
        
        Arboles arbol= new Arboles();
        arbol.cacularAltura();
        arbol.crearFlor();
        arbol.crearFruto();
        arbol.tieneflores=false;
        System.out.println(arbol.tieneflores);
        //tiempo de vida que lleva transcurrido y el tiempo de vida promedio
        arbol.calcularTiempodeVida(465, 100000000);
        

    }

}
