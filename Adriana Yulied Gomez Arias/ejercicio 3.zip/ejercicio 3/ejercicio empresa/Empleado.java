public class Empleado extends Empresa {

    String  tipo;

    public Empleado(String nombre, , int cantidad, String tipo ) {
        super(nombre, cantidad);
        this.tipo = tipo;
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String Tipo) {
        this.tipo = tipo;
    }

    public void show(){
        System.out.println(getNombre() + "-"+getTipo()+"-"+getCantidad());
    }
}