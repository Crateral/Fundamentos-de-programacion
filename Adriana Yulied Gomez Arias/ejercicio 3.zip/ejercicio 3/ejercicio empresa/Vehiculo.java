
public class Vehiculo extends Empresa {

    String  tipo;

    public Vehiculo(String nombre, , int cantidad, String tipo ) {
        super(nombre, cantidad);
        this.tipo = tipo;
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public void show(){
        System.out.println(getNombre() + "-"+getTipo()+"-"+getCantidad());
    }
}