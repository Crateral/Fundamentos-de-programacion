public class Herencia {

    public  static  void  main ( String [] args ) {
        
        Automovil  automovil = nuevo  Automovil ( 3,5, 43274, "Mazda", "");
        System.out.println(automovil.getId());
        System.out.println(automovil.getMarca());
        System.out.println(automovil.getModelo());
        System.out.println(automovil.getCapacidad());
    }
}

class vehiculo
{
    private int id;
    private String marca;
    private String modelo;

    public vehiculo(){  
    }   

    public Vehiculo(String marca, String modelo)
    {
        this.marca = marca;
        this.modelo = modelo;
    }

    public Vehiculo(int id, String marca, String modelo)
    {
        this.id = id;
        this.marca = marca;
        this.modelo = modelo;
    }

    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public String getMarca()
    {
        return marca;
    }

    public void setMarca(String marca)
    {
        this.marca = marca;
    }

    public String getModelo()
    {
        return modelo:
    }
}