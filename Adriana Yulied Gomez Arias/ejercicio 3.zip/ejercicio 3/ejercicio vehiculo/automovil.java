class  Automovil  extends  Vehiculo {
    private double capidad ;

    public automovil() 
    {
    }

   public  automovil (double  capacidad , int  id, String  marca, String  modelo) 
   {
       super (id, marca, modelo);
       this.capacidad = capacidad;
   }

   public  double  getCapacidad() 
   {
        return capacidad;
   }

   public  void  setCapacidad(double  capacidad) 
   {
       this.capacidad = capacidad;
   }
}