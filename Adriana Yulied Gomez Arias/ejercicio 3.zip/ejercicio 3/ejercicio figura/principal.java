import java.util.Scanner;
public class principal
{
    public static void main(String[] args)
    {
        Scannner entrada=new Scanner(System.in);
        double wlado, walt, wbas;
        System.out.print("Lado del cuadradro.....");
        wlado=entrada.nextDouble();
        System.out.print("Base del rectangulo.....");
        wbas=entrada.nexDouble();
        System.out.print("Altura del rectangulo.....");
        walt=entrada.nextDouble();
        cuadrado objcuad = cuadrado(wlado);
        rectangulo objrect = rectangulo(walt, wbas);
        objcuad.setarea();
        objcuad.setperimetro();
        objcuad.dibujar();
        objrect.setbase();
        objrect.setperimetro();
        objrect.dibujar();
    }
}