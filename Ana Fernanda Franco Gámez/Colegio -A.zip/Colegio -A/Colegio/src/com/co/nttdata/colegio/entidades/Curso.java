package com.co.nttdata.colegio.entidades;

public enum Curso {
    MATEMATICAS,
    PROGRAMACION,
    QUIMICA;

}
