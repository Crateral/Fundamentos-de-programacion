package com.co.nttdata.colegio.logica;

import com.co.nttdata.colegio.entidades.Curso;

public class ValidarCurso {

    public Curso validarCurso(String marca) {

        if (marca.trim().equalsIgnoreCase(String.valueOf(Curso.MATEMATICAS))) {
            return Curso.MATEMATICAS;
        } else if (marca.trim().equalsIgnoreCase(String.valueOf(Curso.PROGRAMACION))) {
            return Curso.PROGRAMACION;
        } else if (marca.trim().equalsIgnoreCase(String.valueOf(Curso.QUIMICA))) {
            return Curso.QUIMICA;
        } else {
            return null;
        }
    }
}