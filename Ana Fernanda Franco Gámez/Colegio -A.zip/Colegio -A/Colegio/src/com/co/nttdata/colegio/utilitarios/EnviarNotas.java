package com.co.nttdata.colegio.utilitarios;

import com.co.nttdata.colegio.entidades.DatosProfesor;
import com.co.nttdata.colegio.entidades.Estudiante;
import com.co.nttdata.colegio.entidades.ReporteEstudiante;

import java.io.FileWriter;
import java.util.List;

public class EnviarNotas {

    public void enviarNotas(String nombreArchivo, List<Estudiante> est, DatosProfesor pro) {
        ReporteEstudiante rep = new ReporteEstudiante();
        rep.setIdReporte(1234);
        rep.setNotasEstudi(est);
        rep.setProfesor(pro);
        System.out.println("--------------------------------");
        FileWriter archivo = null;
        try {
            archivo = new FileWriter("C:\\Users\\afrangam\\OneDrive - NTT DATA EMEAL\\Documentos\\Actividades\\Colegio\\" + nombreArchivo, false);

            // archivo.write(rep.getNotasEstudi().toString());
            archivo.write("-----------------------------------------------" + "\n" +
                    "Id Reporte : " + rep.getIdReporte() + "\n" +
                    "Profesor: " + pro.getNombre() + "\n" +
                    "Telefono: " + pro.getTelefono() + "\n");


            for (Estudiante nes : est) {
                if (nes.getPromedio() >= 3) {
                    rep.setObservacion("Aprobo el curso");
                } else {
                    rep.setObservacion("Reprobo el curso");
                }

                archivo.write("-----------------------------------------------" + "\n" +
                        "* Curso: " + nes.getCurso() + "\n" +
                        "* Nombre Estudiante: " + nes.getNombre() + "\n" +
                        " " + "\n" +
                        "Calificaciones obtenidas por el estudiante: " +
                        "\n" + nes.getListaNotas() + "\n" +
                        "               Promedio:  " + nes.getPromedio() + "\n" +
                        "´´´´´´´´´´´´´´´´´´´´´´´´´´´´´´´´´´´´´´´´´´´´´´´" + "\n" +
                        " * Observacion: " + rep.getObservacion() + "\n" +
                        "-----------------------------------------------" + "\n" +
                        "  " + "\n");
            }
            System.out.println("Regorte generado con exito⬇");
            archivo.close();
        } catch (Exception e) {
            System.out.println("Error al escribir el archivo: " + e.getMessage());
        }


    }
}
