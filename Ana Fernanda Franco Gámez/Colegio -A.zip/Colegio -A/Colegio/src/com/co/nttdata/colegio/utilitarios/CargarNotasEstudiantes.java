package com.co.nttdata.colegio.utilitarios;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CargarNotasEstudiantes {

    public List leerArchivo(String nombreArchivo) {
        List<String> lisNoEst = new ArrayList<>();
        File archivo = new File("C:\\Users\\afrangam\\OneDrive - NTT DATA EMEAL\\Documentos\\Actividades\\Colegio\\" + nombreArchivo);
        Scanner s = null;

        try {
            s = new Scanner(archivo);
            while (s.hasNextLine()) {
                String linea = s.nextLine();
                lisNoEst.add(linea);

            }

        } catch (Exception e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        } finally {
            try {
                if (s != null) {
                    s.close();
                }
            } catch (Exception e) {
                System.out.println("Error al cerrar la lectura del archivo: " + e.getMessage());
            }
        }
        return lisNoEst;
    }
}