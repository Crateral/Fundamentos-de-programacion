package com.co.nttdata.colegio.interfaces;

import com.co.nttdata.colegio.entidades.Curso;
import com.co.nttdata.colegio.entidades.Estudiante;
import com.co.nttdata.colegio.entidades.Notas;

import java.util.List;

public interface GestionEstudiantes {

    public List<Estudiante> agregarEstudiantes(List<String> listNotaEst);

    public void cambiarNota(List<Estudiante> registros, String nombre);

    public void calcularPromedio(List<Estudiante> listaEstudi);
}
