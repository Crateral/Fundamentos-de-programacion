package com.co.nttdata.colegio.entidades;

public class Notas {

    private double nota;
    private String descripcion;

    public double getNota() {
        return nota;
    }

    public void setNota(double nota) {
        this.nota = nota;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return "Nota: " + nota + " Descripcion: " + descripcion + "\n";
    }
}
