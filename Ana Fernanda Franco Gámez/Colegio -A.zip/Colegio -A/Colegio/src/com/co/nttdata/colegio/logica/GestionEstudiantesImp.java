package com.co.nttdata.colegio.logica;

import com.co.nttdata.colegio.entidades.Estudiante;
import com.co.nttdata.colegio.entidades.Notas;
import com.co.nttdata.colegio.interfaces.GestionEstudiantes;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class GestionEstudiantesImp implements GestionEstudiantes {
    int num;

    Scanner x = new Scanner(System.in);

    @Override
    public List<Estudiante> agregarEstudiantes(List<String> listNotaEst) {
        List<Estudiante> listaEstudiantes = new ArrayList<>();

        ValidarCurso va = new ValidarCurso();

        for (String nre : listNotaEst) {
            Notas nota1 = new Notas();
            Notas nota2 = new Notas();
            Notas nota3 = new Notas();
            Notas nota4 = new Notas();
            List<Notas> listNotas = new ArrayList<>();
            Estudiante est = new Estudiante();
            String regNotas[] = nre.split(",");
            est.setIdEstudiante(Integer.parseInt(regNotas[0]));
            est.setNombre(regNotas[1]);
            nota1.setNota(Double.parseDouble(regNotas[2]));
            nota1.setDescripcion(regNotas[3]);
            nota2.setNota(Double.parseDouble(regNotas[4]));
            nota2.setDescripcion(regNotas[5]);
            nota3.setNota(Double.parseDouble(regNotas[6]));
            nota3.setDescripcion(regNotas[7]);
            nota4.setNota(Double.parseDouble(regNotas[8]));
            nota4.setDescripcion(regNotas[9]);
            listNotas.add(nota1);
            listNotas.add(nota2);
            listNotas.add(nota3);
            listNotas.add(nota4);
            est.setListaNotas(listNotas);
            est.setCurso(va.validarCurso(regNotas[10]));
            listaEstudiantes.add(est);
        }

        System.out.println(listaEstudiantes.toString());
        return listaEstudiantes;
    }


    public void cambiarNota(List<Estudiante> registros, String nombre) {

        int numNota = 0, num;
        for (int i = 0; i < registros.size(); i++) {
            if (registros.get(i).getNombre().equals(nombre)) {
                System.out.println("lista de notas" + registros.get(i).getListaNotas());

                List<Notas> notacamb = registros.get(i).getListaNotas();

                System.out.println("Que nota deseas cambiar");
                num = x.nextInt();

                for (int j = 0; j < notacamb.size(); j++) {

                    if (num == (numNota + 1)) {
                        System.out.println("La nota a cambiar esta en la posicion: " + (numNota + 1) + " : " + notacamb.get(j).getNota() + " Desc. "
                                + notacamb.get(j).getDescripcion());

                        System.out.println("ingresa la nueva nota");
                        notacamb.get(numNota).setNota(x.nextDouble());
                        System.out.println("Descripcion ");
                        notacamb.get(numNota).setDescripcion(x.next());

                    }

                    numNota++;
                }

                break;

            }


        }


        System.out.println("Cambios actualizados");
        System.out.println(registros.toString());



    }

    @Override
    public void calcularPromedio(List<Estudiante> listaEstudi) {

        double calculoPromedio = 0, dat = 0;
        int cont = 0;

        for (int i = 0; i < listaEstudi.size(); i++) {
            List<Notas> notEst = listaEstudi.get(i).getListaNotas();

            for (int j = 0; j < notEst.size(); j++) {
                System.out.println(notEst.get(j).getNota());
                dat = dat + notEst.get(j).getNota();
                cont++;
            }
            System.out.println("Total notas: " + cont);
            System.out.println("Suma del total de notas " + dat);
            System.out.println("Calculando promedio...");

            calculoPromedio = dat / cont;


            if (calculoPromedio >= 3) {

                System.out.println("El estudiante " + listaEstudi.get(i).getNombre() + " obtuvo promedio " + calculoPromedio +
                        " y aprobo el curso");

            } else {

                System.out.println("El estudiante " + listaEstudi.get(i).getNombre() + " obtuvo promedio " + calculoPromedio +
                        " y reprobo el curso");
            }
            listaEstudi.get(i).setPromedio(calculoPromedio);
            dat = 0;
            cont = 0;
            System.out.println("------------");


        }
      //  System.out.println(listaEstudi.toString());

    }

}
