package com.co.nttdata.colegio.entidades;

import java.util.List;

public class ReporteEstudiante {

    private int idReporte;

    private List<Estudiante> notasEstudi;
    private DatosProfesor profesor;
    private String observacion;

    public ReporteEstudiante(int idReporte, List<Estudiante> notasEstudi, DatosProfesor profesor, String observacion) {
        this.idReporte = idReporte;
        this.notasEstudi = notasEstudi;
        this.profesor = profesor;
        this.observacion = observacion;
    }

    public ReporteEstudiante() {
    }

    public int getIdReporte() {
        return idReporte;
    }

    public void setIdReporte(int idReporte) {
        this.idReporte = idReporte;
    }

    public List<Estudiante> getNotasEstudi() {
        return notasEstudi;
    }

    public void setNotasEstudi(List<Estudiante> notasEstudi) {
        this.notasEstudi = notasEstudi;
    }

    public DatosProfesor getProfesor() {
        return profesor;
    }

    public void setProfesor(DatosProfesor profesor) {
        this.profesor = profesor;
    }

    public String getObservacion() {
        return observacion;
    }

    public void setObservacion(String observacion) {
        this.observacion = observacion;
    }

    @Override
    public String toString() {
        return "ReporteEstudiante{" +
                "idReporte=" + idReporte +
                ", notasEstudi=" + notasEstudi +
                ", profesor=" + profesor +
                ", observacion='" + observacion + '\'' +
                '}';
    }
}
