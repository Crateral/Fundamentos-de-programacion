package com.co.nttdata.colegio.entidades;

import java.util.List;

public class DatosProfesor {

    private int idProf;
    private String nombre;
    private String telefono;
    private List<Estudiante> estudiantes;

    public DatosProfesor(int idProf, String nombre, String telefono, List<Estudiante> estudiantes) {
        this.idProf = idProf;
        this.nombre = nombre;
        this.telefono = telefono;
        this.estudiantes = estudiantes;

    }

    public DatosProfesor() {
    }

    public int getIdProf() {
        return idProf;
    }

    public void setIdProf(int idProf) {
        this.idProf = idProf;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public List<Estudiante> getEstudiantes() {
        return estudiantes;
    }

    public void setEstudiantes(List<Estudiante> estudiantes) {
        this.estudiantes = estudiantes;
    }


    @Override
    public String toString() {
        return "DatosProfesor{" +
                "idProf=" + idProf +
                ", nombre='" + nombre + '\'' +
                ", telefono='" + telefono + '\'' +
                ", estudiantes=" + estudiantes +
                '}';
    }
}
