package com.co.nttdata.colegio.entidades;

import java.util.List;

public class Estudiante {

    private int idEstudiante;
    private String nombre;
    private List<Notas> listaNotas;
    private Curso curso;
    private double promedio;

    public Estudiante() {
    }

    public int getIdEstudiante() {
        return idEstudiante;
    }

    public void setIdEstudiante(int idEstudiante) {
        this.idEstudiante = idEstudiante;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }


    public Curso getCurso() {
        return curso;
    }

    public void setCurso(Curso curso) {
        this.curso = curso;
    }


    public List<Notas> getListaNotas() {
        return listaNotas;
    }

    public void setListaNotas(List<Notas> listaNotas) {
        this.listaNotas = listaNotas;
    }

    public double getPromedio() {
        return promedio;
    }

    public void setPromedio(double promedio) {
        this.promedio = promedio;
    }

    @Override
    public String toString() {
        return "id Estudiante: " + idEstudiante + " nombre: " + nombre + " curso: " + curso + "\n" + listaNotas + "\n"
                + " Promedio: " + promedio + "\n";
    }
}
