import com.co.nttdata.colegio.entidades.DatosProfesor;
import com.co.nttdata.colegio.entidades.Estudiante;
import com.co.nttdata.colegio.entidades.ReporteEstudiante;
import com.co.nttdata.colegio.interfaces.GestionEstudiantes;
import com.co.nttdata.colegio.logica.GestionEstudiantesImp;
import com.co.nttdata.colegio.utilitarios.CargarNotasEstudiantes;
import com.co.nttdata.colegio.utilitarios.EnviarNotas;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        GestionEstudiantes nuest = new GestionEstudiantesImp();
        CargarNotasEstudiantes cne = new CargarNotasEstudiantes();
        ReporteEstudiante re = new ReporteEstudiante();
        List<String> datosEstudiante = new ArrayList<>();
        List<Estudiante> listaestudiantes = new ArrayList<>();
        EnviarNotas ene = new EnviarNotas();
        DatosProfesor prof = new DatosProfesor(2345, "Ana Franco", "312443", listaestudiantes);
        String nombre, nombreArchivo, notasest;
        int op;
        Scanner x = new Scanner(System.in);

        do {
            System.out.println("---------------------------------");
            System.out.println("Notas Colegio");
            System.out.println("---------------------------------");
            System.out.println("Elije el curso que deseas revisar");
            System.out.println("1. Matematicas");
            System.out.println("2. Programacion");
            System.out.println("3. Quimica");
            System.out.println("---------------------------------");
            op = x.nextInt();
            switch (op) {
                case 1:
                    nombreArchivo = "matematicas.txt";
                    datosEstudiante = cne.leerArchivo(nombreArchivo);
                    System.out.println("Cargando registros de estudiantes...");

                    listaestudiantes = nuest.agregarEstudiantes(datosEstudiante);
                    System.out.println("Registros cargados exitosamente ✔");
                    System.out.println();
                    do {
                        System.out.println("---------------------------------");
                        System.out.println("¿Que necesitas?");
                        System.out.println("1. modificar la nota de algun estudiante  ");
                        System.out.println("2. Calcular promedio ");
                        System.out.println("---------------------------------");
                        op = x.nextInt();
                        switch (op) {
                            case 1:
                                System.out.println("Ingrese el nombre del estudiante");
                                nombre = x.next();
                                System.out.println("modificar nota");
                                nuest.cambiarNota(listaestudiantes, nombre);
                                break;
                            case 2:
                                nuest.calcularPromedio(listaestudiantes);
                                break;

                        }
                    } while (op < 2);


                    notasest = "reporteMatematicas.txt";
                    ene.enviarNotas(notasest, listaestudiantes, prof);


                    break;
                case 2:

                    nombreArchivo = "programacion.txt";
                    datosEstudiante = cne.leerArchivo(nombreArchivo);
                    System.out.println("Cargando registros de estudiantes.");

                    listaestudiantes = nuest.agregarEstudiantes(datosEstudiante);
                    System.out.println("Registros cargados exitosamente ✔");
                    System.out.println();
                    do {
                        System.out.println("---------------------------------");
                        System.out.println("¿Que necesitas?");
                        System.out.println("1. modificar la nota de algun estudiante  ");
                        System.out.println("2. Calcular promedio ");
                        System.out.println("---------------------------------");
                        op = x.nextInt();
                        switch (op) {
                            case 1:
                                System.out.println("Ingrese el nombre del estudiante");
                                nombre = x.next();
                                System.out.println("modificar nota");
                                nuest.cambiarNota(listaestudiantes, nombre);
                                break;
                            case 2:
                                nuest.calcularPromedio(listaestudiantes);
                                break;

                        }
                    } while (op < 2);


                    notasest = "reporteProgramacion.txt";
                    ene.enviarNotas(notasest, listaestudiantes, prof);


                    break;
                case 3:

                    nombreArchivo = "quimica.txt";
                    datosEstudiante = cne.leerArchivo(nombreArchivo);
                    System.out.println("Cargando registros de estudiantes.");

                    listaestudiantes = nuest.agregarEstudiantes(datosEstudiante);
                    System.out.println("Registros cargados exitosamente ✔");
                    System.out.println();
                    do {
                        System.out.println("---------------------------------");
                        System.out.println("¿Que necesitas?");
                        System.out.println("1. modificar la nota de algun estudiante  ");
                        System.out.println("2. Calcular promedio ");
                        System.out.println("---------------------------------");
                        op = x.nextInt();
                        switch (op) {
                            case 1:
                                System.out.println("Ingrese el nombre del estudiante");
                                nombre = x.next();
                                System.out.println("modificar nota");
                                nuest.cambiarNota(listaestudiantes, nombre);
                                break;
                            case 2:
                                nuest.calcularPromedio(listaestudiantes);
                                break;

                        }
                    } while (op < 2);


                    notasest = "reporteQuimica.txt";
                    ene.enviarNotas(notasest, listaestudiantes, prof);


                    break;


            }
        } while (op < 3);
    }
}