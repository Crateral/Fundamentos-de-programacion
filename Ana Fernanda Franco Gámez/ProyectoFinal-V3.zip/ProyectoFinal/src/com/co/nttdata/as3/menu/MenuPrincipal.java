package com.co.nttdata.as3.menu;

import com.co.nttdata.as3.loguin.GestionUsuarios;

import java.util.Scanner;

public class MenuPrincipal {

    public void MenuPrinci() {
        Scanner x = new Scanner(System.in);
try {

    GestionUsuarios nuRegis = new GestionUsuarios();

    String nombre, correo, contrasenia;
    int opcion;

    while (true) {
        System.out.println("-----------------------------");
        System.out.println("|   Registro de Usuario     |");
        System.out.println("_____________________________");
        System.out.println("| 1. Crear Usuario            |");
        System.out.println("| 2. Consultar Usuario        |");
        System.out.println("| 3. Iniciar Sesión           |");
        System.out.println("| 4. Gestionar Productos      |");
        //System.out.println("| 5. Agregar productos al 🛒  |");
        System.out.println("| 5. Cambiar Contraseña       |");
        System.out.println("| 6. Recuperar contraseña     |");
        System.out.println("| 7. Salir                    |");

        System.out.print("Digite la opcion que deseas realizar: ");
        opcion = x.nextInt();

        switch (opcion) {
            case 1:

                System.out.println(" - Digite datos del usurario - ");
                System.out.print(" Nombre: ");
                nombre = x.next();
                System.out.print(" Correo: ");
                correo = x.next();
                System.out.print(" Contraseña: ");
                contrasenia = x.next();
                nuRegis.AgregarUsuario(nombre, correo, contrasenia);

                break;

            case 2:
                nuRegis.ConsultarUsuarios();

                break;
            case 3:

                System.out.println(" - Digite sus credenciales -");
                System.out.print("Usuario: ");
                correo = x.next();
                System.out.print("Contraseña: ");
                contrasenia = x.next();
                nuRegis.InicioSeccion(correo, contrasenia);

                break;

            case 4:

                MenuCompra gestPro = new MenuCompra();
                gestPro.GesCompra();

            case 5:

                System.out.print("Digite su correo: ");
                correo = x.next();
                System.out.print("ingresa tu nueva contraseña: ");
                contrasenia = x.next();
                System.out.println("Estas seguro que deseas cambiar contraseña: si [1], no [2]");
                int cambContra = x.nextInt();

                nuRegis.CambiarContrasenia(correo, contrasenia, cambContra);

                break;
            case 6:

                System.out.println("Olvidaste tu contraseña: si[1] no[2] ");
                int resContra = x.nextInt();
                if (resContra == 1) {

                    System.out.print("Digite su correo: ");
                    correo = x.next();
                    System.out.print("ingresa tu nueva contraseña: ");
                    contrasenia = x.next();

                    nuRegis.RecuperarContrasenia(correo, contrasenia);

                } else {
                    System.out.println("Elige otra opcion del menu.");
                }

                break;
            case 7:

                nuRegis.FinalizarSeccion();

                break;
            default:
                System.out.println(" Opcion no valida ");


        }

    }
}
catch (Exception d ){
    System.out.println("Debe ingresar un valor numerico");


}
    }
}
