package com.co.nttdata.as3.menu;

import com.co.nttdata.as3.productos.Categorias;
import com.co.nttdata.as3.productos.GestionProductos;
import com.co.nttdata.as3.productos.Producto;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MenuCompra {

    public void GesCompra() {

        List<Producto> registroProducto = new ArrayList<>();

        GestionProductos nuProd = new GestionProductos();


        Scanner x = new Scanner(System.in);
        String nomPro;
        int  precioPro , idProd = 0, opComp , unid , totalComp , nomCateg ;


        while (true) {
            System.out.println("------------------------------------------------");
            System.out.println("|            🛒 Carrito de compras 🛒         |");
            System.out.println("------------------------------------------------");
            System.out.println("|              1. agregar producto             |");
            System.out.println("|             2. Consultar producto            |");
            System.out.println("|           3. Consultar por categoria         |");
            System.out.println("| 4. ordenar productos de mayor a menor precio |");
            System.out.println("| 5. ordenar productos de menor a mayor precio |");
            System.out.println("|              6. Ordenar por nombre           |");
            System.out.println("|            7. Ordenar por categoria          |");
            System.out.println("|           8. Generar factura de compra       |");
            System.out.println("|          9. Volver al menu anterior          |");
            System.out.println("|           10. Eliminar producto              |");
            System.out.println("------------------------------------------------");
            System.out.println("      Digita la opcion que deseas realizar");
            opComp = x.nextInt();

            switch (opComp) {
                case 1:
                    Integer idP=0;
                    do {
                        System.out.print("Id producto: ");
                        String id= x.next();
                        try {
                           idP= Integer.parseInt(id);
                           idProd=idP;
                           break;
                        }catch (Exception e){
                            System.out.println(" Debe ser un numero entero ");

                        }
                    }while (idP instanceof Integer);


                    System.out.print("Nombre: ");
                    x.nextLine();
                    nomPro = x.nextLine();
                    System.out.print("Precio: ");
                    precioPro = x.nextInt();
                    System.out.print("Unidades: ");
                    unid = x.nextInt();
                    System.out.print("Categoria: ");
                    System.out.println("Disponibles: 1- " + Categorias.LACTEOS + " 2- " + Categorias.FRUTAS + " 3- " + Categorias.ASEO
                            + " 4- " + Categorias.GRANOS + " 5- " + Categorias.PAPELERIA+ " 6- " +Categorias.TECNOLOGIA+ " 7- " +Categorias.BEBIDAS+ " 8- " +Categorias.DULCES);
                    nomCateg = x.nextInt();
                    totalComp = precioPro * unid;
                    System.out.println("Total Compra: " + totalComp);
                    nuProd.AgregarProducto(idProd, nomPro, precioPro, nomCateg, unid, totalComp);

                    break;

                case 2:

                    nuProd.ConsultarProductos();
                    break;

                case 3:
                    for (Producto conCat : registroProducto) {
                            System.out.println("Categorias Disponibles:  " + conCat.getCategoria()+" -> " + conCat.getNombrecaT() );
                        }
                    System.out.println("Escribe el id de la categoria a consultar");
                    int buCat = x.nextInt();
                    nuProd.ConsultarPorCategoria(buCat);

                    break;

                case 4:

                    nuProd.OrdenMayoMeno();

                    break;

                case 5:

                    nuProd.OrdMenorMayor();

                    break;

                case 6:

                    nuProd.OrdenarNombre();

                    break;

                case 7:

                    nuProd.OrdenarCategoria();

                    break;

                case 8:

                    nuProd.GenerarFactura();

                    break;

                case 9:
                    System.out.println(" Gracias por tu compra 🛍, hasta pronto 👋");
                    MenuPrincipal salir = new MenuPrincipal();
                    salir.MenuPrinci();

                case 10:

                    System.out.println("Escribe el nombre del producto que deseas eliminar");
                    String prodEli;
                            prodEli = x.next();
                    nuProd.EliminarProducto(prodEli);

                    break;
                default:
                    System.out.println("ingresa una opcion valida");


            }


        }
    }

}
