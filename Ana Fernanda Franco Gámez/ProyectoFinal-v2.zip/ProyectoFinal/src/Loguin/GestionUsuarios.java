package Loguin;

import java.util.ArrayList;
import java.util.List;

public class GestionUsuarios extends Registro{
    List<Registro> registroUsuarios= new ArrayList<>();
    public void AgregarUsuario(String nombre, String correo, String contrasenia){

        Registro nuReg= new Registro();
        nuReg.setNombre(nombre);
        nuReg.setCorreo(correo);
        nuReg.setContrasenia(contrasenia);
        registroUsuarios.add(nuReg);
        System.out.println("Usuario Registrado con exito 🥳");
    }


    public void ConsultarUsuarios(){
        if (registroUsuarios.size()!=0) {
            for (Registro regPers : registroUsuarios) {
                System.out.println(regPers.toString());
            }
        } else {
            System.out.println("No tienes usuarios Registrados Ingresa otra Opcion ");
        }
    }

    public void InicioSeccion(String correo, String contrasenia ){
        if (registroUsuarios.size()!=0) {

            for (Registro regPers : registroUsuarios) {
                if (regPers.getCorreo().equals(correo) && regPers.getContrasenia().equals(contrasenia)) {
                    System.out.println("Haz Iniciado Sesión 👋");
                } else {
                    System.out.println("Credenciales incorrectas ❌");
                }
            }
        }else {
            System.out.println("No tienes usuarios Registrados Ingresa otra Opcion ");
        }
    }

    public void CambiarContraseña(String correo, String contrasenia, int cambContra){

        if (registroUsuarios.size()!=0) {

            for (Registro caCont : registroUsuarios) {
                if (caCont.getCorreo().equals(correo)) {
                    int indice = registroUsuarios.indexOf(caCont.getCorreo());

                    if (indice != 0) {

                        if (cambContra == 1) {
                            caCont.setContrasenia(contrasenia);
                            System.out.println("Contraseña cambiada con exito 🥳");
                        }else {
                            System.out.println("cambio de contraseña cancelado ❌");
                        }

                    }
                }

            }
        }else {
            System.out.println("No tienes unuarios Registrados Ingresa otra Opcion ");
        }

    }

    public void RecuperarContraseña(String correo, String contrasenia, int resContra){
        if (registroUsuarios.size()!=0) {

                for (Registro caCont : registroUsuarios) {
                    if (caCont.getCorreo().equals(correo)) {
                        int indice = registroUsuarios.indexOf(caCont.getCorreo());

                        if (indice != 0) {

                            caCont.setContrasenia(contrasenia);
                            System.out.println("Contraseña cambiada con exito 🥳");
                        }

                    }
                }

        }else {
            System.out.println("No tienes unuarios Registrados Ingresa otra Opcion ");
        }


    }

    public void FinalizarSeccion(){
        System.out.println(" Seccion finalizada, hasta pronto");
        System.exit(0);
    }
}
