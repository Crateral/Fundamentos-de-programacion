package Productos;

import java.io.Serializable;

public class Producto extends Categoria implements Serializable {

    private int idProducto;
    private String nombProd;
    private int precioProd;

    private int unid;

    private int totalComp;

    public int getUnid() {
        return unid ;
    }

    public void setUnid(int unid ) {
        this.unid  = unid ;
    }

    public int getTotalComp () {
        return totalComp ;
    }

    public void setTotalComp (int totalComp) {
        this.totalComp = totalComp;
    }

    private String categoria;

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public Producto(){

    }
    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public String getNombProd() {
        return nombProd;
    }

    public void setNombProd(String nombProd) {
        this.nombProd = nombProd;
    }

    public int getPrecioProd() {
        return precioProd;
    }

    public void setPrecioProd(int precioProd) {
        this.precioProd = precioProd;
    }

    @Override
    public String toString() {
        return "Producto -> Id producto: " +  idProducto + " Nombre Producto: " + nombProd +" Categoria: "+ categoria+
                " Precio Unitario: " + precioProd +  " Unidades: "+unid + " Total: "+ totalComp;
    }
}
