package Productos;

import Loguin.Registro;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class GestionProductos extends Producto{

    List<Producto> registroProducto= new ArrayList<>();
    List<Categoria> registroCategoria= new ArrayList<>();

    List <Producto> compras = new ArrayList<>();

    public void AgregarProducto(int idProducto, String nomProd, int precioProd, String nomCateg, int unid, int totalComp){

        Producto nuPrp =new Producto();
        nuPrp.setIdProducto(idProducto);
        nuPrp.setNombProd(nomProd);
        nuPrp.setPrecioProd(precioProd);
        nuPrp.setCategoria(nomCateg);
        nuPrp.setUnid(unid);
        nuPrp.setTotalComp(totalComp);
        registroProducto.add(nuPrp);

    }

    public void AgregarCategoria(String nomCateg){
        Categoria nuCat= new Categoria();
        nuCat.setNomCateg(nomCateg);
        registroCategoria.add(nuCat);
    }


    public void ConsultarProductos(){

        if (registroProducto.size() != 0) {
            for (Producto regPro : registroProducto) {
                System.out.println(regPro.toString());
            }
        } else {
            System.out.println(" No tienes productos en el carrito");
        }
    }


    public void ConsultarPorCategoria(String buCat ){
        if (registroProducto.size() != 0) {


            int con = 0;
            for (Producto conCat : registroProducto) {
                System.out.println("categorias Disponibles: " + conCat.getCategoria());
            }

            for (Producto conCat : registroProducto) {
                if (conCat.getCategoria().equals(buCat)) {
                    System.out.println("Nombre del producto: " + conCat.getNombProd() + " Precio del producto: " + conCat.getPrecioProd() + "  Categoria: " + conCat.getCategoria());
                }
                con = con + 1;
            }
        } else {
            System.out.println(" No tienes productos en el carrito");
        }
    }

    public void OrdenMayoMeno(){

        if (registroProducto.size() != 0) {
            System.out.println("Ordenando productos de mayor a menor precio...");
            registroProducto.sort(Comparator.comparing(Producto::getPrecioProd).reversed());
            for (Producto carrCom : registroProducto) {
                System.out.println(carrCom.toString());
            }
        }
        else {
            System.out.println(" No tienes productos en el carrito");
        }
    }

    public void OrdMenorMayor(){
        if (registroProducto.size()!=0) {
            System.out.println("Ordenando productos de menor a mayor precio...");
            registroProducto.sort(Comparator.comparing(Producto::getPrecioProd));
            for (Producto carrCom : registroProducto) {
                System.out.println(carrCom.toString());
            }
        } else {
            System.out.println(" No tienes productos en el carrito");
        }
    }

    public void OrdenarNombre(){
        if (registroProducto.size()!=0) {
            System.out.println("Ordenando productos por nombre...");
            Collections.sort(registroProducto, Comparator.comparing(Producto::getPrecioProd));
            for (Producto carrCom : registroProducto) {

                System.out.println(carrCom.toString());
            }
        } else {
            System.out.println(" No tienes productos en el carrito");
        }
    }

    public void OrdenarCategoria(){
        if (registroProducto.size()!=0) {
            System.out.println("Ordenando productos por categoria...");
            Collections.sort(registroProducto, Comparator.comparing(Producto::getCategoria));
            for (Producto carrCom : registroProducto) {
                System.out.println(carrCom.toString());
            }
        } else {
            System.out.println(" No tienes productos en el carrito");
        }
    }

    public void ConsultarCategoria(){

        for (Categoria conCategoria : registroCategoria){
            System.out.println(conCategoria.toString());
        }

    }



    public void Salir(){
        System.out.println(" Haz agregado productos con exito");
        System.exit(0);
    }



    public void RealizarCompra(String nomPro, int uni){
        Producto nComp = new Producto();

        for (Producto conProductos : registroProducto){

            System.out.println("Productos disponibles: "+ conProductos.getNombProd());
        }
        System.out.println("Escribe el producto que quieres agregar al carrito");

        for (Producto conProductos : registroProducto){

            if (conProductos.getNombProd().equals(nomPro)){
                nComp.setNombProd(nomPro);
                nComp.getIdProducto();
                int total= nComp.getPrecioProd()*uni;
                nComp.setPrecioProd(total);
                compras.add(nComp);
            }
        }


    }

    public void ConsultaCompra(){
        for (Producto comPro : compras){

            System.out.println("Detalle de la compra: "+ comPro.getNombProd()+ "Id Producto: "+comPro.getIdProducto()+ " Precio: "+comPro.getPrecioProd());
        }

    }

}
