package Productos;

public enum Categorias {


}
