package Productos;

import java.io.Serializable;

public class Categoria implements Serializable {

    private String nomCateg;

    public Categoria(){

    }
    public String getNomCateg() {
        return nomCateg;
    }

    public void setNomCateg(String nomCateg) {
        this.nomCateg = nomCateg;
    }

    @Override
    public String toString() {
        return "Categoria: " + nomCateg;
    }
}
