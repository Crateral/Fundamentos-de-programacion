import Loguin.GestionUsuarios;
import Loguin.Registro;
import Productos.GestionProductos;
import Productos.Producto;

import java.sql.SQLOutput;
import java.util.*;

public class Main {
    public static void main(String[] args) {

        List<Registro> registroUsuarios= new ArrayList<>();
        List<Producto> registroProducto= new ArrayList<>();

        GestionUsuarios nuRegis= new GestionUsuarios();
        GestionProductos nuProd= new GestionProductos();


        Scanner x = new Scanner(System.in);
        String nombre, correo, contrasenia, nomPro, nomCateg;
        int opcion=0, precioPro, idProd, opComp, unid, totalComp;

        while (true){
            System.out.println("-----------------------------");
            System.out.println("|   Registro de Usuario     |");
            System.out.println("_____________________________");
            System.out.println("| 1. Crear Usuario            |");
            System.out.println("| 2. Consultar Usuario        |");
            System.out.println("| 3. Iniciar Seccion          |");
            System.out.println("| 4. Gestionar Productos      |");
            //System.out.println("| 5. Agregar productos al 🛒  |");
            System.out.println("| 5. Cambiar Contraseña       |");
            System.out.println("| 6. Recuperar contraseña     |");
            System.out.println("| 7. Salir                    |");

            System.out.print("Digite la opcion que deseas realizar: ");
            opcion= x.nextInt();


            switch (opcion){
                case 1:

                    System.out.println(" - Digite datos del usurario - ");
                    System.out.print(" Nombre: ");
                    nombre= x.next();
                    System.out.print(" Correo: ");
                    correo= x.next();
                    System.out.print(" Contraseña: ");
                    contrasenia = x.next();
                    nuRegis.AgregarUsuario(nombre, correo,contrasenia);

                    break;

                case 2:
                    nuRegis.ConsultarUsuarios();

                    break;
                case 3:

                        System.out.println(" - Digite sus credenciales -");
                        System.out.print("Usuario: ");
                        correo = x.next();
                        System.out.print("Contraseña: ");
                        contrasenia = x.next();
                        nuRegis.InicioSeccion(correo,contrasenia);

                    break;

                case 4:

                    while (true){
                        System.out.println("------------------------------------------------");
                        System.out.println("|            🛒 Carrito de compras 🛒         |");
                        System.out.println("------------------------------------------------");
                        System.out.println("|              1. agregar producto             |");
                        System.out.println("|             2. Consultar producto            |");
                        System.out.println("|           3. Consultar por categoria         |");
                        System.out.println("| 4. ordenar productos de mayor a menor precio |");
                        System.out.println("| 5. ordenar productos de menor a mayor precio |");
                        System.out.println("|              6. Ordenar por nombre           |");
                        System.out.println("|            7. Ordenar por categoria          |");
                        System.out.println("|          8. Volver al menu anterior          |");
                        System.out.println("------------------------------------------------");
                        System.out.println("      Digita la opcion que deseas realizar");

                        opComp = x.nextInt();

                        switch (opComp) {
                            case 1:
                                System.out.print("Id producto: ");
                                idProd=x.nextInt();
                                System.out.print("Nombre: ");
                                nomPro=x.next();
                                System.out.print("Precio: ");
                                precioPro=x.nextInt();
                                System.out.print("Categoria: ");
                                nomCateg= x.next();
                                System.out.print("Unidades: ");
                                unid= x.nextInt();
                                totalComp= precioPro*unid;
                                System.out.println("Total Compra: "+totalComp);
                                nuProd.AgregarProducto(idProd, nomPro, precioPro, nomCateg, unid,totalComp);

                                break;

                            case 2:

                              nuProd.ConsultarProductos();
                                break;

                            case 3:
                                for (Producto conCat : registroProducto) {
                                    System.out.println("categorias Disponibles: " + conCat.getCategoria());
                                }
                                System.out.println("Escribe la categoria que deseeas consultar");
                                String buCat = x.next();
                                nuProd.ConsultarPorCategoria(buCat);

                                break;

                            case 4:

                                nuProd.OrdenMayoMeno();

                                break;

                            case 5:

                                nuProd.OrdMenorMayor();

                                break;

                            case 6:

                                nuProd.OrdenarNombre();

                                break;

                            case 7:

                              nuProd.OrdenarCategoria();

                                break;

                            case 8:
                                System.out.println(" Gracias por tu compra 🛍, hasta pronto 👋");


                            default:
                                System.out.println("ingresa una opcion valida");


                        }



                    }



                case 5:

                    System.out.print("Digite su correo: ");
                    correo = x.next();
                    System.out.print("ingresa tu nueva contraseña: ");
                    contrasenia = x.next();
                    System.out.println("Estas seguro que deseas cambiar contraseña: si [1], no [2]");
                    int cambContra = x.nextInt();

                    nuRegis.CambiarContraseña(correo,contrasenia,cambContra);

                    break;
                case 6:

                        System.out.println("Olvidaste tu contraseña: si[1] no[2] ");
                        int resContra = x.nextInt();
                        if (resContra == 1) {

                        System.out.print("Digite su correo: ");
                        correo = x.next();
                        System.out.print("ingresa tu nueva contraseña: ");
                        contrasenia = x.next();

                        nuRegis.RecuperarContraseña(correo,contrasenia,resContra);

                        } else {
                        System.out.println("Elige otra opcion del menu.");
                        }

                    break;
                case 7:

                   nuRegis.FinalizarSeccion();

                    break;
                default:
                    System.out.println(" Opcion no valida ");

            }

        }

    }
}