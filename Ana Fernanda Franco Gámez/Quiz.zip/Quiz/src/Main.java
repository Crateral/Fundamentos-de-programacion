import java.sql.SQLOutput;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        while(true) {
            System.out.println("Que planta quieres revisar: ");
            System.out.printf("1. Hierbas");
            System.out.printf("2. Matas");
            System.out.println("3. Arboles");
            System.out.println("4. Arbustos");
            System.out.println(" Digite el numero de la planta que quieres revisar");
            Scanner x= new Scanner(System.in);
            int opcion= x.nextInt();

            switch (opcion) {

                case 1:
                    System.out.println("ENCONTRARAS INFORMACION DE LAS HIERBAS");
                    Hierbas nHierba = new Hierbas();
                    nHierba.setTieneFlores("no");
                    nHierba.crearFlor();
                    nHierba.setDaFruto(false);
                    nHierba.crearFruto();
                    nHierba.setAlturaPlanta(18);
                    nHierba.calcularAltura();
                    nHierba.setTiempoVida(3);
                    nHierba.morir();
                    break;

                case 2:
                    System.out.println("ENCONTRARAS INFORMACION SOBRE LAS MATAS");
                    Matas nMata = new Matas();
                    nMata.setTieneFlores("si");
                    nMata.crearFlor();
                    nMata.setAlturaPlanta(23);
                    nMata.calcularAltura();
                    nMata.setDaFruto(true);
                    nMata.crearFruto();
                    nMata.setTiempoVida(34);
                    nMata.morir();

                    break;

                case 3:
                    System.out.printf(" ENCONTRARAS INFORMACION SOBRE LOS ARBOLES");
                    Arboles nArbol = new Arboles();
                    nArbol.setAlturaPlanta(250);
                    nArbol.calcularAltura();
                    nArbol.setDaFruto(true);
                    nArbol.crearFruto();
                    nArbol.setTieneFlores("no");
                    nArbol.crearFlor();
                    nArbol.setTiempoVida(300);
                    nArbol.morir();

                    break;

                case 4:
                    System.out.printf(" ENCONTRARAS INFORMACION SOBRE LOS ARBUSTOS");
                    Arbustos nArbusto = new Arbustos();
                    nArbusto.setAlturaPlanta(20);
                    nArbusto.calcularAltura();
                    nArbusto.setTieneFlores("si");
                    nArbusto.crearFlor();
                    nArbusto.setDaFruto(false);
                    nArbusto.crearFruto();
                    nArbusto.setTiempoVida(4);
                    nArbusto.morir();

                    break;

                default:
                    System.out.println("opcion no valida");
            }
        }

    }
}