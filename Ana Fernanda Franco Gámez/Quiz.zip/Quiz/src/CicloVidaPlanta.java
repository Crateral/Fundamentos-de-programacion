public interface CicloVidaPlanta {
    public void calcularAltura();
    public void crearFlor();
    public void crearFruto();
    public void morir();

}
