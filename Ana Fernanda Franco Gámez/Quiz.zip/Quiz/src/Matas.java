public class Matas extends Planta implements CicloVidaPlanta{

    public void calcularAltura() {
        System.out.println("La altura promedio de las Matas es de 30 a 65 cm");
        if (getAlturaPlanta()<30 || getAlturaPlanta()<65){
            System.out.println("- Aun puede crecer, la mata tiene " + getAlturaPlanta()+ " cm");
        } else if (getAlturaPlanta()==65) {
            System.out.printf("- La Mata tiene la altura promedio de las plantas de su especie "+ getAlturaPlanta()+ " cm");

        }else {
            System.out.println("- La Mata ha crecido mas que el promedio de su especie posee "+getAlturaPlanta()+ " cm");
        }

    }


    public void crearFlor() {
        System.out.printf("¿Tienen Flores las Matas? ");
        System.out.printf("El dato de prueba ingresado es: "+ getTieneFlores());

        if (getTieneFlores()=="si") {
            System.out.println("- Correcto algunas matas dan flores ");
        } else{
            System.out.printf("- Correcto, algunas matas no dan flores");
        }
    }


    public void crearFruto() {
        System.out.print("¿Las matas dan fruto? ");
        System.out.printf("El dato de prueba ingresado es: "+ getDaFruto());

        if (getDaFruto()==true) {
            System.out.println("- Correcto, Algunas matas dan fruto");
        } else{
            System.out.println("- Solo algunas matas dan frutos");
        }

    }


    public void morir() {
        System.out.println("El ciclo de vida promedio de una mata es de 5 a 10 años ");
        if (getTiempoVida()>=10){
            int murio=(getTiempoVida()-10);
            System.out.println(" Dato de prueba : "+getTiempoVida());
            System.out.println("- La Mata cumplio su ciclo de vida hace "+ murio+ " años");
        }else {
            System.out.println( "- La Mata aun esta vida tiene "+ getTiempoVida()+ " años");
        }

    }

}
