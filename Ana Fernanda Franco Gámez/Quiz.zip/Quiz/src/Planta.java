public class Planta {

    private int alturaPlanta;
    private Boolean daFruto;
    private String tieneFlores;

    private int tiempoVida;
    public Planta(){

    }

    public int getAlturaPlanta() {
        return alturaPlanta;
    }

    public void setAlturaPlanta(int alturaPlanta) {
        this.alturaPlanta = alturaPlanta;
    }

    public Boolean getDaFruto(){
        return daFruto;
    }

    public void setDaFruto(boolean daFruto) {
        this.daFruto = daFruto;
    }

    public String getTieneFlores(){
        return tieneFlores;
    }

    public void setTieneFlores(String tieneFlores) {
        this.tieneFlores = tieneFlores;
    }

    public int getTiempoVida(){
        return tiempoVida;
    }

    public void setTiempoVida(int tiempoVida) {
        this.tiempoVida = tiempoVida;
    }





}
