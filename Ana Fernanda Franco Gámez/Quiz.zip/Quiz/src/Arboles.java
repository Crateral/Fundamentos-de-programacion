public class Arboles extends Planta implements CicloVidaPlanta{

    public void calcularAltura() {
        System.out.println("La altura promedio de un arbol es de 300 cm");
        if (getAlturaPlanta()<300){
            System.out.println("- Aun puede crecer, el arbol tiene "+ getAlturaPlanta() + " cm ");
        } else if (getAlturaPlanta()==300) {
            System.out.printf("- El arbol tiene la altura promedio de las plantas de su especie "+ getAlturaPlanta()+ " cm");

        }else {
            System.out.println("- El arbol ha crecido mas que el promedio de su especie posee "+getAlturaPlanta()+ " cm");
        }

    }


    public void crearFlor() {
        System.out.printf("¿Tienen Flores los arboles? ");
        System.out.printf("El dato de prueba ingresado es: "+ getTieneFlores());

        if (getTieneFlores()=="si") {
            System.out.println("- Correcto, Algunos arboles dan flores ");
        } else{
            System.out.printf("-  Correcto, Algunos arboles no dan flores ");
        }
    }


    public void crearFruto() {
        System.out.print("¿Los arboles dan fruto? ");
        System.out.printf("El dato de prueba ingresado es: "+ getDaFruto());

        if (getDaFruto()==true) {
            System.out.println("- Correcto, Algunos arboles dan fruto ");
        } else{
            System.out.println("- Correcto, Algunos arboles no dan frutos");
        }

    }


    public void morir() {
        System.out.println("El ciclo de vida promedio de un arbol es de 1000 años ");
        if (getTiempoVida()>=1000){
            int murio=(getTiempoVida()-1000);
            System.out.println(" Dato de prueba : "+getTiempoVida());
            System.out.println("- El arbol cumplio su ciclo de vida hace "+ murio+ " años");

        }else {
            System.out.println( "- El arbol aun esta vidvo tiene "+ getTiempoVida()+ " años");
        }

    }

}
