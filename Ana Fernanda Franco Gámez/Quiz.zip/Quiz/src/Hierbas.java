public class Hierbas extends Planta implements CicloVidaPlanta{


    public void calcularAltura() {
        System.out.println("La altura promedio de la hierba es de 6 cm");
        if (getAlturaPlanta()<6){
            System.out.println("- Aun puede crecer, la hierba tiene "+ getAlturaPlanta() + "cm");
        } else if (getAlturaPlanta()==6) {
            System.out.printf("- La hierba tiene la altura promedio de las plantas de su especie "+ getAlturaPlanta()+ " cm");

        }else {
            System.out.println("- La hierba ha crecido mas que el promedio de su especie posee "+getAlturaPlanta()+ " cm");
        }

    }


    public void crearFlor() {
        System.out.printf("¿Tienen Flores las hierbas? ");
        System.out.printf("El dato de prueba ingresado es: "+ getTieneFlores());

        if (getTieneFlores()=="si") {
            System.out.println("- Correcto, algunas hierbas dan flores ");
        } else{
            System.out.printf("- Correcto, Algunas hierbas no dan flores");
        }
    }

    public void crearFruto() {
        System.out.print("¿Las hierbas dan fruto? ");
        System.out.printf("El dato de prueba ingresado es: "+ getDaFruto());

        if (getDaFruto()==false) {
            System.out.println("- Correcto, las hierbas NO dan fruto ");
        } else{
            System.out.println("- Error, Las hierbas no dan frutos");
        }

    }


    public void morir() {
        System.out.println("El ciclo de vida promedio de la hierba es 2 años ");
        if (getTiempoVida()>=2){
            int murio=(getTiempoVida()-2);
            System.out.println(" Dato de prueba : "+getTiempoVida());
            System.out.println("- La Hierba cumplio su ciclo de vida hace "+ murio+ " años");
        }else {
            System.out.println( "- La hierba aun esta vida tiene "+ getTiempoVida()+ " años");
        }

    }

}
