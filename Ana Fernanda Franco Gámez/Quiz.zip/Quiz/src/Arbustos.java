public class Arbustos extends Planta{


    public void calcularAltura() {
        System.out.println("La altura promedio de un arbusto es de 50 cm");
        if (getAlturaPlanta()<50){
            System.out.println("- Aun puede crecer, el arbusto tiene  "+ getAlturaPlanta()+ " cm");
        } else if (getAlturaPlanta()==50) {
            System.out.printf("- El arbusto tiene la altura promedio de las plantas de su especie "+ getAlturaPlanta()+ " cm");

        }else {
            System.out.println("- El arbusto ha crecido mas que el promedio de su especie posee "+getAlturaPlanta()+ " cm");
        }

    }


    public void crearFlor() {
        System.out.printf("¿Tienen Flores los arbustos ? ");
        System.out.printf("El dato de prueba ingresado es: "+ getTieneFlores());

        if (getTieneFlores()=="si") {
            System.out.println("-Correcto, algunos arbustos dan flores ");
        } else{
            System.out.printf("- Correcto, algunos arbustos no dan flores");
        }
    }


    public void crearFruto() {
        System.out.print("¿Los arbustos dan fruto? ");
        System.out.printf("El dato de prueba ingresado es: "+ getDaFruto());

        if (getDaFruto()==true) {
            System.out.println("- Correcto, algunos arbustos dan frutos ");
        } else{
            System.out.println("- Correcto, algunos arbustos no dan frutos");
        }

    }


    public void morir() {
        System.out.println("El ciclo de vida promedio de un arbusto es de 5 a lo años ");
        if (getTiempoVida()>=10){
            int murio=(getTiempoVida()-10);
            System.out.println(" Dato de prueba : "+getTiempoVida());
            System.out.println("- El arbusto cumplio su ciclo de vida hace "+ murio+ " años");
        }else {
            System.out.println( "-El arbusto aun esta vivo tiene "+ getTiempoVida()+ " años");
        }

    }


}
