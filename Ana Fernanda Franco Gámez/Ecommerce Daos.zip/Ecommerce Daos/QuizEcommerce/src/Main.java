import com.co.nttdata.ecommerce.daos.MarcaDAO;
import com.co.nttdata.ecommerce.entidades.*;
import com.co.nttdata.ecommerce.interfaces.GestionCarritoDeCompra;
import com.co.nttdata.ecommerce.interfaces.GestionFactura;
import com.co.nttdata.ecommerce.interfaces.GestionUsuario;
import com.co.nttdata.ecommerce.logica.*;
import com.co.nttdata.ecommerce.menu.*;
import com.co.nttdata.ecommerce.utilitarios.ConexionBD;
import com.co.nttdata.ecommerce.utilitarios.GenerarFactura;
import com.co.nttdata.ecommerce.utilitarios.ProductosInventario;

import java.io.File;
import java.io.FileWriter;
import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {


        Scanner x = new Scanner(System.in);
        String usu, con;
        String produ;
        int uni;
        // GestionCarritoDeComprasImp gc = new GestionCarritoDeComprasImp();
        GestionCarritoDeCompra gc = new GestionCarritoDeComprasImp();
        CarritoDeCompras cc = new CarritoDeCompras();
        GestionUsuario guc = new GestionLoginUsuarioClienteImp();
        GestionUsuario gua = new GestionLoginUsuarioAdminImp();
        GestionFactura gf = new GestionFacturaImp();
        Factura f = new Factura();
        Cliente c1 = new Cliente();
        Usuario us1 = new Usuario();
        Usuario us2 = new Usuario();
        List<Producto> listaProductos = new ArrayList<>();
        List<String> pruebaArchivo = new ArrayList<>();
        ProductosInventario pi = new ProductosInventario();
        MarcaDAO marD = new MarcaDAO();
        //  List<Marca> marcas = marD.consultarMarca();


        // Se crean los productos
        Producto producto1 = new Producto();

   /*     Producto pro1 = new Producto(01, " Licuadora", 3, 150000, true,
                0.19, "Producto Licuadora", "img Licuadora", Marca.SAMSUNG, Categoria.ELECTRODOMESTICOS);

        Producto pro2 = new Producto(02, " Bolso    ", 20, 500000, true,
                0.19, "Producto Bolso", "img Bolso", Marca.VELEZ, Categoria.ACCESORIOS);

        Producto pro3 = new Producto(03, " Shampoo para Gatos", 2, 18000, false,
                0.19, "Producto Shampoo", "img Shampoo", Marca.CANAMOR, Categoria.MASCOTAS);

        Producto pro4 = new Producto(4, " Jeans    ", 40, 180000, true,
                0.19, "Producto Jeans", "img Jeans", Marca.STUDIOF, Categoria.ROPA);

        Producto pro5 = new Producto(5, " Edredon  ", 11, 200000, true,
                0.19, "Producto Edredon", "img Edredon", Marca.DISTRIHOGAR, Categoria.HOGAR);

        Producto pro6 = new Producto(6, " Celular  ", 3, 2700000, true,
                0.19, "Producto Celular", "img Celular", Marca.IPHONE, Categoria.TECNOLOGIA);

        Producto pro7 = new Producto(7, " Tenis", 14, 350000, false,
                0.19, "Producto Tenis", "img tenis", Marca.ADIDAS, Categoria.DEPORTES);

        Producto pro8 = new Producto(8, " Lavadora", 3, 800000, true,
                0.19, "Producto Lavadora", "img Lavadora", Marca.LG, Categoria.ELECTRODOMESTICOS);

        Producto pro9 = new Producto(9, " Licuadora", 3, 15000.00, true,
                0.19, "Producto Licuadora", "img Licuadora", Marca.DISNEY, Categoria.JUGUETERIA);

        Producto pro10 = new Producto(10, "Televisor", 3, 2300000, false,
                0.19, "Producto Televisor", "img Televisor", Marca.KIA, Categoria.ELECTRODOMESTICOS);
*/
        // Creacion de clientes

       /* Cliente nuevoCliente = new Cliente(11, "Ana Franco", "asd123", TipoDocumento.PASAPORTE,
                "cc", "ana@gmail.com", "23341", "Calle 26 # 2-5", "Bucaramanga",
                true, MetodoPago.PSE);*/

        //Creacion Administradores

       /* Administrador adminNuevo = new Administrador(221, TipoDocumento.CEDULA_DE_CIUDADANIA, "123456",
                "Maria", "maria@gmail.com", "hi987", true);*/

        // Creacion de empresa
        Empresa datosEmpresa = new Empresa(3232, "AF-FG✨", "img Empresa",
                "Calle 26 # 2-5", "23432");


        Marca azus = new Marca();

        int opcion;
        do {
            System.out.println("-------------------------------");
            System.out.println("1. Crear Usuario ");
            System.out.println("2. Consultar Usuarios");
            System.out.println("3. Iniciar sesión ");
            System.out.println("4. Agregar productos ");
            System.out.println("5. Agregar productos Al carrito");
            System.out.println("6. Calcular costo de envio ");
            System.out.println("7. Generar factura");
            System.out.println("8. Actualizar inventario");
            System.out.println("9. Conexion BD");
            System.out.println("10. Salir");
            System.out.println("-------------------------------");
            System.out.println("-  ingresa la opcion");
            System.out.println("-------------------------------");
            opcion = x.nextInt();
            switch (opcion) {
                case 1:

                    System.out.println("Que tipo de usuario deseas registrar: Cliente [1], Administrador [2]");
                    opcion = x.nextInt();
                    if (opcion == 1) {

                        /*c1 = (Cliente) guc.crearUsuario(11, "Fer Franco", "asd123", TipoDocumento.PASAPORTE,
                                "1065128", "ana@gmail.com", "23341", "Calle 26 # 2-5", "Bucaramanga",
                                true, PSE);*/
                        us1.setNombreUsuario(c1.getCorreo());
                        us1.setContrasenia(c1.getContrasenia());

                    } else {
                        System.out.println();
                      /*  Administrador ad1 = (Administrador) gua.crearUsuario(222, "maria", "hi987",
                                TipoDocumento.CEDULA_DE_CIUDADANIA, "122345", "maria@gmail.com",
                                "", "", "", true, MetodoPago.NO_APLICA);
                        us2.setNombreUsuario(ad1.getCorreo());
                        us2.setContrasenia(ad1.getContrasenia());*/
                        //gua.consultarUsuario();
                    }
                    break;

                case 2:
                    guc.consultarUsuario();
                    gua.consultarUsuario();
                    break;
                case 3:

                    System.out.println(" Eres administrador [1], Cliente[2]");
                    opcion = x.nextInt();
                    System.out.println("Ingrese sus credenciales");
                    System.out.print("👩| Correo Usuario: ");
                    usu = x.next();
                    System.out.print("🔑| Contraseña: ");
                    con = x.next();


                    if (opcion == 2) {

                        guc.loguinUsuario(us1, usu, con);
                    } else {
                        gua.loguinUsuario(us2, usu, con);
                    }


                    break;
                case 4:


                    String nombreArchivo = "ProductosDelInventario.txt";
                    pruebaArchivo = pi.leerArchivo(nombreArchivo);
                    for (int i = 0; i < pruebaArchivo.size(); i++) {
                        System.out.println(pruebaArchivo.get(i));
                    }
                    //cc.setProductos(pi.dividirDatosProducto(pruebaArchivo));


                    break;
                case 5:
                    //Se agregan 6 productos al carrito
                 /* listaProductos.add(pro1);
                    listaProductos.add(pro2);
                    listaProductos.add(pro4);
                    listaProductos.add(pro5);
                    listaProductos.add(pro6);
                    listaProductos.add(pro10);*/

                    // listaProductos= pi.dividirDatosProducto(pruebaArchivo);
                    // System.out.println("NOMBRE PRODUCTOS ##################");

                    //cc.setProductos(pi.dividirDatosProducto(pruebaArchivo));


                    //  gc.seleccionarProductos(pi.dividirDatosProducto(pruebaArchivo));

                    cc = gc.agregarAlCarrito(cc, gc.seleccionarProductos(pi.dividirDatosProducto(pruebaArchivo)));
                    System.out.println(" - Calculando iva de productos 🛍");

                    cc = gc.calcularTotalConIva(cc);
                 /*   HashMap<Integer, Producto > agc = new HashMap<>();
                    System.out.println( " que producto quieres agregar al carrito ");{
                        opcion= x.nextInt();*/


                    break;

                case 6:


                    if (pi.dividirDatosProducto(pruebaArchivo).size() != 0) {
                        //cc.setProductos(listaProductos);
                        //  cc.setProductos(pi.dividirDatosProducto(pruebaArchivo));
                        //   cc = gc.calcularCostoEnvio(cc, nuevoCliente);
                        cc.setValorEnvio(cc.getValorEnvio());

                    } else {
                        System.out.println("No se encontraron productos en el carrito");
                    }


                    break;
                case 7:

                    if (pi.dividirDatosProducto(pruebaArchivo).size() != 0) {
                        // cc.setProductos(pi.dividirDatosProducto(pruebaArchivo));
                        //cc.setProductos(listaProductos);
                       /* f= gf.pagar(c1,cc,datosEmpresa);
                        gf.imprimirFactura(c1);*/

                        GenerarFactura desfac = new GenerarFactura();
                        String factura = "FacturaCompra.txt";
                        desfac.escribirArchivo(factura, c1, datosEmpresa, cc);
                        desfac.leerArchivo(factura);

                    } else {
                        System.out.println("No se encontraron productos en el carrito");
                    }
                    break;
                case 8:

                    pruebaArchivo = gc.cantidadDisponible(pi.dividirDatosProducto(pruebaArchivo), cc);
                    String nombreArchivoAct = "ProductosDelInventario.txt";
                    pi.actualizarInventario(pruebaArchivo, nombreArchivoAct);
                    pruebaArchivo = pi.leerArchivo(nombreArchivoAct);

                    break;


                case 9:

                    ConexionBD cone = new ConexionBD();
                    cone.conectarBD();
                    //cone.desconectarBD(cone.conectarBD());

                    System.out.println(" Que entidad quieres revisar");
                    System.out.println("1. Marca");
                    System.out.println("2. Categoria ");
                    System.out.println("3. Empresa ");
                    System.out.println("4. Ciudad");
                    System.out.println("5. Tipo documento");
                    System.out.println("6. Metodo pago");
                    System.out.println("7. Producto");
                    System.out.println("8. Carrito de compras");
                    System.out.println("9. Factura");
                    System.out.println("10. Cliente");
                    System.out.println("11. Administrador");
                    opcion = x.nextInt();
                    switch (opcion) {
                        case 1:
                            MenuMarcaDao md = new MenuMarcaDao();
                            md.menuMarca();
                            break;
                        case 2:
                            MenuCategoriaDao cd = new MenuCategoriaDao();
                            cd.menuCategoria();
                            break;
                        case 3:

                            MenuEmpresaDao me = new MenuEmpresaDao();
                            me.menuEmpresa();
                            break;
                        case 4:
                            MenuCiudadDao mc =new MenuCiudadDao();
                            mc.menuCiudad();
                            break;
                        case 5:
                            MenuTipoDocumentoDAO td= new MenuTipoDocumentoDAO();
                            td.menuTipoDocumento();
                            break;
                        case 6:
                            MenuMetodoPagoDao mp= new MenuMetodoPagoDao();
                            mp.menuMetodoPago();
                            break;
                        case 7:
                            MenuProductoDao pd= new MenuProductoDao();
                            pd.menuProductos();
                            break;
                        case 8:
                            MenuCarritoComprasDao crr= new MenuCarritoComprasDao();
                            crr.menuCarritoCompras();
                            break;
                        case 9:
                            MenuFacturaDao facD= new MenuFacturaDao();
                            facD.menuFactura();
                            break;
                        case 10:
                            break;
                        case 11:
                            break;

                    }
                    break;


                case 10:


                    System.out.println("Sesion finalizada, hasta pronto ");
                    System.exit(0);
                    break;
            }


        }
        while (opcion < 11);
        System.out.println("ups algo salio mal - Opcion no valida");
    }

}