package com.co.nttdata.ecommerce.menu;

import com.co.nttdata.ecommerce.daos.CiudadDAO;
import com.co.nttdata.ecommerce.daos.TipoDocumentoDAO;
import com.co.nttdata.ecommerce.entidades.Ciudad;
import com.co.nttdata.ecommerce.entidades.TipoDocumento;

import java.util.Scanner;

public class MenuTipoDocumentoDAO {

    TipoDocumentoDAO tipD = new TipoDocumentoDAO();
    int opcion, id;
    Scanner x = new Scanner(System.in);
    TipoDocumento tip = new TipoDocumento();


    public void menuTipoDocumento() {
        do {
            System.out.println("1. Agregar Tipo Documento");
            System.out.println("2. Consultar Tipo Documento");
            System.out.println("3. Buscar Tipo Documento");
            System.out.println("4. Eliminar Tipo Documento");
            System.out.println("5. Modificar Tipo Documento");
            opcion = x.nextInt();
            switch (opcion) {
                case 1:
                    tip.setDescripcion("cedula de ciudadania");
                    tipD.agregarTipoDocumento(tip);


                    break;
                case 2:
                    tipD.consultarTipoDocumento();
                    break;
                case 3:
                    System.out.println("Ingresa el id del Tipo documento que quieres buscar");
                    int ti = x.nextInt();
                    tipD.buscarTipoDocumento(ti);

                    break;
                case 4:
                    System.out.println("Ingresa el id del Tipo de documento que quieres eliminar");
                    id = x.nextInt();
                    tipD.eliminarTipoDocumento(id);

                    break;
                case 5:
                    System.out.println("Id del Tipo de documento a modificar");
                    id = x.nextInt();
                    System.out.println("Descripcion");
                    String nomb = x.next();

                    System.out.println();
                    tipD.modificarValor(nomb, id);
                    break;


            }
        } while (opcion < 5);
    }

}

