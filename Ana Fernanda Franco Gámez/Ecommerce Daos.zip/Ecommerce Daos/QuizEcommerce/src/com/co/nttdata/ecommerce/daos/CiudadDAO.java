package com.co.nttdata.ecommerce.daos;

import com.co.nttdata.ecommerce.entidades.Ciudad;
import com.co.nttdata.ecommerce.entidades.Empresa;
import com.co.nttdata.ecommerce.utilitarios.ConexionBD;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CiudadDAO {

    ConexionBD cone = new ConexionBD();

    public List<Ciudad> consultarCiudad() {
        Connection baseDatos = cone.conectarBD();
        Statement st = null;
        ResultSet rs = null;
        List<Ciudad> listCiudades = new ArrayList<>();
        try {

            st = baseDatos.createStatement();
            rs = st.executeQuery("select * from \"TBL_CIUDADES\"");

            while (rs.next()) {

                Ciudad ciu = new Ciudad();
                ciu.setIdCiudad(rs.getInt("idCiudad"));
                ciu.setNombreCiudad(rs.getString("nombreCiudad"));
                ciu.setPrincipal(rs.getBoolean("principal"));


                listCiudades.add(ciu);
            }


        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                rs.close();
                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }

        for (Ciudad lci : listCiudades) {
            System.out.println("Id Ciudad: " + lci.getIdCiudad());
            System.out.println("Nombre Ciudad: " + lci.getNombreCiudad());
            System.out.println("Principal: " + lci.getPrincipal());


            System.out.println("--");
        }
        return listCiudades;
    }


    public void buscarCiudad(String noCiu) {
        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;
        ResultSet rs = null;

        try {

            st = baseDatos.prepareStatement("select * from \"TBL_CIUDADES\" where \"nombreCiudad\"=?");

            st.setString(1, noCiu);
            rs = st.executeQuery();

            while (rs.next()) {
                Ciudad ciu = new Ciudad();
                ciu.setIdCiudad(rs.getInt("idCiudad"));
                ciu.setNombreCiudad(rs.getString("nombreCiudad"));
                ciu.setPrincipal(rs.getBoolean("principal"));
                System.out.println("Id Ciudad: " + ciu.getIdCiudad());
                System.out.println("Nombre Ciudad: " + ciu.getNombreCiudad());
                System.out.println("Principal: " + ciu.getPrincipal());
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                rs.close();
                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }


    }

    public void agregarCiudad(Ciudad ciu) {

        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;

        try {

            st = baseDatos.prepareStatement("INSERT INTO \"TBL_CIUDADES\"(\n" +
                    "\t \"nombreCiudad\", principal)\n" +
                    "\tVALUES (?, ?)");
            //"idCiudad"    "nombreCiudad"   principal

            st.setString(1, ciu.getNombreCiudad());
            st.setBoolean(2, ciu.getPrincipal());

            st.executeUpdate();

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {

                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }

    }

    public void eliminarCiudad(int idciu) {
        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;


        try {

            st = baseDatos.prepareStatement("delete  from \"TBL_CIUDADES\" where \"idCiudad\" =?");
            st.setInt(1, idciu);
            st.executeUpdate();
            if (st.executeUpdate() == 0) {
                System.out.println("Se ha eliminado con exito");
            } else {
                System.out.println("Ha ocurrido un error");
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {

                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }


    }

    public void modificarValor(String nomb, int id) {
        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;


        try {

            st = baseDatos.prepareStatement("UPDATE \"TBL_CIUDADES\"\n" +
                    "\tSET   \"nombreCiudad\"=?\n" + "\tWHERE \"idCiudad\"=?");
            st.setString(1, nomb);
            st.setInt(2, id);


            st.executeUpdate();

            if (st.executeUpdate() > 0) {
                System.out.println("Actualizado ");
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {

                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }


    }

}
