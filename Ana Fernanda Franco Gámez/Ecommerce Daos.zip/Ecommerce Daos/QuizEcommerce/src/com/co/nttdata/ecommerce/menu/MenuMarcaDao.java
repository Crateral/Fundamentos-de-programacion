package com.co.nttdata.ecommerce.menu;

import com.co.nttdata.ecommerce.daos.MarcaDAO;
import com.co.nttdata.ecommerce.entidades.Marca;

import java.util.Scanner;

public class MenuMarcaDao {
    MarcaDAO marD = new MarcaDAO();
    int opcion;
    Scanner x = new Scanner(System.in);
    Marca azus = new Marca();

    public void menuMarca() {
        do {
            System.out.println("1. Agregar marca");
            System.out.println("2. Consultar Marca");
            System.out.println("3. Buscar Marca");
            System.out.println("4. Eliminar marca");
            System.out.println("5. Modificar Descripcion");
            opcion = x.nextInt();
            switch (opcion) {
                case 1:

                    azus.setNombreMarca("AZUS");
                    azus.setDescripcionMarca("Marca Azus");
                    marD.agregarMarca(azus);
                    break;
                case 2:

                    marD.consultarMarca();
                    break;
                case 3:
                    System.out.println("Que marca quieres buscar");
                    String marca = x.next();
                    marD.buscarMarca(marca);
                    break;
                case 4:
                    System.out.println("Ingresa el id de la marca que quieres eliminar");
                    int idMarc = x.nextInt();
                    marD.eliminarMarca(idMarc);
                    break;
                case 5:
                    System.out.println("Id de la marca a modificar");
                    int id = x.nextInt();
                    System.out.println("Nuevo nombre");
                    String nomb = x.next();
                    System.out.println("Descripcion");
                    String descripcion = x.next();
                    System.out.println();
                    marD.modificarValor(descripcion, id, nomb);
                    break;


            }
        } while (opcion < 5);
    }
}
