package com.co.nttdata.ecommerce.entidades;

import java.io.Serializable;
import java.util.Date;

public class Factura implements Serializable {

    private int idFactura;
    private Date fecha;
    //private Empresa empresa;
    private int empresa;
    //private Cliente cliente;
    private int cliente;
    private String descripcion;
    //private CarritoDeCompras carritoDeCompras;
    private int carritoDeCompras;
    private double valorTotalSinIva;
    private double valorTotalConIva;

    public Factura() {

    }

    public Factura(int idFactura, Date fecha, int empresa, int cliente, String descripcion,
                   int carritoDeCompras, double valorTotalSinIva, double valorTotalConIva) {
        super();
        this.idFactura = idFactura;
        this.fecha = fecha;
        this.empresa = empresa;
        this.cliente = cliente;
        this.descripcion = descripcion;
        this.carritoDeCompras = carritoDeCompras;
        this.valorTotalSinIva = valorTotalSinIva;
        this.valorTotalConIva = valorTotalConIva;
    }

    public int getIdFactura() {
        return idFactura;
    }

    public void setIdFactura(int idFactura) {
        this.idFactura = idFactura;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public int getEmpresa() {
        return empresa;
    }

    public void setEmpresa(int empresa) {
        this.empresa = empresa;
    }

    public int getCliente() {
        return cliente;
    }

    public void setCliente(int cliente) {
        this.cliente = cliente;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getProductos() {
        return carritoDeCompras;
    }

    public void setProductos(int carritoDeCompras) {
        this.carritoDeCompras = carritoDeCompras;
    }

    public double getValorTotalSinIva() {
        return valorTotalSinIva;
    }

    public void setValorTotalSinIva(double valorTotalSinIva) {
        this.valorTotalSinIva = valorTotalSinIva;
    }

    public double getValorTotalConIva() {
        return valorTotalConIva;
    }

    public void setValorTotalConIva(double valorTotalConIva) {
        this.valorTotalConIva = valorTotalConIva;
    }

}
