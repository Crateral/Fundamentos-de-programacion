package com.co.nttdata.ecommerce.entidades;

import java.io.Serializable;

public class TipoDocumento implements Serializable {

  private int idTipodocumento;
  private String descripcion;

    public TipoDocumento() {
    }

    public TipoDocumento(int idTipodocumento, String descripcion) {
        this.idTipodocumento = idTipodocumento;
        this.descripcion = descripcion;
    }

    public int getIdTipodocumento() {
        return idTipodocumento;
    }

    public void setIdTipodocumento(int idTipodocumento) {
        this.idTipodocumento = idTipodocumento;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
