package com.co.nttdata.ecommerce.entidades;

import java.io.Serializable;

public class Categoria implements Serializable {

    /*ELECTRODOMESTICOS(1, "Electrodomestico", "Electrodomestico 10/10", true, 0.10),
    TECNOLOGIA(2, "Tecnologia", "Articulos de Tecnologia ", true, 0.10),
    ROPA(3, "Ropa", "Prendas de vestir", false, 0.15),
    MASCOTAS(4, "Mascotas", "Productos para mascotas", false, 0.05),
    HOGAR(5, "hogar", "Muebles y mas", true, 0.12),
    DEPORTES(6, "Depostes", "Todo lo relacionado con deporte", false, 0),
    JUGUETERIA(7, "Jugueteria", "Articulos de Jugueteria ", true, 0.10),
    ACCESORIOS(8, "Accesorios", "Todo lo relacionado con accesorios", true, 0.12);*/
    private int idCategoria;
    private String nombreCategoria;
    private String descripcion;
    private double descuento;
    private double iva;
    private double valorDescuento;

    public Categoria() {
    }

    public Categoria(int idCategoria, String nombreCategoria, String descripcion, double descuento, double iva, double valorDescuento) {
        this.idCategoria = idCategoria;
        this.nombreCategoria = nombreCategoria;
        this.descripcion = descripcion;
        this.descuento = descuento;
        this.iva = iva;
        this.valorDescuento = valorDescuento;
    }



    public int getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(int idCategoria) {
        this.idCategoria = idCategoria;
    }

    public String getNombreCategoria() {
        return nombreCategoria;
    }

    public void setNombreCategoria(String nombreCategoria) {
        this.nombreCategoria = nombreCategoria;
    }

    public double getIva() {
        return iva;
    }

    public void setIva(double iva) {
        this.iva = iva;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getDescuento() {
        return descuento;
    }

    public void setDescuento(double descuento) {
        this.descuento = descuento;
    }

    public double getValorDescuento() {
        return valorDescuento;
    }

    public void setValorDescuento(double valorDescuento) {
        this.valorDescuento = valorDescuento;
    }
}
