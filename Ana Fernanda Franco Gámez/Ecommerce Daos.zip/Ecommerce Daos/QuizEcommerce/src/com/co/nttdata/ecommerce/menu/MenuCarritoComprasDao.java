package com.co.nttdata.ecommerce.menu;

import com.co.nttdata.ecommerce.daos.CarritoDeComprasDAO;
import com.co.nttdata.ecommerce.daos.CategoriaDAO;
import com.co.nttdata.ecommerce.entidades.CarritoDeCompras;
import com.co.nttdata.ecommerce.entidades.Categoria;

import java.util.Date;

import java.util.Scanner;

public class MenuCarritoComprasDao {

    CarritoDeComprasDAO carrD = new CarritoDeComprasDAO();
    int opcion;
    Scanner x = new Scanner(System.in);

    CarritoDeCompras car = new CarritoDeCompras();

//"idCarrito", fecha, "idProducto", cantidad, subtotal, "valorEnvio", "subtotalConIva"

    public void menuCarritoCompras() {
        do {
            System.out.println("1. Agregar Carrito Compras");
            System.out.println("2. Consultar Carrito Compras");
            System.out.println("3. Buscar Carrito Compras");
            System.out.println("4. Eliminar Carrito Compras");
            System.out.println("5. Modificar Carrito Compras");
            opcion = x.nextInt();
            switch (opcion) {
                case 1:

                    car.setFecha(null);
                    car.setProductos(3);
                    car.setCantidadPedida(4);
                    car.setSubTotaSinIva(2500000 * 4);
                    car.setValorEnvio(25000);
                    car.setSubTotalConIva((2500000 * 4) + (2500000 * 0.10) + 25000);

                    carrD.agregarCarrito(car);

                    break;
                case 2:

                    carrD.consultarCarrito();
                    break;
                case 3:
                    System.out.println("Que Carrito quieres buscar");
                    int cat = x.nextInt();
                    carrD.buscarCarrito(cat);
                    break;
                case 4:
                    System.out.println("Ingresa el id del carrito que quieres eliminar");
                    int idcat = x.nextInt();

                    carrD.eliminarCarrito(idcat);

                    break;
                case 5:
                    System.out.println("Id del carrito a modificar");
                    int id = x.nextInt();
                    System.out.println("Cantidad Producto");
                    int cant = x.nextInt();
                    System.out.println();
                    carrD.modificarValor(id, cant);
                    break;


            }
        } while (opcion < 5);
    }

}

