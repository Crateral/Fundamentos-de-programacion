package com.co.nttdata.ecommerce.daos;

import com.co.nttdata.ecommerce.entidades.Categoria;
import com.co.nttdata.ecommerce.entidades.Ciudad;
import com.co.nttdata.ecommerce.entidades.TipoDocumento;
import com.co.nttdata.ecommerce.utilitarios.ConexionBD;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TipoDocumentoDAO {

    ConexionBD cone = new ConexionBD();

    public List<TipoDocumento> consultarTipoDocumento() {
        Connection baseDatos = cone.conectarBD();
        Statement st = null;
        ResultSet rs = null;
        List<TipoDocumento> lisTipoDc = new ArrayList<>();
        try {

            st = baseDatos.createStatement();
            rs = st.executeQuery("select * from \"TBL_TIPOSDOCUMENTO\"");

            while (rs.next()) {

                TipoDocumento tip = new TipoDocumento();
                tip.setIdTipodocumento(rs.getInt("idTipodocumento"));
                tip.setDescripcion(rs.getString("descripcion"));


                lisTipoDc.add(tip);
            }


        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                rs.close();
                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }

        for (TipoDocumento ltd : lisTipoDc) {
            System.out.println("Id Tipo doc: " + ltd.getIdTipodocumento());
            System.out.println("Nombre : " + ltd.getDescripcion());


            System.out.println("--");
        }
        return lisTipoDc;
    }


    public void buscarTipoDocumento(int noTD) {
        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;
        ResultSet rs = null;

        try {

            st = baseDatos.prepareStatement("select * from \"TBL_TIPOSDOCUMENTO\" where \"idTipodocumento\"=?");

            st.setInt(1, noTD);
            rs = st.executeQuery();

            while (rs.next()) {
                TipoDocumento tip = new TipoDocumento();
                tip.setIdTipodocumento(rs.getInt("idTipodocumento"));
                tip.setDescripcion(rs.getString("descripcion"));
                System.out.println("Id Tipo doc: " + tip.getIdTipodocumento());
                System.out.println("Nombre : " + tip.getDescripcion());

            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                rs.close();
                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }


    }

    public void agregarTipoDocumento(TipoDocumento tipd) {

        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;

        try {

            st = baseDatos.prepareStatement("INSERT INTO public.\"TBL_TIPOSDOCUMENTO\"(\n" +
                    "\t descripcion)\n" + "\tVALUES ( ?);");


            st.setString(1, tipd.getDescripcion());
            st.executeUpdate();

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {

                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }

    }

    public void eliminarTipoDocumento(int idciu) {
        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;


        try {

            st = baseDatos.prepareStatement("delete  from \"TBL_TIPOSDOCUMENTO\" where \"idTipodocumento\" =?");
            st.setInt(1, idciu);
            st.executeUpdate();
            if (st.executeUpdate() == 0) {
                System.out.println("Se ha eliminado con exito");
            } else {
                System.out.println("Ha ocurrido un error");
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {

                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }


    }

    public void modificarValor(String nomb, int id) {
        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;


        try {

            st = baseDatos.prepareStatement("UPDATE \"TBL_TIPOSDOCUMENTO\"\n" +
                    "\tSET   \"descripcion\"=?\n" + "\tWHERE \"idTipodocumento\"=?");
            st.setString(1, nomb);
            st.setInt(2, id);


            st.executeUpdate();

            if (st.executeUpdate() > 0) {
                System.out.println("Actualizado ");
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {

                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }


    }

}

