package com.co.nttdata.ecommerce.entidades;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CarritoDeCompras implements Serializable {

    private int idCarritoDeCompras;
    private Date fecha;
    //  private List<Producto> productos;
    private int productos;
    private int cantidadPedida;
    private double subTotaSinIva;
    private double valorTotalIva;
    private double subTotalConIva;
    private double valorEnvio;
    //Se debe cambiar los artibutos del subTotal a:
    // - subTotalConIva y subTotaSinIva

    public CarritoDeCompras() {

    }

    public CarritoDeCompras(int idCarritoDeCompras, Date fecha, int productos,
                            double subTotaSinIva, double subTotalConIva, double valorTotalIva, double valorEnvio) {
        this.idCarritoDeCompras = idCarritoDeCompras;
        this.fecha = fecha;
        this.productos = productos;
        this.subTotaSinIva = subTotaSinIva;
        this.valorTotalIva = valorTotalIva;
        this.subTotalConIva = subTotalConIva;
        this.valorEnvio = valorEnvio;
    }

    public double getValorTotalIva() {
        return valorTotalIva;
    }

    public int getCantidadPedida() {
        return cantidadPedida;
    }

    public void setCantidadPedida(int cantidadPedida) {
        this.cantidadPedida = cantidadPedida;
    }

    public void setValorTotalIva(double valorTotalIva) {
        this.valorTotalIva = valorTotalIva;
    }

    public int getIdCarritoDeCompras() {
        return idCarritoDeCompras;
    }

    public void setIdCarritoDeCompras(int idCarritoDeCompras) {
        this.idCarritoDeCompras = idCarritoDeCompras;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public int getProductos() {
        return productos;
    }

    public void setProductos(int productos) {
        this.productos = productos;
    }

    public double getSubTotaSinIva() {
        return subTotaSinIva;
    }

    public void setSubTotaSinIva(double subTotaSinIva) {
        this.subTotaSinIva = subTotaSinIva;
    }

    public double getSubTotalConIva() {
        return subTotalConIva;
    }

    public void setSubTotalConIva(double subTotalConIva) {
        this.subTotalConIva = subTotalConIva;
    }

    public double getValorEnvio() {
        return valorEnvio;
    }

    public void setValorEnvio(double valorEnvio) {
        this.valorEnvio = valorEnvio;
    }

    @Override
    public String toString() {
        return "CarritoDeCompras{" +
                "idCarritoDeCompras=" + idCarritoDeCompras +
                ", fecha=" + fecha +
                ", productos=" + productos +
                ", cantidadPedida=" + cantidadPedida +
                ", subTotaSinIva=" + subTotaSinIva +
                ", valorTotalIva=" + valorTotalIva +
                ", subTotalConIva=" + subTotalConIva +
                ", valorEnvio=" + valorEnvio +
                '}';
    }
}
