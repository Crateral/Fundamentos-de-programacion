package com.co.nttdata.ecommerce.menu;

import com.co.nttdata.ecommerce.daos.MetodoPagoDAO;
import com.co.nttdata.ecommerce.daos.TipoDocumentoDAO;
import com.co.nttdata.ecommerce.entidades.MetodoPago;
import com.co.nttdata.ecommerce.entidades.TipoDocumento;

import java.util.Scanner;

public class MenuMetodoPagoDao {
    MetodoPagoDAO metD = new MetodoPagoDAO();
    int opcion, id;
    Scanner x = new Scanner(System.in);
    MetodoPago metP = new MetodoPago();


    public void menuMetodoPago() {
        do {
            System.out.println("1. Agregar Metodo de pago");
            System.out.println("2. Consultar Metodo de pago");
            System.out.println("3. Buscar Metodo de pago");
            System.out.println("4. Eliminar Metodo de pago");
            System.out.println("5. Modificar Metodo de pago");
            opcion = x.nextInt();
            switch (opcion) {
                case 1:
                    metP.setDescripccion("Cheque");
                    metD.agregarMetodoPago(metP);

                    break;
                case 2:
                    metD.consultarMetodoPago();
                    break;
                case 3:
                    System.out.println("Ingresa el id del Metodo de pago que quieres buscar");
                    int ti = x.nextInt();
                    metD.buscarMetodoPagp(ti);

                    break;
                case 4:
                    System.out.println("Ingresa el id del Metodo de pago que quieres eliminar");
                    id = x.nextInt();
                    metD.eliminarMetodoPago(id);

                    break;
                case 5:
                    System.out.println("Id del Metodo de pago a modificar");
                    id = x.nextInt();
                    System.out.println("Descripcion Pago");
                    String nomb = x.next();

                    System.out.println();
                    metD.modificarValor(nomb, id);
                    break;


            }
        } while (opcion < 5);
    }

}
