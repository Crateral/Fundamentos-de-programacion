package com.co.nttdata.ecommerce.menu;

import com.co.nttdata.ecommerce.daos.CiudadDAO;
import com.co.nttdata.ecommerce.daos.EmpresaDAO;
import com.co.nttdata.ecommerce.entidades.Ciudad;
import com.co.nttdata.ecommerce.entidades.Empresa;

import java.util.Scanner;

public class MenuCiudadDao {


    CiudadDAO ciuD = new CiudadDAO();
    int opcion, id;
    Scanner x = new Scanner(System.in);
    Ciudad ciu = new Ciudad();


    public void menuCiudad() {
        do {
            System.out.println("1. Agregar Ciudad");
            System.out.println("2. Consultar Ciudad");
            System.out.println("3. Buscar Ciudad");
            System.out.println("4. Eliminar Ciudad");
            System.out.println("5. Modificar Ciudad");
            opcion = x.nextInt();
            switch (opcion) {
                case 1:
                    ciu.setNombreCiudad("Guapota");
                    ciu.setPrincipal(false);
                    ciuD.agregarCiudad(ciu);


                    break;
                case 2:

                    ciuD.consultarCiudad();
                    break;
                case 3:
                    System.out.println("Que Ciudad quieres buscar");
                    String ci = x.next();
                    ciuD.buscarCiudad(ci);
                    break;
                case 4:
                    System.out.println("Ingresa el id de la ciudad que quieres eliminar");
                    id = x.nextInt();
                    ciuD.eliminarCiudad(id);

                    break;
                case 5:
                    System.out.println("Id de la ciudad a modificar");
                    id = x.nextInt();
                    System.out.println("Nombre");
                    String nomb = x.next();

                    System.out.println();
                    ciuD.modificarValor(nomb, id);
                    break;


            }
        } while (opcion < 5);
    }

}
