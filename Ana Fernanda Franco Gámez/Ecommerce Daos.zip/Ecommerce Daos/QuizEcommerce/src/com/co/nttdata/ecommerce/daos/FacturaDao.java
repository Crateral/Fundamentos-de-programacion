package com.co.nttdata.ecommerce.daos;

import com.co.nttdata.ecommerce.entidades.CarritoDeCompras;
import com.co.nttdata.ecommerce.entidades.Factura;
import com.co.nttdata.ecommerce.utilitarios.ConexionBD;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FacturaDao {
    ConexionBD cone = new ConexionBD();

//"idFactura", fecha, "idEmpresa", "idCliente", descripcion, "idProductosCarrito", "valorSinIva", "valorTotalConIva")

    public List<Factura> consultaFactura() {
        Connection baseDatos = cone.conectarBD();
        Statement st = null;
        ResultSet rs = null;
        List<Factura> listFact = new ArrayList<>();
        try {

            st = baseDatos.createStatement();
            rs = st.executeQuery("select * from \"TBL_FACTURAS\"");

            while (rs.next()) {

                Factura fa = new Factura();

                fa.setIdFactura(rs.getInt("idFactura"));
                fa.setFecha(rs.getDate("fecha"));
                fa.setEmpresa(rs.getInt("idEmpresa"));
                fa.setCliente(rs.getInt("idCliente"));
                fa.setDescripcion(rs.getString("descripcion"));
                fa.setProductos(rs.getInt("idProductosCarrito"));
                fa.setValorTotalSinIva((rs.getDouble("valorSinIva")));
                fa.setValorTotalConIva(rs.getDouble("valorTotalConIva"));

                listFact.add(fa);
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                rs.close();
                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }

        for (Factura lfr : listFact) {
            System.out.println("Id Factura: " + lfr.getIdFactura());
            System.out.println("Fecha: " + lfr.getFecha());
            System.out.println("Id Empresa: " + lfr.getEmpresa());
            System.out.println("Id Cliente: " + lfr.getCliente());
            System.out.println("Descripcion: " + lfr.getDescripcion());
            System.out.println("Id Productos: " + lfr.getProductos());
            System.out.println("Valor sin iva: " + lfr.getValorTotalSinIva());
            System.out.println("Valor Total: " + lfr.getValorTotalConIva());
            System.out.println("--");
        }
        return listFact;
    }

    public void buscarFactura(int nomCa) {
        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;
        ResultSet rs = null;

        try {

            st = baseDatos.prepareStatement("select * from \"TBL_FACTURAS\" where \"idFactura\" =?");
            st.setInt(1, nomCa);
            rs = st.executeQuery();

            while (rs.next()) {
                Factura fa = new Factura();

                fa.setIdFactura(rs.getInt("idFactura"));
                fa.setFecha(rs.getDate("fecha"));
                fa.setEmpresa(rs.getInt("idEmpresa"));
                fa.setCliente(rs.getInt("idCliente"));
                fa.setDescripcion(rs.getString("descripcion"));
                fa.setProductos(rs.getInt("idProductosCarrito"));
                fa.setValorTotalSinIva((rs.getDouble("valorSinIva")));
                fa.setValorTotalConIva(rs.getDouble("valorTotalConIva"));

                System.out.println("Id Factura: " + fa.getIdFactura());
                System.out.println("Fecha: " + fa.getFecha());
                System.out.println("Id Empresa: " + fa.getEmpresa());
                System.out.println("Id Cliente: " + fa.getCliente());
                System.out.println("Descripcion: " + fa.getDescripcion());
                System.out.println("Id Productos: " + fa.getProductos());
                System.out.println("Valor sin iva: " + fa.getValorTotalSinIva());
                System.out.println("Valor Total: " + fa.getValorTotalConIva());
                System.out.println("--");


            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                rs.close();
                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }


    }

    public void agregarFactura(Factura fac) {

        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;

        try {

            st = baseDatos.prepareStatement("INSERT INTO public.\"TBL_FACTURAS\"(\n" +
                    "\t fecha, \"idEmpresa\", \"idCliente\", descripcion, \"idProductosCarrito\", \"valorSinIva\", \"valorTotalConIva\")\n" +
                    "\tVALUES ( ?, ?, ?, ?, ?, ?, ?)");

            st.setDate(1, (Date) fac.getFecha());
            st.setInt(2, fac.getEmpresa());
            st.setInt(3, fac.getCliente());
            st.setString(4, fac.getDescripcion());
            st.setInt(5, fac.getProductos());
            st.setDouble(6, fac.getValorTotalSinIva());
            st.setDouble(7, fac.getValorTotalConIva());


            st.executeUpdate();

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {

                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }

    }

    public void eliminarFactura(int idpro) {
        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;


        try {

            st = baseDatos.prepareStatement("delete  from \"TBL_FACTURAS\" where \"idFactura\" =?");
            st.setInt(1, idpro);
            st.executeUpdate();
            if (st.executeUpdate() == 0) {
                System.out.println("Se ha eliminado con exito");
            } else {
                System.out.println("Ha ocurrido un error");
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {

                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }


    }

    public void modificarFactura(int pro, String desc) {
        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;


        try {

            st = baseDatos.prepareStatement("UPDATE public.\"TBL_FACTURAS\"\n" +
                    "\tSET  descripcion=?\n" +
                    "\tWHERE \"idFactura\"=?\n" +
                    "\t");

            //    st.setDate(1, fec);
            st.setString(1, desc);
            st.setInt(2, pro);

            st.executeUpdate();

            if (st.executeUpdate() > 0) {
                System.out.println("Actualizado ");
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {

                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }


    }


}
