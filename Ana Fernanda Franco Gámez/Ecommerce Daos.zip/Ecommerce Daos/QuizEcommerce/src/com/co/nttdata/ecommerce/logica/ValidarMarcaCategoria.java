package com.co.nttdata.ecommerce.logica;

import com.co.nttdata.ecommerce.entidades.Categoria;
import com.co.nttdata.ecommerce.entidades.Marca;

public class ValidarMarcaCategoria {


    public Marca validarMarca(String marca) {

       /* if (marca.trim().equalsIgnoreCase(String.valueOf(Marca.ADIDAS))) {
            return Marca.ADIDAS;
        } else if (marca.trim().equalsIgnoreCase(String.valueOf(Marca.LG))) {
            return Marca.LG;
        } else if (marca.trim().equalsIgnoreCase(String.valueOf(Marca.SAMSUNG))) {
            return Marca.SAMSUNG;
        } else if (marca.trim().equalsIgnoreCase(String.valueOf(Marca.KIA))){
            return Marca.KIA;
        }else if (marca.trim().equalsIgnoreCase(String.valueOf(Marca.STUDIOF))){
            return Marca.STUDIOF;
        } else if (marca.trim().equalsIgnoreCase(String.valueOf(Marca.CANAMOR))) {
            return Marca.CANAMOR;
        } else if (marca.trim().equalsIgnoreCase(String.valueOf(Marca.VELEZ))) {
            return Marca.VELEZ;
        } else if (marca.trim().equalsIgnoreCase(String.valueOf(Marca.IPHONE))) {
            return Marca.IPHONE;
        }else  if (marca.trim().equalsIgnoreCase(String.valueOf(Marca.DISNEY))) {
            return Marca.DISNEY;
        } else{
            return null;
        }*/
        return null;
    }


    public Categoria validarCategoria(String marca){
       /* if (marca.trim().equalsIgnoreCase(String.valueOf(Categoria.ACCESORIOS))) {
            return Categoria.ACCESORIOS;
        } else if (marca.trim().equalsIgnoreCase(String.valueOf(Categoria.DEPORTES))) {
            return Categoria.DEPORTES;
        } else if (marca.trim().equalsIgnoreCase(String.valueOf(Categoria.HOGAR))) {
            return Categoria.HOGAR;
        } else if (marca.trim().equalsIgnoreCase(String.valueOf(Categoria.TECNOLOGIA))) {
            return Categoria.TECNOLOGIA;
        } else if (marca.trim().equalsIgnoreCase(String.valueOf(Categoria.ELECTRODOMESTICOS))) {
            return Categoria.ELECTRODOMESTICOS;
        } else if (marca.trim().equalsIgnoreCase(String.valueOf(Categoria.MASCOTAS))) {
            return Categoria.MASCOTAS;
        } else if (marca.trim().equalsIgnoreCase(String.valueOf(Categoria.ROPA))) {
            return Categoria.ROPA;
        } else if (marca.trim().equalsIgnoreCase(String.valueOf(Categoria.JUGUETERIA))) {
            return Categoria.JUGUETERIA;
        } else {
            return  null;
        }*/
        return null;
    }
}
