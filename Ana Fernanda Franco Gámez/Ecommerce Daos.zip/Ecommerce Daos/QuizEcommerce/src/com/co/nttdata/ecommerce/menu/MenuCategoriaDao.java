package com.co.nttdata.ecommerce.menu;

import com.co.nttdata.ecommerce.daos.CategoriaDAO;
import com.co.nttdata.ecommerce.daos.MarcaDAO;
import com.co.nttdata.ecommerce.entidades.Categoria;
import com.co.nttdata.ecommerce.entidades.Marca;

import java.util.Scanner;

public class MenuCategoriaDao {

    CategoriaDAO catD = new CategoriaDAO();
    int opcion;
    Scanner x = new Scanner(System.in);

    Categoria cate = new Categoria();


    public void menuCategoria() {
        do {
            System.out.println("1. Agregar Categoria");
            System.out.println("2. Consultar Categoria");
            System.out.println("3. Buscar Categoria");
            System.out.println("4. Eliminar Categoria");
            System.out.println("5. Modificar Categoria");
            opcion = x.nextInt();
            switch (opcion) {
                case 1:

                    cate.setNombreCategoria("Utiles");
                    cate.setDescuento(0.3);
                    cate.setIva(0.15);
                    catD.agregarCategoria(cate);

                    break;
                case 2:

                    catD.consultarCategoria();
                    break;
                case 3:
                    System.out.println("Que categoria quieres buscar");
                    String categ = x.next();
                    catD.buscarCategoria(categ);
                    break;
                case 4:
                    System.out.println("Ingresa el id de la categoria que quieres eliminar");
                    int idcat = x.nextInt();
                    catD.eliminarCategoria(idcat);

                    break;
                case 5:
                    System.out.println("Id de la categoria a modificar");
                    int id = x.nextInt();
                    System.out.println("Nuevo nombre");
                    String nomb = x.next();
                    System.out.println("valor descuento ");
                    double des = x.nextDouble();
                    System.out.println();
                    catD.modificarValor(nomb, des, id);
                    break;


            }
        } while (opcion < 5);
    }


}
