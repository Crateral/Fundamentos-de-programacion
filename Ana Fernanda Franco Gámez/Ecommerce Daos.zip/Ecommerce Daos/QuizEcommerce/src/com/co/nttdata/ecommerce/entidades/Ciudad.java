package com.co.nttdata.ecommerce.entidades;

import java.io.Serializable;

public class Ciudad implements Serializable {

    private int idCiudad;
    private String nombreCiudad;
    private boolean principal;

    public Ciudad() {
    }

    public Ciudad(int idCiudad, String nombreCiudad, boolean principal) {
        this.idCiudad = idCiudad;
        this.nombreCiudad = nombreCiudad;
        this.principal = principal;
    }

    public int getIdCiudad() {
        return idCiudad;
    }

    public void setIdCiudad(int idCiudad) {
        this.idCiudad = idCiudad;
    }

    public String getNombreCiudad() {
        return nombreCiudad;
    }

    public void setNombreCiudad(String nombreCiudad) {
        this.nombreCiudad = nombreCiudad;
    }

    public boolean getPrincipal() {
        return principal;
    }

    public void setPrincipal(boolean principal) {
        this.principal = principal;
    }
}
