package com.co.nttdata.ecommerce.entidades;

import java.io.Serializable;

public class MetodoPago implements Serializable {
  private int idMetodopago;
  private String descripccion;

    public MetodoPago() {
    }

    public MetodoPago(int idMetodopago, String descripccion) {
        this.idMetodopago = idMetodopago;
        this.descripccion = descripccion;
    }

    public int getIdMetodopago() {
        return idMetodopago;
    }

    public void setIdMetodopago(int idMetodopago) {
        this.idMetodopago = idMetodopago;
    }

    public String getDescripccion() {
        return descripccion;
    }

    public void setDescripccion(String descripccion) {
        this.descripccion = descripccion;
    }

}
