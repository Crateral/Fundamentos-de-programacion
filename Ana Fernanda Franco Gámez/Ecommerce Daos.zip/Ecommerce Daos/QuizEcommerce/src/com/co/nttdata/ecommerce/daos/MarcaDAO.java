package com.co.nttdata.ecommerce.daos;

import com.co.nttdata.ecommerce.entidades.Marca;
import com.co.nttdata.ecommerce.utilitarios.ConexionBD;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MarcaDAO {
    ConexionBD cone = new ConexionBD();

    public List<Marca> consultarMarca() {
        Connection baseDatos = cone.conectarBD();
        Statement st = null;
        ResultSet rs = null;
        List<Marca> listMarcas = new ArrayList<>();
        try {

            st = baseDatos.createStatement();
            rs = st.executeQuery("select * from \"TBL_MARCAS\"");

            while (rs.next()) {
                Marca marca = new Marca();
                marca.setIdMarca((rs.getInt("idMarca")));
                marca.setNombreMarca(rs.getString("nombreMarca"));
                marca.setDescripcionMarca(rs.getString("descripcionMarca"));
                listMarcas.add(marca);
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                rs.close();
                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }

        for (Marca lm : listMarcas) {
            System.out.println("Id Marca: " + lm.getIdMarca());
            System.out.println("Nombre: " + lm.getNombreMarca());
            System.out.println("Descripcion: " + lm.getDescripcionMarca());
            System.out.println("--");
        }
        return listMarcas;
    }

    public void buscarMarca(String nombreMar) {
        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;
        ResultSet rs = null;

        try {

            st = baseDatos.prepareStatement("select * from \"TBL_MARCAS\" where \"nombreMarca\" =?");

            st.setString(1, nombreMar);
            rs = st.executeQuery();

            while (rs.next()) {
                Marca marca = new Marca();
                marca.setIdMarca((rs.getInt("idMarca")));
                marca.setNombreMarca(rs.getString("nombreMarca"));
                marca.setDescripcionMarca(rs.getString("descripcionMarca"));
                System.out.println("Id Marca: " + marca.getIdMarca());
                System.out.println("Nombre: " + marca.getNombreMarca());
                System.out.println("Descripcion: " + marca.getDescripcionMarca());

            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                rs.close();
                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }


    }

    public void agregarMarca(Marca marca) {

        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;

        try {

            st = baseDatos.prepareStatement("INSERT INTO public.\"TBL_MARCAS\"(\n" +
                    "\t \"nombreMarca\", \"descripcionMarca\")\n" +
                    "\tVALUES (?, ?);\n");

            st.setString(1, marca.getNombreMarca());
            st.setString(2, marca.getDescripcionMarca());
            st.executeUpdate();

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {

                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }

    }

    public void eliminarMarca(int idMarc) {
        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;


        try {

            st = baseDatos.prepareStatement("delete  from \"TBL_MARCAS\" where \"idMarca\" =?");
            st.setInt(1, idMarc);
            st.executeUpdate();
            if (st.executeUpdate() == 0) {
                System.out.println("Se ha eliminado con exito");
            } else {
                System.out.println("Ha ocurrido un error");
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {

                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }


    }

    public void modificarValor(String descipcion, int idmarc, String nomb) {
        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;


        try {

            st = baseDatos.prepareStatement("UPDATE \"TBL_MARCAS\"\n" +
                    "\tSET   \"nombreMarca\"=?, \"descripcionMarca\"=?\n" +
                    "\tWHERE \"idMarca\"=?");
            st.setString(1, nomb);
            st.setString(2, descipcion);
            st.setInt(3, idmarc);

            st.executeUpdate();

            if (st.executeUpdate() > 0) {
                System.out.println("Actualizado ");
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {

                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }


    }


}
