package com.co.nttdata.ecommerce.menu;

public class MenuAdministradorDao {
}
