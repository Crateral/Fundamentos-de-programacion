package com.co.nttdata.ecommerce.daos;

import com.co.nttdata.ecommerce.entidades.CarritoDeCompras;
import com.co.nttdata.ecommerce.entidades.Producto;
import com.co.nttdata.ecommerce.utilitarios.ConexionBD;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CarritoDeComprasDAO {
    ConexionBD cone = new ConexionBD();


    public List<CarritoDeCompras> consultarCarrito() {
        Connection baseDatos = cone.conectarBD();
        Statement st = null;
        ResultSet rs = null;
        List<CarritoDeCompras> listCarri = new ArrayList<>();
        try {

            st = baseDatos.createStatement();
            rs = st.executeQuery("select * from \"TBL_CARRITOCOMPRAS\"");

            while (rs.next()) {
                CarritoDeCompras ca = new CarritoDeCompras();
                ca.setIdCarritoDeCompras(rs.getInt("idCarrito"));
                ca.setFecha(rs.getDate("fecha"));
                ca.setProductos(rs.getInt("idProducto"));
                ca.setCantidadPedida(rs.getInt("cantidad"));
                ca.setSubTotaSinIva(rs.getDouble("subtotal"));
                ca.setValorEnvio(rs.getDouble("valorEnvio"));
                ca.setSubTotalConIva(rs.getDouble("subtotalConIva"));
                listCarri.add(ca);
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                rs.close();
                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }

        for (CarritoDeCompras lcr : listCarri) {
            System.out.println("Id Carrito: " + lcr.getIdCarritoDeCompras());
            System.out.println("Fecha: " + lcr.getFecha());
            System.out.println("Id Producto: " + lcr.getProductos());
            System.out.println("Cantidad: " + lcr.getCantidadPedida());
            System.out.println("Subtotal: " + lcr.getSubTotaSinIva());
            System.out.println("Envio: " + lcr.getValorEnvio());
            System.out.println("Valor con envio: " + lcr.getSubTotalConIva());
            System.out.println("--");
        }
        return listCarri;
    }

    public void buscarCarrito(int nomCa) {
        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;
        ResultSet rs = null;

        try {

            st = baseDatos.prepareStatement("select * from \"TBL_CARRITOCOMPRAS\" where \"idCarrito\" =?");
            st.setInt(1, nomCa);
            rs = st.executeQuery();

            while (rs.next()) {
                CarritoDeCompras ca = new CarritoDeCompras();
                ca.setIdCarritoDeCompras(rs.getInt("idCarrito"));
                ca.setFecha(rs.getDate("fecha"));
                ca.setProductos(rs.getInt("idProducto"));
                ca.setCantidadPedida(rs.getInt("cantidad"));
                ca.setSubTotaSinIva(rs.getDouble("subtotal"));
                ca.setValorEnvio(rs.getDouble("valorEnvio"));
                ca.setSubTotalConIva(rs.getDouble("subtotalConIva"));

                System.out.println("Id Carrito: " + ca.getIdCarritoDeCompras());
                System.out.println("Fecha: " + ca.getFecha());
                System.out.println("Id Producto: " + ca.getProductos());
                System.out.println("Cantidad: " + ca.getCantidadPedida());
                System.out.println("Subtotal: " + ca.getSubTotaSinIva());
                System.out.println("Envio: " + ca.getValorEnvio());
                System.out.println("Valor con envio: " + ca.getSubTotalConIva());
                System.out.println("--");


            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                rs.close();
                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }


    }

    public void agregarCarrito(CarritoDeCompras ccd) {

        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;

        try {

            st = baseDatos.prepareStatement("INSERT INTO \"TBL_CARRITOCOMPRAS\"(\n" +
                    "\t fecha, \"idProducto\", cantidad, subtotal, \"valorEnvio\", \"subtotalConIva\")\n" +
                    "\tVALUES ( ?, ?, ?, ?, ?, ?) ");

            st.setDate(1, (Date) ccd.getFecha());
            st.setInt(2, ccd.getProductos());
            st.setInt(3, ccd.getCantidadPedida());
            st.setDouble(4, ccd.getSubTotaSinIva());
            st.setDouble(5, ccd.getValorEnvio());
            st.setDouble(6, ccd.getSubTotalConIva());

            st.executeUpdate();

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {

                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }

    }

    public void eliminarCarrito(int idpro) {
        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;


        try {

            st = baseDatos.prepareStatement("delete  from \"TBL_CARRITOCOMPRAS\" where \"idCarrito\" =?");
            st.setInt(1, idpro);
            st.executeUpdate();
            if (st.executeUpdate() == 0) {
                System.out.println("Se ha eliminado con exito");
            } else {
                System.out.println("Ha ocurrido un error");
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {

                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }


    }

    public void modificarValor(int pro, int cat) {
        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;


        try {

            st = baseDatos.prepareStatement("UPDATE public.\"TBL_CARRITOCOMPRAS\"\n" +
                    "\tSET  cantidad=?\n" +
                    "\tWHERE \"idCarrito\"=?\n" +
                    "\t");

            //    st.setDate(1, fec);
            st.setInt(1, cat);
            st.setInt(2, pro);

            st.executeUpdate();

            if (st.executeUpdate() > 0) {
                System.out.println("Actualizado ");
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {

                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }


    }


}
