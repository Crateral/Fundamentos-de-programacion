package com.co.nttdata.ecommerce.daos;

import com.co.nttdata.ecommerce.entidades.Marca;
import com.co.nttdata.ecommerce.entidades.Producto;
import com.co.nttdata.ecommerce.utilitarios.ConexionBD;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductoDAO {
    ConexionBD cone = new ConexionBD();

    // "idProducto", nombre, cantidad, precio, descuento, "valorDescuento", "imgProducto", "idMarca", "idCategoria"
    public List<Producto> consultarProducto() {
        Connection baseDatos = cone.conectarBD();
        Statement st = null;
        ResultSet rs = null;
        List<Producto> listProductos = new ArrayList<>();
        try {

            st = baseDatos.createStatement();
            rs = st.executeQuery("select * from \"TBL_PRODUCTOS\"");

            while (rs.next()) {
                Producto pro = new Producto();
                pro.setIdProducto(rs.getInt("idProducto"));
                pro.setNombre(rs.getString("nombre"));
                pro.setCantidadDiponible(rs.getInt("cantidad"));
                pro.setPrecio(rs.getDouble("precio"));
                pro.setDescuento(rs.getBoolean("descuento"));
                pro.setValorDescuento(rs.getDouble("valorDescuento"));
                pro.setImg(rs.getString("imgProducto"));
                pro.setMarca(rs.getInt("idMarca"));
                pro.setCategoria(rs.getInt("idCategoria"));
                listProductos.add(pro);
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                rs.close();
                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }

        for (Producto lpr : listProductos) {
            System.out.println("Id Producto: " + lpr.getIdProducto());
            System.out.println("Nombre: " + lpr.getNombre());
            System.out.println("Cantidad: " + lpr.getCantidadDiponible());
            System.out.println("Precio: " + lpr.getPrecio());
            System.out.println("Tiene descuento: " + lpr.getDescuento());
            System.out.println("Valor Descuento: " + lpr.getValorDescuento());
            System.out.println("Img producto: " + lpr.getImg());
            System.out.println("Id Marca: " + lpr.getMarca());
            System.out.println("Id Categoria: " + lpr.getCategoria());
            System.out.println("--");
        }
        return listProductos;
    }

    public void buscarProducto(String nomPro) {
        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;
        ResultSet rs = null;

        try {

            st = baseDatos.prepareStatement("select * from \"TBL_PRODUCTOS\" where \"nombre\" =?");
            st.setString(1, nomPro);
            rs = st.executeQuery();

            while (rs.next()) {
                Producto pro = new Producto();
                pro.setIdProducto(rs.getInt("idProducto"));
                pro.setNombre(rs.getString("nombre"));
                pro.setCantidadDiponible(rs.getInt("cantidad"));
                pro.setPrecio(rs.getDouble("precio"));
                pro.setDescuento(rs.getBoolean("descuento"));
                pro.setValorDescuento(rs.getDouble("valorDescuento"));
                pro.setImg(rs.getString("imgProducto"));
                pro.setMarca(rs.getInt("idMarca"));
                pro.setCategoria(rs.getInt("idCategoria"));

                System.out.println("Id Producto: " + pro.getIdProducto());
                System.out.println("Nombre: " + pro.getNombre());
                System.out.println("Cantidad: " + pro.getCantidadDiponible());
                System.out.println("Precio: " + pro.getPrecio());
                System.out.println("Tiene descuento: " + pro.getDescuento());
                System.out.println("Valor Descuento: " + pro.getValorDescuento());
                System.out.println("Img producto: " + pro.getImg());
                System.out.println("Id Marca: " + pro.getMarca());
                System.out.println("Id Categoria: " + pro.getCategoria());


            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                rs.close();
                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }


    }

    public void agregarProducto(Producto prod) {

        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;

        try {

            st = baseDatos.prepareStatement("INSERT INTO \"TBL_PRODUCTOS\"(\n" +
                    "\t  nombre, cantidad, precio, descuento, \"valorDescuento\", \"imgProducto\", \"idMarca\"," +
                    " \"idCategoria\")\n" +
                    "\tVALUES ( ?, ?, ?, ?, ?, ?, ?, ?)");

            st.setString(1, prod.getNombre());
            st.setInt(2, prod.getCantidadDiponible());
            st.setDouble(3, prod.getPrecio());
            st.setBoolean(4, prod.getDescuento());
            st.setDouble(5, prod.getValorDescuento());
            st.setString(6, prod.getImg());
            st.setInt(7, prod.getMarca());
            st.setInt(8, prod.getCategoria());
            st.executeUpdate();

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {

                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }

    }

    public void eliminarProducto(int idpro) {
        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;


        try {

            st = baseDatos.prepareStatement("delete  from \"TBL_PRODUCTOS\" where \"idProducto\" =?");
            st.setInt(1, idpro);
            st.executeUpdate();
            if (st.executeUpdate() == 0) {
                System.out.println("Se ha eliminado con exito");
            } else {
                System.out.println("Ha ocurrido un error");
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {

                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }


    }

    public void modificarValor(String nombre, int pro, String img) {
        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;


        try {

            st = baseDatos.prepareStatement("UPDATE public.\"TBL_PRODUCTOS\"\n" +
                    "\tSET  nombre=?, \"imgProducto\"=?\n" +
                    "\tWHERE \"idProducto\"=?");

            st.setString(1, nombre);
            st.setString(2, img);
            st.setInt(3, pro);

            st.executeUpdate();

            if (st.executeUpdate() > 0) {
                System.out.println("Actualizado ");
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {

                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }


    }


}
