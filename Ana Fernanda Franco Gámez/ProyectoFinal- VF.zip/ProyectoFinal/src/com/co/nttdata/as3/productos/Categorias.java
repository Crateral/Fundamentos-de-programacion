package com.co.nttdata.as3.productos;

public enum Categorias {
    LACTEOS, FRUTAS, ASEO, GRANOS, PAPELERIA, TECNOLOGIA, BEBIDAS, DULCES;



}
