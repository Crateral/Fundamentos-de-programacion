package com.co.nttdata.ecommerce.entidades;

public enum MetodoPago {
    EFECTIVO,
    PSE,
    TARJETADB,
    NO_APLICA,
    TARjETACR;

}
