package com.co.nttdata.ecommerce.utilitarios;

import com.co.nttdata.ecommerce.entidades.CarritoDeCompras;
import com.co.nttdata.ecommerce.entidades.Categoria;
import com.co.nttdata.ecommerce.entidades.Marca;
import com.co.nttdata.ecommerce.entidades.Producto;
import com.co.nttdata.ecommerce.interfaces.GestionCarritoDeCompra;
import com.co.nttdata.ecommerce.logica.GestionCarritoDeComprasImp;
import com.co.nttdata.ecommerce.logica.ValidarMarcaCategoria;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import static java.lang.Integer.parseInt;

public class ProductosInventario {


    public List leerArchivo(String nombreArchivo) {
        List<String> prod = new ArrayList<>();
        File archivo = new File("C:\\Users\\afrangam\\OneDrive - NTT DATA EMEAL\\Documentos\\Actividades\\" + nombreArchivo);
        Scanner s = null;

        try {
            s = new Scanner(archivo);
            while (s.hasNextLine()) {
                String linea = s.nextLine();
                prod.add(linea);

                //  String dividelinea[] = linea.split(",");

                //  System.out.println(linea);
               /* for (int i = 0; i < dividelinea.length; i++) {
                    System.out.println(" " + dividelinea[i]);
                    a.setNombre(dividelinea[i]);
                    System.out.println(a.getNombre());
                    prod.add(dividelinea[i]);

                }*/

            }

        } catch (Exception e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        } finally {
            try {
                if (s != null) {
                    s.close();
                }
            } catch (Exception e) {
                System.out.println("Error al cerrar la lectura del archivo: " + e.getMessage());
            }
        }

        return prod;
    }


    public List<Producto> dividirDatosProducto(List<String> datos) {

        List<Producto> productosInventario = new ArrayList<>();
        ValidarMarcaCategoria val = new ValidarMarcaCategoria();

//        System.out.println();

        for (String proInv : datos) {
            Producto np = new Producto();
            String datosInventario[] = proInv.split(",");

            np.setIdProducto(Integer.parseInt(datosInventario[0]));
            np.setNombre(datosInventario[1]);
            np.setCantidadDiponible(Integer.parseInt(datosInventario[2]));
            np.setPrecio(Double.parseDouble(datosInventario[3]));
            np.setDescuento(Boolean.valueOf(datosInventario[4]));
            np.setIva(Double.parseDouble(datosInventario[5]));
            np.setDescripcion(datosInventario[6]);
            np.setImg(datosInventario[7]);
            np.setMarca(val.validarMarca(datosInventario[8]));
            np.setCategoria(val.validarCategoria(datosInventario[9]));

            productosInventario.add(np);

            /*System.out.println(np.getIdProducto() + " " + np.getNombre() +
                    " " + np.getCantidadDiponible() + " " +np.getPrecio() + " " + np.getDescuento() +" " +np.getIva() + " " + np.getDescripcion() + " " +
                    np.getImg() + " " + np.getMarca() + " " + np.getCategoria());*/



         /*   for (Producto np : productosInventario) {

                System.out.println(np.getIdProducto() + " " + np.getNombre() + " " + np.getCantidadDiponible() + " " +
                        np.getPrecio() + " " + np.getDescuento() +" " +np.getIva() + " " + np.getDescripcion() + " " +
                        np.getImg() + " " + np.getMarca() + " " + np.getCategoria());

            }
*/
        }


        return productosInventario;
    }


      public List<String> cantidadDisponible(List<Producto> productosInventario) {
        int cantid, nuevaCantidad;
        Producto np = new Producto();
        List<String> prod = new ArrayList<>();
        for (int i = 0; i < productosInventario.size(); i++) {
            cantid = productosInventario.get(i).getCantidadDiponible();
            nuevaCantidad = cantid - productosInventario.get(i).getCantidadDiponible();

            np.setCantidadDiponible(nuevaCantidad);


            System.out.println(productosInventario.get(i).getIdProducto() + " " + productosInventario.get(i).getNombre() +
                    " " + np.getCantidadDiponible() + " " + productosInventario.get(i).getPrecio() +
                    " " + productosInventario.get(i).getDescuento() + " " + productosInventario.get(i).getIva() + " " +
                    productosInventario.get(i).getDescripcion() + " " + productosInventario.get(i).getImg() + " " +
                    productosInventario.get(i).getMarca() + " " + productosInventario.get(i).getCategoria());

            prod.add(productosInventario.get(i).getIdProducto()+","+productosInventario.get(i).getNombre() +
                    "," + np.getCantidadDiponible() + "," + productosInventario.get(i).getPrecio() +
                    " ," + productosInventario.get(i).getDescuento() + "," + productosInventario.get(i).getIva() + ", " +
                    productosInventario.get(i).getDescripcion() + "," + productosInventario.get(i).getImg() + " ," +
                    productosInventario.get(i).getMarca() + "," + productosInventario.get(i).getCategoria()+ "\n");

        }


        return prod;

    }

    public void actualizarInventario(List<String> producInv, String nombreArchivo){
        FileWriter archivo =null;

            try {
                archivo = new FileWriter("C:\\Users\\afrangam\\OneDrive - NTT DATA EMEAL\\Documentos\\Actividades\\" + nombreArchivo, false);

             for(int i =0; i<producInv.size(); i++) {
                 archivo.write( producInv+ "\n");
             }

            } catch (IOException e) {
                throw new RuntimeException(e);
            }



    }

}
