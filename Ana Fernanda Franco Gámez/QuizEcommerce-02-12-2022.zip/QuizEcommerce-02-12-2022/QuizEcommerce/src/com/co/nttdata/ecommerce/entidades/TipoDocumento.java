package com.co.nttdata.ecommerce.entidades;

public enum TipoDocumento {

    CEDULA_DE_CIUDADANIA,
    TARJETA_DE_IDENTIDAD,
    TARJETA_DE_EXTRANGERIA,
    CEDULA_DE_EXTRANGERIA,
    NIT,
    TIPO_DOCUMENTO_EXTRANGERO,
    PASAPORTE;

}
