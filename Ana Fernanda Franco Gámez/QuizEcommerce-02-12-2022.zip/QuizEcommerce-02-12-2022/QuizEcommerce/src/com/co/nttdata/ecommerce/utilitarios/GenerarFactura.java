package com.co.nttdata.ecommerce.utilitarios;

import com.co.nttdata.ecommerce.entidades.*;

import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

public class GenerarFactura {

    Factura f = new Factura();


    public void escribirArchivo(String nombreArchivo, Cliente c, Empresa em, CarritoDeCompras cc) {
        // Empresa em= new Empresa();
        f.setIdFactura(123123);
     /*   em.setNombreEmpresa(em.getNombreEmpresa());
        em.setNitEmpresa(em.getNitEmpresa());
        em.setLogo(em.getLogo());
        em.setDireccion(em.getDireccion());
        em.setTelefono(em.getTelefono());
        c.setNombreUsuario(c.getNombreUsuario());
        c.setTipoIdentificacion(c.getTipoIdentificacion());
        c.setNumeroIdentificacion(c.getNumeroIdentificacion());
        c.setTelefono(c.getTelefono());
        c.setDireccion(c.getDireccion());
        c.setCiudad(c.getCiudad());
        c.setMetodoDePago(c.getMetodoDePago());*/
        f.setDescripcion("Mi primera factura");
        f.setValorTotalConIva(cc.getSubTotalConIva() + cc.getValorEnvio());


        FileWriter archivo = null;

        try {
            archivo = new FileWriter("C:\\Users\\afrangam\\OneDrive - NTT DATA EMEAL\\Documentos\\Actividades\\" + nombreArchivo, false);

            archivo.write("                                   Factura N°. " + f.getIdFactura() + "\n" +
                    "-------------------------------------------------------" + "\n" +
                    "       Factura Electronica Empresa " + em.getNombreEmpresa() + "\n" +
                    "-------------------------------------------------------" + "\n" +
                    "                                    NIT Empresa: " + em.getNitEmpresa() + "\n" +
                    "                                    Logo: " + em.getLogo() + "\n" +
                    "                            Direccion: " + em.getDireccion() + "\n" +
                    "                                      Telefono: " + em.getTelefono() + "\n" +
                    "-------------------------------------------------------" + "\n" +

                    "Nombre: " + c.getNombreUsuario() + "   Tipo id: " + c.getTipoIdentificacion() + "\n" +
                    "Num. id: " + c.getNumeroIdentificacion() + "  Tel: " + c.getTelefono() + "  Direccion: " + c.getDireccion()
                    + "\n" +
                    "Ciudad: " + c.getCiudad() + "  Metodo de pago:  " +
                    c.getMetodoDePago() + "\n" +
                    "-------------------------------------------------------" + "\n" +
                    " ID           Nombre            Cantidad       precio" + "\n");


            for (Producto p : cc.getProductos()) {

                archivo.write(" " + p.getIdProducto() + "           " + p.getNombre() + "           " + p.getCantidadDiponible() +
                        "         " + p.getPrecio() + "\n");
            }
            archivo.write("-------------------------------------------------------" + "\n" +
                    "                            Total productos: " + cc.getSubTotaSinIva() + "\n" +
                    "                                        iva: " + cc.getValorTotalIva() + "\n" +
                    "                               Total pedido: " + cc.getSubTotalConIva() + "\n" +
                    "                                Valor envio: " + cc.getValorEnvio() + "\n" +
                    "                              Total a pagar: " + f.getValorTotalConIva() + "\n" +
                    "-------------------------------------------------------" + "\n" +
                    " Descripcion: " + f.getDescripcion() + "\n" +
                    "-------------------------------------------------------");
            System.out.println("La Factura se ha generado con exito⬇");
            archivo.close();
        } catch (Exception e) {
            System.out.println("Error al escribir el archivo: " + e.getMessage());
        }


    }

    public void leerArchivo(String nombreArchivo) {
        File archivo = new File("C:\\Users\\afrangam\\OneDrive - NTT DATA EMEAL\\Documentos\\Actividades\\" + nombreArchivo);
        Scanner s = null;

        try {
            s = new Scanner(archivo);
            while (s.hasNextLine()) {
                String linea = s.nextLine();
                System.out.println(linea);
            }

        } catch (Exception e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        } finally {
            try {
                if (s != null) {
                    s.close();
                }
            } catch (Exception e) {
                System.out.println("Error al cerrar la lectura del archivo: " + e.getMessage());
            }
        }
    }
}
