import java.util.*;

public class Main {
    public static void main(String[] args) {

        System.out.println("Carrito de compras");
        Scanner x = new Scanner(System.in);
        List<Producto> carrito= new ArrayList<>();

        while (true){
            System.out.println("------------------------------------------------");
            System.out.println("|            🛒 Carrito de compras 🛒         |");
            System.out.println("------------------------------------------------");
            System.out.println("|              1. agregar producto             |");
            System.out.println("|             2. Consultar producto            |");
            System.out.println("|           3. Consultar por categoria         |");
            System.out.println("| 4. ordenar productos de mayor a menor precio |");
            System.out.println("| 5. ordenar productos de menor a mayor precio |");
            System.out.println("|              6. Ordenar por nombre           |");
            System.out.println("|            7. Ordenar por categoria          |");
            System.out.println("------------------------------------------------");
            System.out.println("      Digita la opcion que deseas realizar");

            int opcion = x.nextInt();

            switch (opcion) {
                case 1:
                    System.out.println("Cuantos productos deseas agregar");
                    int nuProd = x.nextInt();
                    String noPro;
                    String categ;
                    int precio;

                    for (int i = 0; i < nuProd; i++) {
                        Producto aggProd = new Producto();
                        System.out.println("Ingresa nombre del producto");
                        noPro = x.next();
                        aggProd.setNombre(noPro);
                        System.out.println("Ingresa el precio del producto");
                        precio = x.nextInt();
                        aggProd.setPrecio(precio);
                        System.out.println("Ingresa la categoria del producto");
                        categ = x.next();
                        aggProd.setCategoria(categ);

                        carrito.add(aggProd);
                    }
                    break;

                case 2:

                    if (carrito.size() != 0) {
                        for (Producto carrCom : carrito) {
                            System.out.println(carrCom.toString());
                        }
                    } else {
                        System.out.println(" No tienes productos en el carrito");
                    }
                    break;

                case 3:

                    if (carrito.size() != 0) {

                        String buCat;
                        int con = 0;
                        for (Producto carrCom : carrito) {
                            System.out.println("categorias Disponibles: " + carrCom.getCategoria());
                        }
                        System.out.println("Escribe la categoria que deseeas consultar");
                        buCat = x.next();
                        for (Producto carrCom : carrito) {
                            if (carrCom.getCategoria().equals(buCat)) {
                                System.out.println("Nombre del producto: " + carrCom.getNombre() + " Precio del producto: " + carrCom.getPrecio() + "  Categoria: " + carrCom.getCategoria());
                            }
                            con = con + 1;
                        }
                    } else {
                        System.out.println(" No tienes productos en el carrito");
                    }
                    break;

                case 4:

                    if (carrito.size() != 0) {
                    System.out.println("Ordenando productos de mayor a menor precio...");
                    carrito.sort(Comparator.comparing(Producto::getPrecio).reversed());
                    for (Producto carrCom : carrito) {
                        System.out.println(carrCom.toString());
                        }
                    }
                    else {
                        System.out.println(" No tienes productos en el carrito");
                    }
                    break;

                case 5:

                    if (carrito.size()!=0) {
                        System.out.println("Ordenando productos de menor a mayor precio...");
                        carrito.sort(Comparator.comparing(Producto::getPrecio));
                        for (Producto carrCom : carrito) {
                            System.out.println(carrCom.toString());
                        }
                    } else {
                        System.out.println(" No tienes productos en el carrito");
                    }
                    break;

                case 6:

                    if (carrito.size()!=0) {
                        System.out.println("Ordenando productos por nombre...");
                        Collections.sort(carrito, Comparator.comparing(Producto::getNombre));
                        for (Producto carrCom : carrito) {

                            System.out.println(carrCom.toString());
                        }
                    } else {
                        System.out.println(" No tienes productos en el carrito");
                    }

                    break;

                case 7:

                    if (carrito.size()!=0) {
                        System.out.println("Ordenando productos por categoria...");
                        Collections.sort(carrito, Comparator.comparing(Producto::getCategoria));
                        for (Producto carrCom : carrito) {
                            System.out.println(carrCom.toString());
                        }
                    } else {
                        System.out.println(" No tienes productos en el carrito");
                    }

                    break;
                default:
                    System.out.println("ingresa una opcion valida");


            }



        }

    }
}