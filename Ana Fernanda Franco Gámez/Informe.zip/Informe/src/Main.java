import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Main {


    public static void main(String[] args) {
        System.out.println("        ¡Informe!");
        Scanner x = new Scanner(System.in);
        int contAdm=0, contEmp=0, contPers=0;
        List<Informe> informe = new ArrayList<>();


        while (true) {
            System.out.println("-------------------------------------------");
            System.out.println("|         Que quieres hacer hoy?          |");
            System.out.println("|           1. Agregar informe            |");
            System.out.println("|           2. Eliminar informe           |");
            System.out.println("|           3. Consultar informe          |");
            System.out.println("|      4. ¿Que tipos de informe tienes?   |");
            System.out.println("|        5. consulta informe por tarea    |");
            System.out.println("|      6. consulta informe por codigo     |");
            System.out.println("-------------------------------------------");

            int opcion = x.nextInt();


            switch (opcion) {
                case 1:
                    System.out.println("Cuantos informes deseas ingresar");
                    int numInf= x.nextInt();
                    System.out.println("Agregando informes....");
                    Random random = new Random();
                    for (int i=0; i<numInf; i++){
                        Informe infLlena = new Informe();
                       // System.out.println("ingresa el codigo del informe");
                        int coInf= random.nextInt(300-1+1)+1;
                        infLlena.setCodigo(coInf);
                       // System.out.println("Elige la tarea: 1. Administrativo. 2. Empresarial. 3. Personal");
                        int taInf=random.nextInt(3-1+1)+1;
                        infLlena.setTarea(infLlena.tareas[taInf-1]);
                        if(taInf==1){
                            contAdm=contAdm+1;
                        } else if (taInf==2) {
                            contEmp=contEmp+1;
                        } else if (taInf==3) {
                            contPers=contPers+1;
                        }
                        informe.add(infLlena);

                    }

                    break;

                case 2:
                    informe.clear();
                    System.out.println("- Informe Eliminado ");

                    break;

                case 3:
                    if(informe.size()!=0){
                        for (Informe informes : informe) {
                            System.out.println(informes.toString());
                        }

                    }else {
                        System.out.println("- No hay informes para mostrar");
                    }

                    break;
                case 4:

                    if(informe.size()!=0){
                        System.out.println("- Tienes "+ contAdm+ " informes con tareas de tipo Administrativo");
                        System.out.println("- Tienes "+ contEmp+ " informes con tareas de tipo Empresarial");
                        System.out.println("- Tienes "+ contPers+ " informes con tareas de tipo Personal");
                        contAdm=0;
                        contEmp=0;
                        contPers=0;
                    }else {
                        System.out.println("- No hay informes para mostrar");
                    }

                    break;

                case 5:
                    if(informe.size()!=0){
                    System.out.println("Digite la tarea a consultar opciones: administrativo, empresarial, personal");
                    String buscar = x.next();

                    int contador = 0;
                    for (Informe informes : informe) {

                        if (informes.getTarea().equals(buscar)) {
                            System.out.println("El informe con codigo: " + informes.getCodigo() + " " +
                                    "tiene la tarea " + informes.getTarea());
                           // System.out.println(informes.toString());
                            contador = contador + 1;

                        }
                    }
                    System.out.println("tienes "+contador+ " tareas de este tipo ");

                    }else {
                        System.out.println("- No hay informes para mostrar");
                    }
                            break;

                case 6:
                    if(informe.size()!=0){
                    System.out.println("Digite la tarea a consultar opciones: administrativo, empresarial, personal");
                    int buscarCodigo = x.nextInt();

                    int cont2 = 0;
                    for (Informe informes : informe) {

                        if (informes.getCodigo() ==buscarCodigo) {
                            System.out.println("El informe con codigo: " + informes.getCodigo() + " " +
                                    "tiene la tarea " + informes.getTarea());
                            // System.out.println(informes.toString());
                            cont2 = cont2 + 1;

                        }else {
                            System.out.println("El codigo ingresado no existe");
                        }
                    }

                    }else {
                        System.out.println("- No hay informes para mostrar");
                    }

                    break;



                default:
                    System.out.println("Opcion no valida, por favor ingrese un numero de las opciones");

            }
        }

    }

    }
