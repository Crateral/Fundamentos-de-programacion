-- se crea la base de datos
-- CREATE DATABASE Gimnasio;

-- se crea la tabla CeoGym 
 CREATE TABLE CeoGym ( 
 idCeoGym int ,
 nombre varchar (30),
 apellido varchar (30),
 telefono int, 
 correo varchar (30),
 contrasenia varchar (30),
 direccion varchar (30), 
 PRIMARY KEY (idCeoGym)
 );
 
-- se crea la tabla administrador
 CREATE TABLE Administrador ( 
 idAdministrador int ,
 nombre varchar (30),
 apellido varchar (30),
 telefono int, 
 correo varchar (30),
 contrasenia varchar (30),
 direccion varchar (30), 
 PRIMARY KEY (idAdministrador)
 );
 
-- se crea la tabla rutinas
 CREATE TABLE Rutinas (
 idRutina int,
 descripcion varchar (60),
 ejercicioPractico varchar,
 duracion int,
 PRIMARY KEY ( idRutina)
 );
 
-- se crea la tabla clases
 CREATE TABLE Clases ( 
 idClase int,
 diaClase varchar,
 hora int,
 PRIMARY KEY ( idClase)
 );
 
-- Se crea la tabla medidas
 CREATE TABLE Medidas (
 idMedida int,
 peso int,
 altura int,
 PRIMARY KEY (idMedida)
 );
 
-- se crea la tabla coach
 CREATE TABLE Coach ( 
 idCoach int ,
 nombre varchar (30),
 apellido varchar (30),
 telefono int, 
 correo varchar (30),
 contrasenia varchar (30),
 direccion varchar (30), 
 idRutina int, 
 idClase int,
 PRIMARY KEY (idCoach),
 FOREIGN KEY (idRutina) REFERENCES Rutinas (idRutina),
 FOREIGN KEY (idClase) REFERENCES Clases (idClase)
 );

-- se crea la tabla usuarios
 CREATE TABLE Usuarios ( 
 idUsuario int ,
 nombre varchar (30),
 apellido varchar (30),
 telefono int, 
 membresia boolean,
 correo varchar (30),
 contrasenia varchar (30),
 direccion varchar (30), 
 idRutina int, 
 idClase int,
 idMedida int,
 PRIMARY KEY (idUsuario),
 FOREIGN KEY (idRutina) REFERENCES Rutinas (idRutina),
 FOREIGN KEY (idClase) REFERENCES Clases (idClase),
 FOREIGN KEY (idMedida) REFERENCES Medidas(idMedida)
 
 );
 
-- se crea la tabla Gym
 CREATE TABLE Gym (
 idGym int, 
 nombre varchar (50),
 direccion varchar(50),
 idCeoGym int,
 idAdministrador int,
 idCoach int, 
 idUsuario int, 
 PRIMARY KEY ( idGym),
 FOREIGN KEY (idCeoGym) REFERENCES CeoGym ( idCeoGym),
 FOREIGN KEY (idAdministrador) REFERENCES Administrador (idAdministrador),
 FOREIGN KEY (idUsuario) REFERENCES Usuarios ( idUsuario),
 FOREIGN KEY (idCoach) REFERENCES Coach (idCoach)
 );
 
 
INSERT INTO CeoGym (idCeoGym, nombre, apellido, telefono, correo, contrasenia, direccion) VALUES (1, "Ana", "Franco", 312772, "ana@gamil.com", "asd123", "calle 2");
INSERT INTO CeoGym (idCeoGym, nombre, apellido, telefono, correo, contrasenia, direccion) VALUES (2, "Fer", "Gamez", 23452, "fer@gamil.com", "fegg23", "calle 5");

INSERT INTO Administrador (idAdministrador, nombre, apellido, telefono, correo,contrasenia, direccion) VALUES (1, "jhenny", "martinez", 8975656, "jhe@gmail.com", "jhenny", "carrera 43");
INSERT INTO Administrador (idAdministrador, nombre, apellido, telefono, correo,contrasenia, direccion) VALUES (2, "Marina", "Gamboa", 65435, "mar@gmail.com", "hjkdfd", "carrera 4");

INSERT INTO Rutinas (idRutina, descripcion, ejercicioPractico, duracion) VALUES(1, "abdominales ", "video explicativo", 15);
INSERT INTO Rutinas (idRutina, descripcion, ejercicioPractico, duracion) VALUES(2, "jumping jacks", "video explicativo", 20);

INSERT INTO Clases (idClase, diaClase, hora) VALUES (1, "Lunes", 8);
INSERT INTO Clases (idClase, diaClase, hora) VALUES (2, "Martes", 10);

INSERT INTO Medidas (idMedida, peso, altura) VALUES (1, 67, 167 );
INSERT INTO Medidas (idMedida, peso, altura) VALUES (2, 60, 165 );

INSERT INTO Coach ( idCoach, nombre, apellido, telefono, correo, contrasenia, direccion, idClase, idRutina) VALUES (1, "luis", "perez", 458756, "lu@gmail.com", "we767f","avenida 2", 2,1);
INSERT INTO Coach ( idCoach, nombre, apellido, telefono, correo, contrasenia, direccion, idClase, idRutina) VALUES (2, "German", "diaz", 7543356, "ger@gmail.com", "lo78jf","avenida 72", 1,2);

INSERT INTO Usuarios ( idUsuario, nombre, apellido, telefono, membresia , correo, contrasenia, direccion, idClase, idRutina, idMedida) VALUES(1, "veronica", "flores", 659875, true, "veer@gmail.com", "we678t", "calle 12", 1,2,1);
INSERT INTO Usuarios ( idUsuario, nombre, apellido, telefono, membresia , correo, contrasenia, direccion, idClase, idRutina, idMedida) VALUES(2, "tilcia", "pico", 9087875, false, "ti@gmail.com", "tit896", "calle 2", 2,1,2);

INSERT INTO Gym (idGym, nombre, direccion, idCeoGym, idAdministrador, idCoach,idUsuario) VALUES ( 1, "GymFit", "calle 21 # 3-4", 1,1,2,1);
INSERT INTO Gym (idGym, nombre, direccion, idCeoGym, idAdministrador, idCoach,idUsuario) VALUES ( 2, "Fit Evolution", "calle 15 # 6-21", 2,2,1,2);

SELECT * FROM CeoGym; 
SELECT * FROM Administrador;
SELECT * FROM Rutinas;
SELECT * FROM Clases;
SELECT * FROM Medidas; 
SELECT * FROM Coach;
SELECT * FROM Usuarios;
SELECT * FROM  Gym ;