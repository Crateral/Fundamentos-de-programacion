import com.co.nttdata.gimnasio.*;

import java.security.spec.RSAOtherPrimeInfo;
import java.sql.SQLOutput;

public class Main {
    public static void main(String[] args) {

        System.out.println("        Software Gym        ");
        System.out.println("-----------------------------");

        System.out.println(" Gestion cuentas de usuario");
        System.out.println("-----------------------------");
        Usuarios nuevo = new Usuarios();
        System.out.println("Registrar Usuario: ");
        nuevo.RegistrarUsuarios();
        System.out.println("Inicia Sesión: ");
        nuevo.Ingresar();
        System.out.println("Consultar usuario: ");
        nuevo.ConsultarDatos();
        System.out.println("Ajustar datos perfil: ");
        nuevo.ModificarCredenciales();
        System.out.println();

        System.out.println("------------------------------");
        System.out.println("Gestion cuentas Colaboradores");
        System.out.println("------------------------------");
        Ceo regisCol = new Ceo();
        System.out.println("Registrar Colaborador: ");
        regisCol.RegistrarColaboradores();
        System.out.println("Consultar Colaborador: ");
        regisCol.ConsultarColaboradores();
        System.out.println();

        System.out.println("------------------------------");
        System.out.println("Registro de rutinas");
        System.out.println("------------------------------");
        Coach newCoach = new Coach();
        System.out.println("Nueva rutina:");
        newCoach.RegistrarRutinas();
        System.out.println("Consultar rutina: ");
        newCoach.ConsultarRutinas();
        System.out.println("Modificar rutina:");
        newCoach.ModificarRutinas();
        System.out.println();

        System.out.println("------------------------------");
        System.out.println("Registro de Medidas");
        System.out.println("------------------------------");
        Medidas nuMed = new Medidas();
        System.out.println("Registrar peso: ");
        nuMed.RegistrarPeso();
        System.out.println("Consultar Peso: ");
        nuMed.ConsultarPeso();
        System.out.println("Calcular indice de masa corporal (IMC):");
        nuMed.CalcularIMC();
        System.out.println();

        System.out.println("------------------------------");
        System.out.println("Clases en el Gym");
        System.out.println("------------------------------");
        Clase nuClas = new Clase();
        System.out.println("Agendar clases: ");
        nuClas.AgendarClase();
        System.out.println("Consultar clase: ");
        nuClas.ConsultarClase();
        System.out.println("Cancelar clase: ");
        nuClas.CancelarClase();
        System.out.println("Modificar clase");
        nuClas.ModificarClase();
        System.out.println("Elegir rutina");
        nuClas.ElegirRutina();
        System.out.println();

        System.out.println("--------------------------------------------------");
        System.out.println("Informacion del Gimnasio mostrada al Administrador");
        System.out.println("--------------------------------------------------");
        Administrador repor = new Administrador();
        System.out.println("Generar Reporte:");
        repor.GenerarReportes();
        System.out.println("Consultar Clase:");
        repor.ConsultarClases();
        System.out.println("Consultar Usuarios:");
        repor.ConsultarUsuarios();
        System.out.println("Consultar Rutinas:");
        repor.ConsultarRutinas();
        System.out.println("Consultar Informacion Coach:");
        repor.ConsultarCoach();
        System.out.println();

        System.out.println("---------------------------------------");
        System.out.println("Informacion del Gimnasio mostrada al Ceo");
        System.out.println("---------------------------------------");
        System.out.println("Consultar Colaboradores: ");
        regisCol.ConsultarColaboradores();
        System.out.println("Consultar Clases");
        regisCol.ConsultarClases();
        System.out.println("Consultar Rutinas: ");
        regisCol.ConsultarRutinas();
        System.out.println("Consultar Coach:");
        regisCol.ConsultarCoach();
        System.out.println("Consultar Usuarios:");
        regisCol.ConsultarUsuarios();
        System.out.println();
    }
}