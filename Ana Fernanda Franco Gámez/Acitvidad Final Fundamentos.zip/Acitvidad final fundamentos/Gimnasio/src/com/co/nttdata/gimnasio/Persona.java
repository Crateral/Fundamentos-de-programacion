package com.co.nttdata.gimnasio;

public class Persona {

    private int idPersona;
    private String nombrePersona;
    private String apellidoPersona;
    private String telefono;
    private String correo;
    private String contraseña;


    public void Persona() {

    }

    public void Persona(int idPersona, String nombrePersona, String apellidoPersona, String telefono, String correo, String contraseña) {
        this.nombrePersona = nombrePersona;
        this.apellidoPersona = apellidoPersona;
        this.telefono = telefono;
        this.correo = correo;
        this.contraseña = contraseña;
    }

    public int getIdPersona() {
        return idPersona;
    }

    public void setIdPersona(int idPersona) {
        this.idPersona = idPersona;
    }

    public String getNombrePersona() {
        return nombrePersona;
    }

    public void setNombrePersona(String nombrePersona) {
        this.nombrePersona = nombrePersona;
    }

    public String getApellidoPersona() {
        return apellidoPersona;
    }

    public void setApellidoPersona(String apellidoPersona) {
        this.apellidoPersona = apellidoPersona;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public void Ingresar() {
        System.out.println("-> bienvenido al sistema ");
    }

    public void ConsultarDatos() {
        System.out.println("-> Datos persona ");
    }

    public void ModificarCredenciales() {
        System.out.println("-> Cambios registrados con exito ");
    }

}