package com.co.nttdata.gimnasio;

public class Usuarios extends Persona {
    private int edad;
    private boolean membresia;

    public int getEdad() {
        return edad;
    }

    public boolean membresia() {
        return membresia;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setMembresia(boolean membresia) {
        this.membresia = membresia;
    }

    public void RegistrarUsuarios() {
        System.out.println("-> Usuario registrado con exito ");
    }
}
