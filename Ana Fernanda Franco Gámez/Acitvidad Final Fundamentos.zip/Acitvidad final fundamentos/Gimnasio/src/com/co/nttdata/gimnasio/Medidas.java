package com.co.nttdata.gimnasio;

public class Medidas {
    private int peso;
    private int altura;

    public int getPeso() {
        return peso;
    }

    public void setPeso(int peso) {
        this.peso = peso;
    }

    public int getAltura() {
        return altura;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }

    public void RegistrarPeso() {
        System.out.println("-> Peso registrado");
    }

    public void ConsultarPeso() {
        System.out.println("-> historiar peso ");
    }

    public void CalcularIMC() {
        System.out.println("-> Se ha calculado su IMC");
    }
}
