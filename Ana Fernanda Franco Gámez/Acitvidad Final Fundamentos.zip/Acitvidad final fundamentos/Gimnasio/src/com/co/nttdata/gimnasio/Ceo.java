package com.co.nttdata.gimnasio;

public class Ceo extends Persona implements Colaboradores {

    public void RegistrarColaboradores() {
        System.out.println("-> Colaborador registrado con exito");
    }

    public void ConsultarColaboradores() {
        System.out.println("-> Lista de Colaboradores ");
    }


    @Override
    public void ConsultarClases() {
        System.out.println("-> El Ceo del Gimnasio consulta las clases ");
    }

    @Override
    public void ConsultarRutinas() {
        System.out.println("-> El Ceo del Gimnasio consulta las Rutinas ");
    }

    @Override
    public void ConsultarUsuarios() {
        System.out.println("-> El Ceo del Gimnasio consulta los usuarios");
    }

    @Override
    public void ConsultarCoach() {
        System.out.println("-> El Ceo del Gimnasio consulta Datos de Coach ");
    }
}
