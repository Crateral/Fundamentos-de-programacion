package com.co.nttdata.gimnasio;

public class Rutinas {

    private int idRutina;
    private String nombre;
    private boolean img;
    private int tiempoPracticar;

    public int getIdRutina() {
        return idRutina;
    }

    public void setIdRutina(int idRutina) {
        this.idRutina = idRutina;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public boolean isImg() {
        return img;
    }

    public void setImg(boolean img) {
        this.img = img;
    }

    public int getTiempoPracticar() {
        return tiempoPracticar;
    }

    public void setTiempoPracticar(int tiempoPracticar) {
        this.tiempoPracticar = tiempoPracticar;
    }


}
