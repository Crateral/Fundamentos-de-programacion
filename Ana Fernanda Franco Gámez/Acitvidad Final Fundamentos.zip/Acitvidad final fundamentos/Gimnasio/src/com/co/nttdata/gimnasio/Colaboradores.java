package com.co.nttdata.gimnasio;

public interface Colaboradores {
    public void ConsultarClases();

    public void ConsultarRutinas();

    public void ConsultarUsuarios();

    public void ConsultarCoach();
}
