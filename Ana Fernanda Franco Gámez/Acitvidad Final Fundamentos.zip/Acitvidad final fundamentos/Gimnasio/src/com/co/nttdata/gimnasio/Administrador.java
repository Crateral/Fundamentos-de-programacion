package com.co.nttdata.gimnasio;

public class Administrador extends Persona implements Colaboradores {

    public void GenerarReportes() {
        System.out.println("-> Se ha generado el reporte con exito 📄");

    }

    @Override
    public void ConsultarClases() {
        System.out.println("-> El Administrador del Gimnasio consulta las clases ");
    }

    @Override
    public void ConsultarRutinas() {
        System.out.println("-> El Administrador del Gimnasio consulta las Rutinas ");

    }

    @Override
    public void ConsultarUsuarios() {
        System.out.println("-> El Administrador del Gimnasio consulta los usuarios");

    }

    @Override
    public void ConsultarCoach() {
        System.out.println("-> El Administrador del Gimnasio consulta datos del Coach ");

    }
}
