package com.co.nttdata.gimnasio;

public class Clase extends Usuarios {
    private int idClase;
    private int horaClase;

    public int getIdClase() {
        return idClase;
    }

    public void setIdClase(int idClase) {
        this.idClase = idClase;
    }

    public int getHoraClase() {
        return horaClase;
    }

    public void setHoraClase(int horaClase) {
        this.horaClase = horaClase;
    }

    public void AgendarClase() {
        System.out.println("-> Clase agendada");

    }

    public void ConsultarClase() {
        System.out.println("-> lista de clases");
    }

    public void CancelarClase() {
        System.out.println("-> Clase cancelada");
    }

    public void ModificarClase() {
        System.out.println("-> Cambio de clase registrado");
    }

    public void ElegirRutina() {
        System.out.println("-> Rutina agendada a la clase");
    }

}
