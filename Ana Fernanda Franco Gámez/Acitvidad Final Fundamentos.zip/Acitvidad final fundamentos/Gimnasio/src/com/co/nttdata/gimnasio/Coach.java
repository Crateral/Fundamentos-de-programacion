package com.co.nttdata.gimnasio;

public class Coach extends Persona {
    public void RegistrarRutinas() {
        System.out.println("-> Rutina registrada");

    }

    public void ConsultarRutinas() {
        System.out.println("-> Listado de rutinas");
    }

    public void ModificarRutinas() {
        System.out.println("-> Cambios guardados exitosamente ");
    }

}
