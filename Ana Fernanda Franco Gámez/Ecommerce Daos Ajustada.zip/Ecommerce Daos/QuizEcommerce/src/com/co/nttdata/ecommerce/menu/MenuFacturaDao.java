package com.co.nttdata.ecommerce.menu;

import com.co.nttdata.ecommerce.daos.CarritoDeComprasDAO;
import com.co.nttdata.ecommerce.daos.FacturaDao;
import com.co.nttdata.ecommerce.entidades.CarritoDeCompras;
import com.co.nttdata.ecommerce.entidades.Factura;

import java.util.Scanner;

public class MenuFacturaDao {


    FacturaDao facD = new FacturaDao();
    int opcion;
    Scanner x = new Scanner(System.in);


    Factura fac = new Factura();


    public void menuFactura() {
        do {
            System.out.println("1. Agregar Factura");
            System.out.println("2. Consultar Factura");
            System.out.println("3. Buscar Factura");
            System.out.println("4. Eliminar Factura");
            System.out.println("5. Modificar Factura");
            opcion = x.nextInt();
            switch (opcion) {
                case 1:

                    fac.setFecha(null);
                    fac.setEmpresa(23496);
                    fac.setCliente(2);
                    fac.setDescripcion("Factura electronica");
                    fac.setProductos(5);
                    fac.setValorTotalSinIva(2000000);
                    fac.setValorTotalConIva(2400000);

                    facD.agregarFactura(fac);

                    break;
                case 2:

                    facD.consultaFactura();
                    break;
                case 3:
                    System.out.println("Que Factura quieres buscar");
                    int fact = x.nextInt();
                    facD.buscarFactura(fact);
                    break;
                case 4:
                    System.out.println("Ingresa el id de la factura que quieres eliminar");
                    int idFact = x.nextInt();
                    facD.eliminarFactura(idFact);


                    break;
                case 5:
                    System.out.println("Id Factura a modificar");
                    int id = x.nextInt();
                    System.out.println("Descripcion");
                    String des = x.next();
                    System.out.println();
                    facD.modificarFactura(id, des);

                    break;


            }
        } while (opcion < 5);
    }

}

