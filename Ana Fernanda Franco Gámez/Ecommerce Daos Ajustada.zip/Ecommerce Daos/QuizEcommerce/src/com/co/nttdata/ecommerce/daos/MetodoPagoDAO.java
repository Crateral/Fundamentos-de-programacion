package com.co.nttdata.ecommerce.daos;

import com.co.nttdata.ecommerce.entidades.MetodoPago;
import com.co.nttdata.ecommerce.entidades.TipoDocumento;
import com.co.nttdata.ecommerce.utilitarios.ConexionBD;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MetodoPagoDAO {
    ConexionBD cone = new ConexionBD();

    public List<MetodoPago> consultarMetodoPago() {
        Connection baseDatos = cone.conectarBD();
        Statement st = null;
        ResultSet rs = null;
        List<MetodoPago> lisMetPag = new ArrayList<>();
        try {

            st = baseDatos.createStatement();
            rs = st.executeQuery("select * from \"TBL_METODOSDEPAGO\"");

            while (rs.next()) {

                MetodoPago mep = new MetodoPago();
                mep.setIdMetodopago(rs.getInt("idMetodopago"));
                mep.setDescripccion(rs.getString("descripcionPago"));
                lisMetPag.add(mep);
            }


        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                rs.close();
                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }

        for (MetodoPago lmp : lisMetPag) {
            System.out.println("Id Metodo Pago: " + lmp.getIdMetodopago());
            System.out.println("Descripcion : " + lmp.getDescripccion());


            System.out.println("--");
        }
        return lisMetPag;
    }


    public void buscarMetodoPagp(int noMP) {
        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;
        ResultSet rs = null;

        try {

            st = baseDatos.prepareStatement("select * from \"TBL_METODOSDEPAGO\" where \"idMetodopago\"=?");

            st.setInt(1, noMP);
            rs = st.executeQuery();

            while (rs.next()) {
                MetodoPago mep = new MetodoPago();
                mep.setIdMetodopago(rs.getInt("idMetodopago"));
                mep.setDescripccion(rs.getString("descripcionPago"));
                System.out.println("Id Metodo Pago: " + mep.getIdMetodopago());
                System.out.println("Descripcion : " + mep.getDescripccion());

            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                rs.close();
                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }


    }

    public void agregarMetodoPago(MetodoPago met) {

        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;

        try {

            st = baseDatos.prepareStatement("INSERT INTO public.\"TBL_METODOSDEPAGO\"(\n" +
                    "\t \"descripcionPago\")\n" +
                    "\tVALUES (?)");


            st.setString(1, met.getDescripccion());
            st.executeUpdate();

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {

                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }

    }

    public void eliminarMetodoPago(int idmet) {
        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;


        try {

            st = baseDatos.prepareStatement("delete  from \"TBL_METODOSDEPAGO\" where \"idMetodopago\" =?");
            st.setInt(1, idmet);
            st.executeUpdate();
            if (st.executeUpdate() == 0) {
                System.out.println("Se ha eliminado con exito");
            } else {
                System.out.println("Ha ocurrido un error");
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {

                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }


    }

    public void modificarValor(String nomb, int id) {
        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;


        try {

            st = baseDatos.prepareStatement("UPDATE \"TBL_METODOSDEPAGO\"\n" +
                    "\tSET   \"descripcionPago\"=?\n" + "\tWHERE \"idMetodopago\"=?");
            st.setString(1, nomb);
            st.setInt(2, id);


            st.executeUpdate();

            if (st.executeUpdate() > 0) {
                System.out.println("Actualizado ");
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {

                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }


    }

}

