package com.co.nttdata.ecommerce.daos;

import com.co.nttdata.ecommerce.entidades.Categoria;
import com.co.nttdata.ecommerce.entidades.Marca;
import com.co.nttdata.ecommerce.utilitarios.ConexionBD;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CategoriaDAO {

    ConexionBD cone = new ConexionBD();

    public List<Categoria> consultarCategoria() {
        Connection baseDatos = cone.conectarBD();
        Statement st = null;
        ResultSet rs = null;
        List<Categoria> listCategoria = new ArrayList<>();
        try {

            st = baseDatos.createStatement();
            rs = st.executeQuery("select * from \"TBL_CATEGORIAS\"");

            while (rs.next()) {

                Categoria cat = new Categoria();
                cat.setIdCategoria(rs.getInt("idCategoria"));
                cat.setNombreCategoria(rs.getString("nombreCategoria"));
                cat.setDescuento(rs.getDouble("descuento"));
                cat.setIva(rs.getDouble("iva"));

                listCategoria.add(cat);
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                rs.close();
                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }

        for (Categoria lc : listCategoria) {
            System.out.println("Id Categoria: " + lc.getIdCategoria());
            System.out.println("Nombre Categoria: " + lc.getNombreCategoria());
            System.out.println("Descuento: " + lc.getDescuento());
            System.out.println("Iva: " + lc.getIva());
            System.out.println("--");
        }
        return listCategoria;
    }

    // "idCategoria"      "nombreCategoria"    descuento   iva double

    public void buscarCategoria(String nombrecat) {
        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;
        ResultSet rs = null;

        try {

            st = baseDatos.prepareStatement("select * from \"TBL_CATEGORIAS\" where \"nombreCategoria\"=?");

            st.setString(1, nombrecat);
            rs = st.executeQuery();

            while (rs.next()) {

                Categoria cat = new Categoria();
                cat.setIdCategoria(rs.getInt("idCategoria"));
                cat.setNombreCategoria(rs.getString("nombreCategoria"));
                cat.setDescuento(rs.getDouble("descuento"));
                cat.setIva(rs.getDouble("iva"));
                System.out.println("Id Categoria: " + cat.getIdCategoria());
                System.out.println("Nombre Categoria: " + cat.getNombreCategoria());
                System.out.println("Descuento: " + cat.getDescuento());
                System.out.println("Iva: " + cat.getIva());
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                rs.close();
                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }


    }

    public void agregarCategoria(Categoria categ) {

        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;

        try {

            st = baseDatos.prepareStatement("  INSERT INTO \"TBL_CATEGORIAS\"(\n" +
                    "                      \"nombreCategoria\", descuento, iva)\n" +
                    "            VALUES (?, ?, ?)");


            st.setString(1, categ.getNombreCategoria());
            st.setDouble(2, categ.getDescuento());
            st.setDouble(3, categ.getIva());
            st.executeUpdate();

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {

                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }

    }

    public void eliminarCategoria(int idCat) {
        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;


        try {

            st = baseDatos.prepareStatement("delete  from \"TBL_CATEGORIAS\" where \"idCategoria\" =?");
            st.setInt(1, idCat);
            st.executeUpdate();
            if (st.executeUpdate() == 0) {
                System.out.println("Se ha eliminado con exito");
            } else {
                System.out.println("Ha ocurrido un error");
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {

                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }


    }

    public void modificarValor(String nomb, double des, int id) {
        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;


        try {

            st = baseDatos.prepareStatement("UPDATE \"TBL_CATEGORIAS\"\n" +
                    "\tSET   \"nombreCategoria\"=?, \"descuento\"=?\n" +
                    "\tWHERE \"idCategoria\"=?");
            st.setString(1, nomb);
            st.setDouble(2, des);
            st.setInt(3, id);

            st.executeUpdate();

            if (st.executeUpdate() > 0) {
                System.out.println("Actualizado ");
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {

                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }


    }


}
