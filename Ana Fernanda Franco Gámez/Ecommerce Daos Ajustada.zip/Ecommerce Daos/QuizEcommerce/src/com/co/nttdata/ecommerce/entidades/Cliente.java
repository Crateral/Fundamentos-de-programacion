package com.co.nttdata.ecommerce.entidades;

import java.io.Serializable;

public class Cliente extends Usuario implements Serializable {

    //   "idCliente", "nombreCliente", "idTipodocumento", "numeroDocumento",
    //  correo, contrasenia, direccion, "idCiudad", estado, "idMetodopago"

    private int idCliente;
    private String nombre;
    private String numeroIdentificacion;
    private int tipoIdentificacion;
    private String correo;
    private String contrasenia;
    private String telefono;
    private String direccion;
    private int ciudad;
    private boolean estado;
    private int metodoDePago;


    public Cliente() {
        super();
    }

    public Cliente(int id, String nombreUsuario, String contrasenia, int tipoIdentificacion,
                   String numeroIdentificacion, String correo, String telefono, String direccion, int ciudad,
                   boolean estado, int metodoDePago) {
        super(id, nombreUsuario, contrasenia);
        this.numeroIdentificacion = numeroIdentificacion;
        this.tipoIdentificacion = tipoIdentificacion;
        this.correo = correo;
        this.telefono = telefono;
        this.direccion = direccion;
        this.ciudad = ciudad;
        this.estado = estado;
        this.metodoDePago = metodoDePago;
    }

    public int getCiudad() {
        return ciudad;
    }

    public void setCiudad(int ciudad) {
        this.ciudad = ciudad;
    }

    public Cliente(int id, String nombreUsuario, String contrasenia) {
        super(id, nombreUsuario, contrasenia);
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public boolean getEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public String getNumeroIdentificacion() {
        return numeroIdentificacion;
    }

    public void setNumeroIdentificacion(String numeroIdentificacion) {
        this.numeroIdentificacion = numeroIdentificacion;
    }

    public int getTipoIdentificacion() {
        return tipoIdentificacion;
    }

    public void setTipoIdentificacion(int tipoIdentificacion) {
        this.tipoIdentificacion = tipoIdentificacion;
    }

    public int getMetodoDePago() {
        return metodoDePago;
    }

    public void setMetodoDePago(int metodoDePago) {
        this.metodoDePago = metodoDePago;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String getContrasenia() {
        return contrasenia;
    }

    @Override
    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }

    @Override
    public String toString() {
        return "[ -Id Usuario:" + getId() + " -Nombre: " + getNombreUsuario() + " -Tipo identificacion: " + getTipoIdentificacion() +
                " -Numero identificacion: " + getNumeroIdentificacion() + " -Correo: " + getCorreo() + " -Contraseña " + getContrasenia() +
                " -Direccion: " + getDireccion() + " Ciudad: " + getCiudad() + " -Telefono: " + getTelefono() +
                " -Metodo Pago " + getMetodoDePago() + " ]";
    }
}
