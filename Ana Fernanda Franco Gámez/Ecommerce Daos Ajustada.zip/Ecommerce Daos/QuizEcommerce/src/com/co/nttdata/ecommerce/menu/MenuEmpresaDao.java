package com.co.nttdata.ecommerce.menu;

import com.co.nttdata.ecommerce.daos.CategoriaDAO;
import com.co.nttdata.ecommerce.daos.EmpresaDAO;
import com.co.nttdata.ecommerce.entidades.Categoria;
import com.co.nttdata.ecommerce.entidades.Empresa;

import java.util.Scanner;

public class MenuEmpresaDao {
    //"idEmpresa"  "nombreEmpresa"  "imgLogo"  direccion telefono

    EmpresaDAO empD = new EmpresaDAO();
    int opcion, id;
    Scanner x = new Scanner(System.in);
    Empresa nemp = new Empresa();


    public void menuEmpresa() {
        do {
            System.out.println("1. Agregar Empresa");
            System.out.println("2. Consultar Empresa");
            System.out.println("3. Buscar Empresa");
            System.out.println("4. Eliminar Empresa");
            System.out.println("5. Modificar Empresa");
            opcion = x.nextInt();
            switch (opcion) {
                case 1:
                    nemp.setNitEmpresa(37866);
                    nemp.setNombreEmpresa("lutifraga");
                    nemp.setLogo("../img/emp.png");
                    nemp.setDireccion("Calle 3 # 2-11");
                    nemp.setTelefono("31244234");

                    empD.agregarEmpresa(nemp);

                    break;
                case 2:

                    empD.consultarEmpresa();
                    break;
                case 3:
                    System.out.println("Que Empresa quieres buscar");
                    String emp = x.next();
                    empD.buscarEmpresa(emp);
                    break;
                case 4:
                    System.out.println("Ingresa el id de la empresa que quieres eliminar");
                    id = x.nextInt();
                    empD.eliminarEmpresa(id);

                    break;
                case 5:
                    System.out.println("Id de la empresa a modificar");
                    id = x.nextInt();
                    System.out.println("Nuevo nombre");
                    String nomb = x.next();
                    System.out.println("Nuevo logo");
                    String log = x.next();
                    System.out.println("N. telefono");
                    String tel = x.next();
                    System.out.println();
                    empD.modificarValor(nomb, log, id, tel);
                    break;


            }
        } while (opcion < 5);
    }

}
