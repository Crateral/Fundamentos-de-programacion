package com.co.nttdata.ecommerce.daos;

import com.co.nttdata.ecommerce.entidades.CarritoDeCompras;
import com.co.nttdata.ecommerce.entidades.Cliente;
import com.co.nttdata.ecommerce.utilitarios.ConexionBD;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClienteDAO {
    ConexionBD cone = new ConexionBD();


    public List<Cliente> consultarCliente() {
        Connection baseDatos = cone.conectarBD();
        Statement st = null;
        ResultSet rs = null;
        List<Cliente> listClien = new ArrayList<>();
        try {

            st = baseDatos.createStatement();
            rs = st.executeQuery("select * from \"TBL_CLIENTES\"");

            while (rs.next()) {
                Cliente cli = new Cliente();
                cli.setIdCliente(rs.getInt("idCliente"));
                cli.setNombre(rs.getString("nombreCliente"));
                cli.setTipoIdentificacion(rs.getInt("idTipodocumento"));
                cli.setNumeroIdentificacion(rs.getString("numeroDocumento"));
                cli.setCorreo(rs.getString("correo"));
                cli.setContrasenia(rs.getString("contrasenia"));
                cli.setDireccion(rs.getString("direccion"));
                cli.setCiudad(rs.getInt("idCiudad"));
                cli.setEstado(rs.getBoolean("estado"));
                cli.setMetodoDePago(rs.getInt("idMetodopago"));
                listClien.add(cli);
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                rs.close();
                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }


        for (Cliente lcl : listClien) {
            System.out.println("Id Cliente: " +lcl.getIdCliente() );
            System.out.println("Nombre Cliente: " + lcl.getNombre());
            System.out.println("Id Tipo Documento: " + lcl.getTipoIdentificacion());
            System.out.println("Numero ID: " + lcl.getNumeroIdentificacion());
            System.out.println("Correo: " + lcl.getCorreo());
            System.out.println("Contraseña: " + lcl.getContrasenia());
            System.out.println("Direccion: " + lcl.getDireccion());
            System.out.println("Id Ciudad: " + lcl.getCiudad());
            System.out.println("Estado: "+lcl.getEstado());
            System.out.println("Metodo Pago: "+lcl.getMetodoDePago());
            System.out.println("--");
        }
        return listClien;
    }

    public void buscarCliente(int nomCl) {
        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;
        ResultSet rs = null;

        try {

            st = baseDatos.prepareStatement("select * from \"TBL_CLIENTES\" where \"idCliente\" =?");
            st.setInt(1, nomCl);
            rs = st.executeQuery();

            while (rs.next()) {
                Cliente cli = new Cliente();
                cli.setIdCliente(rs.getInt("idCliente"));
                cli.setNombre(rs.getString("nombreCliente"));
                cli.setTipoIdentificacion(rs.getInt("idTipodocumento"));
                cli.setNumeroIdentificacion(rs.getString("numeroDocumento"));
                cli.setCorreo(rs.getString("correo"));
                cli.setContrasenia(rs.getString("contrasenia"));
                cli.setDireccion(rs.getString("direccion"));
                cli.setCiudad(rs.getInt("idCiudad"));
                cli.setEstado(rs.getBoolean("estado"));
                cli.setMetodoDePago(rs.getInt("idMetodopago"));

                System.out.println("Id Cliente: " +cli.getIdCliente() );
                System.out.println("Nombre Cliente: " + cli.getNombre());
                System.out.println("Id Tipo Documento: " + cli.getTipoIdentificacion());
                System.out.println("Numero ID: " + cli.getNumeroIdentificacion());
                System.out.println("Correo: " + cli.getCorreo());
                System.out.println("Contraseña: " + cli.getContrasenia());
                System.out.println("Direccion: " + cli.getDireccion());
                System.out.println("Id Ciudad: " + cli.getCiudad());
                System.out.println("Estado: "+cli.getEstado());
                System.out.println("Metodo Pago: "+cli.getMetodoDePago());
                System.out.println("--");


            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                rs.close();
                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }


    }

    public void agregarCliente(Cliente cl) {

        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;

        try {

            st = baseDatos.prepareStatement("INSERT INTO public.\"TBL_CLIENTES\"(\n" +
                    "\t \"nombreCliente\", \"idTipodocumento\", \"numeroDocumento\", correo, contrasenia, " +
                    "direccion, \"idCiudad\", estado, \"idMetodopago\")\n" +
                    "\tVALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            st.setString(1,cl.getNombre());
            st.setInt(2,cl.getTipoIdentificacion());
            st.setString(3,cl.getNumeroIdentificacion());
            st.setString(4,cl.getCorreo());
            st.setString(5, cl.getContrasenia());
            st.setString(6, cl.getDireccion());
            st.setInt(7,cl.getCiudad());
            st.setBoolean(8,cl.getEstado());
            st.setInt(9,cl.getMetodoDePago());


            st.executeUpdate();

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {

                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }

    }

    public void eliminarCliente(int idpro) {
        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;


        try {

            st = baseDatos.prepareStatement("delete  from \"TBL_CLIENTES\" where \"idCliente\" =?");
            st.setInt(1, idpro);
            st.executeUpdate();
            if (st.executeUpdate() == 0) {
                System.out.println("Se ha eliminado con exito");
            } else {
                System.out.println("Ha ocurrido un error");
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {

                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }


    }

    public void modificarValor(int pro, String cat) {
        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;


        try {

            st = baseDatos.prepareStatement("UPDATE public.\"TBL_CLIENTES\"\n" +
                    "\tSET \"nombreCliente\"=?\n" +
                    "\tWHERE \"idCliente\"=?");

            //    st.setDate(1, fec);
            st.setString(1, cat);
            st.setInt(2, pro);

            st.executeUpdate();

            if (st.executeUpdate() > 0) {
                System.out.println("Actualizado ");
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {

                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }


    }


}
