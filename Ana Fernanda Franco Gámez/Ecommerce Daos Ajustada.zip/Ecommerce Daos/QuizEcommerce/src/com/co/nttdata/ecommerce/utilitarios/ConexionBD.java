package com.co.nttdata.ecommerce.utilitarios;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConexionBD {

    private static final String URL = "jdbc:postgresql://localhost:5432/BD_ECOMMERCE";
    private static final String USUARIO = "postgres";
    private static final String CONTRASENA = "ANAfer123";

    public Connection conectarBD() {

        Connection baseDatos = null;

        try {
            baseDatos = DriverManager.getConnection(URL, USUARIO, CONTRASENA);
          //  System.out.println("Conexion Exitosa");
        } catch (Exception e) {
            System.out.println("Error : " + e.getMessage());
        }
        return baseDatos;
    }

    public void desconectarBD(Connection baseDatos) {

        try {
            baseDatos.close();
        } catch (Exception e) {
            System.out.println("Error : " + e.getMessage());
        }

    }

}