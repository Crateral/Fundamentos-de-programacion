package com.co.nttdata.ecommerce.menu;

import com.co.nttdata.ecommerce.daos.CiudadDAO;
import com.co.nttdata.ecommerce.daos.ClienteDAO;
import com.co.nttdata.ecommerce.entidades.Ciudad;
import com.co.nttdata.ecommerce.entidades.Cliente;

import java.util.Scanner;

public class MenuClienteDao {
    ClienteDAO cliD = new ClienteDAO();
    int opcion, id;
    Scanner x = new Scanner(System.in);

    Cliente cl= new Cliente();


    public void menuCliente() {
        do {
            System.out.println("1. Agregar Cliente");
            System.out.println("2. Consultar Cliente");
            System.out.println("3. Buscar Cliente");
            System.out.println("4. Eliminar Cliente");
            System.out.println("5. Modificar Cliente");
            opcion = x.nextInt();
            switch (opcion) {
                case 1:

                    cl.setNombre("Matias");
                    cl.setTipoIdentificacion(4);
                    cl.setNumeroIdentificacion("329761");
                    cl.setCorreo("matias@gmail.com");
                    cl.setContrasenia("mat899");
                    cl.setDireccion("calle 4# 1-2");
                    cl.setCiudad(7);
                    cl.setEstado(true);
                    cl.setMetodoDePago(3);

                    cliD.agregarCliente(cl);



                    break;
                case 2:

                    cliD.consultarCliente();
                    break;
                case 3:
                    System.out.println("Id del Cliente quieres buscar");
                    int ci = x.nextInt();
                    cliD.buscarCliente(ci);
                    break;
                case 4:
                    System.out.println("Ingresa el id del cliente que quieres eliminar");
                    id = x.nextInt();
                    cliD.eliminarCliente(id);

                    break;
                case 5:
                    System.out.println("Id del cliente a modificar");
                    id = x.nextInt();
                    System.out.println("Nombre");
                    String nomb = x.next();

                    System.out.println();
                    cliD.modificarValor(id,nomb);
                    break;


            }
        } while (opcion < 5);
    }

}

