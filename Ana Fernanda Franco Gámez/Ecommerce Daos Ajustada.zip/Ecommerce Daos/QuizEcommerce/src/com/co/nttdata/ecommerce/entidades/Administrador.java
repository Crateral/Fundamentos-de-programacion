package com.co.nttdata.ecommerce.entidades;

import java.io.Serializable;

public class Administrador extends Usuario implements Serializable {

    private int idAministrador;
private String nombre;
private String contrasenia;
    private String correo;
    private boolean estado;
    private String numeroIdentificacion;
    private int tipoIdentificacion;

    public Administrador() {
        super();
    }

    public Administrador(String correo, boolean estado, int tipoIdentificacion, String numeroIdentificacion) {
        super();
        this.correo = correo;
        this.estado = estado;
        this.numeroIdentificacion = numeroIdentificacion;
        this.tipoIdentificacion = tipoIdentificacion;
    }

    public Administrador(int id, int tipoIdentificacion, String numeroIdentificacion, String nombreUsuario, String correo, String contrasenia, boolean estado) {
        super(id, nombreUsuario, contrasenia);
        this.correo = correo;
        this.estado = estado;
        this.numeroIdentificacion = numeroIdentificacion;
        this.tipoIdentificacion = tipoIdentificacion;
    }


    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public boolean getEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public String getNumeroIdentificacion() {
        return numeroIdentificacion;
    }

    public void setNumeroIdentificacion(String numeroIdentificacion) {
        this.numeroIdentificacion = numeroIdentificacion;
    }

    public int getTipoIdentificacion() {
        return tipoIdentificacion;
    }

    public void setTipoIdentificacion(int tipoIdentificacion) {
        this.tipoIdentificacion = tipoIdentificacion;
    }

    public int getIdAministrador() {
        return idAministrador;
    }

    public void setIdAministrador(int idAministrador) {
        this.idAministrador = idAministrador;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String getContrasenia() {
        return contrasenia;
    }

    @Override
    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }

    public boolean isEstado() {
        return estado;
    }

    @Override
    public String toString() {
        return "[ -Id Usuario:" + getId() + " -Nombre: " + getNombreUsuario() + " -Tipo identificacion: " + getTipoIdentificacion() +
                " -Numero identificacion: " + getNumeroIdentificacion() + " -Correo: " + getCorreo() + " -Contraseña "
                + getContrasenia() + "-Estado: " + getEstado() + " ]";
    }
}
