package com.co.nttdata.ecommerce.menu;

import com.co.nttdata.ecommerce.daos.MarcaDAO;
import com.co.nttdata.ecommerce.daos.ProductoDAO;
import com.co.nttdata.ecommerce.entidades.Marca;
import com.co.nttdata.ecommerce.entidades.Producto;

import java.util.Scanner;

public class MenuProductoDao {

    // "idProducto", nombre, cantidad, precio, descuento, "valorDescuento", "imgProducto", "idMarca", "idCategoria"

    ProductoDAO proD = new ProductoDAO();
    int opcion;
    Scanner x = new Scanner(System.in);
    Producto prod = new Producto();

    public void menuProductos() {
        do {
            System.out.println("1. Agregar Producto");
            System.out.println("2. Consultar Producto");
            System.out.println("3. Buscar Producto");
            System.out.println("4. Eliminar Producto");
            System.out.println("5. Modificar Producto");
            opcion = x.nextInt();
            switch (opcion) {
                case 1:

                    prod.setNombre("lapiz");
                    prod.setCantidadDiponible(20);
                    prod.setPrecio(1000);
                    prod.setDescuento(false);
                    prod.setValorDescuento(15000);
                    prod.setImg("../img/lapiz.png");
                    prod.setMarca(2);
                    prod.setCategoria(3);
                    proD.agregarProducto(prod);
                    break;
                case 2:

                    proD.consultarProducto();
                    break;
                case 3:
                    System.out.println("Que Producto quieres buscar");
                    String pr = x.next();
                    proD.buscarProducto(pr);
                    break;
                case 4:
                    System.out.println("Ingresa el id del producto que quieres eliminar");
                    int idpr = x.nextInt();
                    proD.eliminarProducto(idpr);
                    break;
                case 5:
                    System.out.println("Id del producto a modificar");
                    int id = x.nextInt();
                    System.out.println("Nuevo nombre");
                    String nomb = x.next();
                    System.out.println("Imagen");
                    String img = x.next();
                    System.out.println();
                    proD.modificarValor(nomb, id, img);
                    break;


            }
        } while (opcion < 5);
    }
}
