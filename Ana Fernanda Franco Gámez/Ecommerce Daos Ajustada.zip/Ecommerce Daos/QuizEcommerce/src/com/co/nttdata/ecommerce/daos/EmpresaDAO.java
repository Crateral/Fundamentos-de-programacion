package com.co.nttdata.ecommerce.daos;

import com.co.nttdata.ecommerce.entidades.Categoria;
import com.co.nttdata.ecommerce.entidades.Empresa;
import com.co.nttdata.ecommerce.utilitarios.ConexionBD;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EmpresaDAO {
    ConexionBD cone = new ConexionBD();

    //"idEmpresa"  "nombreEmpresa"  "imgLogo"  direccion telefono
    public List<Empresa> consultarEmpresa() {
        Connection baseDatos = cone.conectarBD();
        Statement st = null;
        ResultSet rs = null;
        List<Empresa> listEmpresas = new ArrayList<>();
        try {

            st = baseDatos.createStatement();
            rs = st.executeQuery("select * from \"TBL_DATOSEMPRESA\"");

            while (rs.next()) {

                Empresa emp = new Empresa();
                emp.setNitEmpresa(rs.getInt("idEmpresa"));
                emp.setNombreEmpresa(rs.getString("nombreEmpresa"));
                emp.setLogo(rs.getString("imgLogo"));
                emp.setDireccion(rs.getString("direccion"));
                emp.setTelefono(rs.getString("telefono"));

                listEmpresas.add(emp);
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                rs.close();
                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }

        for (Empresa le : listEmpresas) {
            System.out.println("Id empresa: " + le.getNitEmpresa());
            System.out.println("Nombre empresa: " + le.getNombreEmpresa());
            System.out.println("Img Logo: " + le.getLogo());
            System.out.println("Direccion: " + le.getDireccion());
            System.out.println("Telefono: " + le.getTelefono());

            System.out.println("--");
        }
        return listEmpresas;
    }


    public void buscarEmpresa(String nomEmp) {
        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;
        ResultSet rs = null;

        try {

            st = baseDatos.prepareStatement("select * from \"TBL_DATOSEMPRESA\" where \"nombreEmpresa\"=?");

            st.setString(1, nomEmp);
            rs = st.executeQuery();

            while (rs.next()) {

                Empresa emp = new Empresa();
                emp.setNitEmpresa(rs.getInt("idEmpresa"));
                emp.setNombreEmpresa(rs.getString("nombreEmpresa"));
                emp.setLogo(rs.getString("imgLogo"));
                emp.setDireccion(rs.getString("direccion"));
                emp.setTelefono(rs.getString("telefono"));
                System.out.println("Id empresa: " + emp.getNitEmpresa());
                System.out.println("Nombre empresa: " + emp.getNombreEmpresa());
                System.out.println("Img Logo: " + emp.getLogo());
                System.out.println("Direccion: " + emp.getDireccion());
                System.out.println("Telefono: " + emp.getTelefono());
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                rs.close();
                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }


    }

    public void agregarEmpresa(Empresa emp) {

        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;

        try {

            st = baseDatos.prepareStatement("INSERT INTO \"TBL_DATOSEMPRESA\"(\n" +
                    "\t \"idEmpresa\",\"nombreEmpresa\", \"imgLogo\", direccion, telefono)\n" +
                    "\tVALUES (?, ?, ?, ?, ?)");


            st.setInt(1, emp.getNitEmpresa());
            st.setString(2, emp.getNombreEmpresa());
            st.setString(3, emp.getLogo());
            st.setString(4, emp.getDireccion());
            st.setString(5, emp.getTelefono());
            st.executeUpdate();

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {

                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }

    }

    public void eliminarEmpresa(int idEmp) {
        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;


        try {

            st = baseDatos.prepareStatement("delete  from \"TBL_DATOSEMPRESA\" where \"idEmpresa\" =?");
            st.setInt(1, idEmp);
            st.executeUpdate();
            if (st.executeUpdate() == 0) {
                System.out.println("Se ha eliminado con exito");
            } else {
                System.out.println("Ha ocurrido un error");
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {

                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }


    }

    public void modificarValor(String nomb, String logo, int id, String tel) {
        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;


        try {

            st = baseDatos.prepareStatement("UPDATE \"TBL_DATOSEMPRESA\"\n" +
                    "\tSET   \"nombreEmpresa\"=?, \"imgLogo\"=?, \"telefono\"=?\n" +
                    "\tWHERE \"idEmpresa\"=?");
            st.setString(1, nomb);
            st.setString(2, logo);
            st.setString(3, tel);
            st.setDouble(4, id);

            st.executeUpdate();

            if (st.executeUpdate() > 0) {
                System.out.println("Actualizado ");
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {

                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }


    }

}
