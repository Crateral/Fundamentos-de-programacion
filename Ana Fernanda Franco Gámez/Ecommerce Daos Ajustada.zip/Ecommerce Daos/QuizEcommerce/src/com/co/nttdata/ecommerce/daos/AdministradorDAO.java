package com.co.nttdata.ecommerce.daos;

import com.co.nttdata.ecommerce.entidades.Administrador;
import com.co.nttdata.ecommerce.entidades.Cliente;
import com.co.nttdata.ecommerce.utilitarios.ConexionBD;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AdministradorDAO {

    ConexionBD cone = new ConexionBD();


    public List<Administrador> consultarAdministrador() {
        Connection baseDatos = cone.conectarBD();
        Statement st = null;
        ResultSet rs = null;
        List<Administrador> listAdm = new ArrayList<>();
        try {

            st = baseDatos.createStatement();
            rs = st.executeQuery("select * from \"TBL_ADMINISTRADORES\"");

            while (rs.next()) {
                Administrador adm = new Administrador();

                adm.setIdAministrador(rs.getInt("idAdministrador"));
                adm.setNombre(rs.getString("nombre"));
                adm.setTipoIdentificacion(rs.getInt("idTipodocumento"));
                adm.setNumeroIdentificacion(rs.getString("numeroDocumento"));
                adm.setCorreo(rs.getString("correo"));
                adm.setContrasenia(rs.getString("contrasenia"));
                adm.setEstado(rs.getBoolean("estado"));
                listAdm.add(adm);
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                rs.close();
                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }


        for (Administrador lcA : listAdm) {
            System.out.println("Id Adm: " + lcA.getIdAministrador());
            System.out.println("Nombre Admi: " + lcA.getNombre());
            System.out.println("Id Tipo Documento: " + lcA.getTipoIdentificacion());
            System.out.println("Numero ID: " + lcA.getNumeroIdentificacion());
            System.out.println("Correo: " + lcA.getCorreo());
            System.out.println("Contraseña: " + lcA.getContrasenia());
            System.out.println("Estado: " + lcA.getEstado());

            System.out.println("--");
        }
        return listAdm;
    }

    public void buscarAdmin(int nomCl) {
        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;
        ResultSet rs = null;

        try {

            st = baseDatos.prepareStatement("select * from \"TBL_ADMINISTRADORES\" where \"idAdministrador\" =?");
            st.setInt(1, nomCl);
            rs = st.executeQuery();

            while (rs.next()) {
                Administrador adm = new Administrador();

                adm.setIdAministrador(rs.getInt("idAdministrador"));
                adm.setNombre(rs.getString("nombre"));
                adm.setTipoIdentificacion(rs.getInt("idTipodocumento"));
                adm.setNumeroIdentificacion(rs.getString("numeroDocumento"));
                adm.setCorreo(rs.getString("correo"));
                adm.setContrasenia(rs.getString("contrasenia"));
                adm.setEstado(rs.getBoolean("estado"));

                System.out.println("Id Adm: " + adm.getIdAministrador());
                System.out.println("Nombre Admi: " + adm.getNombre());
                System.out.println("Id Tipo Documento: " + adm.getTipoIdentificacion());
                System.out.println("Numero ID: " + adm.getNumeroIdentificacion());
                System.out.println("Correo: " + adm.getCorreo());
                System.out.println("Contraseña: " + adm.getContrasenia());
                System.out.println("Estado: " + adm.getEstado());

                System.out.println("--");


            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                rs.close();
                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }


    }

    public void agregarAdmin(Administrador ad) {

        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;

        try {

            st = baseDatos.prepareStatement("INSERT INTO public.\"TBL_ADMINISTRADORES\"(\n" +
                    "\t nombre, \"idTipodocumento\", \"numeroDocumento\", correo, contrasenia, estado)\n" +
                    "\tVALUES (  ?, ?, ?, ?, ?, ?)");

            st.setString(1, ad.getNombre());
            st.setInt(2, ad.getTipoIdentificacion());
            st.setString(3, ad.getNumeroIdentificacion());
            st.setString(4, ad.getCorreo());
            st.setString(5, ad.getContrasenia());
            st.setBoolean(6, ad.getEstado());

            st.executeUpdate();

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {

                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }

    }

    public void eliminarAdmin(int idpro) {
        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;


        try {

            st = baseDatos.prepareStatement("delete  from \"TBL_ADMINISTRADORES\" where \"idAdministrador\" =?");
            st.setInt(1, idpro);
            st.executeUpdate();
            if (st.executeUpdate() == 0) {
                System.out.println("Se ha eliminado con exito");
            } else {
                System.out.println("Ha ocurrido un error");
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {

                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }


    }

    public void modificarValor(int pro, String cat) {
        Connection baseDatos = cone.conectarBD();
        PreparedStatement st = null;


        try {

            st = baseDatos.prepareStatement("UPDATE public.\"TBL_ADMINISTRADORES\"\n" +
                    "\tSET \"nombre\"=?\n" +
                    "\tWHERE \"idAdministrador\"=?");

            //    st.setDate(1, fec);
            st.setString(1, cat);
            st.setInt(2, pro);

            st.executeUpdate();

            if (st.executeUpdate() > 0) {
                System.out.println("Actualizado ");
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {

                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }


    }


}
