package com.co.nttdata.ecommerce.menu;

import com.co.nttdata.ecommerce.daos.AdministradorDAO;
import com.co.nttdata.ecommerce.daos.ClienteDAO;
import com.co.nttdata.ecommerce.entidades.Administrador;
import com.co.nttdata.ecommerce.entidades.Cliente;

import java.util.Scanner;

public class MenuAdministradorDao {

    AdministradorDAO admD= new AdministradorDAO();
    int opcion, id;
    Scanner x = new Scanner(System.in);

    Administrador ad= new Administrador();



    public void menuAdm() {
        do {
            System.out.println("1. Agregar Cliente");
            System.out.println("2. Consultar Cliente");
            System.out.println("3. Buscar Cliente");
            System.out.println("4. Eliminar Cliente");
            System.out.println("5. Modificar Cliente");
            opcion = x.nextInt();
            switch (opcion) {
                case 1:

                    ad.setNombre("Dilan");
                    ad.setTipoIdentificacion(5);
                    ad.setNumeroIdentificacion("43577");
                    ad.setCorreo("dilan@gmail.com");
                    ad.setContrasenia("di456");
                    ad.setEstado(true);


                    admD.agregarAdmin(ad);



                    break;
                case 2:

                    admD.consultarAdministrador();
                    break;
                case 3:
                    System.out.println("Id del Admin quieres buscar");
                    int ci = x.nextInt();
                    admD.buscarAdmin(ci);
                    break;
                case 4:
                    System.out.println("Ingresa el id del Admmin que quieres eliminar");
                    id = x.nextInt();
                    admD.eliminarAdmin(id);


                    break;
                case 5:
                    System.out.println("Id del Admin a modificar");
                    id = x.nextInt();
                    System.out.println("Nombre");
                    String nomb = x.next();

                    System.out.println();
                    admD.modificarValor(id,nomb);

                    break;


            }
        } while (opcion < 5);
    }

}

