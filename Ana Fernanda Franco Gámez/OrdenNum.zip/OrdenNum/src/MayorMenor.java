import java.util.Arrays;

public class MayorMenor {

    public static int [] OrdMenor(int[]numeros){

        for (int i=0; i<numeros.length;i++){
            for (int j=0; j<numeros.length-1; j++){

                if(numeros[j]>numeros[j+1]){
                    int num=numeros[j+1];
                    numeros[j+1]=numeros[j];
                    numeros[j]=num;
                }


            }
        }

        return numeros;
    }

    public static int [] OrdMayor(int []numeros){

        for (int i=0; i<numeros.length;i++){
            for (int j=0; j<numeros.length-1; j++){

                if(numeros[j]<numeros[j+1]){
                    int num=numeros[j+1];
                    numeros[j+1]=numeros[j];
                    numeros[j]=num;
                }
            }
        }

        return numeros;

    }


    public static void main(String[] args) {
        System.out.println("Ordenamiento de Arreglos");
        int [] numeros = {7, 4, 2, 1,10, 5, 6};
        System.out.println("El array de numeros a ordenar es: {7, 4, 2, 1,10, 5, 6} ");
        OrdMenor(numeros);
        System.out.println("Arreglo ordenado de menor a mayor");
        System.out.println(Arrays.toString(OrdMenor(numeros)));
        OrdMayor(numeros);
        System.out.println("Arreglo ordenado de mayor a menor");
        System.out.println(Arrays.toString(OrdMayor(numeros)));




    }


}


