import java.util.Arrays;

public class Arreglos {
    public static int [] OrdMenor(int[]numeros){

        for (int i=0; i<numeros.length;i++){
            for (int j=0; j<numeros.length-1; j++){

                if(numeros[j]>numeros[j+1]){
                    int num=numeros[j+1];
                    numeros[j+1]=numeros[j];
                    numeros[j]=num;
                }


            }
        }

        return numeros;
    }

    public static int [] OrdMayor(int []numeros){

        for (int i=0; i<numeros.length;i++){
            for (int j=0; j<numeros.length-1; j++){

                if(numeros[j]<numeros[j+1]){
                    int num=numeros[j+1];
                    numeros[j+1]=numeros[j];
                    numeros[j]=num;
                }
            }
        }

        return numeros;

    }

    public static int [] OrdenaEliminaMayor (int []numeros){

        int []org=OrdMayor(numeros);
        int actual= org[0];
        boolean duplicado= false;
        for( int i=0; i<org.length;i++){
            if(actual==org[i]&& !duplicado){
                duplicado=true;

            }else{
                if(actual!=org[i]){
                    System.out.print(" "+ actual);
                    actual=org[i];
                    duplicado=false;
                }
            }
        }
        System.out.print(" "+ actual);

        return org;

    }


    public static int [] OrdenaEliminaMenor (int []numeros){

        int []org=OrdMenor(numeros);
        int actual= org[0];
        boolean duplicado= false;
        for( int i=0; i<org.length;i++){
            if(actual==org[i]&& !duplicado){
                duplicado=true;

            }else{
                if(actual!=org[i]){
                    System.out.print(" "+ actual);
                    actual=org[i];
                    duplicado=false;
                }
            }
        }
        System.out.print(" "+ actual );
        System.out.println(" ");

        return org;

    }
    public static void main(String[] args) {

        System.out.println("Crear un arreclo con los giuientes valores:");
        System.out.println("2,4,6,6,19,3,1,0,5,2,9");
        System.out.println("----------------------------------------------------");
        System.out.println("2.1 Eliminar los números duplicados");
        System.out.println("2.2 Ordenar el arreglo sin duplicador de menor a mayor");
        System.out.println("2.3 Ordenar el arreglo sin duplicados de mayor a menor");

        int [] numeros = { 2,4,6,6,19,3,1,0,5,2,9 };
        OrdMenor(numeros);
        OrdMayor(numeros);
        System.out.println("----------------------------------------------------");
        System.out.println("Arreglo inicial ordenado de mayor a menor y de menor a mayor ");
        System.out.println(Arrays.toString(OrdMayor(numeros)));
        System.out.println(Arrays.toString(OrdMenor(numeros)));
        System.out.println("Arreglo sin duplicados ordenado de menor a mayor");
        OrdenaEliminaMenor(numeros);
        System.out.println("Arreglo sin duplicados ordenado de mayor a menor ");
        OrdenaEliminaMayor(numeros);

    }
}
