import java.sql.SQLOutput;
import java.util.Scanner;

public class Triquii {

    static final char OPCION_O ='O';
    static final char OPCION_X ='X';
    static final char OPCION_VACIO = ' ';


    public static void main(String[] args) {

        char [][] triqui= new char[3][3];
        boolean hayGanador=false;
        int filas;
        int columnas;
        Scanner x= new Scanner(System.in);
        ReiniciarTiqui(triqui);
        System.out.println("Inicia el Juego");
        System.out.println("Jugador 1: Option O | Jugador 2: Opcion X ");



        while (hayGanador==false){
           System.out.println("Eleccion jugador 1: ");
           System.out.println("Jugagor 1: Opcion O ");
           System.out.println("Que posision quieres elegir");
           System.out.print("Filas: ");
           filas = x.nextInt();
           System.out.print("Columnas: ");
           columnas = x.nextInt();
           triqui[filas-1][columnas-1]= OPCION_O;
           mostrarTablero(triqui);

           if (esGanador(triqui,OPCION_O)){
               System.out.println(" Gana el jugador 1 con la opcion O");
               hayGanador=true;
               break;
           }

           System.out.println("Eleccion jugador 2: ");
           System.out.println("Jugagor 2: Opcion X ");
           System.out.println("Que posision quieres elegir");
           System.out.print("Filas: ");
           filas = x.nextInt();
           System.out.print("Columnas: ");
           columnas = x.nextInt();
           triqui[filas-1][columnas-1]= OPCION_X;
           mostrarTablero(triqui);

           if (esGanador(triqui,OPCION_X)){
               System.out.println(" Gana el jugador 2 con la opcion X");
               hayGanador=true;
               break;
           }
       }
        if (hayGanador==false){
         System.out.println("empate ");
}

    }
    private static void ReiniciarTiqui(char [][]triqui ){
        for (int i=0; i<triqui.length;i++){
            for (int j=0; j< triqui.length;j++){
                triqui[i][j]= OPCION_VACIO;

            }
        }
    }

    private static void mostrarTablero(char [][]triqui ) {
        for (int i=0; i<triqui.length;i++){
            for (int j=0; j< triqui.length;j++){
                System.out.print("|" + triqui[i][j]);
            }
            System.out.println("|");
        }
    }

    private static boolean esGanador(char[][] triqui, char opcion) {
        boolean jugada=false;

        //validacion Diagonal
        if (triqui[0][0]==opcion && triqui[1][1]==opcion && triqui[2][2]==opcion){
            jugada=true;
        }else
        if (triqui[2][0]==opcion && triqui[1][1]==opcion && triqui[0][2]==opcion){
            jugada=true;
        }else
            //validacion filas
            if (triqui[0][0]==opcion && triqui[0][1]==opcion && triqui[0][2]==opcion){
                jugada=true;
            }else
            if (triqui[1][0]==opcion && triqui[1][1]==opcion && triqui[1][2]==opcion) {
                jugada=true;
            }else
            if (triqui[2][0]==opcion && triqui[2][1]==opcion && triqui[2][2]==opcion){
                jugada=true;
            }else
                //validacion columnas
                if (triqui[0][0]==opcion && triqui[1][0]==opcion && triqui[2][0]==opcion){
                    jugada=true;
                }else
                if (triqui[0][1]==opcion && triqui[1][1]==opcion && triqui[2][1]==opcion){
                    jugada=true;
                }else
                if (triqui[0][2]==opcion && triqui[1][2]==opcion && triqui[2][2]==opcion){
                    jugada=true;
                }

        return jugada;
    }



}
