import Loguin.Registro;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        List<Registro> registroUsuarios= new ArrayList<>();

        Scanner x = new Scanner(System.in);
        String nombre, correo, contrasenia;
        int opcion=0;

        while (true){
            System.out.println("-----------------------------");
            System.out.println("|   Registro de Usuario     |");
            System.out.println("_____________________________");
            System.out.println("| 1. Crear Usuario          |");
            System.out.println("| 2. Consultar Usuario      |");
            System.out.println("| 3. Iniciar Seccion        |");
            System.out.println("| 4. Cambiar Contraseña     |");
            System.out.println("| 5. Recuperar contraseña   |");
            System.out.println("| 6. Salir                  |");

            System.out.print("Digite la opcion que deseas realizar: ");
            opcion= x.nextInt();

            switch (opcion){
                case 1:

                    Registro nuReg= new Registro();
                    System.out.println(" - Digite datos del usurario - ");
                    System.out.print(" Nombre: ");
                    nombre= x.next();
                    nuReg.setNombre(nombre);
                    System.out.print(" Correo: ");
                    correo= x.next();
                    nuReg.setCorreo(correo);
                    System.out.print(" Contraseña: ");
                    contrasenia = x.next();
                    nuReg.setContrasenia(contrasenia);

                    registroUsuarios.add(nuReg);
                    System.out.println("Usuario Registrado con exito 🥳");


                    break;

                case 2:
                    if (registroUsuarios.size()!=0) {
                        for (Registro regPers : registroUsuarios) {
                            System.out.println(regPers.toString());
                        }
                    } else {
                        System.out.println("No tienes usuarios Registrados Ingresa otra Opcion ");
                    }


                    break;
                case 3:
                    if (registroUsuarios.size()!=0) {
                        System.out.println(" - Digite sus credenciales -");
                        System.out.print("Usuario: ");
                        correo = x.next();
                        System.out.print("Contraseña: ");
                        contrasenia = x.next();

                        for (Registro regPers : registroUsuarios) {
                            if (regPers.getCorreo().equals(correo) && regPers.getContrasenia().equals(contrasenia)) {
                                System.out.println("Haz Iniciado Sesión 👋");
                            } else {
                                System.out.println("Credenciales incorrectas ❌");
                            }
                        }
                    }else {
                        System.out.println("No tienes usuarios Registrados Ingresa otra Opcion ");
                    }

                    break;
                case 4:
                    if (registroUsuarios.size()!=0) {

                            System.out.print("Digite su correo: ");
                            correo = x.next();

                            for (Registro caCont : registroUsuarios) {
                                if (caCont.getCorreo().equals(correo)) {
                                    int indice = registroUsuarios.indexOf(caCont.getCorreo());

                                    if (indice != 0) {
                                        System.out.print("ingresa tu nueva contraseña: ");
                                        contrasenia = x.next();
                                        System.out.println("Estas seguro que deseas cambiar contraseña: si [1], no [2]");
                                        int cambContra = x.nextInt();
                                        if (cambContra == 1) {
                                            caCont.setContrasenia(contrasenia);
                                            System.out.println("Contraseña cambiada con exito 🥳");
                                        }else {
                                            System.out.println("cambio de contraseña cancelado ❌");
                                        }

                                    }
                                }

                        }
                    }else {
                        System.out.println("No tienes unuarios Registrados Ingresa otra Opcion ");
                    }

                    break;
                case 5:
                    if (registroUsuarios.size()!=0) {
                        System.out.println("Olvidaste tu contraseña: si[1] no[2] ");
                        int resContra = x.nextInt();
                        if (resContra == 1) {
                            System.out.print("Digite su correo: ");
                            correo = x.next();

                            for (Registro caCont : registroUsuarios) {
                                if (caCont.getCorreo().equals(correo)) {
                                    int indice = registroUsuarios.indexOf(caCont.getCorreo());

                                    if (indice != 0) {
                                        System.out.print("ingresa tu nueva contraseña: ");
                                        contrasenia = x.next();
                                        caCont.setContrasenia(contrasenia);
                                        System.out.println("Contraseña cambiada con exito 🥳");
                                    }

                                }
                            }

                        } else {
                            System.out.println("Elige otra opcion del menu.");
                        }

                    }else {
                        System.out.println("No tienes unuarios Registrados Ingresa otra Opcion ");
                    }


                    break;
                case 6:

                    System.out.println(" Seccion finalizada, hasta pronto");
                    System.exit(0);

                    break;
                default:
                    System.out.println(" Opcion no valida ");

            }


        }

    }
}