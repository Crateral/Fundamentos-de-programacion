import com.co.nttdata.as3.menu.MenuPrincipal;

public class Main {
    public static void main(String[] args) {

        MenuPrincipal menuPrin = new MenuPrincipal();
        menuPrin.MenuPrinci();

    }
}


