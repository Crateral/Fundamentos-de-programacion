package com.co.nttdata.as3.productos;

import java.io.Serializable;

public class Producto implements Serializable {
    private int idProducto;
    private String nombProd;
    private int precioProd;
    private int categoria;
    private String nombrecaT;
    private int unid;
    private int totalComp;

    public String getNombrecaT() {
        return nombrecaT;
    }

    public void setNombrecaT(String nombrecaT) {
        this.nombrecaT = nombrecaT;
    }

    public int getUnid() {
        return unid;
    }

    public void setUnid(int unid) {
        this.unid = unid;
    }

    public int getTotalComp() {
        return totalComp;
    }

    public void setTotalComp(int totalComp) {
        this.totalComp = totalComp;
    }

    public int getCategoria() {
        return categoria;
    }

    public void setCategoria(int categoria) {
        this.categoria = categoria;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public Producto() {

    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    public String getNombProd() {
        return nombProd;
    }

    public void setNombProd(String nombProd) {
        this.nombProd = nombProd;
    }

    public int getPrecioProd() {
        return precioProd;
    }

    public void setPrecioProd(int precioProd) {
        this.precioProd = precioProd;
    }

    @Override
    public String toString() {
        return "Producto -> Id producto: " + idProducto + " Nombre Producto: " + nombProd + " Categoria: " + categoria + ". " + nombrecaT +
                " Precio Unitario: " + precioProd + " Unidades: " + unid + " Total: " + totalComp;
    }
}
