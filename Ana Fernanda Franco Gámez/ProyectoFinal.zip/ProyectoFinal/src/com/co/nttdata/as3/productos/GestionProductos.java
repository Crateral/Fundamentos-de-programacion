package com.co.nttdata.as3.productos;

import com.co.nttdata.as3.loguin.Registro;

import java.util.*;

public class GestionProductos extends Producto {
    List<Producto> registroProducto = new ArrayList<>();

    public void AgregarProducto(int idProducto, String nomProd, int precioProd, int nomCateg, int unid, int totalComp) {

        Producto nuPrp = new Producto();
        nuPrp.setIdProducto(idProducto);
        nuPrp.setNombProd(nomProd);
        nuPrp.setPrecioProd(precioProd);
        nuPrp.setCategoria(nomCateg);
        if (nomCateg == 1) {
            nuPrp.setNombrecaT(String.valueOf(Categorias.LACTEOS));
        } else if (nomCateg == 2) {
            nuPrp.setNombrecaT(String.valueOf(Categorias.FRUTAS));
        } else if (nomCateg == 3) {
            nuPrp.setNombrecaT(String.valueOf(Categorias.ASEO));
        } else if (nomCateg == 4) {
            nuPrp.setNombrecaT(String.valueOf(Categorias.GRANOS));
        } else if (nomCateg == 5) {
            nuPrp.setNombrecaT(String.valueOf(Categorias.PAPELERIA));
        } else if (nomCateg == 6) {
            nuPrp.setNombrecaT(String.valueOf(Categorias.TECNOLOGIA));
        } else if (nomCateg == 7) {
            nuPrp.setNombrecaT(String.valueOf(Categorias.BEBIDAS));
        } else if (nomCateg == 8) {
            nuPrp.setNombrecaT(String.valueOf(Categorias.DULCES));
        } else {
            System.out.println("No elegiste una categoria de las disponibles, El sistema pondra el nombre de OTRA");
            nuPrp.setNombrecaT("OTRA");
        }

        nuPrp.setUnid(unid);
        nuPrp.setTotalComp(totalComp);
        registroProducto.add(nuPrp);

    }

    public void ConsultarProductos() {

        if (registroProducto.size() != 0) {
            for (Producto regPro : registroProducto) {
                System.out.println(regPro.toString());
            }
        } else {
            System.out.println(" No tienes productos en el carrito");
        }
    }

    public void ConsultarPorCategoria(String buCat) {
        if (registroProducto.size() != 0) {

            int con = 0;

            for (Producto conCat : registroProducto) {
                if (conCat.getNombrecaT().equals(buCat)) {
                    System.out.println("- Categoria: " + conCat.getNombrecaT() + " - Nombre del producto: " + conCat.getNombProd() + " - Precio del producto: " + conCat.getPrecioProd());
                }
                con = con + 1;
            }
        } else {
            System.out.println(" No tienes productos en el carrito");
        }
    }

    public void OrdenMayoMeno() {

        if (registroProducto.size() != 0) {
            System.out.println("Ordenando productos de mayor a menor precio...");
            registroProducto.sort(Comparator.comparing(Producto::getPrecioProd).reversed());
            for (Producto carrCom : registroProducto) {
                System.out.println("- Nombre del producto: " + carrCom.getNombProd() + " - Precio del producto: " + carrCom.getPrecioProd() + " - Categoria: " + carrCom.getNombrecaT());
            }
        } else {
            System.out.println(" No tienes productos en el carrito");
        }
    }

    public void OrdMenorMayor() {
        if (registroProducto.size() != 0) {
            System.out.println("Ordenando productos de menor a mayor precio...");
            registroProducto.sort(Comparator.comparing(Producto::getPrecioProd));
            for (Producto carrCom : registroProducto) {

                System.out.println("- Nombre del producto: " + carrCom.getNombProd() + " - Precio del producto: " + carrCom.getPrecioProd() + " - Categoria: " + carrCom.getNombrecaT());
            }
        } else {
            System.out.println(" No tienes productos en el carrito");
        }
    }

    public void OrdenarNombre() {
        if (registroProducto.size() != 0) {
            System.out.println("Ordenando productos por nombre...");
            Collections.sort(registroProducto, Comparator.comparing(Producto::getNombProd));
            for (Producto carrCom : registroProducto) {

                System.out.println("- Nombre del producto: " + carrCom.getNombProd() + " - Precio del producto: " + carrCom.getPrecioProd() + " - Categoria: " + carrCom.getNombrecaT());

            }
        } else {
            System.out.println(" No tienes productos en el carrito");
        }
    }

    public void OrdenarCategoria() {
        if (registroProducto.size() != 0) {
            System.out.println("Ordenando productos por categoria...");
            Collections.sort(registroProducto, Comparator.comparing(Producto::getNombrecaT));
            for (Producto carrCom : registroProducto) {
                //  System.out.println(carrCom.toString());
                System.out.println("- Categoria: " + carrCom.getNombrecaT() + " - Nombre Producto: " + carrCom.getNombProd() + " - Precio: " + carrCom.getPrecioProd());
            }
        } else {
            System.out.println(" No tienes productos en el carrito");
        }
    }

    public void GenerarFactura() {
        if (registroProducto.size() != 0) {
            int subtotal = 0;
            double iva, total, descuentos, totalPaga;
            System.out.println("                                Factura de compra 📄");
            System.out.println("____________________________________________________________________________________");

            System.out.println(" Id Producto     Nombre Producto    Categoria   Precio Unitario   Unidades   Total");

            for (Producto factura : registroProducto) {

                System.out.format("%10s %15s %15s %15s %15s %8s", factura.getIdProducto(), factura.getNombProd(), factura.getNombrecaT(),
                        factura.getPrecioProd(), factura.getUnid(), factura.getTotalComp());
                System.out.println();
            }

            for (Producto factura : registroProducto) {

                subtotal += factura.getTotalComp();
            }

            iva = (subtotal * 19);
            iva = iva / 100;
            total = subtotal + iva;

            System.out.println("____________________________________________________________________________________");
            System.out.println("                                                            Subtotal compra: " + subtotal);
            System.out.println("                                                                        iva: " + iva);
            System.out.println("                                                               Total compra: " + total);

            if (total > 100000) {
                System.out.println(" Su compra fue superior a $100.000 tiene un descuento del 10% 🥳");
                descuentos = (total * 10) / 100;
                totalPaga = total - descuentos;
                System.out.println(" Debes cancelar en total : " + totalPaga);
                System.out.println();


            } else {
                System.out.println(" Debes cancelar en total : " + total);
                System.out.println();
            }
        } else {
            System.out.println("Aun no tienes productos en el carrito.");
        }

    }

    public void EliminarProducto(String prodEli) {

        if (registroProducto.size() != 0) {

            registroProducto.removeIf(pro -> pro.getNombProd().equals(prodEli));
            System.out.println("Producto eliminado");

        }


    }
}