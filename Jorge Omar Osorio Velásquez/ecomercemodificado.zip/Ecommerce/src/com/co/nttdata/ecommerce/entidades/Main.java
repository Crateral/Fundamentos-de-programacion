package com.co.nttdata.ecommerce.entidades;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.co.nttdata.ecommerce.entidades.*;
import com.co.nttdata.ecommerce.logica.GestionCarritoDeCompras;
import com.co.nttdata.ecommerce.logica.GestionFactura;

public class Main {

	public static void main(String[] args) {
		
		GestionCarritoDeCompras gcdc = new GestionCarritoDeCompras();
		GestionFactura gf = new GestionFactura();
		Factura f = new Factura();
		
		//Crear 10 prodcutos
		//Añadir 6 al carrito de comprar
		//Crear la factura de ese carrito de compras
	
	

	
	//Crear 10 productos
	
	Producto televisor = new Producto(1, "televisor", 9, 2000000,true,20000,19,"32 pulgadas", "imagen 4k",Marca.LG,Categoria.TECNOLOGIA);
	Producto televisor1 = new Producto(2, "televisor1", 9, 44000000,false,200,19,"52 pulgadas", "imagen 7k",Marca.SAMSUNG,Categoria.TECNOLOGIA);
	Producto televisor2 = new Producto(3, "televisor2", 9, 2000000,true,20000,19,"32 pulgadas", "imagen 4k",Marca.LG,Categoria.TECNOLOGIA);
	Producto televisor3 = new Producto(4, "televisor3", 9, 2000000,true,20000,19,"32 pulgadas", "imagen 4k",Marca.LG,Categoria.TECNOLOGIA);
	Producto televisor4 = new Producto(5, "televisor4", 9, 2000000,true,20000,19,"32 pulgadas", "imagen 4k",Marca.LG,Categoria.TECNOLOGIA); 
	Producto televisor5 = new Producto(6, "televisor5", 9, 2000000,true,20000,19,"32 pulgadas", "imagen 4k",Marca.LG,Categoria.TECNOLOGIA);
	Producto televisor6 = new Producto(7, "televisor6", 9, 2000000,true,20000,19,"32 pulgadas", "imagen 4k",Marca.LG,Categoria.TECNOLOGIA);
	Producto televisor7= new Producto(8, "televisor7", 9, 2000000,true,20000,19,"32 pulgadas", "imagen 4k",Marca.LG,Categoria.TECNOLOGIA);
	Producto televisor8 = new Producto(9, "televisor8", 9, 2000000,true,20000,19,"32 pulgadas", "imagen 4k",Marca.LG,Categoria.TECNOLOGIA);
	Producto televisor9 = new Producto(10, "televisor9", 9, 2000000,true,20000,19,"32 pulgadas", "imagen 4k",Marca.LG,Categoria.TECNOLOGIA);
	
	List<Producto> lp = new ArrayList<>();
	
	
	//Añadir al carrito 6 productos
	
	lp.add(televisor1);
	lp.add(televisor2);
	lp.add(televisor3);
	lp.add(televisor4);
	lp.add(televisor5);
	lp.add(televisor6);
	
	//Añadir al carrito 6 Productos
	
	CarritoDeCompras cdc  = new CarritoDeCompras();
	cdc.setProductos(lp);
	
	cdc.getProductos().forEach( (p) -> System.out.println(p.getIdProducto()+" "+ p.getNombre()+ " " + p.getCantidadDiponible() + " " + p.getPrecio()  ));
	cdc = gcdc.calcularTotalConIva(cdc);

    // crear la factura
	Cliente cl = new Cliente("jorge@gmail","536367373","1",true,"834563","cc","contado");
	gcdc.calcularCostoEnvio(cdc,cl.getDireccion());
    System.out.println();
		f = gf.pagar(cl,cdc);
		 gf.imprimir();
	
	
		 
		 

		
 	}

}


