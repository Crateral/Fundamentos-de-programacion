package com.co.nttdata.ecommerce.logica;

import com.co.nttdata.ecommerce.entidades.CarritoDeCompras;
import com.co.nttdata.ecommerce.entidades.Cliente;
import com.co.nttdata.ecommerce.entidades.Factura;

public class GestionFactura {
	Factura f = new Factura();
	public Factura pagar(Cliente cliente, CarritoDeCompras cdc) {
		
		f.setCliente(cliente);
		f.setDescripcion("Mi primera factura");
		f.setIdFactura(123123);
		f.setProductos(cdc);
		f.setValorTotalConIva(cdc.getSubTotalConIva() + cdc.getValorEnvio());
		
		f.setValorDeEnvio(cdc.getValorEnvio());
		return f;
	}

	public void imprimir() {
		System.out.println(  f.getCliente() + f.getDescripcion() + f.getIdFactura() + 
				f.getProductos().getProductos() + f.getValorTotalConIva() + f.getValorDeEnvio());                                                         
		
		
	}
	
	
	
	
}