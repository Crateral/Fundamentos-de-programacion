package com.co.nttdata.ecommerce.logica;

import java.util.ArrayList;
import java.util.List;

import com.co.nttdata.ecommerce.entidades.*;
import com.co.nttdata.ecommerce.interfaces.GestionCarritoDeCompras;


public class GestionCarritoDeComprasImpl implements GestionCarritoDeCompras {

	@Override
	public CarritoDeCompras añadirAlCarrito(CarritoDeCompras cdc, List<Producto> p) {

		cdc.setProductos(p);
		return cdc;
	}

	@Override
	public CarritoDeCompras calcularTotalConIva(CarritoDeCompras cdc) {
		double total = 0.0;

		for (int i = 0; i < cdc.getProductos().size(); i++) {
		//1100           2000
		total = total + cdc.getProductos().get(i).getPrecio() +
		(cdc.getProductos().get(i).getPrecio() *
		(cdc.getProductos().get(i).getIva()/100));

		}
		cdc.setSubTotalConIva(total);
		return cdc;
	}

	@Override
	public CarritoDeCompras calcularTotalSinIva(CarritoDeCompras cdc) {
		double total = 0.0;

		for (int i = 0; i < cdc.getProductos().size(); i++) {
		//1100           2000
		total = total + cdc.getProductos().get(i).getPrecio();


		}
		cdc.setSubTotalSinIva(total);
		return cdc;
	}

	@Override
	public CarritoDeCompras calcularCostoEnvio(CarritoDeCompras cdc, String direccion) {
		//Para el calculo del envio se debe tener en cuenta la ubicacion del cliente
				//Si se encuentra en ciudades principales se debe cobrar el 5%
				//Si se encuentra en ciudades no principales se debe cobrar el 10%

				double total = 0;
				double totalEnvio = 0;

				for (int i = 0; i < cdc.getProductos().size(); i++) {
				//1100           2000
				total = total + cdc.getProductos().get(i).getPrecio() +
				(cdc.getProductos().get(i).getPrecio() *
				(cdc.getProductos().get(i).getIva()/100));
				}

				if(direccion == "1") {
				System.out.println("Se debe cobrar el 5% del envio Total, porque es Ciudad Principal" );
				totalEnvio= (total * 5)/100;
				}else if(direccion =="2") {

				System.out.println("Se debe cobrar el  10 % envio total, porque es Ciudad No  Principal");
				totalEnvio= (total * 10)/100;
				}


				System.out.println("El valor del envio es: "+ totalEnvio);
				cdc.setValorEnvio(totalEnvio);
		return cdc;
	}

}
