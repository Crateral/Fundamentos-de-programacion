package com.co.nttdata.ecommerce.logica;

import com.co.nttdata.ecommerce.entidades.CarritoDeCompras;
import com.co.nttdata.ecommerce.entidades.Cliente;
import com.co.nttdata.ecommerce.entidades.Factura;
import com.co.nttdata.ecommerce.interfaces.GestionCarritoDeCompras;
import com.co.nttdata.ecommerce.interfaces.GestionFactura;

public class GestionFacturaImpl implements GestionFactura{
	Factura f = new Factura();

	@Override
	public Factura pagar(Cliente cliente, CarritoDeCompras cdc) {
		f.setDescripcion("Mi primera factura");
		f.setIdFactura(001);
		f.setFecha("28/11/2022");
		f.setCliente(cliente);
		f.setProductos(cdc);
		f.setValorTotalConIva(cdc.getSubTotalConIva() + cdc.getValorEnvio());
		f.setValorDeEnvio(cdc.getValorEnvio());
		return f;
	}

	@Override
	public void imprimir() {
		System.out.println(f.getDescripcion() + "\n" + f.getIdFactura() + f.getFecha() + "\n" + f.getCliente()+ "\n" +
				f.getProductos().getProductos() +"\n" + f.getValorTotalConIva() + "\n" + f.getValorDeEnvio());

		
	}
	
}