package com.co.nttdata.ecommerce.logica;

import com.co.nttdata.ecommerce.entidades.Cliente;
import com.co.nttdata.ecommerce.entidades.Usuario;
import com.co.nttdata.ecommerce.interfaces.GestionLogin;

public class GestionLoginImpl implements GestionLogin{
	
	//Metodo de registrar usuarios

	@Override
	public Usuario registrar(String nombre, String contrasenia, String correo, String direccion,
		String tipoIdentificacion, String numeroIdentificacion) {
		
		//instancio la clase Cliente para traerme todos sus variables y poder registrar un usuario
		Cliente usuar = new Cliente();
		
		usuar.setNombreUsuario(nombre);
	
		usuar.setContrasenia(contrasenia);
		usuar.setCorreo(correo);
		usuar.setDireccion(direccion);
		usuar.setTipoIdentificacion(tipoIdentificacion);
		usuar.setNumeroIdentificacion(numeroIdentificacion);
		
        return usuar;
	}
	
	//metodo para ingresar al sistema de ecommerce

	@Override
	public boolean login(String nombreUsuario, String contrasenia) {
		
		String usuar = "jorge";
		String pass = "12";
	
		 if(usuar.equalsIgnoreCase(nombreUsuario) && pass.equalsIgnoreCase(contrasenia)) {

	        
			 System.out.println("ingreso exitoso");
	            return true;

	        }else {
	            System.out.println("ingreso no exitoso");

	        }
		 return true;
		
	}
     // método de recuperar contraseña
	@Override
	public String recuperarContrasena(String contrasenia) {
		 if(contrasenia.equals("S")) {
	            System.out.println("ingrese la nueva contraseña");
	            
	            System.out.println("cambio de contraseña exitosa");
	            
	        }else {
	            System.out.println("no deseo recuperar contraseña");
	        }

		return contrasenia;
	}
	
	
     // Método para salir del sistema
	@Override
	public boolean logout() {
		 System.out.println("salida del sistema con éxito");
	        System.exit(0);
		return false;
	}




	
	
	
	
	
	
	
}

	

   
