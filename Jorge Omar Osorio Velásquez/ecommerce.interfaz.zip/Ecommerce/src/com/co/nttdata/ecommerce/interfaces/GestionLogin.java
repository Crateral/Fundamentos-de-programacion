package com.co.nttdata.ecommerce.interfaces;

import com.co.nttdata.ecommerce.entidades.Cliente;
import com.co.nttdata.ecommerce.entidades.Usuario;

public interface GestionLogin {
	
	
	public Usuario registrar( String nombre, String contrasenia, String correo, String direccion, String tipoIdentificacion, String numeroIdentificacion );
	
	
	
	
	public boolean login(String nombreUsuario, String contrasenia);
	
	
	
	
	public String recuperarContrasena( String contrasenia); 
	
	
	
	
	
	public boolean logout();
	
		

	

}
