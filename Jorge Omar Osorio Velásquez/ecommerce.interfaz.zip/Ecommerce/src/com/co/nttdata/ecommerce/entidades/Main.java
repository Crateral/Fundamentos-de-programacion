package com.co.nttdata.ecommerce.entidades;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Iterator;
import java.util.List;

import com.co.nttdata.ecommerce.entidades.*;
import com.co.nttdata.ecommerce.interfaces.GestionCarritoDeCompras;
import com.co.nttdata.ecommerce.interfaces.GestionFactura;
import com.co.nttdata.ecommerce.interfaces.GestionLogin;
import com.co.nttdata.ecommerce.logica.GestionCarritoDeComprasImpl;
import com.co.nttdata.ecommerce.logica.GestionFacturaImpl;
import com.co.nttdata.ecommerce.logica.GestionLoginImpl;

public class Main {

	public static void main(String[] args) {
		
		//instancia de clases en objetos
		GestionLogin gl = new GestionLoginImpl();
		GestionCarritoDeCompras gcdc = new GestionCarritoDeComprasImpl();
		GestionFactura gf = new GestionFacturaImpl();
		Factura f = new Factura();
		
		//Crear 10 prodcutos
		//Añadir 6 al carrito de comprar
		//Crear la factura de ese carrito de compras
	
	

	
	//Crear 10 productos
	
	/*Producto televisor = new Producto(1, "televisor",9, 20000,true,20000,19,"32 pulgadas", "imagen 4k",Marca.LG,Categoria.TECNOLOGIA);
	Producto televisor1 = new Producto(2, "televisor1", 9, 44000000,false,200,19,"52 pulgadas", "imagen 7k",Marca.SAMSUNG,Categoria.TECNOLOGIA);
	Producto televisor2 = new Producto(3, "televisor2", 9, 2000000,true,20000,19,"32 pulgadas", "imagen 4k",Marca.LG,Categoria.TECNOLOGIA);
	Producto televisor3 = new Producto(4, "televisor3", 9, 2000000,true,20000,19,"32 pulgadas", "imagen 4k",Marca.LG,Categoria.TECNOLOGIA);
	Producto televisor4 = new Producto(5, "televisor4", 9, 2000000,true,20000,19,"32 pulgadas", "imagen 4k",Marca.LG,Categoria.TECNOLOGIA); 
	Producto televisor5 = new Producto(6, "televisor5", 9, 2000000,true,20000,19,"32 pulgadas", "imagen 4k",Marca.LG,Categoria.TECNOLOGIA);
	Producto televisor6 = new Producto(7, "televisor6", 9, 2000000,true,20000,19,"32 pulgadas", "imagen 4k",Marca.LG,Categoria.TECNOLOGIA);
	Producto televisor7= new Producto(8, "televisor7", 9, 2000000,true,20000,19,"32 pulgadas", "imagen 4k",Marca.LG,Categoria.TECNOLOGIA);
	Producto televisor8 = new Producto(9, "televisor8", 9, 2000000,true,20000,19,"32 pulgadas", "imagen 4k",Marca.LG,Categoria.TECNOLOGIA);
	Producto televisor9 = new Producto(10, "televisor9", 9, 2000000,true,20000,19,"32 pulgadas", "imagen 4k",Marca.LG,Categoria.TECNOLOGIA);
	
	List<Producto> lp = new ArrayList<>();
	
	
	//Añadir al carrito 6 productos
	
	lp.add(televisor1);
    lp.add(televisor2);
	lp.add(televisor3);
	lp.add(televisor4);
	lp.add(televisor5);
	lp.add(televisor6);
	
	//Añadir al carrito 6 Productos
	
	CarritoDeCompras cdc  = new CarritoDeCompras();
	cdc.setProductos(lp);
	
	cdc.getProductos().forEach( (p) -> System.out.println(p.getIdProducto()+" "+ p.getNombre()+ " " + p.getCantidadDiponible() + " " + p.getPrecio()  ));
	cdc = gcdc.calcularTotalConIva(cdc);
	System.out.println();
	System.out.println("****************** ");
    System.out.println("FACTURA FALABELLA ");
    System.out.println("****************** ");
   


    // crear la factura
	Cliente usuar = new Cliente();

	f = gf.pagar(usuar,cdc);
    gf.imprimir();
    System.out.println();
    System.out.println("*************************");
	gcdc.calcularCostoEnvio(cdc,usuar.getDireccion());
    System.out.println("*************************");
    
    System.out.println();*/
    
    System.out.println("*****(Registro de usuario)*****");
    
    // Formulario registro de usuario al ecommerce
    
     Cliente c = (Cliente) gl.registrar(" jorge", " 12", "jor@gmail.com ", " calle 43 sur", "CC", "9102129 ");
   
    
    System.out.println("nombre de usuario: " + c.getNombreUsuario()); 
    System.out.println("la contraseña es: " + c.getContrasenia());
    System.out.println("nombre de usuario: " + c.getTipoIdentificacion()); 
    System.out.println("la contraseña es: " + c.getNumeroIdentificacion());
    System.out.println("correo: " + c.getCorreo()); 
    System.out.println("la dirección: " + c.getDireccion());
    
    System.out.println();
    System.out.println("************");
    System.out.println("Ingreso login");
    System.out.println("**************");
    
    gl.login(c.getNombreUsuario(), c.getContrasenia() );
    System.out.println(gl);
    
    System.out.println();
    System.out.println("************");
    System.out.println("Recuperar contraseña");
    System.out.println("**************");
    
    gl.recuperarContrasena(c.getContrasenia());
    System.out.println(""+ gl);
    
    System.out.println();
    System.out.println("************");
    System.out.println("Logout");
    System.out.println("**************");
    
    gl.logout();

    //Crear 2 productos
    Producto televisor = new Producto(1, "televisor",9, 200000,true,20000,19,"20 pulgadas", "imagen 4k",Marca.LG,Categoria.TECNOLOGIA);
    Producto televisor1 = new Producto(2, "televisor",9, 5000000,true,20000,19,"32 pulgadas", "imagen 8k",Marca.SAMSUNG,Categoria.TECNOLOGIA);
  
    List<Producto> lp = new ArrayList<>();
	
	
	//Añadir al carrito 6 productos
	
	lp.add(televisor);
    lp.add(televisor1);
  //Añadir al carrito 6 Productos
	
  	CarritoDeCompras cdc  = new CarritoDeCompras();
  	cdc.setProductos(lp);
  	
  	cdc.getProductos().forEach( (p) -> System.out.println(p.getIdProducto()+" "+ p.getNombre()+ " " + p.getCantidadDiponible() + " " + p.getPrecio()  ));
  	cdc = gcdc.calcularTotalConIva(cdc);
  	
  	
  	System.out.println();
  	System.out.println("****************** ");
      System.out.println("FACTURA FALABELLA ");
      System.out.println("****************** ");
     


      // crear la factura
  	Cliente cl = new Cliente();

  	 f= gf.pagar(cl,cdc);
      gf.imprimir();
      System.out.println();
      System.out.println("*************************");
  	gcdc.calcularCostoEnvio(cdc,cl.getDireccion());
      System.out.println("*************************");
      
      System.out.println();
      
 
		 

		
 	}

}


