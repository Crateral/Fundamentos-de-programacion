package com.co.nttdata.ecommerce.entidades;

public enum Empresa {
	
	FALABELLA(1,9000022);
	
	private int id; ;
	private int nit;
	
	



private Empresa(int id, int nit) {
	this.id = id;
	this.nit = nit;
	
	
	}

public int getId() {
	return id;
}


public void setId(int id) {
	this.id = id;
}

public int getNit() {
		return nit;
	}

public void setNit(int nit) {
		this.nit = nit;
	}
	
	
	
	
	


}

