import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.co.nttdata.ecommerce.entidades.*;
import com.co.nttdata.ecommerce.logica.GestionCarritoDeComprasImpl;
import com.co.nttdata.ecommerce.logica.GestionFacturaImpl;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Crear 10 prodcutos
		//Añadir 6 al carrito de comprar
		//Crear la factura de ese carrito de compras
		
 	}

}
