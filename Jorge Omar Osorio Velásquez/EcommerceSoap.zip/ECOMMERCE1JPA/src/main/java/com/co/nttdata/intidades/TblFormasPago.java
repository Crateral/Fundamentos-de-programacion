package com.co.nttdata.intidades;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the "TBL_FORMAS_PAGO" database table.
 * 
 */
@Entity
@Table(name="\"TBL_FORMAS_PAGO\"")
@NamedQuery(name="TblFormasPago.findAll", query="SELECT t FROM TblFormasPago t")
public class TblFormasPago implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="id_forma_pago")
	private Integer idFormaPago;

	@Column(name="forma_pago")
	private String formaPago;

	public TblFormasPago() {
	}

	public Integer getIdFormaPago() {
		return this.idFormaPago;
	}

	public void setIdFormaPago(Integer idFormaPago) {
		this.idFormaPago = idFormaPago;
	}

	public String getFormaPago() {
		return this.formaPago;
	}

	public void setFormaPago(String formaPago) {
		this.formaPago = formaPago;
	}

}