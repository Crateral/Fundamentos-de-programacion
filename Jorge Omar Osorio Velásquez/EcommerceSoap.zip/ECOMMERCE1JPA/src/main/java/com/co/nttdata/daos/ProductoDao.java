package com.co.nttdata.daos;

import javax.persistence.EntityManager;

import com.co.nttdata.intidades.*;

public class ProductoDao {
	
	
	private EntityManager entityManager;
    //private Object object;


	  public ProductoDao(EntityManager entityManager) {
		
			this.entityManager = entityManager;
		}
   


    public void create(TblProducto producto) {
        entityManager.getTransaction().begin();
        entityManager.persist(producto);
        entityManager.getTransaction().commit();


   }
 
//encontrar por id
    public TblProducto findById(int id_producto) {
       return entityManager.find(TblProducto.class,id_producto);
   }

    //actualizar

    public void update(TblProducto producto ) {
       entityManager.getTransaction().begin();
       entityManager.merge(producto);
       entityManager.getTransaction().commit();
   }


    //eliminar

    public void delete(TblProducto producto) {
       entityManager.getTransaction().begin();
       entityManager.remove(producto);
       entityManager.getTransaction().commit();
		
		
	}

}
