package com.co.nttdata.servicesImpl;

import javax.jws.WebService;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.co.nttdata.daos.CategoriaDao;
import com.co.nttdata.daos.MarcaDao;
import com.co.nttdata.intidades.*;
import com.co.nttdata.services.CategoriaService;
import com.co.nttdata.services.MarcaService;



	@WebService(endpointInterface = "com.co.nttdata.services.CategoriaService")
	public class CategoriaServiceImpl  implements CategoriaService{

	 

	    public  final String PERSISTENCE_UNIT_NAME="ECOMMERCE1JPA";
	    private  EntityManagerFactory factory;

	   
	    public TblCategoria findById(int idCategoria) {
	    	
	    	
	    	factory=Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
	    	EntityManager em=factory.createEntityManager();

	    	CategoriaDao cdao=new CategoriaDao(em);

	    	TblCategoria m= new TblCategoria(); 
	    	m= cdao.findById(idCategoria);
	    	em.close();
	    	factory.close();

	    	return m;
	    	
	    }
	}
