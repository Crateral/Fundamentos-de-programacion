package com.co.nttdata.intidades;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the "TBL_FACTURAS" database table.
 * 
 */
@Entity
@Table(name="\"TBL_FACTURAS\"")
@NamedQuery(name="TblFactura.findAll", query="SELECT t FROM TblFactura t")
public class TblFactura implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="id_factura")
	private Integer idFactura;

	private String descripcion;

	@Temporal(TemporalType.DATE)
	private Date fecha;

	@Column(name="id_carrito")
	private Integer idCarrito;

	@Column(name="id_cliente")
	private Integer idCliente;

	@Column(name="nit_empresa")
	private String nitEmpresa;

	@Column(name="valor_descuento")
	private double valorDescuento;

	@Column(name="valor_envio")
	private double valorEnvio;

	@Column(name="valor_iva")
	private double valorIva;

	@Column(name="valor_total_con_iva")
	private double valorTotalConIva;

	@Column(name="valor_total_factura")
	private double valorTotalFactura;

	@Column(name="valor_total_sin_iva")
	private double valorTotalSinIva;

	public TblFactura() {
	}

	public Integer getIdFactura() {
		return this.idFactura;
	}

	public void setIdFactura(Integer idFactura) {
		this.idFactura = idFactura;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Date getFecha() {
		return this.fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public Integer getIdCarrito() {
		return this.idCarrito;
	}

	public void setIdCarrito(Integer idCarrito) {
		this.idCarrito = idCarrito;
	}

	public Integer getIdCliente() {
		return this.idCliente;
	}

	public void setIdCliente(Integer idCliente) {
		this.idCliente = idCliente;
	}

	public String getNitEmpresa() {
		return this.nitEmpresa;
	}

	public void setNitEmpresa(String nitEmpresa) {
		this.nitEmpresa = nitEmpresa;
	}

	public double getValorDescuento() {
		return this.valorDescuento;
	}

	public void setValorDescuento(double valorDescuento) {
		this.valorDescuento = valorDescuento;
	}

	public double getValorEnvio() {
		return this.valorEnvio;
	}

	public void setValorEnvio(double valorEnvio) {
		this.valorEnvio = valorEnvio;
	}

	public double getValorIva() {
		return this.valorIva;
	}

	public void setValorIva(double valorIva) {
		this.valorIva = valorIva;
	}

	public double getValorTotalConIva() {
		return this.valorTotalConIva;
	}

	public void setValorTotalConIva(double valorTotalConIva) {
		this.valorTotalConIva = valorTotalConIva;
	}

	public double getValorTotalFactura() {
		return this.valorTotalFactura;
	}

	public void setValorTotalFactura(double valorTotalFactura) {
		this.valorTotalFactura = valorTotalFactura;
	}

	public double getValorTotalSinIva() {
		return this.valorTotalSinIva;
	}

	public void setValorTotalSinIva(double valorTotalSinIva) {
		this.valorTotalSinIva = valorTotalSinIva;
	}

}