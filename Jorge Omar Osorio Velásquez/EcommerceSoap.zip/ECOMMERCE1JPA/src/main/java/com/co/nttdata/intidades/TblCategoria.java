package com.co.nttdata.intidades;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the "TBL_CATEGORIAS" database table.
 * 
 */
@Entity
@Table(name="\"TBL_CATEGORIAS\"")
@NamedQuery(name="TblCategoria.findAll", query="SELECT t FROM TblCategoria t")
public class TblCategoria implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="id_categoria")
	private Integer idCategoria;

	private String categoria;

	private String descripcion;

	@Column(name="iva_precio")
	private double ivaPrecio;
	public Integer getIdCategoria() {
		return this.idCategoria;
	}

	public void setIdCategoria(Integer idCategoria) {
		this.idCategoria = idCategoria;
	}

	public String getCategoria() {
		return this.categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public double getIvaPrecio() {
		return this.ivaPrecio;
	}

	public void setIvaPrecio(double ivaPrecio) {
		this.ivaPrecio = ivaPrecio;
	}

}