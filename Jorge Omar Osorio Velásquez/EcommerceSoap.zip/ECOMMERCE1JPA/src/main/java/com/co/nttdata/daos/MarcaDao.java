package com.co.nttdata.daos;

import java.util.List;

import javax.persistence.EntityManager;

import com.co.nttdata.intidades.TblMarca;
public class MarcaDao {
	
	

	private EntityManager entityManager;
    //private Object object;


	  public MarcaDao(EntityManager entityManager) {
		
			this.entityManager = entityManager;
		}
   


    public void create(TblMarca marca) {
        entityManager.getTransaction().begin();
        entityManager.persist(marca);
        entityManager.getTransaction().commit();


   }
    
    
    public List<TblMarca> findAll(){
        entityManager.getTransaction().begin();
        javax.persistence.Query q = entityManager.createQuery("SELECT m FROM TblMarca m");
        entityManager.getTransaction().commit();
        return q.getResultList();
    }
 
//encontrar por id
    public TblMarca findById(int id_marca) {
       return entityManager.find(TblMarca.class,id_marca);
   }

    //actualizar

    public void update(TblMarca marca ) {
       entityManager.getTransaction().begin();
       entityManager.merge(marca);
       entityManager.getTransaction().commit();
   }


    //eliminar

    public void delete(TblMarca marca) {
       entityManager.getTransaction().begin();
       entityManager.remove(marca);
       entityManager.getTransaction().commit();
		
		
	}
	
	
	
}
		
