package com.co.nttdata.services;

import javax.jws.WebMethod;
import javax.jws.WebService;

import com.co.nttdata.intidades.TblCategoria;

@WebService
public interface CategoriaService {
	@WebMethod
	 public TblCategoria findById(int idCategoria);
   
		  

}

