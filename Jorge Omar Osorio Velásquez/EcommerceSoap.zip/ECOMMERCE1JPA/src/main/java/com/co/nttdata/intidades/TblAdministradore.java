package com.co.nttdata.intidades;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the "TBL_ADMINISTRADORES" database table.
 * 
 */
@Entity
@Table(name="\"TBL_ADMINISTRADORES\"")
@NamedQuery(name="TblAdministradore.findAll", query="SELECT t FROM TblAdministradore t")
public class TblAdministradore implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="id_admin")
	private Integer idAdmin;

	private String contrasenia;

	private String correo;

	private Boolean estado;

	@Column(name="\"id_tipoIdentificacion\"")
	private Integer id_tipoIdentificacion;

	private String nombre;

	@Column(name="num_identificacion")
	private String numIdentificacion;

	public TblAdministradore() {
	}

	public Integer getIdAdmin() {
		return this.idAdmin;
	}

	public void setIdAdmin(Integer idAdmin) {
		this.idAdmin = idAdmin;
	}

	public String getContrasenia() {
		return this.contrasenia;
	}

	public void setContrasenia(String contrasenia) {
		this.contrasenia = contrasenia;
	}

	public String getCorreo() {
		return this.correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public Boolean getEstado() {
		return this.estado;
	}

	public void setEstado(Boolean estado) {
		this.estado = estado;
	}

	public Integer getId_tipoIdentificacion() {
		return this.id_tipoIdentificacion;
	}

	public void setId_tipoIdentificacion(Integer id_tipoIdentificacion) {
		this.id_tipoIdentificacion = id_tipoIdentificacion;
	}

	public String getNombre() {
		return this.nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getNumIdentificacion() {
		return this.numIdentificacion;
	}

	public void setNumIdentificacion(String numIdentificacion) {
		this.numIdentificacion = numIdentificacion;
	}

}