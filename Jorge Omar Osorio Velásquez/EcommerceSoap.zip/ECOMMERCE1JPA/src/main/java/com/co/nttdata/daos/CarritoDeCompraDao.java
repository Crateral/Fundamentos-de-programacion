package com.co.nttdata.daos;

import javax.persistence.EntityManager;

import com.co.nttdata.intidades.*;


public class CarritoDeCompraDao {
	
	private EntityManager entityManager;
    //private Object object;


	  public CarritoDeCompraDao(EntityManager entityManager) {
		
			this.entityManager = entityManager;
		}
   


    public void create(TblCarritoDeCompra carrito) {
        entityManager.getTransaction().begin();
        entityManager.persist(carrito);
        entityManager.getTransaction().commit();


   }
 
//encontrar por id
    public TblCarritoDeCompra  findById(int id_carrito) {
       return entityManager.find(TblCarritoDeCompra.class,id_carrito);
   }

    //actualizar

    public void update(TblCarritoDeCompra carrito ) {
       entityManager.getTransaction().begin();
       entityManager.merge(carrito);
       entityManager.getTransaction().commit();
   }


    //eliminar

    public void delete(TblCarritoDeCompra carrito) {
       entityManager.getTransaction().begin();
       entityManager.remove(carrito);
       entityManager.getTransaction().commit();
		
		
	}

}
