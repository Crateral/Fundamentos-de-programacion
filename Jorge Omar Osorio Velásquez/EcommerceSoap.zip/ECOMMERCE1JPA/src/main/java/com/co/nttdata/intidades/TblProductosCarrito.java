package com.co.nttdata.intidades;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the "TBL_PRODUCTOS_CARRITO" database table.
 * 
 */
@Entity
@Table(name="\"TBL_PRODUCTOS_CARRITO\"")
@NamedQuery(name="TblProductosCarrito.findAll", query="SELECT t FROM TblProductosCarrito t")
public class TblProductosCarrito implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="id_producto_carrito")
	private Integer idProductoCarrito;

	@Column(name="id_carrito")
	private Integer idCarrito;

	@Column(name="id_producto")
	private Integer idProducto;

	public TblProductosCarrito() {
	}

	public Integer getIdProductoCarrito() {
		return this.idProductoCarrito;
	}

	public void setIdProductoCarrito(Integer idProductoCarrito) {
		this.idProductoCarrito = idProductoCarrito;
	}

	public Integer getIdCarrito() {
		return this.idCarrito;
	}

	public void setIdCarrito(Integer idCarrito) {
		this.idCarrito = idCarrito;
	}

	public Integer getIdProducto() {
		return this.idProducto;
	}

	public void setIdProducto(Integer idProducto) {
		this.idProducto = idProducto;
	}

}