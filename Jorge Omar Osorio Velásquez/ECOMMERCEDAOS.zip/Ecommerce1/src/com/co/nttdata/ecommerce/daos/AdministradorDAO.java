package com.co.nttdata.ecommerce.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.co.nttdata.ecommerce.entidades.Administrador;
import com.co.nttdata.ecommerce.entidades.Marca;
import com.co.nttdata.ecommerce.utils.Conection;

public class AdministradorDAO {
	
	
	
	
	
	
	
	
	  Conection con = new Conection();
	    Scanner teclado = new Scanner(System.in);
	    
	    public List<Administrador> buscarAdministrador(){
	        
	        Connection baseDatos = con.conectarBD();
	        PreparedStatement st = null;
	        ResultSet rs = null;
	        
	        List<Administrador> admin = new ArrayList<Administrador>();
	        
	        try {
	            
	            st = baseDatos.prepareStatement("SELECT * FROM \"TBL_ADMINISTRADORES\" ORDER BY id_marca ASC");
	            rs = st.executeQuery();
	            
	            while (rs.next()) {
	                
	                Administrador adm = new Administrador();
	                adm.setId(rs.getInt("id_admin"));
	                adm.setNombreUsuario(rs.getString("usuario"));
	                adm.setContrasenia(rs.getString("contrasenia"));
	                adm.setCorreo(rs.getString("correo"));
	                adm.setEstado(rs.getBoolean("estado"));
	                adm.setNumeroIdentificacion(rs.getString("num_identificacion"));
	                adm.setTipoIdentificacion(rs.getString("id_tipoIdentificacion"));
	                
	             
	               
	                
	                admin.add(adm);
	            }
	            
	        } catch (Exception e) {
	            System.err.println(e.getMessage());
	        } finally {
	            try {
	                rs.close();
	                st.close();
	                con.desconectarBD(baseDatos);
	            } catch (Exception e2) {
	                System.err.println(e2.getMessage());
	            }
	        }
	                
	        
	        return admin;
	    
	        
}
	    public Administrador buscarAdministrador(int adminis) {
	    	
	           Administrador ad = new Administrador();
	            
	            Connection baseDatos = con.conectarBD();
	            PreparedStatement st = null;
	            ResultSet rs = null;
	            
	            try {
	                st = baseDatos.prepareStatement("SELECT * FROM \"TBL_ADMINISTRADORES\" WHERE id_admin = ? ");
	                st.setInt(1, adminis);
	               
	                rs = st.executeQuery();
	                
	                while (rs.next()) {
	                    ad.setIdAdmin(rs.getInt("id_admin"));
	                    ad.setNombreUsuario(rs.getNString("usuario"));
	                    ad.setContrasenia(rs.getString("contrasenia"));
	                    ad.setCorreo(rs.getString("correo"));
	                    ad.setEstado(rs.getBoolean("estado"));
	                    ad.setNumeroIdentificacion(rs.getString("num_identificacion"));
	                    ad.setTipoIdentificacion(rs.getString("id_tipoIdentificacion"));
	                
	                 
	                 
	                }
	                
	            } catch (Exception e) {
	                System.err.println(e.getMessage());
	            } finally {
	                try {
	                    rs.close();
	                    st.close();
	                    con.desconectarBD(baseDatos);
	                } catch (Exception e2) {
	                    System.err.println(e2.getMessage());
	                }
	            }
	            return ad;        
	        }
  public void agregarAdministrador(Administrador ad) {
	        
	        Connection baseDatos = con.conectarBD();
	        PreparedStatement st = null;
	        
	        try {
	            st = baseDatos.prepareStatement("INSERT INTO \"TBL_ADMINISTRADORES\" (id_admin,usuario,contrasenia,correo,estado,num_identificacion,id_tipoIdentificacion) VALUES (?, ?)");
	            st.setInt(1, ad.getIdAdmin());
	            st.setString(2,ad.getNombreUsuario());
	            st.setString(3, ad.getContrasenia());
	            st.setString(4,ad.getCorreo());
	            st.setBoolean(5, ad.isEstado());
	            st.setString(6,ad.getNumeroIdentificacion());
	            st.setString(7,ad.getTipoIdentificacion());
	            
	            int val = st.executeUpdate();
	            
	            if (val > 0)
	                System.out.println("\nRegistro guardado con éxito...");
	            else
	                System.err.println("\nError al guardar el registro... !");
	            
	        } catch (Exception e) {
	            System.err.println(e.getMessage());
	        } finally {
	            try {
	                st.close();
	                con.desconectarBD(baseDatos);
	            } catch (Exception e2) {
	                System.err.println(e2.getMessage());
	            }
	        }   
	        
	    }
	    
	    //metodo eliminar
	    public Administrador elimAdministrador(int ad) {
	      Administrador adm = new Administrador();
	        
	        Connection baseDatos = con.conectarBD();
	        PreparedStatement st = null;
	                
	        System.out.print("\nDesea eliminar el administrador (s/n) ? : ");
	        String rg = teclado.next();
	        if (rg.equals("s")) {
	            try {
	                st = baseDatos.prepareStatement("DELETE FROM \"TBL_ADMINISTRADORES\" WHERE id_admin = ? ");
	                st.setInt(1, ad);
	                int val = st.executeUpdate();
	                
	                if (val > 0)
	                    System.out.println("\nRegistro eliminado con éxito...");
	                else
	                    System.err.println("\nError al eliminar el registro... !");
	                
	            } catch (Exception e) {
	                System.err.println(e.getMessage());
	            } finally {
	                try {
	                    st.close();
	                    con.desconectarBD(baseDatos);
	                } catch (Exception e2) {
	                    System.err.println(e2.getMessage());
	                }
	            }
	                
	        } else if (rg.equals("n")) {
	            System.out.println("\nSeleccionó no eliminar ADMINISTRADOR... !");
	        }
	        return adm;    
	    }
	    // metod modificar
	    
	    public void modAdministrador(int idAdmin, String correo, boolean estado, String numeroIdentificacion, String tipoIdentificacion) {
            
	        Connection baseDatos = con.conectarBD();
	        PreparedStatement st = null;
	                
	        try {
	            st = baseDatos.prepareStatement("UPDATE \"TBL_ADMINISTRADORES\" SET id_admin = ?, correo = ?, estado = ?, num_identificacion = ?, id_tipoIdentificacion = ? WHERE id_marca = ?");
	            st.setInt(1, idAdmin);
	            st.setString(2, correo);
	            st.setBoolean(3, estado);
	            st.setString(4, numeroIdentificacion);
	            st.setString(5, tipoIdentificacion);
	           
	            int val = st.executeUpdate();



	           if (val > 0)
	                System.out.println("\nRegistro modificado con éxito...");
	            else
	                System.err.println("\nError al modificar el registro... !");



	       } catch (Exception e) {
	            System.err.println(e.getMessage());
	        } finally {
	            try {
	                st.close();
	                con.desconectarBD(baseDatos);
	            } catch (Exception e2) {
	                System.err.println(e2.getMessage());
	            }
	        }

}
}
