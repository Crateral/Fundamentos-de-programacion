package com.co.nttdata.ecommerce.logica;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.co.nttdata.ecommerce.entidades.*;

import com.co.nttdata.ecommerce.interfaces.GestionCarritoDeCompras;



public class GestionCarritoDeComprasImpl implements GestionCarritoDeCompras{
	double total = 0.0;
	

List<Producto> list = new ArrayList<>();
Scanner consola =  new Scanner(System.in);


GestionFacturaImpl gf = new GestionFacturaImpl();

Factura f =new Factura();
CarritoDeCompra cdc = new CarritoDeCompra();
Cliente cl = new Cliente();
Scanner teclado = new Scanner(System.in);
//creacion de los 10 productos


	@Override
	public CarritoDeCompra añadirAlCarrito(CarritoDeCompra cdc,List<Producto> list) {
		
		cdc.setProductos(list);		
		return cdc;
	}
	
	

	
	@Override
	public CarritoDeCompra calcularTotalConIva(CarritoDeCompra cdc) {
		
		
		for (int i = 0; i < cdc.getProductos().size(); i++) {
		       //1100           2000
		total = total + cdc.getProductos().get(i).getPrecio() + 
				(cdc.getProductos().get(i).getPrecio() * 
						(cdc.getProductos().get(i).getIva())/100);
		}
		cdc.setSubTotalConIva(total);
		System.out.println(cdc.getSubTotalConIva());
		return cdc;

	}

	 

	@Override
	public  CarritoDeCompra calcularCostoEnvio(CarritoDeCompra cdc,Ciudad ciudad ){
		//Para el calculo del envio se debe tener en cuenta la ubicacion del cliente
				//Si se encuentra en ciudades principales se debe cobrar el 5%
				//Si se encuentra en ciudades no principales se debe cobrar el 10%
		
		double valor = 0;
		
			if(ciudad.isPrincipal()){
				valor=total * 0.05;
			}else {
				valor=total * 0.1;
			}
			cdc.setValorEnvio(valor);
			System.out.println(cdc.getValorEnvio());
		return cdc;
	}




	
	




	




	


	
	/*
double total = 0.0;
	@overrider
	public CarritoDeCompras añadirAlCarrito(CarritoDeCompras cdc, List<Producto> p) {
		
		cdc.setProductos(p);
		return cdc;
		
	}
	
	public CarritoDeCompras calcularTotalConIva(CarritoDeCompras cdc) {
		
		for (int i = 0; i < cdc.getProductos().size(); i++) {
			       //1100           2000
			total = total + cdc.getProductos().get(i).getPrecio() + 
					(cdc.getProductos().get(i).getPrecio() * 
							(cdc.getProductos().get(i).getIva())/100);
		}
		cdc.setSubTotalConIva(total);
		System.out.println(cdc.getSubTotalConIva());
		return cdc;
	}
	
	public CarritoDeCompras calcularTotalSinIva(CarritoDeCompras cdc) {
		double total =0;
		for(int i = 1; i<cdc.getProductos().size(); i++){
			total= total + cdc.getProductos().get(i).getPrecio();
			
		}
	cdc.setSubTotalSinIva(total);
	return cdc;
	}
	
	//Para el calculo del envio se debe tener en cuenta la ubicacion del cliente
		//Si se encuentra en ciudades principales se debe cobrar el 5%
		//Si se encuentra en ciudades no principales se debe cobrar el 10%
	
	/* public double calcularCostoEnvio(Cliente c, double valor) {
		if(c.getCiudad().isPrincipal()){
			return valor * 0.05;
		}else {
			return valor * 0.1;
		}
	}*/

	
	




		
		

	


}

