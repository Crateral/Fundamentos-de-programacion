package com.co.nttdata.ecommerce.interfaces;

import com.co.nttdata.ecommerce.entidades.CarritoDeCompra;
import com.co.nttdata.ecommerce.entidades.Cliente;
import com.co.nttdata.ecommerce.entidades.Factura;

public interface GestionFactura {
	
	public Factura pagar(Cliente cliente, CarritoDeCompra cdc);
	
	public void ImprimirFactura();
	
	
}
