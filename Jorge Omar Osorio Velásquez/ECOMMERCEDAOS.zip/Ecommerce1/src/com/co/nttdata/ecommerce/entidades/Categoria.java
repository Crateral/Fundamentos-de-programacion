package com.co.nttdata.ecommerce.entidades;

import java.io.Serializable;

public class Categoria implements Serializable {
	
	
	

	private static final long serialVersionUID = 1L;
	
	private int idCategoria;
	private String categoria;
	private String descripcion;
	private double iva;
	
	
	public Categoria() {
		
	}
	

	
	
	


	public int getIdCategoria() {
		return idCategoria;
	}
	public void setIdCategoria(int idCategoria) {
		this.idCategoria = idCategoria;
	}
	public String getCategoria() {
		return categoria;
	}
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public double getIva() {
		return iva;
	}
	public void setIva(double iva) {
		this.iva = iva;
	}

	

	
	
	
	
}
