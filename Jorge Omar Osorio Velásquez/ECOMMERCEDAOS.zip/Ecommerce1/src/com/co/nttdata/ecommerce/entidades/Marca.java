package com.co.nttdata.ecommerce.entidades;

import java.io.Serializable;

public class Marca implements Serializable {

	
	private static final long serialVersionUID = 1L;
	private int id;
	private String descripcion;
	private String nombreMarca;
	
	public Marca() {
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getNombreMarca() {
		return nombreMarca;
	}

	public void setNombreMarca(String nombreMarca) {
		this.nombreMarca = nombreMarca;
	}	
	
	
}

