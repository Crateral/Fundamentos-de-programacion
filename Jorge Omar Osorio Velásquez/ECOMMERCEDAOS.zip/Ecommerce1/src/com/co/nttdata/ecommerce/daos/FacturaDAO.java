package com.co.nttdata.ecommerce.daos;

public class FacturaDAO {

}
