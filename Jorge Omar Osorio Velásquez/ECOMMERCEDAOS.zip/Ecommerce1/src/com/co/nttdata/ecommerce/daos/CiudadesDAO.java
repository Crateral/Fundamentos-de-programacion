package com.co.nttdata.ecommerce.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.co.nttdata.ecommerce.entidades.Administrador;
import com.co.nttdata.ecommerce.entidades.Ciudad;
import com.co.nttdata.ecommerce.entidades.Marca;
import com.co.nttdata.ecommerce.utils.Conection;

public class CiudadesDAO {
	
	
	 Conection con = new Conection();
	    Scanner teclado = new Scanner(System.in);
	    
	    public List<Ciudad> buscarCiudad(){
	        
	        Connection baseDatos = con.conectarBD();
	        PreparedStatement st = null;
	        ResultSet rs = null;
	        
	        List<Ciudad> ciu = new ArrayList<Ciudad>();
	        
	        try {
	            
	            st = baseDatos.prepareStatement("SELECT * FROM \"TBL_CIUDADES\" ORDER BY id_marca ASC");
	            rs = st.executeQuery();
	            
	            while (rs.next()) {
	                
	               Ciudad ciudades = new Ciudad();
	                ciudades.setIdCiudades(rs.getInt("id_ciudad"));
	                ciudades.setCiudad(rs.getString("ciudad"));
	                ciudades.setPrincipal(rs.getBoolean("principal"));
	               
	             
	               ciu.add(ciudades);
	            }
	            
	        } catch (Exception e) {
	            System.err.println(e.getMessage());
	        } finally {
	            try {
	                rs.close();
	                st.close();
	                con.desconectarBD(baseDatos);
	            } catch (Exception e2) {
	                System.err.println(e2.getMessage());
	            }
	        }
	                
	        
	        return ciu;
	    
	        
}
	    public Ciudad buscarCiudad(int ciud) {
	    	
	          Ciudad ci = new Ciudad();
	            
	            Connection baseDatos = con.conectarBD();
	            PreparedStatement st = null;
	            ResultSet rs = null;
	            
	            try {
	                st = baseDatos.prepareStatement("SELECT * FROM \"TBL_CIUDADES\" WHERE id_ciudad = ? ");
	                st.setInt(1, ciud);
	               
	                rs = st.executeQuery();
	                
	                while (rs.next()) {
	                    ci.setIdCiudades(rs.getInt("id_ciudad"));
	                    ci.setCiudad(rs.getString("ciudad"));
	                    ci.setPrincipal(rs.getBoolean("principal"));
	              
	                 
	                 
	                }
	                
	            } catch (Exception e) {
	                System.err.println(e.getMessage());
	            } finally {
	                try {
	                    rs.close();
	                    st.close();
	                    con.desconectarBD(baseDatos);
	                } catch (Exception e2) {
	                    System.err.println(e2.getMessage());
	                }
	            }
	            return ci;        
	        }
 public void agregMarca(Ciudad c) {
	        
	        Connection baseDatos = con.conectarBD();
	        PreparedStatement st = null;
	        
	        try {
	            st = baseDatos.prepareStatement("INSERT INTO \"TBL_CIUDADES\" (id_ciudad,ciudad, principal) VALUES (?, ?)");
	            st.setInt(1, c.getIdCiudades());
	            st.setString(2, c.getCiudad());
	            st.setBoolean(3, c.isPrincipal());
	            int val = st.executeUpdate();
	            
	            if (val > 0)
	                System.out.println("\nRegistro guardado con éxito...");
	            else
	                System.err.println("\nError al guardar el registro... !");
	            
	        } catch (Exception e) {
	            System.err.println(e.getMessage());
	        } finally {
	            try {
	                st.close();
	                con.desconectarBD(baseDatos);
	            } catch (Exception e2) {
	                System.err.println(e2.getMessage());
	            }
	        }   
	        
	    }
	    
	    //metodo eliminar
	    public Ciudad elimMarca(int ciu) {
	       Ciudad ciud = new Ciudad();
	        
	        Connection baseDatos = con.conectarBD();
	        PreparedStatement st = null;
	                
	        System.out.print("\nDesea eliminar la ciudad (s/n) ? : ");
	        String rg = teclado.next();
	        if (rg.equals("s")) {
	            try {
	                st = baseDatos.prepareStatement("DELETE FROM \"TBL_CIUDADES\" WHERE id_ciudad = ? ");
	                st.setInt(1, ciu);
	                int val = st.executeUpdate();
	                
	                if (val > 0)
	                    System.out.println("\nRegistro eliminado con éxito...");
	                else
	                    System.err.println("\nError al eliminar el registro... !");
	                
	            } catch (Exception e) {
	                System.err.println(e.getMessage());
	            } finally {
	                try {
	                    st.close();
	                    con.desconectarBD(baseDatos);
	                } catch (Exception e2) {
	                    System.err.println(e2.getMessage());
	                }
	            }
	                
	        } else if (rg.equals("n")) {
	            System.out.println("\nSeleccionó no eliminar ciudad... !");
	        }
	        return ciud;    
	    }
	    // metod modificar
	    
	    public void modCiudad(int idCiudad, String ciudad, boolean principal) {
            
	        Connection baseDatos = con.conectarBD();
	        PreparedStatement st = null;
	                
	        try {
	            st = baseDatos.prepareStatement("UPDATE \"TBL_CIUDADES\" SET id_ciuadad = ?, ciudad = ?, principal = ? WHERE id_ciudad = ?");
	            st.setInt(1, idCiudad);
	            st.setString(2, ciudad);
	            st.setBoolean(3, principal);
	            int val = st.executeUpdate();



	           if (val > 0)
	                System.out.println("\nRegistro modificado con éxito...");
	            else
	                System.err.println("\nError al modificar el registro... !");



	       } catch (Exception e) {
	            System.err.println(e.getMessage());
	        } finally {
	            try {
	                st.close();
	                con.desconectarBD(baseDatos);
	            } catch (Exception e2) {
	                System.err.println(e2.getMessage());
	            }
	        }

}
}
