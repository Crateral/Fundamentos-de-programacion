package com.co.nttdata.ecommerce.entidades;

import java.io.Serializable;

public class Ciudad implements Serializable{
    
   
	
	private static final long serialVersionUID = 1L;
	
	private int idCiudad;
    private String ciudad;
    private boolean principal;
    
    public Ciudad() {
    	
    }

	public int getIdCiudades() {
		return idCiudad;
	}

	public void setIdCiudades(int idCiudades) {
		this.idCiudad = idCiudades;
	}

	public String getCiudad() {
		return ciudad;
	}

	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}

	public boolean isPrincipal() {
		return principal;
	}

	public void setPrincipal(boolean principal) {
		this.principal = principal;
	}
    
    
    
	
    
    
	
    
    

}