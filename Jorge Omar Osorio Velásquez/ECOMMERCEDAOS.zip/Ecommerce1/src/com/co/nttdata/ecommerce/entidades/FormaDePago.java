package com.co.nttdata.ecommerce.entidades;

public class FormaDePago {
	
	private int idFormaDePago;
	private String formaDePago;
	
	public FormaDePago(int idFormaDePago, String formaDePago) {
		super();
		this.idFormaDePago = idFormaDePago;
		this.formaDePago = formaDePago;
	}

	public int getIdFormaDePago() {
		return idFormaDePago;
	}

	public void setIdFormaDePago(int idFormaDePago) {
		this.idFormaDePago = idFormaDePago;
	}

	public String getFormaDePago() {
		return formaDePago;
	}

	public void setFormaDePago(String formaDePago) {
		this.formaDePago = formaDePago;
	}

	@Override
	public String toString() {
		return "FormaDePago [idFormaDePago=" + idFormaDePago + ", formaDePago=" + formaDePago + "]";
	}
	
	
	
}
