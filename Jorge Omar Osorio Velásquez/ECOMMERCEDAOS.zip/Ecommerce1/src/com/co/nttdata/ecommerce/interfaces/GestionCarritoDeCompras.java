package com.co.nttdata.ecommerce.interfaces;

import java.util.List;

import com.co.nttdata.ecommerce.entidades.CarritoDeCompra;
import com.co.nttdata.ecommerce.entidades.Ciudad;

import com.co.nttdata.ecommerce.entidades.Producto;


public interface GestionCarritoDeCompras {
	
	public CarritoDeCompra añadirAlCarrito(CarritoDeCompra cdc, List<Producto> list);
	
	public CarritoDeCompra calcularTotalConIva(CarritoDeCompra cdc);

	public  CarritoDeCompra calcularCostoEnvio(CarritoDeCompra cdc,Ciudad ciudad );
	
	
}
