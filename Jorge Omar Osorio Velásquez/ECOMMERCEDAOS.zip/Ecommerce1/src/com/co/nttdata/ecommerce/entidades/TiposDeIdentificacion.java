package com.co.nttdata.ecommerce.entidades;

public class TiposDeIdentificacion {

	private int idTipiIdentificacion;
	private String tipoIdentificacion;
	
	public TiposDeIdentificacion(int idTipiIdentificacion, String tipoIdentificacion) {
		super();
		this.idTipiIdentificacion = idTipiIdentificacion;
		this.tipoIdentificacion = tipoIdentificacion;
	}

	public int getIdTipiIdentificacion() {
		return idTipiIdentificacion;
	}

	public void setIdTipiIdentificacion(int idTipiIdentificacion) {
		this.idTipiIdentificacion = idTipiIdentificacion;
	}

	public String getTipoIdentificacion() {
		return tipoIdentificacion;
	}

	public void setTipoIdentificacion(String tipoIdentificacion) {
		this.tipoIdentificacion = tipoIdentificacion;
	}
	
	
}
