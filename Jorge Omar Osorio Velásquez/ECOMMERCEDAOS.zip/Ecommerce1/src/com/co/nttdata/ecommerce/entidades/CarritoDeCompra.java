package com.co.nttdata.ecommerce.entidades;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class CarritoDeCompra {

	private int idCarrito;
	private int idProducto;
	private Date fecha;
	private double valorEnvio;
	private double descuento;
	private double iva;
	private double subtotalSinIva;
	private double subtotalConIva;
	
	
	public CarritoDeCompra() {
		
	}


	public CarritoDeCompra(int idCarrito, int idProducto, Date fecha, double valorEnvio, double descuento, double iva,
			double subtotalSinIva, double subtotalConIva) {
		super();
		this.idCarrito = idCarrito;
		this.idProducto = idProducto;
		this.fecha = fecha;
		this.valorEnvio = valorEnvio;
		this.descuento = descuento;
		this.iva = iva;
		this.subtotalSinIva = subtotalSinIva;
		this.subtotalConIva = subtotalConIva;
	}


	public int getIdCarrito() {
		return idCarrito;
	}


	public void setIdCarrito(int idCarrito) {
		this.idCarrito = idCarrito;
	}


	public int getIdProducto() {
		return idProducto;
	}


	public void setIdProducto(int idProducto) {
		this.idProducto = idProducto;
	}


	public Date getFecha() {
		return fecha;
	}


	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}


	public double getValorEnvio() {
		return valorEnvio;
	}


	public void setValorEnvio(double valorEnvio) {
		this.valorEnvio = valorEnvio;
	}


	public double getDescuento() {
		return descuento;
	}


	public void setDescuento(double descuento) {
		this.descuento = descuento;
	}


	public double getIva() {
		return iva;
	}


	public void setIva(double iva) {
		this.iva = iva;
	}


	public double getSubtotalSinIva() {
		return subtotalSinIva;
	}


	public void setSubtotalSinIva(double subtotalSinIva) {
		this.subtotalSinIva = subtotalSinIva;
	}


	public double getSubtotalConIva() {
		return subtotalConIva;
	}


	public void setSubtotalConIva(double subtotalConIva) {
		this.subtotalConIva = subtotalConIva;
	}


	@Override
	public String toString() {
		return "CarritoDeCompras [idCarrito=" + idCarrito + ", idProducto=" + idProducto + ", fecha=" + fecha
				+ ", valorEnvio=" + valorEnvio + ", descuento=" + descuento + ", iva=" + iva + ", subtotalSinIva="
				+ subtotalSinIva + ", subtotalConIva=" + subtotalConIva + "]";
	}
	
	
	
	
	

	
	
	
}