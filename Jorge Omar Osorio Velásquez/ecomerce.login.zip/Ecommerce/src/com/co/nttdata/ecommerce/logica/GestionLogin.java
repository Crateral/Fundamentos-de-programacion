package com.co.nttdata.ecommerce.logica;

import com.co.nttdata.ecommerce.entidades.Cliente;
 
import java.util.Scanner;
public class GestionLogin {
	
	Scanner teclado = new Scanner(System.in);
    Cliente cl = new Cliente();
    
    //registro de usuario
	public Cliente registrarUsuario(Cliente cl) {
		
		cl.setTipoIdentificacion("CC");
		cl.setNumeroIdentificacion("1234");
		cl.setNombre("jorge");
		cl.setContrasenia("12");
		
	    System.out.println(cl.getTipoIdentificacion() + "  " + cl.getNumeroIdentificacion()+ "\n" + cl.getNombre()+ " " + cl.getContrasenia());
	    return cl;
		
}
	//ingreso al login
	public void ingresar(Cliente cl) {
		
	    System.out.println("Ingrese su numero de identificacion");
	    String numI = teclado.next();
	    System.out.println("Ingrese su contraseña");
	    String numC = teclado.next();
	    
	    if(cl.getNumeroIdentificacion().equals(numI) && cl.getContrasenia().equals(numC)) {   
	    	
	    	System.out.println("ingreso exitoso");
	    	
	    }else {
	    	System.out.println("ingreso no exitoso");
	    
	    }
	
	
		 
		
	}
// cambio de contraseña
	public void olvidoContrasena(Cliente cl) {
		System.out.println("olvido su contraseña?");
		String numC = teclado.next();
		if(numC.equals("S")) {
			System.out.println("ingrese la nueva contraseña");
			String numA = teclado.next();
			System.out.println("cambio de contraseña exitosa");
			cl.setContrasenia(numA);
		}else {
			System.out.println("no deseo recuperar contraseña");
		}
		
	} 
		    	
		    
		
	
	    
	//Salir del sistema	
	public void salirSistema() {
		System.out.println("salida del sistema con éxito");
		System.exit(0);
		
	}

}
