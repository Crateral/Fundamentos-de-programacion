
package punto5;

/**
 *
 * @author 
 */
public class Hierba extends Planta {

   
    @Override
    public  void cacularAltura(){
        System.out.println("Calculando altura ");
       
    }
    @Override
    public  void crearFlor(){
        System.out.println("Creando flor");
    }
    @Override
    public  void crearFruto(){
          System.out.println("Creando fruto");
    }
    @Override
    public void calcularTiempodeVida(int diasquelleva, int diasdevidaestimado){

        System.out.println("Tiempo de vida en dias: "+(diasdevidaestimado-diasquelleva));
    }
}