/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package punto5;

/**
 *
 * @author 
 */
public class Arbustos extends Planta{
    @Override
    public  void cacularAltura(){
        System.out.println("Calculando altura arbusto ");
       
    }
    @Override
    public  void crearFlor(){
        System.out.println("Creando flor arbusto");
    }
    @Override
    public  void crearFruto(){
          System.out.println("Creando fruto arbusto");
    }
    @Override
    public void calcularTiempodeVida(int diasquelleva, int diasdevidaestimado){

        System.out.println("Tiempo de vida en dias: "+(diasdevidaestimado-diasquelleva));
    }

}
