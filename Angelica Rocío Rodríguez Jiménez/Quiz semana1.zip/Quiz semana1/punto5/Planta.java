/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package punto5;

/**
 *
 * @author 
 */
 abstract class Planta {

     public int altura;

     public boolean dafruto;
     public boolean tieneflores;



     public abstract void cacularAltura();
     public abstract void crearFlor();
     public abstract void crearFruto();
     public abstract void calcularTiempodeVida(int diasquelleva, int diasdevidaestimado);


}
