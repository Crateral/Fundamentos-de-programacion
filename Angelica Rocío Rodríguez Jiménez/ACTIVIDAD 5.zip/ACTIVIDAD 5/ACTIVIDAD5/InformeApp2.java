import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import java.util.Stack;
import java.util.Queue;
import java.util.LinkedList;
import java.util.Scanner;

public class InformeApp2 {
    public static void main(String[] args){
        Stack pila = new Stack();
        pila.push(1);
        pila.push("Informe1");
        pila.push(2);
        pila.push("Informe2");
        pila.push(3);
        pila.push("Informe3");
        pila.push(4);
        pila.push("Informe4");
        pila.push(5);
        pila.push("Informe5");
        pila.push(6);
        pila.push("Informe6");
        pila.push(7);
        pila.push("Informe7");
        pila.push(8);
        pila.push("Informe8");
        pila.push(9);
        pila.push("Informe9");
        pila.push(10);
        pila.push("Informe10");

        System.out.println("El ultimo elemento en entrar, es el primero en salir es: "+pila.peek());
        while(pila.empty()==false);
        {
            System.out.println(pila.pop());
        }
    }
}






