import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import java.util.Stack;
import java.util.Queue;
import java.util.LinkedList;
import java.util.Scanner;

public class ConsultaInforme {
    public static void main(String[] args){
        System.out.println("Elemento Codigo tarea");
        byte opcion = 0;

        // Declaramos el objeto Scanner
        Scanner lectura= new Scanner (System.in);

        do { // Hacer como mínimo una vez.

            System.out.println("Se ageragaron 10 informes de tipo Administrativo, Empresarial y Personal");
            System.out.println("1. Quiere consultar los tipos informes añadidos?");
            System.out.println("2. Cada numero representa un Informe:");
            System.out.println("-->El No 1 identifica Clase Administrativo");
            System.out.println("-->El No 2 identifica Clase Empresarial");
            System.out.println("-->El No 3 identifica Clase Personal");

            // Mostramos un mensaje por pantalla
            System.out.println("Introduce un número: ");

            // Lo leemos y lo guardamos en la variable.
            opcion = lectura.nextByte();

            // y mientras el número sea menor que 1 o menor que 10

        } while (opcion<1 || opcion> 10);

        // Dependiendo de lo que el usuario introduzca
        //ejecutamos una opcion u otra

        switch(opcion) {
            case 1:
                System.out.println("Informe Administrativo posee 3 Codigos");
                System.out.println("Que son:");
                System.out.println("Cogigo 4, Codigo 7, Codigo 10");
                break;

            case 2:
                System.out.println("Informe Empresarial posee 3 Codigos");
                System.out.println("Que son:");
                System.out.println("Cogigo 2, Codigo 6, Codigo 9");
                break;

            case 3:
                System.out.println("El informe Personal posee 4 Codigos");
                System.out.println("Que son:");
                System.out.println("Cogigo 1, Codigo 3, Codigo 5, Codigo 8");
                break;

        }

        Scanner lectura2= new Scanner (System.in);

        do { // Hacer como mínimo una vez.

            System.out.println("--Quiere consultar los otro informe?");


            // Mostramos un mensaje por pantalla
            System.out.println("Introduce un número: ");

            // Lo leemos y lo guardamos en la variable.
            opcion = lectura.nextByte();

            // y mientras el número sea menor que 1 o menor que 10

        } while (opcion<1 || opcion> 10);

        // Dependiendo de lo que el usuario introduzca
        //ejecutamos una opcion u otra

        switch(opcion) {
            case 1:
                System.out.println("Informe Administrativo posee 3 Codigos ");
                System.out.println("Que son:");
                System.out.println("Cogigo 4, Codigo 7, Codigo 10");
                break;

            case 2:
                System.out.println("Informe Empresarial posee 3 Codigos");
                System.out.println("Que son:");
                System.out.println("Cogigo 2, Codigo 6, Codigo 9");
                break;

            case 3:
                System.out.println("El informe Personal posee 4 Codigos");
                System.out.println("Que son:");
                System.out.println("Cogigo 1, Codigo 3, Codigo 5, Codigo 8");
                break;
        }
        Scanner lectura3 = new Scanner (System.in);

        do { // Hacer como mínimo una vez.

            System.out.println("--Quiere consultar los otro informe?");


            // Mostramos un mensaje por pantalla
            System.out.println("Introduce un número: ");

            // Lo leemos y lo guardamos en la variable.
            opcion = lectura.nextByte();

            // y mientras el número sea menor que 1 o menor que 10

        } while (opcion<1 || opcion> 10);

        // Dependiendo de lo que el usuario introduzca
        //ejecutamos una opcion u otra

        switch(opcion) {
            case 1:
                System.out.println("Informe Administrativo posee 3 Codigos");
                System.out.println("Que son:");
                System.out.println("Cogigo 4, Codigo 7, Codigo 10");
                break;

            case 2:
                System.out.println("Informe Empresarial posee 3 Codigos");
                System.out.println("Que son:");
                System.out.println("Cogigo 2, Codigo 6, Codigo 9");
                break;

            case 3:
                System.out.println("El informe Personal posee 4 Codigos");
                System.out.println("Que son:");
                System.out.println("Cogigo 1, Codigo 3, Codigo 5, Codigo 8");
                break;
        }
    }
}


