import java.util.ArrayList;
import java.util.List;

import java.util.Stack;




class InformeApp {

    public static void main(String[] args) {
        List<Informe> lista = new ArrayList<>();

        Informe informe1 = new Informe();
        informe1.setCodigo(1);
        informe1.setTarea("Personal");

        Informe informe2 = new Informe();
        informe2.setCodigo(2);
        informe2.setTarea("Empresarial");

        Informe informe3 = new Informe();
        informe3.setCodigo(3);
        informe3.setTarea("Personal");

        Informe informe4 = new Informe();
        informe4.setCodigo(4);
        informe4.setTarea("Administrativo");

        Informe informe5 = new Informe();
        informe5.setCodigo(5);
        informe5.setTarea("Personal");

        Informe informe6 = new Informe();
        informe6.setCodigo(6);
        informe6.setTarea("Empresarial");

        Informe informe7 = new Informe();
        informe7.setCodigo(7);
        informe7.setTarea("Administrativo");

        Informe informe8 = new Informe();
        informe8.setCodigo(8);
        informe8.setTarea("Personal");

        Informe informe9 = new Informe();
        informe9.setCodigo(9);
        informe9.setTarea("Empresarial");

        Informe informe10 = new Informe();
        informe10.setCodigo(10);
        informe10.setTarea("Administrativo");

        Informe informe11 = new Informe();
        informe11.setCodigo(11);
        informe11.setTarea("Administrativo");

        Informe informe12 = new Informe();
        informe12.setCodigo(12);
        informe12.setTarea("Personal");

        Informe informe13 = new Informe();
        informe13.setCodigo(13);
        informe13.setTarea("Empresarial");

        Informe informe14 = new Informe();
        informe14.setCodigo(14);
        informe14.setTarea("Administrativo");

        Informe informe15 = new Informe();
        informe15.setCodigo(15);
        informe15.setTarea("Administrativo");

        lista.add(informe1);
        lista.add(informe2);
        lista.add(informe3);
        lista.add(informe4);
        lista.add(informe5);
        lista.add(informe6);
        lista.add(informe7);
        lista.add(informe8);
        lista.add(informe9);
        lista.add(informe10);
        lista.add(informe11);
        lista.add(informe12);
        lista.add(informe13);
        lista.add(informe14);
        lista.add(informe15);


        System.out.println("---Primeros 10 informes agregados:");

        for (int i = 0; i<10; i++) {
            System.out.println("el informe con codigo:" +lista.get(i).getCodigo()+" "+
                    "tiene la tarea" + lista.get(i).getTarea());
        }

        System.out.println("---Eliminar cada informe: ");
        Stack <String> stack = new Stack<String>();
        stack.add("Informe1");
        stack.add("Informe2");
        stack.add("Informe3");
        stack.add("Informe4");
        stack.add("Informe5");
        stack.add("Informe6");
        stack.add("Informe7");
        stack.add("Informe8");
        stack.add("Informe9");
        stack.add("Informe10");

        System.out.println("Informes: "+ stack);
        boolean res = stack.remove("Informe10");
        System.out.println("Eliminar el Informe10: " + res );
        System.out.println("Los informes quedaron asi: " +stack);

        boolean res2 = stack.remove("Informe9");
        System.out.println("Eliminar el Informe9: " + res );
        System.out.println("Los informes quedaron asi: " +stack);

        boolean res3 = stack.remove("Informe8");
        System.out.println("Eliminar el Informe8: " + res );
        System.out.println("Los informes quedaron asi: " +stack);

        boolean res4 = stack.remove("Informe7");
        System.out.println("Eliminar el Informe7: " + res );
        System.out.println("Los informes quedaron asi: " +stack);

        boolean res5 = stack.remove("Informe6");
        System.out.println("Eliminar el informe8 : " + res );
        System.out.println("Los informes quedaron asi: " +stack);

        boolean res6 = stack.remove("Informe5");
        System.out.println("Eliminar el Informe5: " + res );
        System.out.println("Los informes quedaron asi: " +stack);

        boolean res7 = stack.remove("Informe4");
        System.out.println("Eliminar el Informe4: " + res );
        System.out.println("Los informes quedaron asi: " +stack);

        boolean res8 = stack.remove("Informe3");
        System.out.println("Eliminar el Informe3 : " + res );
        System.out.println("Los informes quedaron asi: " +stack);

        boolean res9 = stack.remove("Informe2");
        System.out.println("Eliminar el informe2: " + res );
        System.out.println("Los informes quedaron asi: " +stack);

        boolean res10 = stack.remove("Informe1");
        System.out.println("Eliminar el Informe1: " + res );
        System.out.println("Eliminados todos los Informes: " +stack);



        System.out.println("---Agregamos cinco Informes mas: ");
        for(int i = 10; i <=15; i++){
            System.out.println("El informe con codigo: " + lista.get(i).getCodigo() + " "+
                    "posee la tarea: " + lista.get(i).getTarea());
        }


    }
}

