import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.co.nttdata.ecommerce.Dao.CiudadDao;
import com.co.nttdata.ecommerce.Dao.MarcaDao;
import com.co.nttdata.ecommerce.entidades.*;
import com.co.nttdata.ecommerce.interfaces.GestionFactura;
import com.co.nttdata.ecommerce.interfaces.GestionLogin;
import com.co.nttdata.ecommerce.logica.GestionCarritoDeComprasImpl;
import com.co.nttdata.ecommerce.logica.GestionFacturaImpl;
import com.co.nttdata.ecommerce.logica.GestionLoginImpl;
import com.co.nttdata.ecommerce.utilitarios.Facturatxt;
import com.co.nttdata.ecommerce.utilitarios.ProductoInventario;

import static com.co.nttdata.ecommerce.utilitarios.Facturatxt.eliminar;

public class Main {

    public static void main(String[] args) {
        // TODO Auto-generated method stub


        List<Producto> lp = new ArrayList<>();

/*
        //List<Producto> lp = new ArrayList<>();
        Producto p1 = new Producto(1, "lavadora", 1, 100, false, 0, 10, "mediano", "xxx", Marca.SAMSUNG, Categoria.ELETROHOGAR);
        Producto p2 = new Producto(2, "celular", 1, 100, false, 0, 10, "alto rendimiento", "xxxx", Marca.MOTOROLA, Categoria.TECNOLOGIA);
        Producto p3 = new Producto(3, "televisor", 1, 100, false, 0, 10, "Televisor 43", "xxxx", Marca.LG, Categoria.ELETROHOGAR);
        Producto p4 = new Producto(4, "nevera", 1, 100, false, 0, 10, "grande", "xxxxx", Marca.WHIRLPOOL, Categoria.ELETROHOGAR);
        Producto p5 = new Producto(5, "camara", 1, 100, false, 0, 10, "alta de3finicion", "xxx", Marca.NIKON, Categoria.TECNOLOGIA);
        Producto p6 = new Producto(6, "lavadora", 1, 100, false, 0, 10, "mediano", "xxx", Marca.SAMSUNG, Categoria.ELETROHOGAR);
        Producto p7 = new Producto(7, "celular", 1, 100, false, 0, 10, "alto rendimiento", "xxxx", Marca.MOTOROLA, Categoria.TECNOLOGIA);
        Producto p8 = new Producto(8, "televisor", 1, 100, false, 0, 10, "Televisor 43", "xxxx", Marca.LG, Categoria.ELETROHOGAR);
        Producto p9 = new Producto(9, "nevera", 1, 100, false, 0, 10, "grande", "xxxxx", Marca.WHIRLPOOL, Categoria.ELETROHOGAR);
        Producto p10 = new Producto(10, "camara", 1, 100, false, 0, 10, "alta de3finicion", "xxx", Marca.NIKON, Categoria.TECNOLOGIA);

        lp.add(p1);
        lp.add(p2);
       /* lp.add(p3);
        lp.add(p4);
        lp.add(p5);
        lp.add(p6);
        lp.add(p7);
        lp.add(p8);
        lp.add(p9);
        lp.add(p10);*/
// probando conexiones con la BD
        // TABLA  MARCA 
        MarcaDao m=new MarcaDao();
        List<Marca> listaMarca=new ArrayList<>();
        listaMarca.addAll(m.buscarMarca());
        
        for(Marca mar:listaMarca) {
        	System.out.println(mar.getId_marca()+" " + mar.getMarca()+"  "+mar.getDescripcion());
        }
        
        
        // TABLA CIUDAD
        CiudadDao c=new CiudadDao();
        
        
       List<Ciudad>listaCiudad=new ArrayList<>();
        listaCiudad.addAll(c.buscarCiudad());
        
        for (Ciudad ciudad : listaCiudad) {
			System.out.println(ciudad.getId_Ciudades());
			}
        
      
        
        Scanner sc = new Scanner(System.in);
        // instanciamos
        CarritoDeCompras cdc = new CarritoDeCompras();
        GestionFactura gf = new GestionFacturaImpl();
        GestionCarritoDeComprasImpl gcdc = new GestionCarritoDeComprasImpl();
        GestionLogin gl = new GestionLoginImpl();
        GestionLogin glL = new GestionLoginImpl();

        Cliente cl = new Cliente();
        Empresa em = new Empresa("ecommmerce s.a", "carrera 9 # 6-50 N");
        Factura f = new Factura();
        Facturatxt ar = new Facturatxt();
        // Cliente cl = new Cliente(1,"andres008","123456789","nnnnn@gmail.com","111111111","1",true,"45644","cc","contado");
       ProductoInventario pi=new ProductoInventario();



       int opcion = 0;

        do {
            System.out.println("\n*********************");
            System.out.println("     login      ");
            System.out.println("1.registro de usuario");
            System.out.println("2.inicio sesión");
            System.out.println("3.cambio de contraseña");;
            System.out.println("4.salir");
            System.out.println("ingrese una opcion");
            opcion = sc.nextInt();

            switch (opcion) {

                case 1:
                    System.out.println("ingrese sus Datos");
                    System.out.println("id de cliente");
                    int id = sc.nextInt();
                    cl.setId(id);
                    System.out.println("ingrese nombre de usuario");
                    String nombreUsuario = sc.next();
                    cl.setNombreUsuario(nombreUsuario);
                    System.out.println("ingrese contraseña");
                    String contrasenia = sc.next();
                    cl.setContrasenia(contrasenia);
                    System.out.println("correo");
                    String correo = sc.next();
                    cl.setCorreo(correo);
                    System.out.println("telefono");
                    String telefono = sc.next();
                    cl.setTelefono(telefono);
                    System.out.println("direcion");
                    String direccion = sc.next();
                    cl.setDireccion(direccion);
                    System.out.println("tipo de identificacio");
                    String tipoidentificacion = sc.next();
                    cl.setTipoIdentificacion(tipoidentificacion);
                    System.out.println("numero de identificacion");
                    String numeroidentificacion = sc.next();
                    cl.setTipoIdentificacion(numeroidentificacion);
                    System.out.println("metodo de pago");
                    String metodopago = sc.next();
                    cl.setMetodoDePago(metodopago);


                    break;
                case 2:
                    System.out.println("\nlogin");
                    System.out.println("nombre de usuario");
                    String nombreUsuarios = sc.next();

                    System.out.println("ingrese contraseña");
                    String clave = sc.next();

                    glL.ingresarsistema(cl,nombreUsuarios,clave);
                    boolean validacionIngres=glL.ingresarsistema(cl,nombreUsuarios,clave);

                        if(validacionIngres){
                            System.out.println("datos correctos\n");
                            while (opcion!=7){

                                System.out.println("\nEscoja una opcion  \n");
                                System.out.println("1.lista de productos");
                                System.out.println("2.carrito de compras.");
                                System.out.println("3.guardar la lista de productos en txt");
                                System.out.println("4.mostrar productos de txt ");
                                System.out.println("5.traer los productos de txt(en construcion)");
                                System.out.println("6.generar factura en txt");
                                System.out.println("7.mostrar factura");
                                opcion=sc.nextInt();



                                switch (opcion){

                                    case 1:
                                       //gp.listaP();
                                        System.out.println(" productos ");
                                        System.out.println(lp);
                                    break;

                                    case 2:
                                        cdc = gcdc.anadirAlCarrito(cdc, lp);
                                        cdc.setProductos(lp);

                                        System.out.println("Los productos añadidos son: ");
                                        cdc.getProductos().forEach((
                                                p -> System.out.println("\n"+
                                                        p.getIdProducto()+" "+
                                                        p.getNombre()+" "+
                                                        p.getCantidadDiponible()+" "+
                                                        p.getPrecio()+" "+
                                                        p.isDescuento()+" "+
                                                        p.getValorDescuento()+" "+
                                                        p.getIva()+" "+
                                                        p.getDescripcion()+" "+
                                                        p.getImg()+" "+
                                                        p.getMarca()+" "+
                                                        p.getCategoria())));

                                        break;

                                    case 3:

                                      pi.traerProductos(cdc);

                                        break;

                                    case 4:
                                        pi.mostrarProductos();
                                        break;
                                    case 5:


                                        ar.buscarRegistro("idp1");
                                        ar.buscarRegistro("idP10");
                                        break;

                                    case 6:

                                        cdc.setProductos(lp);
                                        gcdc.calcularTotalConIva(cdc);
                                        gcdc.calcularCostoEnvio(cdc,"1");
                                        ar.escribirArchivoS(em,cl,cdc,f);
                                        //ar.leerArchivoss();
                                      //  ar.escribirArchivo(cl,cdc,f,"datos.txt");

                                        break;
                                    case 7:

                                      ar.leerArchivoss();

                                        break;
                                        
                                    case 8:
                                    System.out.print(m.toString());
                                    	
                                        
                                }

                            }





                        }else{
                            System.out.println("datos incorrectos");
                        }



                    break;

                case 3:

                    System.out.print("Digite su contraseña: ");
                    String clav=sc.next();

                    if (cl.getContrasenia().equals(clav));{
                    System.out.println(" ======================== ");
                    System.out.print("ingresa tu nueva clave ");
                    String claves = sc.next();
                    cl.setContrasenia(claves);
                    System.out.println("clave cambiada ");
                }

                    break;


                case 4:


                    System.out.println("  -- VUELVA PRONTO --    ");

                    System.exit(0);

                    break;
                default:
                    System.out.println(" ================ ");
                    System.out.println(" Opcion no valida ");


            }


            }
            while (opcion != 9) ;


            //gl.registarusuario(cl);
            //System.out.println(gl);

            //gl.ingresarsistema(cl);

            //gl.olvidocontrasena(cl);

            //gl.salirsistema();


            //Crear 10 prodcutos
            //Añadir 6 al carrito de comprar
            //Crear la factura de ese carrito de compras





    }
}


