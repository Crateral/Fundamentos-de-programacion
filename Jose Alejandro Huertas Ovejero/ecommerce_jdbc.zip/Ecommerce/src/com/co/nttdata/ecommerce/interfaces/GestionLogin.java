package com.co.nttdata.ecommerce.interfaces;

import com.co.nttdata.ecommerce.entidades.Cliente;
import com.co.nttdata.ecommerce.entidades.Usuario;

public interface GestionLogin {


    Usuario registrar(String nombre, String contrasenia, String tipoIdentificacion, String numeroIdentificacion, String correo);

    public boolean  ingresarsistema(Cliente cliente);

    Cliente registarusuario(Cliente cliente);

    boolean ingresarsistema(Cliente cliente, String usuario, String contrasena);

    void ingresar(Cliente cli);

    public void olvidocontrasena(Cliente cliente);
    public void salirsistema();


}
