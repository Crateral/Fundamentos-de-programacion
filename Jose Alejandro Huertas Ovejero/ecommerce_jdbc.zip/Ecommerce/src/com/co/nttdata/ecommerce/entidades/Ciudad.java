package com.co.nttdata.ecommerce.entidades;

import java.io.Serializable;

public class Ciudad implements Serializable{
    
   
	
	private static final long serialVersionUID = 1L;
	
	private int id_Ciudades;
    private String ciudad;
    private boolean principal;
    
    public Ciudad() {
    	
    }
    
    
    
    

	public Ciudad(int id_Ciudades, String ciudad, boolean principal) {
		super();
		this.id_Ciudades = id_Ciudades;
		this.ciudad = ciudad;
		this.principal = principal;
	}





	public int getId_Ciudades() {
		return id_Ciudades;
	}





	public void setId_Ciudades(int id_Ciudades) {
		this.id_Ciudades = id_Ciudades;
	}





	public String getCiudad() {
		return ciudad;
	}





	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}





	public boolean isPrincipal() {
		return principal;
	}





	public void setPrincipal(boolean principal) {
		this.principal = principal;
	}





	@Override
	public String toString() {
		return "Ciudad [id_Ciudades=" + id_Ciudades + ", ciudad=" + ciudad + ", principal=" + principal + "]";
	}



    
	
    
    
	
    
    

}
	


