package com.co.nttdata.ecommerce.entidades;

public class formaDePago {

    private  int id_formaDepago;
    private String formaDepago;

    public formaDePago() {
    }

    public formaDePago(int id_formaDepago, String formaDepago) {
        this.id_formaDepago = id_formaDepago;
        this.formaDepago = formaDepago;
    }

    public int getId_formaDepago() {
        return id_formaDepago;
    }

    public void setId_formaDepago(int id_formaDepago) {
        this.id_formaDepago = id_formaDepago;
    }

    public String getFormaDepago() {
        return formaDepago;
    }

    public void setFormaDepago(String formaDepago) {
        this.formaDepago = formaDepago;
    }














}
