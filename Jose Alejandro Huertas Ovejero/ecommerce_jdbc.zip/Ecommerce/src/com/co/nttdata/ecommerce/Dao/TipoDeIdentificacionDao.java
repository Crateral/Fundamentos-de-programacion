package com.co.nttdata.ecommerce.Dao;

public class TipoDeIdentificacionDao {
}
