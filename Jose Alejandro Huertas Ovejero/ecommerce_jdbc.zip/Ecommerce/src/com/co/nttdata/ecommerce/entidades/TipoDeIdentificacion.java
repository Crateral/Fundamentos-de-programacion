package com.co.nttdata.ecommerce.entidades;

public class TipoDeIdentificacion {


    private  int id_tipoIdentificacion;
    private int id_productos;


    public TipoDeIdentificacion() {
    }

    public TipoDeIdentificacion(int id_tipoIdentificacion, int id_productos) {
        this.id_tipoIdentificacion = id_tipoIdentificacion;
        this.id_productos = id_productos;
    }


    public int getId_tipoIdentificacion() {
        return id_tipoIdentificacion;
    }

    public void setId_tipoIdentificacion(int id_tipoIdentificacion) {
        this.id_tipoIdentificacion = id_tipoIdentificacion;
    }

    public int getId_productos() {
        return id_productos;
    }

    public void setId_productos(int id_productos) {
        this.id_productos = id_productos;
    }

    @Override
    public String toString() {
        return "TipoDeIdentificacion{" +
                "id_tipoIdentificacion=" + id_tipoIdentificacion +
                ", id_productos=" + id_productos +
                '}';
    }
}


