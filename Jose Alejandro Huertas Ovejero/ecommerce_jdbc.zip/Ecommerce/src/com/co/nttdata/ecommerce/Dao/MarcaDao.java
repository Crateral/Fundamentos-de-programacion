package com.co.nttdata.ecommerce.Dao;

import com.co.nttdata.ecommerce.entidades.Marca;
import com.co.nttdata.ecommerce.utils.Conexion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MarcaDao {

    Conexion con = new Conexion();
    Scanner teclado = new Scanner(System.in);

    public List<Marca> buscarMarca(){

        Connection baseDatos = con.conectarBD();
        PreparedStatement st = null;
        ResultSet rs = null;

        List<Marca> marcas = new ArrayList<Marca>();

        try {
        	//st = baseDatos.prepareStatement("SELECT * FROM \"tbl_marca\" ORDER BY id_marca ASC");
            st = baseDatos.prepareStatement("SELECT * FROM tbl_marca ORDER BY id_marca ASC");
            rs = st.executeQuery();

            while (rs.next()) {

                Marca marca = new Marca();

                marca.setId_marca(rs.getInt("id_marca"));
                marca.setMarca(rs.getString("marca"));
                marca.setDescripcion(rs.getString("descripcion"));

                marcas.add(marca);
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                rs.close();
                st.close();
                con.desconectarBD(baseDatos);
            } catch (Exception e2) {
                System.err.println(e2.getMessage());
            }
        }


        return marcas;


}
    
    public void agregarmarca(Marca m) {
    	
    	Connection baseDatos = con.conectarBD();
        PreparedStatement st = null;
        
        try {
            st = baseDatos.prepareStatement("INSERT INTO tbl_marca (marca, descripcion) VALUES (?, ?)");
            st.setString(1, m.getMarca());
            st.setString(2, m.getDescripcion());
            int val = st.executeUpdate();
            
            if (val > 0)
                System.out.println("\nRegistro guardado con éxito...");
            else
                System.err.println("\nError al guardar el registro... !");
            
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                st.close();
                con.desconectarBD(baseDatos);
            } catch (Exception e2) {
                System.err.println(e2.getMessage());
            }
        }        
    }
    
    
    
    public Marca eliminarMarca(int marca) {
        Marca m = new Marca();
        
        Connection baseDatos = con.conectarBD();
        PreparedStatement st = null;
                
        System.out.print("\nDesea eliminar la Marca (s/n) ? : ");
        String rg = teclado.next();
        if (rg.equals("s")) {
            try {
                st = baseDatos.prepareStatement("DELETE FROM tbl_marca WHERE id_marca = ? ");
                st.setInt(1, marca);
                int val = st.executeUpdate();
                
                if (val > 0)
                    System.out.println("\nRegistro eliminado con éxito...");
                else
                    System.err.println("\nError al eliminar el registro... !");
                
            } catch (Exception e) {
                System.err.println(e.getMessage());
            } finally {
                try {
                    st.close();
                    con.desconectarBD(baseDatos);
                } catch (Exception e2) {
                    System.err.println(e2.getMessage());
                }
            }
                
        } else if (rg.equals("n")) {
            System.out.println("\nSeleccionó no eliminar Marca... !");
        }
        return m;    
    }
    
    
    
    public void modificarMarca(int id_marca, String marca, String descripcion) {
        
        Connection baseDatos = con.conectarBD();
        PreparedStatement st = null;
                
        try {
            st = baseDatos.prepareStatement("UPDATE tbl_marca SET marca = ?, descripcion = ? WHERE id_marca = ?");
            st.setInt(3, id_marca);
            st.setString(1, marca);
            st.setString(2, descripcion);
            int val = st.executeUpdate();



           if (val > 0)
                System.out.println("\nRegistro modificado con éxito...");
            else
                System.err.println("\nError al modificar el registro... !");



       } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                st.close();
                con.desconectarBD(baseDatos);
            } catch (Exception e2) {
                System.err.println(e2.getMessage());
            }
        }
    }
    
    


}
