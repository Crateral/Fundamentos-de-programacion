package com.co.nttdata.ecommerce.utils;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion {

    private static final String URL = "jdbc:mysql://localhost:3306/ecommerce";
    private static final String USUARIO = "root";
    private static final String CONTRASENA = "";

    public Connection conectarBD() {

        Connection baseDatos = null;

        try {
            baseDatos = DriverManager.getConnection(URL, USUARIO, CONTRASENA);
        } catch (Exception e) {
            System.out.println("Error : " + e.getMessage());
        }
        return baseDatos;
    }

    public void desconectarBD(Connection baseDatos) {

        try {
            baseDatos.close();
        } catch (Exception e) {
            System.out.println("Error : " + e.getMessage());
        }

    }






}
