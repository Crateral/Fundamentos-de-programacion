package com.co.nttdata.ecommerce.interfaces;

import com.co.nttdata.ecommerce.entidades.CarritoDeCompras;
import com.co.nttdata.ecommerce.entidades.Producto;

import java.util.List;

public interface GestionCarritoDeCompras {

    public CarritoDeCompras anadirAlCarrito(CarritoDeCompras cdc, List<Producto> p);
    public CarritoDeCompras calcularTotalConIva(CarritoDeCompras cdc);

    public CarritoDeCompras calcularCostoEnvio(CarritoDeCompras cdc, String direccion);
    public CarritoDeCompras agregarAlCarrito(CarritoDeCompras cdc, List<Producto> p);




}
