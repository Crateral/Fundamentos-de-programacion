package com.co.nttdata.ecommerce.entidades;

import java.util.Date;

public class Audotoria {

    private int id_auditoria;
    private  String usr;
    private  String documento;
    private  String accion;
    private String fechaAccion;
    private  String descripcion;
    private  String IP;

    public Audotoria() {
    }

    public Audotoria(int id_auditoria, String usr, String documento, String accion, String fechaAccion, String descripcion, String IP) {
        this.id_auditoria = id_auditoria;
        this.usr = usr;
        this.documento = documento;
        this.accion = accion;
        this.fechaAccion = fechaAccion;
        this.descripcion = descripcion;
        this.IP = IP;
    }

    public int getId_auditoria() {
        return id_auditoria;
    }

    public void setId_auditoria(int id_auditoria) {
        this.id_auditoria = id_auditoria;
    }

    public String getUsr() {
        return usr;
    }

    public void setUsr(String usr) {
        this.usr = usr;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public String getAccion() {
        return accion;
    }

    public void setAccion(String accion) {
        this.accion = accion;
    }

    public String getFechaAccion() {
        return fechaAccion;
    }

    public void setFechaAccion(String fechaAccion) {
        this.fechaAccion = fechaAccion;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getIP() {
        return IP;
    }

    public void setIP(String IP) {
        this.IP = IP;
    }

    @Override
    public String toString() {
        return "Audotoria{" +
                "id_auditoria=" + id_auditoria +
                ", usr='" + usr + '\'' +
                ", documento='" + documento + '\'' +
                ", accion='" + accion + '\'' +
                ", fechaAccion='" + fechaAccion + '\'' +
                ", descripcion='" + descripcion + '\'' +
                ", IP='" + IP + '\'' +
                '}';
    }
}
