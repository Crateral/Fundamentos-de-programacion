package com.co.nttdata.ecommerce.utilitarios;

import com.co.nttdata.ecommerce.entidades.*;
import com.co.nttdata.ecommerce.logica.GestionCarritoDeComprasImpl;
import com.co.nttdata.ecommerce.logica.GestionFacturaImpl;


import java.io.*;
import java.util.Scanner;

public class Facturatxt {

    //List<Producto> lp = new ArrayList<>();
    //Producto p1 = new Producto(1, "lavadora", 1, 00, false, 00, 00, "mediano", "xxxxxxx", Marca.SAMSUNG, Categoria.ELETROHOGAR);

        GestionCarritoDeComprasImpl gcdc=new GestionCarritoDeComprasImpl();
        //se crea la factura


    public  void escribirArchivoS(Empresa em,Cliente cliente, CarritoDeCompras cdc,Factura f ) {
        f.setEmpresa(em);
        f.setCliente(cliente);
        f.setDescripcion(" factura ");
        f.setIdFactura(1);
        f.setFecha("XX/12/2022");
        f.setProductos(cdc);
        f.setValorTotalConIva(cdc.getSubTotalConIva() + cdc.getValorEnvio());
        f.setValorDeEnvio(cdc.getValorEnvio());
        f.setValorTotalSinIva(cdc.getSubTotaSinIva());
        f.setValorTotalConIva(cdc.getSubTotalConIva());
        f.setIva(cdc.getValorIva());


        try {
            FileWriter archivo = new FileWriter("C:\\Users\\jhuertov\\OneDrive - NTT DATA EMEAL\\Documentos\\archivostxt\\datos.txt" );

            archivo.write(
                    "    -------FACTURA------" + "\n" +
                            "\nNombre de la empresa:  "+ f.getEmpresa() +"\n" +"\n"
                            + f.getCliente() + f.getDescripcion() +" "+ f.getIdFactura() +" "+
                            f.getProductos().getProductos()+ f.getCarritoDeCompras() +
                            "\nvalor total  del envio  :         "+ (f.getValorDeEnvio()) +
                            "\n valor del iva de los productos   " +f.getIva() +
                            "\n Valor de los productos:          " + f.getValorTotalSinIva()  +
                            "\n Productos con iva                "+ f.getValorTotalConIva()+
                            "\n valor total total a pagar        "+ (f.getValorTotalConIva()+f.getValorDeEnvio()));


            for (int i = 0; i <= 0; i++) {
                archivo.write(i + "\n");
            }
            System.out.println("El archivo se ha escrito con exito");
            archivo.close();
        }
        catch(Exception e) {
            System.out.println("Error al escribir el archivo: " + e.getMessage());
        }


    }



 /*   public void escribirArchivo(Cliente cliente, CarritoDeCompras cdc, Factura f, String nombreArchivo) {

        // lp.add(p1);
        GestionFacturaImpl gf = new GestionFacturaImpl();
        //Factura f =new Factura();
        f.setCliente(cliente);
        f.setDescripcion(" factura ");
        f.setIdFactura(1);
        f.setValorTotalConIva(cdc.getSubTotalConIva() + cdc.getValorEnvio());
        f.setValorDeEnvio(cdc.getValorEnvio());
        cdc.setProductos();
        f.getEmpresa();

        FileWriter archivo = null;

        try {
            archivo = new FileWriter("C:\\Users\\jhuertov\\OneDrive - NTT DATA EMEAL\\Documentos\\archivostxt\\" + nombreArchivo, false);

            archivo.write(" " + "\n" + f.getEmpresa() + "\n" + f.getCliente() + "\nfactura\n" + "id " + f.getIdFactura() + cdc.getProductos() +
                    "\n" + f.getDescripcion() +
                    "\nvalor total  del envio  :  " + (f.getValorDeEnvio()) +
                    "\n valor del iva de los productos " + f.getIva() +
                    "\n Valor de los productos:  " + f.getValorTotalSinIva() +
                    "\n valor total total a pagar   " + (f.getValorTotalConIva()));
            ;

            for (int i = 0; i <= 0; i++) {
                archivo.write(i + "\n");
            }
            System.out.println("El archivo se ha escrito con exito");
            archivo.close();
        } catch (Exception e) {
            System.out.println("Error al escribir el archivo: " + e.getMessage());
        }


    }*/

    public void leerArchivo(String nombreArchivo) {
        File archivo = new File("C:\\Users\\jhuertov\\OneDrive - NTT DATA EMEAL\\Documentos\\archivostxt\\"
                + nombreArchivo);
        Scanner s = null;

        try {
            s = new Scanner(archivo);
            while (s.hasNextLine()) {
                String linea = s.nextLine();
                System.out.println(linea);
            }

        } catch (Exception e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        } finally {
            try {
                if (s != null) {
                    s.close();
                }
            } catch (Exception e) {
                System.out.println("Error al cerrar la lectura del archivo: " + e.getMessage());
            }
        }
    }

    public void mostrarArchivos() {
        try {

            FileReader fr = new FileReader("C:\\Users\\jhuertov\\OneDrive - NTT DATA EMEAL\\Documentos\\archivostxt\\antti.txt");

            BufferedReader br = new BufferedReader(fr);
            String cadena;
            while ((cadena = br.readLine()) != null) {
                System.out.println(" " + cadena);
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());

        }
    }


    public String buscarRegistro(String id) {

        String Usuario = id;

        try {
            BufferedReader leer = new BufferedReader(new FileReader("C:\\Users\\jhuertov\\OneDrive - NTT DATA EMEAL\\Documentos\\archivostxt\\antti.txt"));
            String linea = "";
            int i = 0;
            while ((linea = leer.readLine()) != null) {
                i++;
                if (linea.contains(Usuario)) {
                    System.out.println("\nSe encontro la busqueda;\n ;" + linea);
                }
            }

        } catch (Exception e) {
            System.out.println("" + e.getMessage());
        }
        return Usuario;


    }


  public static void eliminar(String Nombrearchivo){

        File archivo=new File("C:\\Users\\jhuertov\\OneDrive - NTT DATA EMEAL\\Documentos\\archivostxt\\"+Nombrearchivo);
        archivo.delete();
        System.out.println("archivo eliminado");
    }



   /* public void escribir(String nombre){
        File f;
        FileWriter w;
        BufferedReader bw;
        PrintWriter wr;

        try {
            f=new File(nombre);
            w=new FileWriter(f);
            bw=new BufferedReader(w);
            wr=new PrintWriter(bw);

        }catch (Exception e){

            e.getMessage();
        }



    }

*/


    public  void leerArchivoss() {

        File archivo = new File("C:/Users/jhuertov/OneDrive - NTT DATA EMEAL/Documentos/archivostxt/datos.txt");
        Scanner s =null;

        try {
            s = new Scanner(archivo);
            while(s.hasNextLine()) {
                String linea = s.nextLine();
                System.out.println(linea);
            }

        }catch(Exception e) {
            System.out.println("Error al leer el archivo" + e.getMessage());
        }finally {
            try {
                if(s !=null ) {
                    s.close();
                }

            }catch(Exception e) {
                System.out.println("Error al cerrar el archivo" + e.getMessage());
            }
        }


    }
}











