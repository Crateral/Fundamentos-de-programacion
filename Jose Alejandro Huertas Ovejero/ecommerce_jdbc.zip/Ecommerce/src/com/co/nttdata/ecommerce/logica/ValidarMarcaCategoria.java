package com.co.nttdata.ecommerce.logica;

import com.co.nttdata.ecommerce.entidades.Categoria;
import com.co.nttdata.ecommerce.entidades.Marca;

public class ValidarMarcaCategoria {


/*
    public Marca validarMarca(String marca) {

        if (marca.trim().equalsIgnoreCase(String.valueOf(Marca.LG))) {
            return Marca.LG;
        } else if (marca.trim().equalsIgnoreCase(String.valueOf(Marca.MOTOROLA))) {
            return Marca.MOTOROLA;
        } else if (marca.trim().equalsIgnoreCase(String.valueOf(Marca.SAMSUNG))) {
            return Marca.SAMSUNG;
        } else if (marca.trim().equalsIgnoreCase(String.valueOf(Marca.WHIRLPOOL))){
            return Marca.WHIRLPOOL;
        }else if (marca.trim().equalsIgnoreCase(String.valueOf(Marca.NIKON))){
            return Marca.NIKON;
        } else{
            return null;
        }

    }


    public Categoria validarCategoria(String marca){
        if (marca.trim().equalsIgnoreCase(String.valueOf(Categoria.ELETROHOGAR))) {
            return Categoria.ELETROHOGAR;
        } else if (marca.trim().equalsIgnoreCase(String.valueOf(Categoria.TECNOLOGIA))) {
            return Categoria.TECNOLOGIA;
        } else {
            return  null;
        }
    }

*/
}
