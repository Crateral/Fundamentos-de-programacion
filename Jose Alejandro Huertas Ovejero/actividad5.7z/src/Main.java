import java.util.*;

public class Main {
       public static void main(String[] args) {



                ArrayList<empleado>listaempleado=new ArrayList<empleado>();

                listaempleado.add(new empleado("EMPRESARIAL",45));
                listaempleado.add(new empleado("empresarial",65));
                listaempleado.add(new empleado("administrativa",65));
                listaempleado.add(new empleado("PERSONAL",90));
                listaempleado.add(new empleado("personal",45));
                listaempleado.add(new empleado("administrativa",65));
                listaempleado.add(new empleado("administrativa",95));
                listaempleado.add(new empleado("EMPRESARIAL",45));
                listaempleado.add(new empleado("administrativa",65));
                listaempleado.add(new empleado("empresarial",65));
                listaempleado.add(new empleado("PERSONAL",90));
                listaempleado.add(new empleado("personal",45));
                listaempleado.add(new empleado("administrativa",95));







           System.out.println("________________________________");
           System.out.println("->Lista completa");
           for (empleado j: listaempleado){
               System.out.println(j.damedatos());
           }

           System.out.println("________________________________");
           System.out.println("->consulto solo los adminitrativos ");


               System.out.println(listaempleado.get(2).damedatos());
               System.out.println(listaempleado.get(5).damedatos());
               System.out.println(listaempleado.get(6).damedatos());
               System.out.println(listaempleado.get(8).damedatos());
               System.out.println(listaempleado.get(12).damedatos());

           System.out.println("_____________________________________");
           System.out.println("-> le cambio los datos a la lista ");


               for (empleado e: listaempleado){

                    listaempleado.set(1,new empleado("NUEVO INFORME   ",600000));
                    listaempleado.set(9,new empleado("  NUEVO segundo INFORME   ",655000));
                    System.out.println(e.damedatos());

                }

           System.out.println("eliminar");

               listaempleado.remove(0);
           listaempleado.remove(6);
           System.out.println("elementos nuevoss  ");

           for (empleado h: listaempleado){
               System.out.println(h.damedatos());
           }

        }


}