public class empleado {

public empleado(String tarea   , int codigo){
    this.tarea=tarea;
    this.codigo=codigo;


}

public String damedatos(){


    return "la tarea  es   "+ tarea+ " y tiene como el ID  "+codigo+ "  -";
}


private  String tarea;
private  int codigo;


}


