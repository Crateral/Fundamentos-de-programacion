package com.co.nttdata.ecommerce.logica;

import com.co.nttdata.ecommerce.entidades.Cliente;
import com.co.nttdata.ecommerce.entidades.Usuario;
import com.co.nttdata.ecommerce.interfaces.GestionLogin;

import java.util.Scanner;

public class GestionLoginImpl implements GestionLogin {
    Scanner sc = new Scanner(System.in);

    @Override
    public Usuario registrar(String nombre, String contrasenia, String tipoIdentificacion, String numeroIdentificacion, String correo){

        Cliente cli=new Cliente();
        cli.setNombreUsuario(nombre);
        cli.setContrasenia(contrasenia);
        cli.setTipoIdentificacion(tipoIdentificacion);
        cli.setNumeroIdentificacion(numeroIdentificacion);
        cli.setCorreo(correo);
        return   cli;

    }

    @Override
    public boolean ingresarsistema(Cliente cliente) {
        return false;
    }


    @Override
    public Cliente registarusuario(Cliente cliente) {


        System.out.println("\ndatos de registro de usuario\n" + cliente.getTipoIdentificacion() + " :" + cliente.getNumeroIdentificacion() +
                " " + "\n contreseña " + cliente.getContrasenia() + "\n " + "Nombre usuario: " + cliente.getNombreUsuario() +
                "\n " + "correo: " + cliente.getCorreo());
        return cliente;
    }

    @Override
    public boolean ingresarsistema(Cliente cliente, String usuario, String contrasena) {


        if (cliente.getNombreUsuario().equals(usuario) && cliente.getContrasenia().equals(contrasena)) {


            return true;
        } else {

        }

        return false;

    }
    @Override
    public void ingresar(Cliente cli) {


        if (cli.getNombreUsuario().equals(cli.getNombreUsuario()) && cli.getContrasenia().equals(cli.getContrasenia())) {

            System.out.println(" bienvenido ");

        } else {
            System.out.println(" Datos no correctos ");

        }


    }

    @Override
    public void olvidocontrasena(Cliente cliente) {
        System.out.println("\n**********************");
        System.out.println("cambio de  contraseña");
        //se le asigna una nueva  clave
        String nuevaclave = "999999";

        cliente.setContrasenia(nuevaclave);
        //se imprime la nueva contraseña con los datos predefinidos
        System.out.println("\nSu nueva contraseña es :" + cliente.getContrasenia() + " " + "\nNombre de Usuario: " +
                " " + cliente.getNombreUsuario());
    }

    @Override
    public void salirsistema() {
        System.out.println("\n*****************");
        System.out.println("salida del sistema");
        System.out.println("Vuelva Pronto");
        // código de salida
        System.exit(0);
    }


}
