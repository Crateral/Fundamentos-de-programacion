package com.co.nttdata.ecommerce.logica;

import com.co.nttdata.ecommerce.entidades.CarritoDeCompras;
import com.co.nttdata.ecommerce.entidades.Categoria;
import com.co.nttdata.ecommerce.entidades.Marca;
import com.co.nttdata.ecommerce.entidades.Producto;

import java.util.ArrayList;
import java.util.List;

public class GestionProducto {

    public List<Producto> lp = new ArrayList<>();

    public  List<Producto> listaP() {

        CarritoDeCompras cdc = new CarritoDeCompras();
        //List<Producto> lp = new ArrayList<>();
        Producto p1 = new Producto(1, "lavadora", 3, 10, false, 0, 0, "mediano", "xxx", Marca.SAMSUNG, Categoria.ELETROHOGAR);
        Producto p2 = new Producto(2, "celular", 3, 10, false, 0, 0, "alto rendimiento", "xxxx", Marca.MOTOROLA, Categoria.TECNOLOGIA);
        Producto p3 = new Producto(3, "televisor", 3, 10, false, 0, 0, "Televisor 43", "xxxx", Marca.LG, Categoria.ELETROHOGAR);
        Producto p4 = new Producto(4, "nevera", 3, 10, false, 0, 0, "grande", "xxxxx", Marca.WHIRLPOOL, Categoria.ELETROHOGAR);
        Producto p5 = new Producto(5, "camara", 3, 10, false, 0, 0, "alta de3finicion", "xxx", Marca.NIKON, Categoria.TECNOLOGIA);
        Producto p6 = new Producto(6, "lavadora", 3, 10, false, 0, 0, "mediano", "xxx", Marca.SAMSUNG, Categoria.ELETROHOGAR);
        Producto p7 = new Producto(7, "celular", 3, 10, false, 0, 0, "alto rendimiento", "xxxx", Marca.MOTOROLA, Categoria.TECNOLOGIA);
        Producto p8 = new Producto(8, "televisor", 3, 10, false, 0, 0, "Televisor 43", "xxxx", Marca.LG, Categoria.ELETROHOGAR);
        Producto p9 = new Producto(9, "nevera", 3, 10, false, 0, 0, "grande", "xxxxx", Marca.WHIRLPOOL, Categoria.ELETROHOGAR);
        Producto p10 = new Producto(10, "camara", 3, 10, false, 0, 0, "alta de3finicion", "xxx", Marca.NIKON, Categoria.TECNOLOGIA);

        lp.add(p1);
        lp.add(p2);
        lp.add(p5);
        lp.add(p6);
        lp.add(p7);
        lp.add(p10);


        for (Producto x : lp) {
            System.out.println(x.toString());

        }
        cdc.setProductos(lp);

        //añadi a C-


         return lp;


    }
}