package com.co.nttdata.ecommerce.logica;

import com.co.nttdata.ecommerce.entidades.*;
import com.co.nttdata.ecommerce.interfaces.GestionFactura;

public class GestionFacturaImpl implements GestionFactura {
		Factura f=new Factura();
		Producto p=new Producto();

		@Override
	public Factura pagar(Empresa em,Cliente cliente, CarritoDeCompras cdc) {

		f.setEmpresa(em);
		f.setCliente(cliente);
		f.setDescripcion(" factura ");
		f.setIdFactura(1);
		f.setProductos(cdc);
		f.setValorTotalConIva(cdc.getSubTotalConIva() + cdc.getValorEnvio());
		f.setValorDeEnvio(cdc.getValorEnvio());

		return f;
	}
@Override
	public void imprimirfactura() {
		System.out.println("\nNombre de la empresa: "+ f.getEmpresa() +"\n" +"\n"
				+ f.getCliente() + f.getDescripcion() +" "+ f.getIdFactura() +" "+
				f.getProductos().getProductos()+ f.getCarritoDeCompras() +
				"\nvalor total  con iva : "+ f.getValorTotalConIva() +
				"\nvalor total envio; "+ f.getValorDeEnvio()+
				"\n"+ "valor sin iva "+f.getValorTotalSinIva()+
				"\nvalor total; "+ (f.getValorDeEnvio()+ f.getValorTotalConIva())+
				"\nprecio: "+p.getPrecio()+"\n");


	}




}
