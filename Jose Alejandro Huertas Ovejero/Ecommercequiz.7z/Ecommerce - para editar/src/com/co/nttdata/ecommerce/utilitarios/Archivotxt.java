package com.co.nttdata.ecommerce.utilitarios;

import com.co.nttdata.ecommerce.entidades.*;
import com.co.nttdata.ecommerce.logica.GestionFacturaImpl;
import com.co.nttdata.ecommerce.logica.GestionProducto;

import java.io.*;
import java.util.Scanner;

public class Archivotxt {

    //List<Producto> lp = new ArrayList<>();
    //Producto p1 = new Producto(1, "lavadora", 1, 00, false, 00, 00, "mediano", "xxxxxxx", Marca.SAMSUNG, Categoria.ELETROHOGAR);

    public void escribirArchivo(Cliente cliente, CarritoDeCompras cdc, Factura f, String nombreArchivo) {
        GestionProducto gp = new GestionProducto();
        // lp.add(p1);
        GestionFacturaImpl gf = new GestionFacturaImpl();
        //Factura f =new Factura();
        f.setCliente(cliente);
        f.setDescripcion(" factura ");
        f.setIdFactura(1);
        f.setValorTotalConIva(cdc.getSubTotalConIva() + cdc.getValorEnvio());
        f.setValorDeEnvio(cdc.getValorEnvio());
        cdc.setProductos(gp.listaP());


        FileWriter archivo = null;

        try {
            archivo = new FileWriter("C:\\Users\\jhuertov\\OneDrive - NTT DATA EMEAL\\Documentos\\archivostxt\\" + nombreArchivo, false);

            archivo.write(" " + f.getCliente() + cdc.getProductos() +
                    "\n" + f.getDescripcion() + "id; " + f.getIdFactura() + "valor total con envio; " + f.getValorTotalConIva() + "valor del envio:" + f.getValorDeEnvio());

            for (int i = 0; i <= 0; i++) {
                archivo.write(i + "\n");
            }
            System.out.println("El archivo se ha escrito con exito");
            archivo.close();
        } catch (Exception e) {
            System.out.println("Error al escribir el archivo: " + e.getMessage());
        }


    }

    public void leerArchivo(String nombreArchivo) {
        File archivo = new File("C:\\Users\\jhuertov\\OneDrive - NTT DATA EMEAL\\Documentos\\archivostxt\\"
                + nombreArchivo);
        Scanner s = null;

        try {
            s = new Scanner(archivo);
            while (s.hasNextLine()) {
                String linea = s.nextLine();
                System.out.println(linea);
            }

        } catch (Exception e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        } finally {
            try {
                if (s != null) {
                    s.close();
                }
            } catch (Exception e) {
                System.out.println("Error al cerrar la lectura del archivo: " + e.getMessage());
            }
        }
    }


    public void mostrarArchivos() {
        try {

            FileReader fr = new FileReader("C:\\Users\\jhuertov\\OneDrive - NTT DATA EMEAL\\Documentos\\archivostxt\\antti.txt");

            BufferedReader br = new BufferedReader(fr);
            String cadena;
            while ((cadena = br.readLine()) != null) {
                System.out.println(" " + cadena);
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());

        }
    }


    public String buscarRegistro(String id) {

        String Usuario = id;

        try {
            BufferedReader leer = new BufferedReader(new FileReader("C:\\Users\\jhuertov\\OneDrive - NTT DATA EMEAL\\Documentos\\archivostxt\\antti.txt"));
            String linea = "";
            int i = 0;
            while ((linea = leer.readLine()) != null) {
                i++;
                if (linea.contains(Usuario)) {
                    System.out.println("\nSe encontro la busqueda;\n ;" + linea);
                }
            }

        } catch (Exception e) {
            System.out.println("" + e.getMessage());
        }
        return Usuario;


    }
}












