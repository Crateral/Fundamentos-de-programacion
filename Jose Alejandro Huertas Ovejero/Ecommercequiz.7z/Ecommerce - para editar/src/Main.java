import java.util.Scanner;

import com.co.nttdata.ecommerce.entidades.*;
import com.co.nttdata.ecommerce.interfaces.GestionFactura;
import com.co.nttdata.ecommerce.interfaces.GestionLogin;
import com.co.nttdata.ecommerce.logica.GestionCarritoDeComprasImpl;
import com.co.nttdata.ecommerce.logica.GestionFacturaImpl;
import com.co.nttdata.ecommerce.logica.GestionLoginImpl;
import com.co.nttdata.ecommerce.logica.GestionProducto;
import com.co.nttdata.ecommerce.utilitarios.Archivotxt;

public class Main {

    public static void main(String[] args) {
        // TODO Auto-generated method stub

        Scanner sc = new Scanner(System.in);
     // instanciamos
        CarritoDeCompras cdc = new CarritoDeCompras();
        GestionFactura gf = new GestionFacturaImpl();
        GestionCarritoDeComprasImpl  gcdc = new GestionCarritoDeComprasImpl();
        GestionLogin gl = new GestionLoginImpl();
        GestionLogin glL = new GestionLoginImpl();
        GestionProducto  gp=new GestionProducto();
        Cliente cl=new Cliente();
        Empresa em=new Empresa("ecommmerce s.a","carrera 9 # 6-50 N");
        Factura f=new Factura();
        Archivotxt ar=new Archivotxt();
       // Cliente cl = new Cliente(1,"andres008","123456789","nnnnn@gmail.com","111111111","1",true,"45644","cc","contado");



        int opcion = 0;

        do {
            System.out.println("\n*********************");
            System.out.println("     login      ");
            System.out.println("1.registro de usuario");
            System.out.println("2.inicio sesión");
            System.out.println("3.cambio de contraseña");;
            System.out.println("4.salir");
            System.out.println("ingrese una opcion");
            opcion = sc.nextInt();

            switch (opcion) {

                case 1:
                    System.out.println("ingrese sus Datos");
                    System.out.println("id de cliente");
                    int id = sc.nextInt();
                    cl.setId(id);
                    System.out.println("ingrese nombre de usuario");
                    String nombreUsuario = sc.next();
                    cl.setNombreUsuario(nombreUsuario);
                    System.out.println("ingrese contraseña");
                    String contrasenia = sc.next();
                    cl.setContrasenia(contrasenia);
                    System.out.println("correo");
                    String correo = sc.next();
                    cl.setCorreo(correo);
                    System.out.println("telefono");
                    String telefono = sc.next();
                    cl.setTelefono(telefono);
                    System.out.println("direcion");
                    String direccion = sc.next();
                    cl.setDireccion(direccion);
                    System.out.println("tipo de identificacio");
                    String tipoidentificacion = sc.next();
                    cl.setTipoIdentificacion(tipoidentificacion);
                    System.out.println("numero de identificacion");
                    String numeroidentificacion = sc.next();
                    cl.setTipoIdentificacion(numeroidentificacion);
                    System.out.println("metodo de pago");
                    String metodopago = sc.next();
                    cl.setMetodoDePago(metodopago);


                    break;
                case 2:
                    System.out.println("\nlogin");
                    System.out.println("nombre de usuario");
                    String nombreUsuarios = sc.next();

                    System.out.println("ingrese contraseña");
                    String clave = sc.next();

                    glL.ingresarsistema(cl,nombreUsuarios,clave);
                    boolean validacionIngres=glL.ingresarsistema(cl,nombreUsuarios,clave);

                        if(validacionIngres){
                            System.out.println("datos correctos\n");
                            while (opcion!=5){

                                System.out.println("\nEscoja una opcion  \n");
                                System.out.println("1.lista de productos");
                                System.out.println("2.factura.");
                                System.out.println("3.generar lista de productos guardados en un txt");
                                System.out.println("4.buscar datos en el archivo txt");
                                System.out.println("5.generar factura txt");
                                opcion=sc.nextInt();



                                switch (opcion){

                                    case 1:
                                       //gp.listaP();
                                       cdc.setProductos(gp.listaP());

                                    break;

                                    case 2:

                                       // cdc.setProductos(gp.listaP());
                                        //gcdc.anadirAlCarrito(cdc,gp.listaP());
                                       // cdc.getProductos().forEach( (p) -> System.out.println( "\n"+"id: " + p.getIdProducto()+" "+ "nombre: " +p.getNombre()+ " " + "cantidad: "+ p.getCantidadDiponible() + " " +"marca: " + p.getMarca()+" " + "precio: " +p.getPrecio()  +"\n"));
                                        //cdc = gcdc.calcularTotalConIva(cdc);
                                         cdc=(gcdc.calcularCostoEnvio(cdc,"1"));
                                        System.out.println("paso por aqui factura");
                                       // gf.pagar(em,cl,cdc);

                                        f = gf.pagar(em,cl,cdc);

                                        gf.imprimirfactura();

                                        break;

                                    case 3:

                                        System.out.println("\n");

                                        ar.mostrarArchivos();

                                        break;
                                    case 4:


                                        ar.buscarRegistro("idp1");
                                        ar.buscarRegistro("idP10");
                                        break;

                                    case 5:

                                        cdc.setProductos(gp.lp);
                                        ar.escribirArchivo(cl,cdc,f,"datos.txt");

                                        break;


                                }

                            }





                        }else{
                            System.out.println("datos incorrectos");
                        }



                    break;

                case 3:

                    System.out.print("Digite su contraseña: ");
                    String clav=sc.next();

                    if (cl.getContrasenia().equals(clav));{
                    System.out.println(" ======================== ");
                    System.out.print("ingresa tu nueva clave ");
                    String claves = sc.next();
                    cl.setContrasenia(claves);
                    System.out.println("clave cambiada ");
                }

                    break;

                    /*case 4:

                    // producto a carrito

                       /* lp.add(p1);
                        lp.add(p2);
                        lp.add(p3);
                        lp.add(p4);
                        lp.add(p5);
                        lp.add(p6);
                        cdc=gcdc.agregarAlCarrito(cdc,lp);
                        System.out.println("paso por añadirxxxxxxx");
                        cdc=gcdc.calcularTotalConIva(cdc);


                break;


                case 5:


                    break;
                    */
                case 4:


                    System.out.println("  -- VUELVA PRONTO --    ");

                    System.exit(0);

                    break;
                default:
                    System.out.println(" ================ ");
                    System.out.println(" Opcion no valida ");


            }


            }
            while (opcion != 7) ;


            //gl.registarusuario(cl);
            //System.out.println(gl);

            //gl.ingresarsistema(cl);

            //gl.olvidocontrasena(cl);

            //gl.salirsistema();


            //Crear 10 prodcutos
            //Añadir 6 al carrito de comprar
            //Crear la factura de ese carrito de compras





    }}


