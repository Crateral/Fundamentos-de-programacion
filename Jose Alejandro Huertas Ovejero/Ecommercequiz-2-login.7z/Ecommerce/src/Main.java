import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.co.nttdata.ecommerce.entidades.*;
import com.co.nttdata.ecommerce.logica.GestionCarritoDeCompras;
import com.co.nttdata.ecommerce.logica.GestionFactura;
import com.co.nttdata.ecommerce.logica.GestionLogin;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Crear 10 prodcutos
		List<Producto>lp=new ArrayList<>();
		Producto p1=new Producto(1,"lavadora",1,10,false,0,0,"mediano","xxx",Marca.SAMSUNG,Categoria.ELETROHOGAR);
		Producto p2=new Producto(2,"celular",1,10,false,0,0,"alto rendimiento","xxxx",Marca.MOTOROLA,Categoria.TECNOLOGIA);
		Producto p3= new Producto(3,"televisor",1,10,false,0,0,"Televisor 43","xxxx",Marca.LG,Categoria.ELETROHOGAR);
		Producto p4=new Producto(4,"nevera",1,10,false,0,0,"grande","xxxxx",Marca.WHIRLPOOL,Categoria.ELETROHOGAR);
		Producto p5=new Producto(5,"camara",1,10,false,0,19,"alta de3finicion","xxx",Marca.NIKON,Categoria.TECNOLOGIA);
		Producto p6=new Producto(6,"lavadora",1,10,false,0,0,"mediano","xxx",Marca.SAMSUNG,Categoria.ELETROHOGAR);
		Producto p7=new Producto(7,"celular",1,10,false,0,0,"alto rendimiento","xxxx",Marca.MOTOROLA,Categoria.TECNOLOGIA);
		Producto p8= new Producto(8,"televisor",1,10,false,0,0,"Televisor 43","xxxx",Marca.LG,Categoria.ELETROHOGAR);
		Producto p9=new Producto(9,"nevera",1,10,false,0,0,"grande","xxxxx",Marca.WHIRLPOOL,Categoria.ELETROHOGAR);
		Producto p10=new Producto(10,"camara",1,10,false,0,19,"alta de3finicion","xxx",Marca.NIKON,Categoria.TECNOLOGIA);

		lp.add(p1);
		lp.add(p2);
		lp.add(p3);
		lp.add(p4);
		lp.add(p5);
		lp.add(p6);

		// instanciamos
		CarritoDeCompras cdc =new CarritoDeCompras();

		GestionLogin gl =new GestionLogin();
		Empresa em=new Empresa("emperador","centro calle 9 # 6-50");

		GestionFactura gf=new GestionFactura();
		//Cliente cli1=new Cliente(11,"XX","12340","p@xxx.com","113133","calle6",true,"13133","cc","efectivo");
		GestionCarritoDeCompras gcdc =new GestionCarritoDeCompras();
		Factura f =new Factura();


		//Añadir 6 al carrito de comprar
		cdc.setProductos(lp);

		cdc.getProductos().forEach( (p) -> System.out.println( "\n"+ p.getIdProducto()+" "+ p.getNombre()+ " " + p.getCantidadDiponible() + " " + p.getMarca()+" " + p.getPrecio()  +"\n"));
		cdc = gcdc.calcularTotalConIva(cdc);

		// factura

		Cliente cl = new Cliente(1,"andres008","123456789","nnnnn@gmail.com","111111111","1",true,"45644","cc","contado");
		gcdc.calcularCostoEnvio(cdc,cl.getDireccion());
		System.out.println();
		f = gf.pagar(em,cl,cdc);


		gf.imprimirfactura();


		gl.registarusuario(cl);
		//System.out.println(gl);

		gl.ingresarsistema(cl);

		gl.olvidocontrasena(cl);

		gl.salirsistema();

		//________________________________/
		//profe yo lo hice con datos fijos/
		//_________________________________/
		//Crear 10 prodcutos
		//Añadir 6 al carrito de comprar
		//Crear la factura de ese carrito de compras
		
 	}

}
