package com.co.nttdata.ecommerce.logica;

import com.co.nttdata.ecommerce.entidades.Cliente;
import com.co.nttdata.ecommerce.entidades.Usuario;

public class GestionLogin {

  public Cliente registarusuario(Cliente cliente) {


      System.out.println("\ndatos de registro de usuario\n"+cliente.getTipoIdentificacion()+" :"+ cliente.getNumeroIdentificacion()+
              " "+"\n contreseña " +cliente.getContrasenia()+"\n " +"Nombre usuario: " +cliente.getNombreUsuario()+
              "\n " +"correo: " +cliente.getCorreo());
    return cliente;
  }
      public boolean  ingresarsistema(Cliente cliente){
        System.out.println("\ningreso al sistema");
        System.out.println("********************");

        //comprobar si funciona la logica  al cambiar los datos
    String nombreusuarioin=("andres008");
    String clave=("123456789");
    // validacion
    if (cliente.getNombreUsuario().equals(nombreusuarioin)&& cliente.getContrasenia().equals(clave)){

      System.out.println("Datos correctos");

      System.out.println("Bienvenido al Sistema");

      return true;
    }else
      System.out.println("Datos incorrectos");
      return false;

    }


    public void olvidocontrasena(Cliente cliente){
      System.out.println("\n**********************");
      System.out.println("cambio de  contraseña");
      //se le asigna una nueva  clave
      String nuevaclave="999999";

    cliente.setContrasenia(nuevaclave);
    //se imprime la nueva contraseña con los datos predefinidos
      System.out.println( "\nSu nueva contraseña es :" +cliente.getContrasenia()+ " " + "\nNombre de Usuario: " +
              " "+cliente.getNombreUsuario());
    }

    public void salirsistema(){
      System.out.println("\n*****************");
      System.out.println("salida del sistema");
      System.out.println("Vuelva Pronto");
      // código de salida
      System.exit(0);
    }


}
