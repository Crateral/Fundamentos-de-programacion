public class matas extends plantas implements carateristicas  {

    public matas(float  altura, boolean dafruto,boolean tieneflores){
        super(altura, dafruto, tieneflores);
    }






    public void calcularaltura() {
        System.out.println("matas calcular");
        System.out.println("-");

    }


    public void crearflor() {
        System.out.println("crear flor matas");
        System.out.println("-");

    }
    public void crearfruto() {
        System.out.println("crearfruto  matas");
        System.out.println("-");

    }


}



