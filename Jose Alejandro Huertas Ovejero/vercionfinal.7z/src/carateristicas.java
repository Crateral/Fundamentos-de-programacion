public interface carateristicas {

    void calcularaltura();
    void crearflor();

    void crearfruto();


}
