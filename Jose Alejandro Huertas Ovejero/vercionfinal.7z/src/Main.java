public class Main {
    public static void main(String[] args) {

        Arboles c = new Arboles(12.6f,false,false);

        Arbustos b = new Arbustos(11.6f,true,false);

        hierbas    h=new hierbas(10.2f,true,false);
        matas m = new matas(15.6f,true,true);


        c.calcularaltura();
        b.calcularaltura();
        m.calcularaltura();
        h.calcularaltura();

        c.crearfruto();
        b.crearfruto();
        m.crearfruto();
        h.crearfruto();

        c.crearflor();
        b.crearflor();
        m.crearflor();
        h.crearflor();
    }

}