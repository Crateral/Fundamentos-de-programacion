public class Arboles extends plantas implements carateristicas {

    public Arboles(float  altura, boolean dafruto,boolean tieneflores){
        super(altura, dafruto, tieneflores);
    }





    public void calcularaltura() {
        System.out.println("se calculo ls sltura y el ciclo de vida es de 30 anos");
        System.out.println("-");


    }

    public void crearflor() {
        System.out.println("se creo la flor en los arboles");
        System.out.println("-");

    }

    public void crearfruto() {
        System.out.println(" creado exitoso fruto de arboles");
        System.out.println("-");

    }



}
