public class hierbas extends plantas implements carateristicas {
    public hierbas(float  altura, boolean dafruto,boolean tieneflores){
        super(altura, dafruto, tieneflores);
    }



    public void calcularaltura() {
        System.out.println("hierbas calcular");
        System.out.println("-");

    }


    public void crearflor() {
        System.out.println("hierbas flor ");
        System.out.println("-");

    }
    public void crearfruto() {
        System.out.println("crearfruto  hierbas");
        System.out.println("-");

    }



}
