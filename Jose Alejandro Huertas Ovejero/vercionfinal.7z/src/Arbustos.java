public class Arbustos extends plantas implements carateristicas {

    public Arbustos(float  altura, boolean dafruto,boolean tieneflores){
        super(altura, dafruto, tieneflores);
    }




    public void calcularaltura() {
        System.out.println("se calculo exitosamente la altura del arbusto");
        System.out.println("-");

    }


    public void crearflor() {
        System.out.println("crear flor arbusto");
        System.out.println("-");

    }
    public void crearfruto() {
        System.out.println("se crearfruto de  arbusto");
        System.out.println("-");

    }


}
