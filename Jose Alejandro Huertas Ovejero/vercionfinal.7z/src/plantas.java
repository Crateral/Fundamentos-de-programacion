public class plantas   {
    private final float altura;
    private final boolean dafruto;
    private final boolean tieneflores;



    public plantas(float altura,boolean dafruto,boolean tieneflores) {
        this.altura = altura;
        this.dafruto=dafruto;
        this.tieneflores=tieneflores;
    }

    public float getAltura() {
        return altura;
    }

    public boolean isDafruto() {
        return dafruto;
    }

    public boolean isTieneflores() {
        return tieneflores;
    }


}
