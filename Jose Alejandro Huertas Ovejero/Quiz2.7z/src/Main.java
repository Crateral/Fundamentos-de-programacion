import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        System.out.println("Hola Bienvenido!!!!");
        int cantproduTotal=5;
        int codproductos[] = new int[]{100, 200, 300, 400, 500};
        String nombre[] = new String[]{"p_A", "p_B", "p_C", "p_D","p_E"};
        int precios[] = new int[]{10,20,30,40,50};

        Scanner teclado = new Scanner(System.in);
        int codprodcarro[] = new int[10];
        int cantcarro[] = new int[10];
        int subcarro[] = new int[10];

        int cantlineas = 0;
        int op;

        do {
            System.out.println("Menu de opciones ");
            System.out.println("_________________ ");
            System.out.println("1 - mostrar productos");
            System.out.println("2 - mostrar carrito");
            System.out.println("3 - agregar productos ");
            System.out.println("4 - salir ");
            System.out.println("ingrese la opcion deseada ");
            op = teclado.nextInt();

            switch (op){

                //llamar a muestra producto
                case 1:mostrarproductos(codproductos,nombre,precios,cantproduTotal);
                    break;
                            // llamar a mustra carrito
                    case 2: mostrarcarrito(codproductos,nombre,precios,codprodcarro,cantcarro,subcarro,cantlineas);
                        break;
                //agregar producto
                        case 3:if ( cantlineas<9){
                            cantlineas=agragarcarrito(codproductos,nombre,precios,codprodcarro,cantcarro,subcarro,cantlineas,teclado);
                        }else {

                            System.out.println("limite del carro");
                        }
                        break;
            }

         } while (op != 4);
        int sumatotal=mostrarcarrito(codproductos,nombre,precios,codprodcarro,cantcarro,subcarro,cantlineas);

        System.out.println("Total es " + sumatotal);
    }

    public  static  void mostrarproductos(int[ ] cp,String[] np,int []pp,int cant){
        int i;
        System.out.println("");
        System.out.println("Lista de productos ");
        System.out.println("______________");

        for (i=0;i<cant;i++){
            System.out.println(cp[i] + "  -  " + np[i] + "--" + pp[i] );

        }
    }
    public  static  int mostrarcarrito(int[] cp,String[] np,int []pp,
               int [] cp_linea, int[]cantlinea,int[] subt, int cantlineas){
        int i, suma = 0;
        System.out.println();
        System.out.println("Carrito de Compro   ");
        System.out.println("====================");

        for (i=0;i<cantlineas;i++){
            int a=buscarprod(cp_linea[i],cp);
            System.out.println(cp_linea[i] + "  -  " + np[a] + "--" + pp[a]     + "     "
                    + cantlinea[i]+"  " + subt[i]);
            suma = suma + subt[i];
        }
        return suma;
    }
    public  static int buscarprod(int codbusc,int[] productos){
        int poscion=-1;
        for (int i=0;i<5;i++){
            if (codbusc==productos[i]){
                poscion=1;
            }
        }
    return poscion;
    }
    public  static  int agragarcarrito(int[] cp,String[] np,int []pp, int [] cp_linea, int[]cantlinea,int[] subt, int cantlineas,Scanner teclado){
        System.out.println("ingrese codigo producto deseada ");
       int cod = teclado.nextInt();
       int posi = buscarprod(cod,cp);
       if (posi ==-1){
           System.out.println(" producto no exite");
           return cantlineas;
       }
        System.out.println("ingrese cantidad deseada ");
        int cant = teclado.nextInt();
        cp_linea[cantlineas]=cod;
        cantlinea[cantlineas]=cant;
        subt[cantlineas]=pp[posi] * cant;
        return (cantlineas + 1);
    }
}


