public class Main {
    public static void main(String[] args) {

    //alejandro Huertas
    // figura de retangulo

        retangulo r1 = new retangulo(1.0, 2.0);

        System.out.println(" FIGURA RETANGULO");
        System.out.println(" PERIMETRO RETANGULO");
        System.out.println("retangulo base " + r1.getBase() + "y altura es" + r1.getAltura() + "es "
                            + r1.calcularperimetro());

        System.out.println("AREA RETANGULO");

        System.out.println("retangulo base " + r1.getBase() + "y altura es" + r1.getAltura() + "es "
                                + r1.calcularArea());

    // FIGURA CIRCULO
        circulo a = new circulo(3);

        System.out.println("FIGURA CIRCULO");
        System.out.println("perimetro CIRCULO");
        System.out.println("circulo radio " + a.getRadio() + a.calcularperimetro());


        System.out.println("AREA CIRCULO");

        System.out.println("circulo radio " + a.getRadio() + a.calcularArea());


    }

}


