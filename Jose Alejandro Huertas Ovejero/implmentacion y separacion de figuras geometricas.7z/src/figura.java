public class figura {

    figura() {

    }

    public double calcularperimetro() {
        return 0;
    }

    public double calcularArea() {
        return 0;
    }



}
