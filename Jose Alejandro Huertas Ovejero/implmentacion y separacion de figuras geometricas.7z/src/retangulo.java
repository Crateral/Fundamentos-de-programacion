public class retangulo extends figura {
    private double base;
    private double altura;

    public retangulo(double base, double altura) {
        this.base = base;
        this.altura = altura;
    }

    public double calcularperimetro() {
        return (base * 2 + altura);

    }

    public double calcularArea() {

        return base * altura * 0.5;
    }

    public double getBase() {

        return base;
    }
    public double getAltura() {
        return altura;
    }


}
