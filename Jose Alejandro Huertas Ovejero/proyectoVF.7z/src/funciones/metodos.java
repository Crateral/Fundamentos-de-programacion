package funciones;

import clases.compras;
import clases.factura;

import java.util.Scanner;

public class metodos {

    public static factura verfact(){

        factura factura=new factura();
        int subtotal;
        int iva;
        int total;


        return factura ;
    }

    public static compras agregarcompras() {
        compras nuevacompra = new compras("", " ", 0);
        String producto;
        String categoria;
        int precio;
        Scanner t = new Scanner(System.in);
        System.out.print("\nEscribe el nombre de producto: ");
        producto = t.next();
        nuevacompra.setProducto(producto);

        System.out.print("\nEscribe la categoria: ");
        categoria = t.next();
        nuevacompra.setCategoria(categoria);

        System.out.print("\nEscribe el precio: ");
        precio = t.nextInt();
        nuevacompra.setPrecio(precio);


        return nuevacompra;

    }




}
