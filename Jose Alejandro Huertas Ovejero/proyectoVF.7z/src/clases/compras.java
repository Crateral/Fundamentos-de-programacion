package clases;

public class compras {
    private String producto;
    private String categoria;
    public int precio;

    public compras(String producto, String categoria, int precio) {
        this.producto = producto;
        this.categoria = categoria;
        this.precio = precio;
    }

    public compras() {

    }

    public int getPrecio() {
        return precio;
    }

    public String getProducto() {
        return producto;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public String mostrarDatos (){
        return "producto: " + producto +"\n Categoria: " + categoria+ "\n Precio: $ " + precio + "\n" ;
    }

}





