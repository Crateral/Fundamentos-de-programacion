package clases;

public class factura {

    private int subtotal;
    private  int iva;
    private int total;

    public factura(int subtotal,int iva,int total) {
        this.subtotal = subtotal;
        this.iva=iva;
        this.total=total;
    }

    public factura() {

    }


    public int getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(int subtotal) {
        this.subtotal = subtotal;
    }

    public int getIva() {
        return iva;
    }

    public void setIva(int iva) {
        this.iva = iva;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public int verfact (){



        return subtotal+iva+total;

    }
}


