import clases.Registro;
import clases.compras;
import clases.factura;
import funciones.metodos;

import javax.swing.text.html.Option;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import static funciones.metodos.agregarcompras;
import static funciones.metodos.verfact;
//import static funciones.metodos.opciones;

public class Main {

    public static void main(String[] args) {

        List<Registro> registroUsuarios = new ArrayList<>();
        //List<compras> registrocompras = new ArrayList<>();

        Scanner t = new Scanner(System.in);
        String nombre, clave;
        int opcion = 0;

        while (true) {
            System.out.println("| =======================|");
            System.out.println("|          LOGIN         |");
            System.out.println("|========================|");
            System.out.println("| //       OPCIONES    //|");
            System.out.println("| 1. Crear     Usuario   |");
            System.out.println("| 2. Consultar Usuario   |");
            System.out.println("| 3. Iniciar    Sesion   |");
            System.out.println("| 4. Cambiar     Clave   |");
            System.out.println("| 5. Salir               |");
            System.out.println("|========================|");
            System.out.print(" opciones que deseas realizar: ");
            opcion = t.nextInt();

            switch (opcion) {
                case 1:
                    Registro Regist = new Registro();
                    System.out.println("|===============================|");
                    System.out.println("| - Digite datos del usurario - |");
                    System.out.println("|===============================|");
                    System.out.print(" Escriba su Nombre de usuario: ");
                    nombre = t.next();
                    Regist.setNombre(nombre);
                    System.out.println("=====================");
                    System.out.print(" Escriba su Clave: ");
                    clave = t.next();
                    Regist.setClave(clave);
                    registroUsuarios.add(Regist);
                    System.out.println("=====================");
                    System.out.println("- Usuario Registrado  - ");
                    break;
                case 2:
                    if (registroUsuarios.size() != 0) {
                        System.out.println(" ==================== ");
                        for (Registro p : registroUsuarios) {
                            System.out.println(p.toString());
                        }
                    } else {
                        System.out.println("| - usuario no encontrado -|");
                    }
                    break;
                case 3:
                    if (registroUsuarios.size() != 0) {
                        System.out.println("============================");
                        System.out.println(" - Digite sus credenciales -");
                        System.out.println("============================");
                        System.out.print("  Usuario: ");
                        nombre = t.next();
                        System.out.println("============================");
                        System.out.print("  Clave:  ");
                        clave = t.next();
                        for (Registro registroPersona : registroUsuarios) {
                            if (registroPersona.getNombre().equals(nombre) && registroPersona.getClave().equals(clave)) {
                                System.out.println("===================================");
                                System.out.println("Haz Iniciado Sesión correctamente  ");
                                System.out.println("===================================");
                                ArrayList<compras> listacompras = new ArrayList<>();
                                while (opcion != 6) {
                                    System.out.println("============================");
                                    System.out.println("|-- CARRITO DE COMPRAS ---|");
                                    System.out.println("============================");
                                    System.out.println("| -----   OPCIONES -----   |");
                                    System.out.println("============================");
                                    System.out.println("1. Agregar productos      -");
                                    System.out.println("2. estos son los precios  -");
                                    System.out.println("3. Estas son las categorias");
                                    System.out.println("4. productos por nombres  -");
                                    System.out.println("5. genera  factura        -");
                                    System.out.println("6. Salir                  -");
                                    System.out.println("===========================");
                                    System.out.print("Escribe la opcion que desea hacer ->:");
                                    opcion = t.nextInt();
                                    switch (opcion) {
                                        case 1:
                                            System.out.println("----Agrega  Productos a tu carrito :) ---");
                                            metodos metodos = new metodos();
                                            listacompras.add(agregarcompras());
                                            break;
                                        case 2:
                                            System.out.println(" ======================== ");
                                            System.out.println(" precios de sus productos ");

                                            for (compras h : listacompras) {
                                                System.out.println(h.getPrecio());
                                            }
                                            break;
                                        case 3:
                                            System.out.println(" ======================== ");
                                            System.out.println("categorias");
                                            for (compras c : listacompras) {
                                                System.out.println(c.getCategoria());
                                            }
                                            break;

                                        case 4:
                                            System.out.println(" ======================== ");
                                            System.out.println("  estos son sus productos :  ");
                                            for (compras c : listacompras) {
                                                System.out.println(c.getProducto());
                                            }

                                            break;

                                        case 5:
                                            System.out.println("  Fin de las compras  ");
                                            System.out.println("=========================   ");
                                            System.out.println("Factura ");
                                            compras compras = new compras();

                                            compras.mostrarDatos();

                                            int acumulado = 0;
                                            for (compras c : listacompras) {
                                                System.out.println(c.mostrarDatos());
                                                acumulado = acumulado + c.getPrecio();
                                            }
                                            int subtotal;
                                            subtotal = acumulado;

                                            int iva = (subtotal * 19 / 100);
                                            int total = subtotal + iva;
                                            System.out.println(" ======================== ");
                                            System.out.println("El total de la compra fue: ");
                                            System.out.println("Subtotal " + subtotal);
                                            System.out.println("IVA " + iva);
                                            System.out.println("Total a Pagar " + total);
                                            System.out.println(" ======================== ");

                                    }

                                }
                            } else {

                                System.out.println("Credenciales incorrectas ");
                            }
                        }
                    } else {

                        System.out.println("usuario no encontrado , vuela a menu  ");
                    }


                    break;
                case 4:
                    if (registroUsuarios.size() != 0) {
                        System.out.println(" ======================== ");
                        System.out.print("Digite su clave: ");
                        clave = t.next();

                        int indice = 0;
                        for (Registro nclave : registroUsuarios) {
                            if (nclave.getClave().equals(clave)) {
                                indice = registroUsuarios.indexOf(nclave.getClave());

                                if (indice != 0) {
                                    System.out.println(" ======================== ");
                                    System.out.print("ingresa tu nueva clave ");
                                    clave = t.next();
                                    nclave.setClave(clave);
                                    System.out.println("clave cambiada ");
                                }
                            } else {
                                System.out.println("error ");
                            }
                        }
                    } else {
                        System.out.println("informacion no encontrada ");
                    }

                    break;

                case 5:
                    System.out.println("|=========================|");
                    System.out.println("|  -- VUELVA PRONTO --    |");
                    System.out.println("|=========================|");
                    System.exit(0);

                    break;
                default:
                    System.out.println(" ================ ");
                    System.out.println(" Opcion no valida ");

            }


        }


    }


}