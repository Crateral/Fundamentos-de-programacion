package clases;

public class Persona {
    private String nombre;
    private String apellido;
    private String numero_identifiacion;

    private String genero;
    private int telefono;
    private  Rol rol;
    private String login_user;
    private String passuser;
    private int telefono_emergente;


    public Persona(String nombre, String apellido, String numero_identifiacion, String genero, int telefono,
                   Rol rol, String login_user, String passuser, int telefono_emergente) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.numero_identifiacion = numero_identifiacion;
        this.genero = genero;
        this.telefono = telefono;
        this.rol = rol;
        this.login_user = login_user;
        this.passuser = passuser;
        this.telefono_emergente = telefono_emergente;
    }

    public Persona() {

    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getNumero_identifiacion() {
        return numero_identifiacion;
    }

    public void setNumero_identifiacion(String numero_identifiacion) {
        this.numero_identifiacion = numero_identifiacion;
    }


    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public Rol getRol() {
        return rol;
    }

    public void setRol(Rol rol) {
        this.rol = rol;
    }

    public String getLogin_user() {
        return login_user;
    }

    public void setLogin_user(String login_user) {
        this.login_user = login_user;
    }

    public String getPassuser() {
        return passuser;
    }

    public void setPassuser(String passuser) {
        this.passuser = passuser;
    }

    public int getTelefono_emergente() {
        return telefono_emergente;
    }

    public void setTelefono_emergente(int telefono_emergente) {
        this.telefono_emergente = telefono_emergente;
    }

    public String mostrarUsuario (){
        return "nombre: " + nombre +"\n apellido: " + apellido+ "\n telefono: " + telefono + "\n telefono emegente" + telefono_emergente
                + "\nnombre de usuario " + login_user + "\n clave " +  passuser;
    }

}
