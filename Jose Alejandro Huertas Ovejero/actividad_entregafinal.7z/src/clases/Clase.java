package clases;

public class Clase {

    private  String nombre;
    private  String fecha_inicio;
    private  String Fecha_finalizacion;


    public  Clase(String nombre,String fecha_inicio,String fecha_finalizacion){
        this.nombre=nombre;
        this.fecha_inicio=fecha_inicio;
        this.Fecha_finalizacion=fecha_finalizacion;
    }

    public  Clase(){}


    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getFecha_inicio() {
        return fecha_inicio;
    }

    public void setFecha_inicio(String fecha_inicio) {
        this.fecha_inicio = fecha_inicio;
    }

    public String getFecha_finalizacion() {
        return Fecha_finalizacion;
    }

    public void setFecha_finalizacion(String fecha_finalizacion) {
        Fecha_finalizacion = fecha_finalizacion;
    }
}

