package clases;

public class Usuario extends Persona {

    private  boolean membrecia;



    public Usuario() {
    super();
    this.membrecia=true;
    }


    public boolean getMembrecia() {
        return membrecia;
    }

        public void setMembrecia(boolean membrecia) {
        this.membrecia = membrecia;
    }



}
