package clases;

import java.util.Scanner;

public class Datos_Peso {

    private  int peso_actual;
    private  int peso_anterior;
    private  int peso_records;
    private  String username;

    public  Datos_Peso(int peso_actual,int peso_anterior,int peso_records,String username){
        this.peso_actual=peso_actual;
        this.peso_anterior=peso_anterior;
        this.peso_records=peso_records;
        this.username=username;

    }

    public Datos_Peso(){}

    public int getPeso_actual() {
        return peso_actual;
    }

    public void setPeso_actual(int peso_actual) {
        this.peso_actual = peso_actual;
    }

    public int getPeso_anterior() {
        return peso_anterior;
    }

    public void setPeso_anterior(int peso_anterior) {
        this.peso_anterior = peso_anterior;
    }

    public int getPeso_records() {
        return peso_records;
    }

    public void setPeso_records(int peso_records) {
        this.peso_records = peso_records;
    }


    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
    public static Datos_Peso AgregarDatos(){
        Datos_Peso nuevopeso=new Datos_Peso();

        int peso_actual;
        int peso_anterior;
        int peso_records;

        Scanner t = new Scanner(System.in);
        System.out.println("\n escribe su peso actual  ");
        peso_actual=t.nextInt();
        nuevopeso.setPeso_actual(peso_actual);

        System.out.println("\n escribe su peso anterior  ");
        peso_anterior=t.nextInt();
        nuevopeso.setPeso_anterior(peso_anterior);

        System.out.println("\n escribe su peso records  ");
        peso_records=t.nextInt();
        nuevopeso.setPeso_records(peso_records);

        //Pesos_registrados.add(nuevopeso);
        return nuevopeso;


    }


    @Override
    public String toString() {
        return "Su peso actual  " + peso_actual +  "\n  peso anterior:  " + peso_anterior + "\n peso records" + peso_records ;

    }
}
