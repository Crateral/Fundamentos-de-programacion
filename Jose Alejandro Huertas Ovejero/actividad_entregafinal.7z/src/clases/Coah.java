package clases;

public class Coah extends Persona {


    public  Coah(){}

}
