package clases;

public class Administrador extends Persona {

public  Administrador(){}
    


}
