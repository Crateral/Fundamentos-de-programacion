package clases;

public enum Rol {
    Administrador,Coach,Usuario


}
