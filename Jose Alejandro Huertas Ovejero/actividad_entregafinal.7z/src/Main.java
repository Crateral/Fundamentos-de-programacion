import clases.*;
//import funciones.peso;

import java.util.*;


public class Main {


    public static void main(String[] args) {


        List<Persona> login = new ArrayList<>();
        Scanner t = new Scanner(System.in);
        String nombre, apellido, numero_identificacion, genero, login_user, passuser;
        int telefono, telefono_emergente;
        int opcion = 0;
        // peso pesos=new peso();
        String rol;
        Persona loggeduser;
        while (true) {
            System.out.println("| =======================|");
            System.out.println("|          Login         |");
            System.out.println("|========================|");
            System.out.println("| //    Opciones       //|");
            System.out.println("| 1. Crear     Usuario   |");
            System.out.println("| 2. Iniciar sesión      |");
            System.out.println("| 3. Salir                    |");
            System.out.println("|========================|");
            System.out.print(" opciones que deseas realizar: ");
            opcion = t.nextInt();

            switch (opcion) {
                case 1:
                    Persona Regist = null;
                    System.out.println("=====================");
                    System.out.print(" Usuario,Administrador,Coach ");
                    System.out.print("\n Escriba su rol: ");
                    rol = t.next();
                    Rol persona = Rol.valueOf(rol);
                    switch (persona){
                        case Administrador:
                            Regist=new Administrador();
                            break;

                        case Usuario:
                            Regist=new Usuario();
                            break;

                        case Coach:
                                Regist=new Coah();
                            break;
                    }
                    Regist.setRol(persona);
                    System.out.println("=====================");
                    System.out.print(" Escriba su nombre: ");
                    nombre = t.next();
                    Regist.setNombre(nombre);
                    System.out.println("=====================");
                    System.out.print(" Escriba su apellido: ");
                    apellido = t.next();
                    Regist.setApellido(apellido);
                    System.out.println("=====================");
                    System.out.print(" Escriba su telefono: ");
                    telefono = Integer.parseInt(t.next());
                    Regist.setTelefono(telefono);
                    System.out.println("=====================");
                    System.out.print(" Escriba su telefono en caso de una emergencia: ");
                    telefono_emergente = Integer.parseInt(t.next());
                    Regist.setTelefono_emergente(telefono_emergente);
                    System.out.println("=====================");
                    System.out.print(" Escriba su nombre de usuario: ");
                    login_user = t.next();
                    Regist.setLogin_user(login_user);
                    System.out.println("=====================");
                    System.out.print(" Escriba su nombre de password:  ");
                    passuser = t.next();
                    Regist.setPassuser(passuser);
                    login.add(Regist);
                    System.out.println("=====================");
                    System.out.println("- Usuario Registrado  - ");
                    break;

                case 2:

                    if (login.size() != 0) {
                        System.out.println("============================");
                        System.out.println(" - Digite sus credenciales -");
                        System.out.println("============================");
                        System.out.print("  Cual es su rol: ");
                        rol = t.next();
                        System.out.println("============================");
                        System.out.print("  nombre de usuario:  ");
                        login_user = t.next();
                        System.out.println("============================");
                        System.out.print("  passuser:  ");
                        passuser = t.next();


                        for (Persona inicio : login) {
                            if (inicio.getRol().equals(Rol.Coach)) {
                                if (inicio.getLogin_user().equals(login_user) && inicio.getPassuser().equals(passuser)) {

                                    loggeduser = inicio;

                                    ArrayList<Datos_Peso> ListaPeso = new ArrayList<>();


                                    while (opcion != 3) {
                                        ArrayList<Datos_Peso> ListaPesos = new ArrayList<>();
                                        System.out.println("===================================");
                                        System.out.println("Haz Iniciado Sesión correctamente  ");
                                        System.out.println("================================");
                                        System.out.println("|===============================|");
                                        System.out.println("| - Bienvenido Coach -   |");
                                        System.out.println("|===============================|");
                                        System.out.println("|===============================|");
                                        System.out.println("| - OPCIONES  -              |");
                                        System.out.println("|===============================|");
                                        System.out.println("| 1. VER DATOS USUARIOS     |");
                                        System.out.println("| 2. CONSULTAR DATOS         |");
                                        System.out.println("| 3. SALIR                    |");
                                        System.out.println("|========================|");
                                        System.out.print("Escribe la opcion que desea hacer ->:");
                                        opcion = t.nextInt();

                                        //List<Persona> OPCIONES = new ArrayList<>();
                                        switch (opcion) {

                                            case 1:
                                                System.out.println("----Agrega  datos peso ---");
                                                Datos_Peso D = new Datos_Peso();
                                                ListaPeso.add(Datos_Peso.AgregarDatos());
                                                break;

                                            case 2:
                                                if (ListaPeso.size() != 0) {
                                                    System.out.println(" ==================== ");
                                                    for (Datos_Peso l : ListaPeso) {
                                                        System.out.println(l.toString());
                                                    }
                                                } else {
                                                    System.out.println("| - usuario no encontrado -|");
                                                }
                                                break;


                                        }


                                    }
                                } else {

                                    System.out.println("Credenciales incorrectas000000 ");
                                }
                            }
                        }
                        for (Persona inicio : login) {
                            if (inicio.getRol().equals(Rol.Administrador)) {
                                if (inicio.getLogin_user().equals(login_user) && inicio.getPassuser().equals(passuser)) {

                                    loggeduser = inicio;

                                    ArrayList<Datos_Peso> ListaPeso = new ArrayList<>();


                                    while (opcion != 3) {
                                        ArrayList<Datos_Peso> ListaPesos = new ArrayList<>();
                                        System.out.println("===================================");
                                        System.out.println("Haz Iniciado Sesión correctamente  ");
                                        System.out.println("================================");
                                        System.out.println("|===============================|");
                                        System.out.println("| - Bienvenido Administrador -   |");
                                        System.out.println("|===============================|");
                                        System.out.println("|===============================|");
                                        System.out.println("| - OPCIONES  -              |");
                                        System.out.println("|===============================|");
                                        System.out.println("| 1. VER DATOS USUARIOS     |");
                                        System.out.println("| 2. Ver membresia         |");
                                        System.out.println("| 3. SALIR                    |");
                                        System.out.println("|========================|");
                                        System.out.print("Escribe la opcion que desea hacer ->:");
                                        opcion = t.nextInt();

                                        //List<Persona> OPCIONES = new ArrayList<>();
                                        switch (opcion) {

                                            case 1:
                                                System.out.println("----Lista Usuarios ---");
                                                for (Persona usuario : login){
                                                    if (usuario.getRol()==Rol.Usuario){
                                                        System.out.println("__________________" );
                                                        System.out.println("Nombre:" + usuario.getNombre());

                                                        System.out.println("telefono:" + usuario.getTelefono());
                                                        //agregar datos

                                                    }
                                                }
                                                break;

                                            case 2:
                                                System.out.println("----Usuario Activos ---");
                                                for (Persona usuario : login){
                                                    if (usuario.getRol()==Rol.Usuario){
                                                        Usuario user= (Usuario)usuario ;
                                                        if(user.getMembrecia()){
                                                            System.out.println("Nombre:" + usuario.getNombre());
                                                        }


                                                    }
                                                }
                                                break;

                                        }


                                    }
                                } else {

                                    System.out.println("Credenciales incorrectas 222");
                                }
                            }
                        }

                        for (Persona inicio : login) {
                            if (inicio.getRol().equals(Rol.Usuario)) {
                                if (inicio.getLogin_user().equals(login_user) && inicio.getPassuser().equals(passuser)) {

                                    loggeduser = inicio;

                                    ArrayList<Datos_Peso> ListaPeso = new ArrayList<>();


                                    while (opcion != 3) {
                                        ArrayList<Datos_Peso> ListaPesos = new ArrayList<>();
                                        System.out.println("===================================");
                                        System.out.println("Haz Iniciado Sesión correctamente  ");
                                        System.out.println("================================");
                                        System.out.println("|===============================|");
                                        System.out.println("| - BIENVENIDO  -              |");
                                        System.out.println("|===============================|");
                                        System.out.println("|===============================|");
                                        System.out.println("| - OPCIONES  -              |");
                                        System.out.println("|===============================|");
                                        System.out.println("| 1. REGISTRAR PESO     |");
                                        System.out.println("| 2. CONSULTAR DATOS         |");
                                        System.out.println("| 3. SALIR                    |");
                                        System.out.println("|========================|");
                                        System.out.print("Escribe la opcion que desea hacer ->:");
                                        opcion = t.nextInt();


                                        switch (opcion) {

                                            case 1:
                                                System.out.println("----Agrega  datos peso ---");
                                                Datos_Peso D = new Datos_Peso();
                                                ListaPeso.add(Datos_Peso.AgregarDatos());
                                                break;

                                            case 2:
                                                if (ListaPeso.size() != 0) {
                                                    System.out.println(" ==================== ");
                                                    for (Datos_Peso l : ListaPeso) {
                                                        System.out.println(l.toString());
                                                    }
                                                } else {
                                                    System.out.println("| - usuario no encontrado -|");
                                                }
                                                break;


                                        }


                                    }
                                } else {

                                    System.out.println("Credenciales incorrectas ");
                                }
                            }
                        }

                    }
                case 3:
                    System.out.println("|=========================|");
                    System.out.println("|  -- VUELVA PRONTO --    |");
                    System.out.println("|=========================|");
                    System.exit(0);

                    break;
                default:
                    System.out.println(" ================ ");
                    System.out.println(" Opcion no valida ");
            }

        }
    }
}



























