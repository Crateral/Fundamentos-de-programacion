public class personal extends  vehiculo{

    private  String nombre;
    private  String apellido;
    private  int cc;

    public personal(String nombreempresa, String ruta,String marca , String color, String nombre,String apellido,int cc) {
        super(nombreempresa, ruta, marca, color);
        this.nombre = nombre;
        this.apellido = apellido;
        this.cc = cc;
    }



    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public int getIdentificacion() {
        return cc;
    }

    public void Datospersonal () {
            System.out.println("el nombre de la empresa es ->  " + getNombreempresa() +  "con ruta  " + getRuta() + "  de color  " + getColor() + " nombre de la persona que entrega  " + nombre + " y apellido " + apellido
                    + "  con numero de identificacion " + getIdentificacion());

        }

}
