public class empresa {

    private String nombreempresa;
    private  String ruta;

    public empresa(String nombreempresa, String ruta) {
        this.nombreempresa = nombreempresa;
        this.ruta= ruta;
    }

    public String getNombreempresa() {
        return nombreempresa;
    }

    public String getRuta() {
        return ruta;
    }


}

