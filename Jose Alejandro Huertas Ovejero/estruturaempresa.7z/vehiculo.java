public class vehiculo extends empresa {
    private String  marca;
    private String  color;

    public vehiculo(String nombreempresa, String ruta,String marca , String color){
    super(nombreempresa, ruta);
    this.marca=marca;
    this.color=color;

    }

    public String getMarca() {
        return marca;
    }

    public String getColor() {
        return color;
    }

    public void DatosVehiculo(){
       System.out.println("El nombre de la empresa es - > "+ getNombreempresa()+ "  con ruta  "  + getRuta() + "   y  la marca del vehiculo  es: "+ marca
                        + " de color " + color );




   }



}
