public class mercancia extends  empresa {

    private String  fragil;
    private String  perecederos;
    private String  resistente;

    public mercancia (String nombreempresa, String ruta,String fragil, String perecederos,String resistente){
        super(nombreempresa, ruta);
        this.fragil=fragil;
        this.perecederos=perecederos;
        this.resistente=resistente;

    }



    public void DatosMercancia () {
        System.out.println( "empresa responsable " + getNombreempresa() + " con ruta  " + getRuta() + "llevamos productos fragiles como " + fragil + "  perecederos " + perecederos + " y resistente  "  + resistente);

    }




}
