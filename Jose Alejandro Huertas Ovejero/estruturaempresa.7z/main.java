public class main { 

    public static void main(String [] args){

        vehiculo vehiculo = new vehiculo("velotax","sol", "volvo","blanco");

        vehiculo.DatosVehiculo();



        personal personal= new personal("velotax","el sol","volvo","negro","LUIS",
                "peres",965611);

        personal.Datospersonal();

        mercancia mercancia = new mercancia("RAPIDO SA"," libertadores","vidrio","plantas","acero");
        mercancia.DatosMercancia();


    }
}
