

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ArrayList<usuario>usuario=new ArrayList<>();

        Scanner lector = new Scanner(System.in);
        boolean programaactivo=true;
        do {

            System.out.println("  menu ");
            System.out.println("_____________________________");
            System.out.println(" 1. Crear Usuario     ");
            System.out.println(" 2. modificar Usuario   ");
            System.out.println(" 3. eliminar usuario    ");
            System.out.println(" 4. Consultar usuario    ");
            System.out.println(" 5. Salir    ");
            int opcion = lector.nextInt();

            if (opcion == 1) {// crear
                System.out.println("introdusca el nombre de usuario");
                String nombre=lector.next();
                System.out.println("introdusca la contraseña");
                String clave=lector.next();

                usuario a = new usuario();
                a.setNombre(nombre);
                a.setClave(clave);
                usuario.add(a);



            } else if (opcion == 2) {// modificar
                System.out.println("introdusca el nombre de usuario a modificar");
                String nombre=lector.next();
                System.out.println("introdusca el nuevo nombre de usuario");
                String nombre2=lector.next();
                System.out.println("introdusca la nueva clave");
                String clave2=lector.next();
                Iterator<usuario>it=usuario.iterator();
                while (it.hasNext()){
                    usuario a= it.next();
                    if(a.getNombre().equals(nombre)){
                        a.setNombre(nombre2);
                        a.setClave(clave2);

                    }
                }

            } else if (opcion == 3) {
                System.out.println("introdusca el nombre del usuario a eliminar ");
                String nombre = lector.next();
                Iterator<usuario> it = usuario.iterator();
                while (it.hasNext()) {
                    usuario a = it.next();
                    if (a.getNombre().equals(nombre)){
                    it.remove();

                    }
                }




            } else if (opcion == 4) {// consultar
                for (usuario a: usuario){
                    System.out.println("nombre  " +  a.getNombre() + "   clave "  + a.getClave());
                }

            } else if (opcion   == 5) {
                        programaactivo=false;
                System.out.println("secion cerrada con exito vuelva pronto");
            } else {
                System.out.println("no existe");
            }
            }while (programaactivo);
    }
}