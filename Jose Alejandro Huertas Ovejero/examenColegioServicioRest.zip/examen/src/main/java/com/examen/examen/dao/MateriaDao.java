package com.examen.examen.dao;

import java.util.List;

import com.examen.examen.entity.Materia;
import com.examen.examen.entity.Notas;

public interface MateriaDao {
	
	
public Materia findById(int id);
	
	public List<Materia> findAll();
	
	public void guardar(Materia materia);
	 
	public void deleteById(int id_materia);
	

}
