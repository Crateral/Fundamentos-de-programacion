package com.examen.examen.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examen.examen.entity.Materia;

import com.examen.examen.service.MateriaService;

@RestController
//@CrossOrigin(origins = "http://localhost:3321")
@RequestMapping("/api")
public class MateriaController {
	
	 //Inyectamos el servicio para poder hacer uso de el
	@Autowired	
	private MateriaService materiaService;

	/*Este método se hará cuando por una petición GET (como indica la anotación) se llame a la url + el id de un usuario
	http://127.0.0.1:8080/api/Marca/1*/
	@GetMapping("/Materia/{idmateria}")
	public Materia getMateria(@PathVariable int idmateria) {
		Materia materia = materiaService.findById(idmateria);
		
		if(materia == null)
			throw new RuntimeException("nota no encontrada"   +  idmateria + "!");
		
		return materia;
		
	}
	/*Este método se hará cuando por una petición GET (como indica la anotación) se llame a la url 
	http://127.0.0.1:8080/api/Marca*/

	@GetMapping("/Materia")
	public List<Materia> findAll(){
	   //retornará todos los usuarios
	   return materiaService.findAll();
	}

	/*Este método se hará cuando por una petición POST (como indica la anotación) se llame a la url
	http://127.0.0.1:8080/api/Marca/  */
	@PostMapping("/Materia")
	public Materia addMateria(@RequestBody Materia materia) {
		materia.setIdmateria(0);
		

	   //Este metodo guardará al usuario enviado
		materiaService.guardar(materia);

	   return materia;
	   

	}

	/*Este método se hará cuando por una petición PUT (como indica la anotación) se llame a la url
	http://127.0.0.1:8080/api/users/  */
	@PutMapping("/Materia/{idmateria}")
	public Materia updateMateria(@RequestBody Materia materia , @PathVariable int idmateria ) {
		
		List<Materia>lismateria=materiaService.findAll();
		Materia n=new Materia();
		
		for (Materia n3 : lismateria) {
			
			n=n3;
			if(n3.getIdmateria()==idmateria) {
				n.setNombre(materia.getNombre());
				
				materiaService.guardar(n);
				break;		
			}
			
		}

		
	   //este metodo actualizará al usuario enviado

	   return n;
	}
		


	/*Este método se hará cuando por una petición DELETE (como indica la anotación) se llame a la url + id del usuario
	http://127.0.0.1:8080/api/users/1  */
	@DeleteMapping("/Materia/{idmateria}")
	public String deteteNota(@PathVariable int idmateria) {

		Materia materia = materiaService.findById(idmateria);

	   if(materia == null) {
	       throw new RuntimeException("Materia no id not found -"+idmateria);
	   }

	   materiaService.deleteById(idmateria);

	   //Esto método, recibira el id de un usuario por URL y se borrará de la bd.
	   return "Deleted nota id - "+idmateria;
	}

		
	
	
	
	

}
