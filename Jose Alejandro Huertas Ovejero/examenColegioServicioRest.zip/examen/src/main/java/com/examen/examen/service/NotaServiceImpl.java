package com.examen.examen.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.examen.examen.dao.NotasDao;
import com.examen.examen.entity.Notas;
@Service
public class NotaServiceImpl implements NotaService {

	@Autowired
	private NotasDao notaDao;
	
	@Override
	@Transactional(readOnly = true)
	public Notas findById(int id) {
		
		Notas notas=notaDao.findById(id);
	
		return notas;
		
		
	}
	
	@Override
	@Transactional(readOnly = true)
    public List<Notas> findAll() {
        List<Notas> listUsers= notaDao.findAll();
        return listUsers;
    }
	
	
	@Override
	@Transactional
	public void guardar(Notas notas) {
		notaDao.guardar(notas);

    }
	
	
	@Override
	@Transactional
    public void deleteById(int id) {
		notaDao.deleteById(id);
    }

	

}
