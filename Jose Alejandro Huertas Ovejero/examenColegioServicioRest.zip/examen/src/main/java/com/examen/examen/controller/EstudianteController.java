package com.examen.examen.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examen.examen.entity.Estudiante;
import com.examen.examen.entity.Materia;
import com.examen.examen.service.EstudianteService;
import com.examen.examen.service.MateriaService;

@RestController
//@CrossOrigin(origins = "http://localhost:3321")
@RequestMapping("/api")
public class EstudianteController {
	
	 //Inyectamos el servicio para poder hacer uso de el
		@Autowired	
		private EstudianteService estudianteService;

		/*Este método se hará cuando por una petición GET (como indica la anotación) se llame a la url + el id de un usuario
		http://127.0.0.1:8080/api/Marca/1*/
		@GetMapping("/Estudiante/{idestudiante}")
		public Estudiante getEstudiante(@PathVariable int idestudiante) {
			Estudiante estudiante = estudianteService.findById(idestudiante);
			
			if(estudiante == null)
				throw new RuntimeException("nota no encontrada"   +  idestudiante + "!");
			
			return estudiante;
			
		}
		/*Este método se hará cuando por una petición GET (como indica la anotación) se llame a la url 
		http://127.0.0.1:8080/api/Marca*/

		@GetMapping("/Estudiante")
		public List<Estudiante> findAll(){
		   //retornará todos los usuarios
		   return estudianteService.findAll();
		}

		/*Este método se hará cuando por una petición POST (como indica la anotación) se llame a la url
		http://127.0.0.1:8080/api/Marca/  */
		@PostMapping("/Estudiante")
		public Estudiante addestudiante(@RequestBody Estudiante estudiante) {
			estudiante.setIdestudiante(0);
			

		   //Este metodo guardará al usuario enviado
			estudianteService.guardar(estudiante);

		   return estudiante;
		   

		}

		/*Este método se hará cuando por una petición PUT (como indica la anotación) se llame a la url
		http://127.0.0.1:8080/api/users/  */
		
		@PutMapping("/Estudiante/{idestudiante}")
		public Estudiante updateEstudiante(@RequestBody Estudiante estudiante , @PathVariable int idestudiante ) {
			
			List<Estudiante>lisestudiat=estudianteService.findAll();
			
			Estudiante n=new Estudiante();
			
			for (Estudiante n3 : lisestudiat) {
				
				n=n3;
				if(n3.getIdestudiante()==idestudiante) {
					n.setNombre(estudiante.getNombre());
					
					n.setDireccion(estudiante.getDireccion());
					n.setTelefono(estudiante.getTelefono());
					
					
					estudianteService.guardar(n);
					break;		
				}
				
			}

			
		   //este metodo actualizará al usuario enviado

		   return n;
		}
			


		/*Este método se hará cuando por una petición DELETE (como indica la anotación) se llame a la url + id del usuario
		http://127.0.0.1:8080/api/users/1  */
		@DeleteMapping("/Estudiante/{idestudiante}")
		public String deleteestudiante(@PathVariable int idestudiante) {

			Estudiante estudiante= estudianteService.findById(idestudiante);

		   if(estudiante == null) {
		       throw new RuntimeException("estudiante no id not found -"+idestudiante);
		   }

		   estudianteService.deleteById(idestudiante);

		   //Esto método, recibira el id de un usuario por URL y se borrará de la bd.
		   return "Deleted Estudiante id - "+idestudiante;
		}

			
		
	
	

}
