package com.examen.examen.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.examen.examen.dao.MateriaDao;
import com.examen.examen.dao.NotasDao;
import com.examen.examen.entity.Materia;
import com.examen.examen.entity.Notas;
@Service
public class MateriaServiceImpl implements MateriaService {

	
	@Autowired
	private MateriaDao materiaDao;
	
	@Override
	@Transactional(readOnly = true)
	public Materia findById(int id) {
		
		Materia materia=materiaDao.findById(id);
	
		return materia;
		
		
	}
	
	@Override
	@Transactional(readOnly = true)
    public List<Materia> findAll() {
        List<Materia> listUsers= materiaDao.findAll();
        return listUsers;
    }
	
	
	@Override
	@Transactional
	public void guardar(Materia materia) {
		materiaDao.guardar(materia);

    }
	
	
	@Override
	@Transactional
    public void deleteById(int id) {
		materiaDao.deleteById(id);
    }

	
	
	
	
	
	
	
	
	
	
	
}
