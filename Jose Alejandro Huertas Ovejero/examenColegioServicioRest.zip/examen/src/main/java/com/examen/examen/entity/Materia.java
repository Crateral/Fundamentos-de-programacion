package com.examen.examen.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_materias")
@NamedQuery(name = "Materia.findAll", query = "SELECT t FROM Materia t")
public class Materia implements Serializable {

	@Id
	@Column(name = "id_materia")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idmateria;
	private String nombre;

	

	public Materia() {
		super();
	}

	public int getIdmateria() {
		return idmateria;
	}

	public void setIdmateria(int idmateria) {
		this.idmateria = idmateria;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Override
	public String toString() {
		return "Materia [idmateria=" + idmateria + ", nombre=" + nombre + "]";
	}

}
