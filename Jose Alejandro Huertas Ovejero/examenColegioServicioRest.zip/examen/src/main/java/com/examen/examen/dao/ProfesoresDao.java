package com.examen.examen.dao;

import java.util.List;

import com.examen.examen.entity.Notas;
import com.examen.examen.entity.Profesores;

public interface ProfesoresDao {
	
	
public Profesores findById(int id);
	
	public List<Profesores> findAll();
	
	public void guardar(Profesores profesores);
	 
	public void deleteById(int idprofesor);

}
