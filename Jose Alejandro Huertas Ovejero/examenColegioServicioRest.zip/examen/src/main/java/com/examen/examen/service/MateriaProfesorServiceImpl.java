package com.examen.examen.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.examen.examen.dao.MateriaProfesorDao;

import com.examen.examen.entity.MateriaProfesor;

@Service
public class MateriaProfesorServiceImpl implements MateriaProfesorService {

	@Autowired
	private MateriaProfesorDao materiaProfesorDao;

	@Override
	@Transactional(readOnly = true)
	public MateriaProfesor findById(int id_materiaProfesor) {

		MateriaProfesor materiaProfesor = materiaProfesorDao.findById(id_materiaProfesor);

		return materiaProfesor;

	}

	@Override
	@Transactional(readOnly = true)
	public List<MateriaProfesor> findAll() {
		List<MateriaProfesor> list = materiaProfesorDao.findAll();
		return list;
	}

	@Override
	@Transactional
	public void guardar(MateriaProfesor materiaProfesor) {
		materiaProfesorDao.guardar(materiaProfesor);

	}

	@Override
	@Transactional
	public void deleteById(int id_materiaProfesor) {
		materiaProfesorDao.deleteById(id_materiaProfesor);
	}

}
