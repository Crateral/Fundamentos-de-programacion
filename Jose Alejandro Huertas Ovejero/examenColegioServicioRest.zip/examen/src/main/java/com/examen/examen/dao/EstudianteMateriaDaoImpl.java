package com.examen.examen.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.examen.examen.entity.EstudianteMateria;
import com.examen.examen.entity.Materia;
import com.examen.examen.entity.Notas;
@Repository
public class EstudianteMateriaDaoImpl implements EstudianteMateriaDao {

	

	@Autowired
	private EntityManager entityManager;
	
	
	@Override
	public EstudianteMateria findById(int idEstudianteMateria) {
		
		Session currentSession = entityManager.unwrap(Session.class);
		
		EstudianteMateria estudianteMateria = currentSession.get(EstudianteMateria.class, idEstudianteMateria);
		
		return estudianteMateria;
		
		
	}
	@Override
    public List<EstudianteMateria> findAll() {
        Session currentSession = entityManager.unwrap(Session.class);

        Query<EstudianteMateria> theQuery = currentSession.createQuery("from EstudianteMateria", EstudianteMateria.class);

        List<EstudianteMateria> estudianteMateria = theQuery.getResultList();

        return estudianteMateria;

    }
	@Override
	public void guardar(EstudianteMateria estudianteMateria){
        Session currentSession = entityManager.unwrap(Session.class);

        currentSession.saveOrUpdate(estudianteMateria);  

    }
	
	@Override
    public void deleteById(int idEstudianteMateria) {
        Session currentSession = entityManager.unwrap(Session.class);

        Query<EstudianteMateria> theQuery = currentSession.createQuery("delete from EstudianteMateria where idEstudianteMateria=:idEstudianteMateria");

        theQuery.setParameter("idEstudianteMateria", idEstudianteMateria);
        theQuery.executeUpdate();

    }
}
