package com.examen.examen.dao;

import java.util.List;

import com.examen.examen.entity.Notas;



public interface NotasDao {
	
public Notas findById(int id);
	
	public List<Notas> findAll();
	
	public void guardar(Notas notas);
	 
	public void deleteById(int id);

}
