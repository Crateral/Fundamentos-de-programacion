package com.examen.examen.service;

import java.util.List;

import com.examen.examen.entity.Notas;
import com.examen.examen.entity.Profesores;

public interface ProfesoreService {
	
public Profesores findById(int idprofesor);
	
	public List<Profesores> findAll();
	
	public void guardar(Profesores profesores);
	
	public void deleteById(int id);

}
