package com.examen.examen.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="tbl_profesores")
@NamedQuery(name="Profesores.findAll", query="SELECT t FROM Profesores t")
public class Profesores  implements Serializable{
	
	@Id
	@Column(name="id_profesore")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idprofesor;
	private String nombre;
	private int telefono;
	
	
	


	public Profesores() {
		super();
	}


	public int getIdprofesor() {
		return idprofesor;
	}


	public void setIdprofesor(int idprofesor) {
		this.idprofesor = idprofesor;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public int getTelefono() {
		return telefono;
	}


	public void setTelefono(int telefono) {
		this.telefono = telefono;
	}


	@Override
	public String toString() {
		return "Profesores [idprofesor=" + idprofesor + ", nombre=" + nombre + ", telefono=" + telefono + "]";
	}
	
	
	
	

}
