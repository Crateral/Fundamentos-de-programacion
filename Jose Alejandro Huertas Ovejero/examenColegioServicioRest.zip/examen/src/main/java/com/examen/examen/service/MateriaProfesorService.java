package com.examen.examen.service;

import java.util.List;


import com.examen.examen.entity.MateriaProfesor;

public interface MateriaProfesorService {
	
	
	
	public MateriaProfesor findById(int id_materiaProfesor);
	
	public List<MateriaProfesor> findAll();
	
	public void guardar(MateriaProfesor materiaProfesor);
	
	public void deleteById(int id_materiaProfesor);

}
