package com.examen.examen.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.examen.examen.entity.MateriaProfesor;

@Repository
public class MateriaProfesorDaoImpl implements MateriaProfesorDao {
	@Autowired
	private EntityManager entityManager;
	
	
	@Override
	public MateriaProfesor findById(int idMateriaProfesor) {
		
		Session currentSession = entityManager.unwrap(Session.class);
		
		MateriaProfesor Mp = currentSession.get(MateriaProfesor.class, idMateriaProfesor);
		
		return Mp;
		
		
	}
	@Override
    public List<MateriaProfesor> findAll() {
        Session currentSession = entityManager.unwrap(Session.class);

        Query<MateriaProfesor> theQuery = currentSession.createQuery("from MateriaProfesor", MateriaProfesor.class);

        List<MateriaProfesor> materiaProfesor = theQuery.getResultList();

        return materiaProfesor;

    }
	@Override
	public void guardar(MateriaProfesor materiaProfesor){
        Session currentSession = entityManager.unwrap(Session.class);

        currentSession.saveOrUpdate(materiaProfesor);  

    }
	
	@Override
    public void deleteById(int idMateriaProfesor) {
        Session currentSession = entityManager.unwrap(Session.class);

        Query<MateriaProfesor> theQuery = currentSession.createQuery("delete from MateriaProfesor where idMateriaProfesor=:idMateriaProfesor");

        theQuery.setParameter("idMateriaProfesor", idMateriaProfesor);
        theQuery.executeUpdate();

    }
	
	

}
