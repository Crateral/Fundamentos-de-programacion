package com.examen.examen.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="tbl_e__tbl_m")
//@NamedQuery(name="EstudianteMateria.findAll", query="SELECT t FROM EstudianteMateria t")
public class EstudianteMateria  {

	
	@Id
	@Column(name="id_tbl_estudiantes__tbl_materias")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idEstudianteMateria;
	
	@ManyToOne
	@JoinColumn(name = "tbl_estudiantes_id_estudiante")
	private  Estudiante estudiante;
	
	@ManyToOne
	@JoinColumn(name = "tbl_materias_id_materia")
	private Materia materia;
	

	public EstudianteMateria() {
		super();
	}


	public int getIdEstudianteMateria() {
		return idEstudianteMateria;
	}


	public void setIdEstudianteMateria(int idEstudianteMateria) {
		this.idEstudianteMateria = idEstudianteMateria;
	}


	public Estudiante getEstudiante() {
		return estudiante;
	}


	public void setEstudiante(Estudiante estudiante) {
		this.estudiante = estudiante;
	}


	public Materia getMateria() {
		return materia;
	}


	public void setMateria(Materia materia) {
		this.materia = materia;
	}


	@Override
	public String toString() {
		return "EstudianteMateria [idEstudianteMateria=" + idEstudianteMateria + ", estudiante=" + estudiante
				+ ", materia=" + materia + "]";
	}

	
	
	
	
	

}
