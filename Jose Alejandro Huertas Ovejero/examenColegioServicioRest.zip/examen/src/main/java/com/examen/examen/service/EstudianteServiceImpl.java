package com.examen.examen.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.examen.examen.dao.EstudianteDao;

import com.examen.examen.entity.Estudiante;


@Service
public class EstudianteServiceImpl implements EstudianteService {

	

	
	@Autowired
	private EstudianteDao estudianteDao;
	
	@Override
	@Transactional(readOnly = true)
	public Estudiante findById(int id) {
		
		Estudiante estudiante=estudianteDao.findById(id);
	
		return estudiante;
		
		
	}
	
	@Override
	@Transactional(readOnly = true)
    public List<Estudiante> findAll() {
        List<Estudiante> listUsers= estudianteDao.findAll();
        return listUsers;
    }
	
	
	@Override
	@Transactional
	public void guardar(Estudiante estudiante) {
		estudianteDao.guardar(estudiante);

    }
	
	
	@Override
	@Transactional
    public void deleteById(int id) {
		estudianteDao.deleteById(id);
    }

	
	
}
