package com.examen.examen.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "tbl_materiasprofesores")
public class MateriaProfesor   {
	//private static final Long SERIALVERCIONUID_LONG = 1L;
	
	
	@Id
	@Column(name = "id_materiaProfesor")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idMateriaProfesor;

	@ManyToOne
	@JoinColumn(name = "tbl_materias_id_materia")
	private Materia materia;

	@ManyToOne
	@JoinColumn(name = "tbl_profesores_id_profesore")
	private Profesores profesores;

	

	public MateriaProfesor() {
		super();
	}

	public int getIdMateriaProfesor() {
		return idMateriaProfesor;
	}

	public void setIdMateriaProfesor(int idMateriaProfesor) {
		this.idMateriaProfesor = idMateriaProfesor;
	}

	public Materia getMateria() {
		return materia;
	}

	public void setMateria(Materia materia) {
		this.materia = materia;
	}

	public Profesores getProfesores() {
		return profesores;
	}

	public void setProfesores(Profesores profesores) {
		this.profesores = profesores;
	}

	/*
	 * public static Long getSerialvercionuidLong() { return SERIALVERCIONUID_LONG;
	 * }
	 */

	@Override
	public String toString() {
		return "MateriaProfesor [idMateriaProfesor=" + idMateriaProfesor + ", materia=" + materia + ", profesores="
				+ profesores + "]";
	}

}
