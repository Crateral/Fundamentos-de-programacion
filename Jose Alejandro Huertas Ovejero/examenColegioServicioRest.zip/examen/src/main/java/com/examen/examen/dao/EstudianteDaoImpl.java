package com.examen.examen.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.examen.examen.entity.Estudiante;



@Repository
public class EstudianteDaoImpl implements EstudianteDao {


	@Autowired
	private EntityManager entityManager;
	
	
	@Override
	public Estudiante findById(int id) {
		
		Session currentSession = entityManager.unwrap(Session.class);
		
		Estudiante estudiante = currentSession.get(Estudiante.class, id);
		
		return estudiante;
		
		
	}
	@Override
    public List<Estudiante> findAll() {
        Session currentSession = entityManager.unwrap(Session.class);

        Query<Estudiante> theQuery = currentSession.createQuery("from Estudiante", Estudiante.class);

        List<Estudiante> estudiante = theQuery.getResultList();

        return estudiante;

    }
	@Override
	public void guardar(Estudiante estudiante){
        Session currentSession = entityManager.unwrap(Session.class);

        currentSession.saveOrUpdate(estudiante);  

    }
	
	@Override
    public void deleteById(int id_estudiante) {
        Session currentSession = entityManager.unwrap(Session.class);

        Query<Estudiante> theQuery = currentSession.createQuery("delete from Estudiante where id_estudiante =:id_estudiante");

        theQuery.setParameter("id_estudiante", id_estudiante);
        theQuery.executeUpdate();

    }
	
	
}
