package com.examen.examen.dao;

import java.util.List;

import com.examen.examen.entity.MateriaProfesor;
import com.examen.examen.entity.Notas;

public interface MateriaProfesorDao {
	
	
	
public MateriaProfesor findById(int id_materiaProfesor);
	
	public List<MateriaProfesor> findAll();
	
	public void guardar(MateriaProfesor materiaProfesor);
	 
	public void deleteById(int id_materiaProfesor);

}
