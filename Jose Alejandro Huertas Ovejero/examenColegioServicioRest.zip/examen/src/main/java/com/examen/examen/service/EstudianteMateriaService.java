package com.examen.examen.service;

import java.util.List;

import com.examen.examen.entity.Estudiante;
import com.examen.examen.entity.EstudianteMateria;

public interface EstudianteMateriaService {
	
public EstudianteMateria findById(int idEstudianteMateria);
	
	public List<EstudianteMateria> findAll();
	
	public void guardar(EstudianteMateria estudianteMateria);
	
	public void deleteById(int idEstudianteMateria);

}
