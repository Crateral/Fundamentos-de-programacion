package com.examen.examen.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examen.examen.entity.EstudianteMateria;
import com.examen.examen.entity.Materia;
import com.examen.examen.service.EstudianteMateriaService;
import com.examen.examen.service.MateriaService;

@RestController
//@CrossOrigin(origins = "http://localhost:3321")
@RequestMapping("/api")
public class EstudianteMateriaController {
	
	
	

	 //Inyectamos el servicio para poder hacer uso de el
	@Autowired	
	private EstudianteMateriaService estudianteMateriaService;

	/*Este método se hará cuando por una petición GET (como indica la anotación) se llame a la url + el id de un usuario
	http://127.0.0.1:8080/api/Marca/1*/
	@GetMapping("/EstudianteMateria/{idEstudianteMateria}")
	public EstudianteMateria getEstudianteMateria(@PathVariable int idEstudianteMateria) {
		EstudianteMateria EstudMater = estudianteMateriaService.findById(idEstudianteMateria);
		
		if(EstudMater == null)
			throw new RuntimeException("EstudianteMateria no encontrada"   +  idEstudianteMateria + "!");
		
		return EstudMater;
		
	}
	/*Este método se hará cuando por una petición GET (como indica la anotación) se llame a la url 
	http://127.0.0.1:8080/api/Marca*/

	@GetMapping("/EstudianteMateria")
	public List<EstudianteMateria> findAll(){
	   //retornará todos los usuarios
	   return estudianteMateriaService.findAll();
	}

	/*Este método se hará cuando por una petición POST (como indica la anotación) se llame a la url
	http://127.0.0.1:8080/api/Marca/  */
	@PostMapping("/EstudianteMateria")
	public EstudianteMateria addMateria(@RequestBody EstudianteMateria estudianteMateria) {
		estudianteMateria.setIdEstudianteMateria(0);
		
		

	   //Este metodo guardará al usuario enviado
		estudianteMateriaService.guardar(estudianteMateria);

	   return estudianteMateria;
	   

	}

	/*Este método se hará cuando por una petición PUT (como indica la anotación) se llame a la url
	http://127.0.0.1:8080/api/users/  */
	@PutMapping("/EstudianteMateria/{idEstudianteMateria}")
	public EstudianteMateria updateEstudianteMateria(@RequestBody EstudianteMateria estudianteMateria , @PathVariable int idEstudianteMateria ) {
		
		List<EstudianteMateria>lisEm=estudianteMateriaService.findAll();
		
		EstudianteMateria n=new EstudianteMateria();
		
		for (EstudianteMateria n3 : lisEm) {
			
			n=n3;
			if(n3.getIdEstudianteMateria()==idEstudianteMateria) {
				n.setEstudiante(estudianteMateria.getEstudiante());
				n.setMateria(estudianteMateria.getMateria());
				
				
				estudianteMateriaService.guardar(n);
				break;		
			}
			
		}

		
	   //este metodo actualizará al usuario enviado

	   return n;
	}
		


	/*Este método se hará cuando por una petición DELETE (como indica la anotación) se llame a la url + id del usuario
	http://127.0.0.1:8080/api/users/1  */
	@DeleteMapping("/EstudianteMateria/{idEstudianteMateria}")
	public String deteteEstudianteMateria(@PathVariable int idEstudianteMateria) {

		EstudianteMateria Em = estudianteMateriaService.findById(idEstudianteMateria);

	   if(Em == null) {
	       throw new RuntimeException("EstudianteMateria no id not found -"+idEstudianteMateria);
	   }

	   estudianteMateriaService.deleteById(idEstudianteMateria);

	   //Esto método, recibira el id de un usuario por URL y se borrará de la bd.
	   return "Deleted EstudianteMateria id - "+idEstudianteMateria;
	}

		
	
	
	
	
	

}
