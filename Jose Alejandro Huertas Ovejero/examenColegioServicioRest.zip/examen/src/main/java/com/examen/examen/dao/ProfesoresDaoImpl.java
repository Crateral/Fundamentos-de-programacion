package com.examen.examen.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.examen.examen.entity.Notas;
import com.examen.examen.entity.Profesores;

@Repository
public class ProfesoresDaoImpl implements ProfesoresDao {

	@Autowired
	private EntityManager entityManager;
	
	
	@Override
	public Profesores findById(int id) {
		
		Session currentSession = entityManager.unwrap(Session.class);
		
		Profesores profesores = currentSession.get(Profesores.class, id);
		
		return profesores;
		
		
	}
	@Override
    public List<Profesores> findAll() {
        Session currentSession = entityManager.unwrap(Session.class);

        Query<Profesores> theQuery = currentSession.createQuery("from Profesores", Profesores.class);

        List<Profesores> profesores = theQuery.getResultList();

        return profesores;

    }
	@Override
	public void guardar(Profesores Profesores){
        Session currentSession = entityManager.unwrap(Session.class);

        currentSession.saveOrUpdate(Profesores);  

    }
	
	@Override
    public void deleteById(int id_profesore) {
        Session currentSession = entityManager.unwrap(Session.class);

        Query<Profesores> theQuery = currentSession.createQuery("delete from Profesores where id_profesore=:id_profesore");

        theQuery.setParameter("id_profesore", id_profesore);
        theQuery.executeUpdate();

    }
	
	
	
}
