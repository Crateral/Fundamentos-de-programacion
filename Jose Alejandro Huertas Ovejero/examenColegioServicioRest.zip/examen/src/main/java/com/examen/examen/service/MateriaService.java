package com.examen.examen.service;

import java.util.List;

import com.examen.examen.entity.Materia;
import com.examen.examen.entity.Notas;

public interface MateriaService {
	
	
public Materia findById(int idNota);
	
	public List<Materia> findAll();
	
	public void guardar(Materia materia);
	
	public void deleteById(int id);

}
