package com.examen.examen.dao;

import java.util.List;

import com.examen.examen.entity.EstudianteMateria;


public interface EstudianteMateriaDao {
	
public EstudianteMateria findById(int id);
	
	public List<EstudianteMateria> findAll();
	
	public void guardar(EstudianteMateria estudianteMateria);
	 
	public void deleteById(int idEstudianteMateria);

}
