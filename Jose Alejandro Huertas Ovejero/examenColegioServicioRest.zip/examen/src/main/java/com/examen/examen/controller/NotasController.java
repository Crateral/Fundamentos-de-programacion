package com.examen.examen.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.examen.examen.entity.Notas;
import com.examen.examen.service.NotaService;

@RestController
//@CrossOrigin(origins = "http://localhost:3321")
@RequestMapping("/api")
public class NotasController {

	 //Inyectamos el servicio para poder hacer uso de el
@Autowired	
private NotaService notaService;

/*Este método se hará cuando por una petición GET (como indica la anotación) se llame a la url + el id de un usuario
http://127.0.0.1:8080/api/Marca/1*/
@GetMapping("/Notas/{idnotas}")
public Notas getNotas(@PathVariable int idnotas) {
	Notas notas = notaService.findById(idnotas);
	
	if(notas == null)
		throw new RuntimeException("nota no encontrada"   +  idnotas + "!");
	
	return notas;
	
}
/*Este método se hará cuando por una petición GET (como indica la anotación) se llame a la url 
http://127.0.0.1:8080/api/Marca*/

@GetMapping("/Notas")
public List<Notas> findAll(){
   //retornará todos los usuarios
   return notaService.findAll();
}

/*Este método se hará cuando por una petición POST (como indica la anotación) se llame a la url
http://127.0.0.1:8080/api/Marca/  */
@PostMapping("/Notas")
public Notas addNota(@RequestBody Notas notas) {
	notas.setIdnota(0);
	

   //Este metodo guardará al usuario enviado
	notaService.guardar(notas);

   return notas;
   

}

/*Este método se hará cuando por una petición PUT (como indica la anotación) se llame a la url
http://127.0.0.1:8080/api/users/  */
@PutMapping("/Notas/{idnotas}")
public Notas updateNota(@RequestBody Notas notas , @PathVariable int idnotas ) {
	
	List<Notas>lisnota=notaService.findAll();
	Notas n=new Notas();
	
	for (Notas n3 : lisnota) {
		
		n=n3;
		if(n3.getIdnota()==idnotas) {
			n.setNota(notas.getNota());
			n.setIdmateria(notas.getIdmateria());
			n.setIdestudiante(notas.getIdestudiante());
			notaService.guardar(n);
			break;		
		}
		
	}

	
   //este metodo actualizará al usuario enviado

   return n;
}
	


/*Este método se hará cuando por una petición DELETE (como indica la anotación) se llame a la url + id del usuario
http://127.0.0.1:8080/api/users/1  */
@DeleteMapping("/Notas/{idnotas}")
public String deteteNota(@PathVariable int idnotas) {

	Notas notas = notaService.findById(idnotas);

   if(notas == null) {
       throw new RuntimeException("Notas no id not found -"+idnotas);
   }

   notaService.deleteById(idnotas);

   //Esto método, recibira el id de un usuario por URL y se borrará de la bd.
   return "Deleted nota id - "+idnotas;
}

	
	
}
