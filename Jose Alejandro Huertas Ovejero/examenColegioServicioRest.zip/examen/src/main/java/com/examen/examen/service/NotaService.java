package com.examen.examen.service;

import java.util.List;


import com.examen.examen.entity.Notas;

public interface NotaService {

public Notas findById(int idNota);
	
	public List<Notas> findAll();
	
	public void guardar(Notas notas);
	
	public void deleteById(int id);
	
	
}
