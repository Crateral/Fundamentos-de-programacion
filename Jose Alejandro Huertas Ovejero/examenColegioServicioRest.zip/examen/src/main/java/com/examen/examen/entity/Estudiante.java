package com.examen.examen.entity;

import java.io.Serializable;

import javax.management.loading.PrivateClassLoader;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="tbl_estudiantes")
@NamedQuery(name="Estudiante.findAll", query="SELECT t FROM Estudiante t")
public class Estudiante implements Serializable {
	
	@Id
	@Column(name="id_estudiante")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int idestudiante;
	private String nombre;
	private String direccion;
	private int telefono;
	
	
	


	public Estudiante() {
		super();
	}


	public int getIdestudiante() {
		return idestudiante;
	}


	public void setIdestudiante(int idestudiante) {
		this.idestudiante = idestudiante;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getDireccion() {
		return direccion;
	}


	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}


	public int getTelefono() {
		return telefono;
	}


	public void setTelefono(int telefono) {
		this.telefono = telefono;
	}


	@Override
	public String toString() {
		return "Estudiante [idestudiante=" + idestudiante + ", nombre=" + nombre + ", direccion=" + direccion
				+ ", telefono=" + telefono + "]";
	}


	
	
	
	
}
