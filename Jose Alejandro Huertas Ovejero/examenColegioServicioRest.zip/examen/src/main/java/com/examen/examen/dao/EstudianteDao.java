package com.examen.examen.dao;

import java.util.List;

import com.examen.examen.entity.Estudiante;
import com.examen.examen.entity.Materia;

public interface EstudianteDao {
	
	
public Estudiante findById(int id);
	
	public List<Estudiante> findAll();
	
	public void guardar(Estudiante estudiante);
	 
	public void deleteById(int id);
	

}
