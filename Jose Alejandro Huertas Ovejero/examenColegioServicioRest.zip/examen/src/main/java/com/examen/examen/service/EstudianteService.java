package com.examen.examen.service;

import java.util.List;

import com.examen.examen.entity.Estudiante;
import com.examen.examen.entity.Materia;

public interface EstudianteService {
	
public Estudiante findById(int idNota);
	
	public List<Estudiante> findAll();
	
	public void guardar(Estudiante estudiante);
	
	public void deleteById(int id);

}
