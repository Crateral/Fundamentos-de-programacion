package com.examen.examen.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.examen.examen.entity.Notas;


@Repository
public class NotasDaoImpl implements NotasDao {
	
	@Autowired
	private EntityManager entityManager;
	
	
	@Override
	public Notas findById(int id) {
		
		Session currentSession = entityManager.unwrap(Session.class);
		
		Notas notas = currentSession.get(Notas.class, id);
		
		return notas;
		
		
	}
	@Override
    public List<Notas> findAll() {
        Session currentSession = entityManager.unwrap(Session.class);

        Query<Notas> theQuery = currentSession.createQuery("from Notas", Notas.class);

        List<Notas> notas = theQuery.getResultList();

        return notas;

    }
	@Override
	public void guardar(Notas notas){
        Session currentSession = entityManager.unwrap(Session.class);

        currentSession.saveOrUpdate(notas);  

    }
	
	@Override
    public void deleteById(int id_nota) {
        Session currentSession = entityManager.unwrap(Session.class);

        Query<Notas> theQuery = currentSession.createQuery("delete from Notas where id_nota=:id_nota");

        theQuery.setParameter("id_nota", id_nota);
        theQuery.executeUpdate();

    }
	

}
