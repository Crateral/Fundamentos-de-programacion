package com.examen.examen.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.examen.examen.entity.Materia;
import com.examen.examen.entity.Notas;
@Repository
public class MateriaDaoImpl  implements MateriaDao{
	
	
	@Autowired
	private EntityManager entityManager;
	
	
	@Override
	public Materia findById(int id) {
		
		Session currentSession = entityManager.unwrap(Session.class);
		
		Materia notas = currentSession.get(Materia.class, id);
		
		return notas;
		
		
	}
	@Override
    public List<Materia> findAll() {
        Session currentSession = entityManager.unwrap(Session.class);

        Query<Materia> theQuery = currentSession.createQuery("from Materia", Materia.class);

        List<Materia> materia = theQuery.getResultList();

        return materia;

    }
	@Override
	public void guardar(Materia materia){
        Session currentSession = entityManager.unwrap(Session.class);

        currentSession.saveOrUpdate(materia);  

    }
	
	@Override
    public void deleteById(int id_materia) {
        Session currentSession = entityManager.unwrap(Session.class);

        Query<Notas> theQuery = currentSession.createQuery("delete from Materia where id_materia=:id_materia");

        theQuery.setParameter("id_materia", id_materia);
        theQuery.executeUpdate();

    }
	

}
