package com.examen.examen.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.examen.examen.dao.ProfesoresDao;

import com.examen.examen.entity.Profesores;

@Service
public class ProfesoreServiceImpl implements ProfesoreService {
	
	@Autowired
	private ProfesoresDao profesoresDao;
	
	@Override
	@Transactional(readOnly = true)
	public Profesores findById(int id) {
		
		Profesores profesores=profesoresDao.findById(id);
	
		return profesores;
		
		
	}
	
	@Override
	@Transactional(readOnly = true)
    public List<Profesores> findAll() {
        List<Profesores> listUsers= profesoresDao.findAll();
        return listUsers;
    }
	
	
	@Override
	@Transactional
	public void guardar(Profesores profesores) {
		profesoresDao.guardar(profesores);

    }
	
	
	@Override
	@Transactional
    public void deleteById(int id) {
		profesoresDao.deleteById(id);
    }
	
	
	

}
