package com.examen.examen.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_notas")
@NamedQuery(name = "Notas.findAll", query = "SELECT t FROM Notas t")
public class Notas implements Serializable {

	@Id
	@Column(name = "id_nota")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int idnota;
	private double nota;
	@Column(name = "tbl_estudiantes_id_estudiante")
	private int idestudiante;
	@Column(name = "tbl_materias_id_materia")
	private int idmateria;

	

	public Notas() {
		super();
	}

	public int getIdnota() {
		return idnota;
	}

	public void setIdnota(int idnota) {
		this.idnota = idnota;
	}

	public double getNota() {
		return nota;
	}

	public void setNota(double nota) {
		this.nota = nota;
	}

	public int getIdestudiante() {
		return idestudiante;
	}

	public void setIdestudiante(int idestudiante) {
		this.idestudiante = idestudiante;
	}

	public int getIdmateria() {
		return idmateria;
	}

	public void setIdmateria(int idmateria) {
		this.idmateria = idmateria;
	}

	@Override
	public String toString() {
		return "Notas [idnota=" + idnota + ", nota=" + nota + ", idestudiante=" + idestudiante + ", idmateria="
				+ idmateria + "]";
	}

}
