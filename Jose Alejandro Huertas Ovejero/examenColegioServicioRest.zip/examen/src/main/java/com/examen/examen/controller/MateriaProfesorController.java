package com.examen.examen.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examen.examen.entity.MateriaProfesor;
import com.examen.examen.entity.Profesores;
import com.examen.examen.service.MateriaProfesorService;
import com.examen.examen.service.ProfesoreService;

@RestController
//@CrossOrigin(origins = "http://localhost:3321")
@RequestMapping("/api")
public class MateriaProfesorController {

	

	 //Inyectamos el servicio para poder hacer uso de el
		@Autowired	
		private MateriaProfesorService materiaProfesorService;

		/*Este método se hará cuando por una petición GET (como indica la anotación) se llame a la url + el id de un usuario
		http://127.0.0.1:8080/api/Marca/1*/
		@GetMapping("/MateriaProfesor/{idMateriaProfesor}")
		public MateriaProfesor getMateriaProfesor(@PathVariable int idMateriaProfesor) {
			MateriaProfesor mp = materiaProfesorService.findById(idMateriaProfesor);
			
			if(mp == null)
				throw new RuntimeException("MateriaProfesor no encontrada"   +  idMateriaProfesor + "!");
			
			return mp;
			
		}
		/*Este método se hará cuando por una petición GET (como indica la anotación) se llame a la url 
		http://127.0.0.1:8080/api/Marca*/

		@GetMapping("/MateriaProfesor")
		public List<MateriaProfesor> findAll(){
		   //retornará todos los usuarios
		   return materiaProfesorService.findAll();
		}

		/*Este método se hará cuando por una petición POST (como indica la anotación) se llame a la url
		http://127.0.0.1:8080/api/Marca/  */
		@PostMapping("/MateriaProfesor")
		public MateriaProfesor addMateriaProfesor(@RequestBody MateriaProfesor materiaProfesor) {
			materiaProfesor.setIdMateriaProfesor(0);
			
		   //Este metodo guardará al usuario enviado
			materiaProfesorService.guardar(materiaProfesor);

		   return materiaProfesor;
		   

		}

		/*Este método se hará cuando por una petición PUT (como indica la anotación) se llame a la url
		http://127.0.0.1:8080/api/users/  */
		@PutMapping("/MateriaProfesor/{idMateriaProfesor}")
		public MateriaProfesor updateMateriaProfesor(@RequestBody MateriaProfesor materiaProfesor , @PathVariable int idMateriaProfesor ) {
			
			List<MateriaProfesor>lisp=materiaProfesorService.findAll();
			MateriaProfesor n=new MateriaProfesor();
			
			for (MateriaProfesor n3 : lisp) {
				
				n=n3;
				if(n3.getIdMateriaProfesor()==idMateriaProfesor) {
					n.setMateria(materiaProfesor.getMateria());
					n.setProfesores(materiaProfesor.getProfesores());
					
					
					materiaProfesorService.guardar(n);
					break;		
				}
				
			}	
		   //este metodo actualizará al usuario enviado
		   return n;
		}
			


		/*Este método se hará cuando por una petición DELETE (como indica la anotación) se llame a la url + id del usuario
		http://127.0.0.1:8080/api/users/1  */
		@DeleteMapping("/MateriaProfesor/{idMateriaProfesor}")
		public String deteteMateriaProfesor(@PathVariable int idMateriaProfesor) {

			MateriaProfesor p = materiaProfesorService.findById(idMateriaProfesor);

		   if(p == null) {
		       throw new RuntimeException("MateriaProfesor no id not found -"+idMateriaProfesor);
		   }

		   materiaProfesorService.deleteById(idMateriaProfesor);

		   //Esto método, recibira el id de un usuario por URL y se borrará de la bd.
		   return "Deleted MateriaProfesor id - "+idMateriaProfesor;
		}

			
	
	
}
