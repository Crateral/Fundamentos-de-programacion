package com.examen.examen.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.examen.examen.dao.EstudianteDao;
import com.examen.examen.dao.EstudianteMateriaDao;
import com.examen.examen.entity.Estudiante;
import com.examen.examen.entity.EstudianteMateria;

@Service
public class EstudianteMateriaServiceImpl  implements EstudianteMateriaService{
	

	
	@Autowired
	private EstudianteMateriaDao estudianteMateriaDao;
	
	@Override
	@Transactional(readOnly = true)
	public EstudianteMateria findById(int idEstudianteMateria) {
		
		EstudianteMateria estudianteMateria=estudianteMateriaDao.findById(idEstudianteMateria);
	
		return estudianteMateria;
		
		
	}
	
	@Override
	@Transactional(readOnly = true)
    public List<EstudianteMateria> findAll() {
        List<EstudianteMateria> listUsers= estudianteMateriaDao.findAll();
        return listUsers;
    }
	
	
	@Override
	@Transactional
	public void guardar(EstudianteMateria estudianteMateria) {
		estudianteMateriaDao.guardar(estudianteMateria);

    }
	
	
	@Override
	@Transactional
    public void deleteById(int idEstudianteMateria) {
		estudianteMateriaDao.deleteById(idEstudianteMateria);
    }

	
	
	
	

}
