package entidades;

import java.util.List;

public class Alumno {

    private  int id ;
    private  String nombre;


    private List<nota>notas;
    private  double promedio;


    public Alumno() {
    }

    public Alumno(int id, String nombre, List<nota> notas, double promedio) {
        this.id = id;
        this.nombre = nombre;

        this.notas = notas;
        this.promedio=promedio;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }


    public List<nota> getNotas() {
        return notas;
    }

    public void setNotas(List<nota> notas) {
        this.notas = notas;
    }

    public double getPromedio() {
        return promedio;
    }

    public void setPromedio(double promedio) {
        this.promedio = promedio;
    }


    @Override
    public String toString() {
        return "alumno{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                '\'' +
                ", notas=" + notas +
                ", notafinal=" + promedio +
                '}';
    }
}
