package entidades;

public enum materia {

    INGLES, MATEMATICAS, FILOSOFIA

}
