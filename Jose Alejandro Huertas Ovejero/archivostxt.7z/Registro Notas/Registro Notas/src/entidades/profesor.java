package entidades;

import java.util.List;

public class profesor {

    private int id;
    private String nombre;

    private List<Alumno> alumno;
    private  materia materia;


    public profesor() {
    }

    public profesor(int id, String nombre, List<Alumno> alumno, entidades.materia materia) {
        this.id = id;
        this.nombre = nombre;

        this.alumno = alumno;
        this.materia = materia;

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }





    public List<Alumno> getAlumno() {
        return alumno;
    }

    public void setAlumno(List<Alumno> alumno) {
        this.alumno = alumno;
    }

    public entidades.materia getMateria() {
        return materia;
    }

    public void setMateria(entidades.materia materia) {
        this.materia = materia;
    }



    @Override
    public String toString() {
        return "profesor{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +

                ", alumno=" + alumno +
                ", materia=" + materia +
                '}';
    }
}
