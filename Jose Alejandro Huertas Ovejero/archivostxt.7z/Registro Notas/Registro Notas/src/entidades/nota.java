package entidades;

public class nota {

    private  double nota;
    private String observacion;

    public nota() {
    }

    public nota(double nota, String observacion) {
        this.nota = nota;
        this.observacion = observacion;
    }


    public double getNota() {
        return nota;
    }

    public void setNota(double nota) {
        this.nota = nota;
    }

    public String getObservacion() {
        return observacion;
    }

    public void setObservacion(String observacion) {
        this.observacion = observacion;
    }

    @Override
    public String toString() {
        return "nota{" +
                "nota=" + nota +
                ", observacion='" + observacion + '\'' +
                '}';
    }
}
