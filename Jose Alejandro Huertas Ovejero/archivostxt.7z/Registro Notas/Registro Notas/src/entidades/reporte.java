package entidades;

import java.util.List;

public class reporte {

private  int id;
private profesor profesor;

private  String observacionFinal;

    public reporte() {
    }

    public reporte(int id, entidades.profesor profesor, String observacionFinal) {
        this.id = id;
        this.profesor = profesor;
        this.observacionFinal = observacionFinal;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public entidades.profesor getProfesor() {
        return profesor;
    }

    public void setProfesor(entidades.profesor profesor) {
        this.profesor = profesor;
    }

    public String getObservacionFinal() {
        return observacionFinal;
    }

    public void setObservacionFinal(String observacionFinal) {
        this.observacionFinal = observacionFinal;
    }


    @Override
    public String toString() {
        return "reporte{" +
                "id=" + id +
                ", profesor=" + profesor +
                ", observacionFinal='" + observacionFinal + '\'' +
                '}';
    }
}
