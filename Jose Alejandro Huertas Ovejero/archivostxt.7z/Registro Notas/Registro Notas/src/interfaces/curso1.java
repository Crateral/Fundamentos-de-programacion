package interfaces;

import entidades.Alumno;
import entidades.nota;

import java.util.List;

public interface curso1 {










}
