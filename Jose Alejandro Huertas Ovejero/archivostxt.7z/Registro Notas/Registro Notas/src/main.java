

import entidades.Alumno;
import entidades.nota;
import entidades.profesor;
import entidades.reporte;
import logica.AlumnoFilosofiaImpl;
import logica.AlumnoInglesImpl;
import logica.AlumnoMatematicasImpl;

import java.util.Scanner;

public class main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Alumno a = new Alumno();
        nota n = new nota();
        profesor p = new profesor();
        reporte r = new reporte();
        AlumnoMatematicasImpl al = new AlumnoMatematicasImpl();
        AlumnoInglesImpl in = new AlumnoInglesImpl();
        AlumnoFilosofiaImpl filo = new AlumnoFilosofiaImpl();
       // al.alumnos("matematicas.txt");


        int opcion = 0;

        do {
            System.out.println("\n*********************");
            System.out.println("1.materia de matematicas");
            System.out.println("2.materia de ingles");
            System.out.println("3.materia de filosofia");
            System.out.println("************************");
            System.out.println("4.reporte de matematicas");
            System.out.println("5.reporte de ingles ");
            System.out.println("6. reporte de  filosofia");
            System.out.println("7.salir");

            opcion = sc.nextInt();

            switch (opcion) {

                case 1:
                    al.leerArchivos("matematicas.txt");

                    break;
                case 2:

                    in.leerArchivos("ingles.txt");
                    break;


                case 3:
                    filo.leerArchivos("filosofia.txt");

                    break;

                case 4:

                    al.reportealumnos();
                    break;
                case 5:
                    in.reportealumnos();

                    break;
                    case 6:

                    filo.reportealumnos();
                    break;

                case 7:


                    System.out.println("  -- VUELVA PRONTO --    ");

                    System.exit(0);

                    break;
                default:
                    System.out.println(" ================ ");
                    System.out.println(" Opcion no valida ");


            }


        }
        while (opcion != 9);


    }
//MODIFICAR EN CONSTRUCION //

}
