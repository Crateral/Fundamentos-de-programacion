package logica;

import entidades.*;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class AlumnoMatematicasImpl {
    Scanner sc=new Scanner(System.in);
    reporte r = new reporte();


    public void leerArchivos(String archivos) {

        File archivo = new File("C:\\Users\\jhuertov\\OneDrive - NTT DATA EMEAL\\Documentos\\archivostxt\\" + archivos);
        Scanner s = null;

        try {
            s = new Scanner(archivo);
            while (s.hasNextLine()) {
                String linea = s.nextLine();
                System.out.println(linea);
            }

        } catch (Exception e) {
            System.out.println("Error al leer el archivo" + e.getMessage());
        } finally {
            try {
                if (s != null) {
                    s.close();
                }

            } catch (Exception e) {
                System.out.println("Error al cerrar el archivo" + e.getMessage());
            }
        }


    }


    public List<nota> reportealumnos() {
        File archivo = new File("C:\\Users\\jhuertov\\OneDrive - NTT DATA EMEAL\\Documentos\\archivostxt\\matematicas.txt");

        Scanner imput = null;
        profesor p = new profesor();
        Alumno a = new Alumno();
        nota nota = new nota();
        nota nota1 = new nota();
        nota nota2 = new nota();
        List<nota> lisnotas = new ArrayList<>();
        List<Alumno> listalumnos = new ArrayList<>();
        List<profesor> listaProfesro = new ArrayList<>();
        try {
            imput = new Scanner(archivo);
            while (imput.hasNextLine()) {
                String linea = imput.nextLine();
                String[] parts = linea.split(",");
                p.setId(Integer.parseInt(parts[0]));
                p.setNombre(parts[1]);
                a.setId(Integer.parseInt(parts[2]));
                a.setNombre(parts[3]);
                nota.setNota(Double.parseDouble(parts[4]));
                nota.setObservacion(parts[5]);
                nota1.setNota(Double.parseDouble(parts[6]));
                nota1.setObservacion(parts[7]);
                nota2.setNota(Double.parseDouble(parts[8]));
                nota2.setObservacion(parts[9]);
                p.setMateria(materia.valueOf(parts[10]));


                lisnotas.add(nota);
                lisnotas.add(nota1);
                lisnotas.add(nota2);

                a.setNotas(lisnotas);
                listalumnos.add(a);
                //profesro
                listaProfesro.add(p);

                double promedio = 0;
                promedio = (nota.getNota() + nota1.getNota() + nota2.getNota()) / 3;
                a.setPromedio(promedio);
                if (promedio > 30) {

                    r.setObservacionFinal("aprobado");
                } else {

                    r.setObservacionFinal("no aprobo");
                }

                System.out.println(p.getId() + " " + p.getNombre() + " " + a.getId() + " " + a.getNombre() + "  " + nota.getNota() + "  "
                        + "nota 1; "+ nota.getObservacion() + "  "+ "nota 2; " + nota1.getNota() + " " + nota1.getObservacion() + "  " +"nota 3 ; " + nota2.getNota() +
                        "  " + nota2.getObservacion() + "  " + " observacion final " + r.getObservacionFinal() + "  " +" la materia;  " + p.getMateria());
            }

/*            System.out.println("desea cambiar una nota 1.si-2.no");
            int uno=sc.nextInt();
            //int num=sc.nextInt();
            if (uno==1) {
                for (int i = 0; i < lisnotas.size(); i++) {

                }

                uno = sc.nextInt();




                    System.out.println("nota que quiere cambiar");
                    System.out.println("nota 1");
                    System.out.println("nota 2");
                    System.out.println("nota 3");
                    uno = sc.nextInt();

                    if (uno == 1) {
                        System.out.println("ingrese nueva nota");
                        int no = sc.nextInt();
                        nota.setNota(no);
                    } else if (uno == 2) {
                        System.out.println("ingrese la nueva nota");
                        int nos = sc.nextInt();
                        nota1.setNota(nos);
                    } else if (uno == 3) {
                        System.out.println("ingrese la nueva nota");
                        int not = sc.nextInt();
                        nota2.setNota(not);
                    }

                }*/



        } catch (Exception e) {
            e.getMessage();

        }


        return lisnotas;
    }


}



