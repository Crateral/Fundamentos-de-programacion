package logica;

import entidades.*;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class AlumnoFilosofiaImpl {

    reporte r = new reporte();

        Scanner sc=new Scanner(System.in);
    public  void leerArchivos(String archivos) {

        File archivo = new File("C:\\Users\\jhuertov\\OneDrive - NTT DATA EMEAL\\Documentos\\archivostxt\\"+archivos);
        Scanner s =null;

        try {
            s = new Scanner(archivo);
            while(s.hasNextLine()) {
                String linea = s.nextLine();
                System.out.println(linea);
            }

        }catch(Exception e) {
            System.out.println("Error al leer el archivo" + e.getMessage());
        }finally {
            try {
                if(s !=null ) {
                    s.close();
                }

            }catch(Exception e) {
                System.out.println("Error al cerrar el archivo" + e.getMessage());
            }
        }


    }


    public List<nota> reportealumnos() {
        File archivo = new File("C:\\Users\\jhuertov\\OneDrive - NTT DATA EMEAL\\Documentos\\archivostxt\\filosofia.txt");

        Scanner imput = null;
        profesor p = new profesor();
        Alumno a = new Alumno();
        nota nota = new nota();
        nota nota1 = new nota();
        nota nota2 = new nota();
        List<nota> lisnotas = new ArrayList<>();
        List<Alumno> listalumnos = new ArrayList<>();
        List<profesor> listaProfesro = new ArrayList<>();





        try {
            imput = new Scanner(archivo);
            while (imput.hasNextLine()) {
                String linea = imput.nextLine();
                String[] parts = linea.split(",");
                p.setId(Integer.parseInt(parts[0]));
                p.setNombre(parts[1]);
                a.setId(Integer.parseInt(parts[2]));
                a.setNombre(parts[3]);
                nota.setNota(Double.parseDouble(parts[4]));
                nota.setObservacion(parts[5]);
                nota1.setNota(Double.parseDouble(parts[6]));
                nota1.setObservacion(parts[7]);
                nota2.setNota(Double.parseDouble(parts[8]));
                nota2.setObservacion(parts[9]);
                p.setMateria(materia.valueOf(parts[10]));


                lisnotas.add(nota);
                lisnotas.add(nota1);
                lisnotas.add(nota2);

                a.setNotas(lisnotas);
                listalumnos.add(a);
                //profesro
                listaProfesro.add(p);

                double promedio = 0;
                promedio = (nota.getNota() + nota1.getNota() + nota2.getNota()) / 3;
                a.setPromedio(promedio);
                if (promedio > 30) {

                    r.setObservacionFinal("aprobado");
                } else {

                    r.setObservacionFinal("no aprobo");
                }

                System.out.println(p.getId() + " " + p.getNombre() + " " + a.getId() + " " + a.getNombre() + "  " + nota.getNota() + "  "
                       + "nota 1; "+ nota.getObservacion() + "  "+ "nota 2; " + nota1.getNota() + " " + nota1.getObservacion() + "  " +"nota 3 ; " + nota2.getNota() +
                        "  " + nota2.getObservacion() + "  " + " observacion final " + r.getObservacionFinal() + "  " +" la materia  " + p.getMateria());
            }



        } catch (Exception e) {
            e.getMessage();

        }





        return lisnotas;


    }



    public void filosofiaguardartxt(List<profesor>profesor){

        reporte r=new reporte();
        Alumno a=new Alumno();
       r.setProfesor(profesor.get(1));
      // r.setObservacionFinal();
        try {
            FileWriter archivo = new FileWriter("C:\\\\Users\\\\jhuertov\\\\OneDrive - NTT DATA EMEAL\\\\Documentos\\\\archivostxt\\\\filosofia.txt");

            archivo.write(
                    "    -------REPORTE------" + "\n" +
                            "ALUMNO;        "+ r.getProfesor()+"\n"+
                            "observacion    "+ r.getObservacionFinal()+"\n");


            for (int i = 0; i <= 0; i++) {
                archivo.write(i + "\n");
            }
            System.out.println("El archivo se ha escrito con exito");
            archivo.close();
        }
        catch(Exception e) {
            System.out.println("Error al escribir el archivo: " + e.getMessage());
        }


    }



    }




