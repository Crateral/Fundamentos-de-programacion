public class MayoraMenor {



        public static void main(String[] args) {
            int[] uno = new int[]{7, 4, 2, 1,10, 5, 6};
            int dos;
//mayor a mayor  a menor  sin libreria
            for (int i = 0; i <uno.length -1 ; i++) {
                for (int j = i +1; j <uno.length ; j++) {
                    if (uno[i]<uno[j]){
                        dos=uno[i];
                        uno[i]=uno[j];
                        uno[j]=dos;

                    }

                }

            }


            for (int j = 0; j <uno.length ; j++) {
                System.out.print("   "+uno[j]);

            }

        }




    }






