public class triqui {

    public static void main(String args[]){

        String [][]arrayTabla = new String[3][3];


        for(int renglon = 0; renglon < 3; renglon++){

            for(int columna = 0; columna < 3; columna++){

                arrayTabla[renglon][columna] = "<> ";

            }

        }

        for(int renglon = 0; renglon < 3; renglon++){

            for(int columna = 0; columna < 3; columna++){

                System.out.print(arrayTabla[renglon][columna]);

            }

            System.out.println();

        }

    }

}






