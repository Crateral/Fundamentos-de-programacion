
    public class eliminarDuplicados {


        public static void main(String[] args) {

            int[] A = {2, 4, 6, 6, 19, 3, 1, 0, 5, 2, 9};
            int[] B = new int[A.length];
            int j,contador = 0;

            boolean repetido;
            for (int i = 0; i < A.length; i++) {
                repetido = false;
                j = 0;

                while (!repetido && (j < contador)) {

                    if (A[i] == B[j]) {
                        repetido = true;
                    }
                    j ++;
                }
                if (!repetido) {
                    B[contador] = A[i];
                    contador++;
                }
            }
            System.out.println("arreglo"+ " ");
            for (int i = 0; i < A.length; i++) {
                System.out.print(A[i] + " ");
            }
            System.out.println("  "+ " ");
            System.out.println("arreglo sin repetidos ");
            for (int i = 0; i < contador ; i++) {
                System.out.print(B[i] + " ");
            }

            //código ordenamiento
            int aux;



            for (int i = 0; i <B.length -1 ; i++) {
                for (int Y = i +1 ; Y <B.length ; Y++) {
                    if (B[i]>B[Y]){
                        aux=B[i];
                        B[i]=B[Y];
                        B[Y]=aux;

                    }

                }

            }
            System.out.println(" ");
            System.out.println(" Ordenados menor a mayor");
            for (int Y =+3; Y <B.length ; Y++) {
                System.out.print("  "+B[Y]);

            }

            //mayor a menor


            for (int i = 0; i <B.length -1 ; i++) {
                for (int Y = i +1 ; Y <B.length ; Y++) {
                    if (B[i]<B[Y]){
                        aux=B[i];
                        B[i]=B[Y];
                        B[Y]=aux;

                    }

                }

            }
            System.out.println(" ");
            System.out.println(" Ordenados menor a mayor");
            for (int Y =0; Y <B.length ; Y++) {
                System.out.print("  "+B[Y]);

            }




        }
// se realizo con otro compañero este parte.
    }
