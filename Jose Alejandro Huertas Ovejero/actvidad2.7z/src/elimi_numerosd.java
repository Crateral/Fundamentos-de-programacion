import java.util.Arrays;

public class elimi_numerosd {

    public static int elimina(int d[], int n){
        if (n==0 || n==1){
            return n;
        }
        int[] a = new int[n];
        int j = 0;

        for (int i=0; i<n-1; i++){
            if (d[i] != d[i+1]){
                a[j++] = d[i];
            }
        }

        a[j++] = d[n-1];



        for (int i=0; i<j; i++){
            d[i] = a[i];
        }
        return j;
    }

    public static void main (String[] args) {

        int d[] = {2,4,6,6,19,3,1,0,5,2,9};
        Arrays.sort(d);
        System.out.println("De menor a Mayor");
        int length = d.length;
        length = elimina(d, length);
        for (int i=0; i<length; i++)
            System.out.println(d[i]+" ");


        int numeros2[] = {2,4,6,19,3,1,0,5,9};
        Arrays.sort(numeros2);
        System.out.println("Mayor a Menor");

        for (int i = numeros2.length-1; 1 >= 0; i--){
            System.out.println(" " + numeros2[i]+" ");
        }

    }




}
