package com.co.nttdata.ecommerce.entidades;

public enum Marca {
	
	LG(1, "Marca LG de TVs"),
	MOTOROLA(2,"Marca de celulares"),
	SAMSUNG(3,"Marca de lavadora"),
	WHIRLPOOL(4,"Marca de neveras"),
	NIKON(5," rango dinámico excepcional y calidad de imagen extraordinaria.");
	private int id;
	private String descripcion;
	
	private Marca(int id, String descripcion) {
		this.id = id;
		this.descripcion = descripcion;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}	
	
}
