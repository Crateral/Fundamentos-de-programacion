package com.co.nttdata.ecommerce.entidades;

public class Empresa {

private String nombre;
private String direcion;


    public Empresa() {
    }

    public Empresa(String nombre, String direcion) {
        this.nombre = nombre;
        this.direcion = direcion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDirecion() {
        return direcion;
    }

    public void setDirecion(String direcion) {
        this.direcion = direcion;
    }

    //colocar su estrutura
}
