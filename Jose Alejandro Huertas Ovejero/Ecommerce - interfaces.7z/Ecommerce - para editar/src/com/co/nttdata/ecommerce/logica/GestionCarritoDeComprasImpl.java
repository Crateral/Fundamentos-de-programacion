package com.co.nttdata.ecommerce.logica;

import java.util.List;

import com.co.nttdata.ecommerce.entidades.CarritoDeCompras;
import com.co.nttdata.ecommerce.entidades.Producto;
import com.co.nttdata.ecommerce.interfaces.GestionCarritoDeCompras;

public class GestionCarritoDeComprasImpl implements GestionCarritoDeCompras {
	@Override
	public CarritoDeCompras anadirAlCarrito(CarritoDeCompras cdc, List<Producto> p) {
		
		cdc.setProductos(p);
		return cdc;
		
	}
	@Override
	public CarritoDeCompras agregarAlCarrito(CarritoDeCompras cdc, List<Producto> p) {


		System.out.println("");
		System.out.println(" - Productos agregados : ");
		cdc.getProductos().forEach((pe) -> System.out.println(pe.toString()));
		System.out.println();
		cdc.setProductos(p);
		return cdc;
	}

	@Override
	public CarritoDeCompras calcularTotalConIva(CarritoDeCompras cdc) {

		double total = 0.0, subtotal = 0.0, totalproducto = 0.0, subtotalUnidad = 0.0;

		for (int i = 0; i < cdc.getProductos().size(); i++) {
			//1100           2000
			subtotal=subtotal + cdc.getProductos().get(i).getPrecio()* cdc.getProductos().get(i).getIva();
			subtotalUnidad= cdc.getProductos().get(i).getPrecio() * cdc.getProductos().get(i).getIva();
			totalproducto= totalproducto + cdc.getProductos().get(i).getPrecio();
			total = total + cdc.getProductos().get(i).getPrecio() +
					(cdc.getProductos().get(i).getPrecio() *
							cdc.getProductos().get(i).getIva());

			System.out.println("los producto son:"+ cdc.getProductos().get(i).getNombre()+"  "  + "valor producto ->: "
								+ cdc.getProductos().get(i).getPrecio() + "  "+ " el es iva ->  " + subtotalUnidad);










		}
		cdc.setSubTotaSinIva(totalproducto);
		cdc.setSubTotalConIva(subtotal);
		cdc.setSubTotal(total);

		return cdc;
	
	}
	@Override
	public CarritoDeCompras calcularCostoEnvio(CarritoDeCompras cdc, String direccion) {
		//Para el calculo del envio se debe tener en cuenta la ubicacion del cliente
		//Si se encuentra en ciudades principales se debe cobrar el 5%
		//Si se encuentra en ciudades no principales se debe cobrar el 10%
		double total = 0;
		double totalEnvio = 0;

		for (int i = 0; i < cdc.getProductos().size(); i++) {

			total = total + cdc.getProductos().get(i).getPrecio() +
					(cdc.getProductos().get(i).getPrecio() *
							(cdc.getProductos().get(i).getIva()/100));
		}

		if(direccion == "1") {
			System.out.println(" 5% del envio Total, porque es Ciudad Principal" );
			totalEnvio= (total * 5)/100;
		}else if(direccion =="2") {

			System.out.println(" 10 % envio total, porque es Ciudad No  Principal");
			totalEnvio= (total * 10)/100;
		}


		System.out.println("El valor del envio es: "+ totalEnvio);
		cdc.setValorEnvio(totalEnvio);
		return cdc;



	}






	}


