package com.co.nttdata.ecommerce.logica;

import com.co.nttdata.ecommerce.entidades.CarritoDeCompras;
import com.co.nttdata.ecommerce.entidades.Cliente;
import com.co.nttdata.ecommerce.entidades.Empresa;
import com.co.nttdata.ecommerce.entidades.Factura;
import com.co.nttdata.ecommerce.interfaces.GestionFactura;

public class GestionFacturaImpl implements GestionFactura {
		Factura f=new Factura();
		Empresa em=new Empresa();

		@Override
	public Factura pagar(Empresa empresa,Cliente cliente, CarritoDeCompras cdc) {
		em.setNombre("cadena de supermecados xx");
		em.setDirecion("calle 9 # 6 - 90 N ");
		f.setCliente(cliente);
		f.setDescripcion(" factura ");
		f.setIdFactura(1);
		f.setProductos(cdc);
		f.setValorTotalConIva(cdc.getSubTotalConIva() + cdc.getValorEnvio());
		f.setValorDeEnvio(cdc.getValorEnvio());

		return f;
	}
@Override
	public void imprimirfactura() {
		System.out.println("\nNombre de la empresa: "+ em.getNombre()+"\n" +"Direccion;: "+ em.getDirecion() +"\n"+ f.getCliente() + f.getDescripcion() +" "+ f.getIdFactura() +" "+
				f.getProductos().getProductos() +"\nvalor total con iva "+ f.getValorTotalConIva() +"\nvalor total envio; "+ f.getValorDeEnvio()+
				"\nvalor total; "+ (f.getValorDeEnvio()+ f.getValorTotalConIva()));


	}




}
