package com.co.nttdata.ecommerce.entidades;

import java.io.Serializable;

public class Cliente extends Usuario implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private int id_cliente;
	private int id_ciudad;
	private int id_forma_de_pago;
	private String usuario;
	private String contrasenia;
	private String correo;
	private String telefono;
	private String direccion;
	private boolean estado;
	private int num_Identificaicon;
	
	public Cliente() {
		super();
	}
	public Cliente(int id_cliente, int id_ciudad, int id_forma_de_pago, String usuario, String contrasenia,
			String correo, String telefono, String direccion, boolean estado, int num_Identificaicon) {
		super();
		this.id_cliente = id_cliente;
		this.id_ciudad = id_ciudad;
		this.id_forma_de_pago = id_forma_de_pago;
		this.usuario = usuario;
		this.contrasenia = contrasenia;
		this.correo = correo;
		this.telefono = telefono;
		this.direccion = direccion;
		this.estado = estado;
		this.num_Identificaicon = num_Identificaicon;
	}
	public int getId_cliente() {
		return id_cliente;
	}
	public void setId_cliente(int id_cliente) {
		this.id_cliente = id_cliente;
	}
	public int getId_ciudad() {
		return id_ciudad;
	}
	public void setId_ciudad(int id_ciudad) {
		this.id_ciudad = id_ciudad;
	}
	public int getId_forma_de_pago() {
		return id_forma_de_pago;
	}
	public void setId_forma_de_pago(int id_forma_de_pago) {
		this.id_forma_de_pago = id_forma_de_pago;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public String getContrasenia() {
		return contrasenia;
	}
	public void setContrasenia(String contrasenia) {
		this.contrasenia = contrasenia;
	}
	public String getCorreo() {
		return correo;
	}
	public void setCorreo(String correo) {
		this.correo = correo;
	}
	public String getTelefono() {
		return telefono;
	}
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public boolean isEstado() {
		return estado;
	}
	public void setEstado(boolean estado) {
		this.estado = estado;
	}
	public int getNum_Identificaicon() {
		return num_Identificaicon;
	}
	public void setNum_Identificaicon(int num_Identificaicon) {
		this.num_Identificaicon = num_Identificaicon;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "Cliente [id_cliente=" + id_cliente + ", id_ciudad=" + id_ciudad + ", id_forma_de_pago="
				+ id_forma_de_pago + ", usuario=" + usuario + ", contrasenia=" + contrasenia + ", correo=" + correo
				+ ", telefono=" + telefono + ", direccion=" + direccion + ", estado=" + estado + ", num_Identificaicon="
				+ num_Identificaicon + "]";
	}
	
	
	
}
