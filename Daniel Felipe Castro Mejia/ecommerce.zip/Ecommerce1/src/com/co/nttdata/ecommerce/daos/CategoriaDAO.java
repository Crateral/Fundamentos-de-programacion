package com.co.nttdata.ecommerce.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.co.nttdata.ecommerce.entidades.Categoria;
import com.co.nttdata.ecommerce.entidades.Marca;
import com.co.nttdata.ecommerce.utils.Conection;

public class CategoriaDAO {
	

	Conection con = new Conection();
    Scanner teclado = new Scanner(System.in);
    
    public List<Categoria> buscarCategoria(){
        
        Connection baseDatos = con.conectarBD();
        PreparedStatement st = null;
        ResultSet rs = null;
        
        List<Categoria> categoria = new ArrayList<Categoria>();
        
        try {
            
            st = baseDatos.prepareStatement("SELECT * FROM \"TBL_CATEGORIA\" ORDER BY id_categoria ASC");
            rs = st.executeQuery();
            
            while (rs.next()) {
                
            	Categoria cate = new Categoria();
            	
                cate.setIdCategoria(rs.getInt("id_categoria"));
                cate.setCategoria(rs.getString("categoria"));
                cate.setDescripcion(rs.getString("descriocion"));
                cate.setIva(rs.getDouble("iva"));
                
                categoria.add(cate);
            }
            
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                rs.close();
                st.close();
                con.desconectarBD(baseDatos);
            } catch (Exception e2) {
                System.err.println(e2.getMessage());
            }
        }
                
        
        return categoria;
    }
    public Categoria buscarCategoria(int cate) {
    	Categoria ct = new Categoria();
        
        Connection baseDatos = con.conectarBD();
        PreparedStatement st = null;
        ResultSet rs = null;
        
        try {
            st = baseDatos.prepareStatement("SELECT * FROM \"TBL_CATEGORIA\" WHERE id_categoria = ? ");
            st.setInt(1, cate);
            //st.setString(1, marca);
            rs = st.executeQuery();
            
            while (rs.next()) {
            	
            	ct.setIdCategoria(rs.getInt("id_categoria"));
                ct.setCategoria(rs.getString("categoria"));
                ct.setDescripcion(rs.getString("descriocion"));
                ct.setIva(rs.getDouble("iva"));
            }
            
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                rs.close();
                st.close();
                con.desconectarBD(baseDatos);
            } catch (Exception e2) {
                System.err.println(e2.getMessage());
            }
        }
        return ct;        
    }

    public void agregCategoria(Categoria ct ) {
        
        Connection baseDatos = con.conectarBD();
        PreparedStatement st = null;
        
        try {
            st = baseDatos.prepareStatement("INSERT INTO \"TBL_CATEGORIA\" (categoria, descripcion) VALUES (?, ?)");
            st.setString(1, ct.getCategoria());
            st.setString(2, ct.getDescripcion());
            int val = st.executeUpdate();
            
            if (val > 0)
                System.out.println("\nRegistro guardado con éxito...");
            else
                System.err.println("\nError al guardar el registro... !");
            
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                st.close();
                con.desconectarBD(baseDatos);
            } catch (Exception e2) {
                System.err.println(e2.getMessage());
            }
        }        
    }
    
    public Categoria elimCategoria(int categoria) {
    	Categoria ct  = new Categoria();
        
        Connection baseDatos = con.conectarBD();
        PreparedStatement st = null;
                
        System.out.print("\nDesea eliminar la Categoria (s/n) ? : ");
        String rg = teclado.next();
        if (rg.equals("s")) {
            try {
                st = baseDatos.prepareStatement("DELETE FROM \"TBL_CATEGORIA\" WHERE id_categoria = ? ");
                st.setInt(1, categoria);
                int val = st.executeUpdate();
                
                if (val > 0)
                    System.out.println("\nRegistro eliminado con éxito...");
                else
                    System.err.println("\nError al eliminar el registro... !");
                
            } catch (Exception e) {
                System.err.println(e.getMessage());
            } finally {
                try {
                    st.close();
                    con.desconectarBD(baseDatos);
                } catch (Exception e2) {
                    System.err.println(e2.getMessage());
                }
            }
                
        } else if (rg.equals("n")) {
            System.out.println("\nSeleccionó no eliminar Categoria... !");
        }
        return ct;    
    }
    
    public void modMarca(int idmarca, String marca, String descripcion) {
        
        Connection baseDatos = con.conectarBD();
        PreparedStatement st = null;
                
        try {
            st = baseDatos.prepareStatement("UPDATE \"TBL_MARCAS\" SET marca = ?, descripcion = ? WHERE id_marca = ?");
            st.setInt(3, idmarca);
            st.setString(1, marca);
            st.setString(2, descripcion);
            int val = st.executeUpdate();



           if (val > 0)
                System.out.println("\nRegistro modificado con éxito...");
            else
                System.err.println("\nError al modificar el registro... !");



       } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                st.close();
                con.desconectarBD(baseDatos);
            } catch (Exception e2) {
                System.err.println(e2.getMessage());
            }
        }
    }
}
