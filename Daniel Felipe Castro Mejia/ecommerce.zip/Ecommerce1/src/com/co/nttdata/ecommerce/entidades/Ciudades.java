package com.co.nttdata.ecommerce.entidades;

import java.io.Serializable;

public class Ciudades implements Serializable{
    
	private static final long serialVersionUID = 1L;
	private int id_ciudades;
    private String ciudades;
    private boolean principal;
    
	public Ciudades() {
		super();
	}

	public Ciudades(int id_ciudades, String ciudades, boolean principal) {
		super();
		this.id_ciudades = id_ciudades;
		this.ciudades = ciudades;
		this.principal = principal;
	}

	public int getId_ciudades() {
		return id_ciudades;
	}

	public void setId_ciudades(int id_ciudades) {
		this.id_ciudades = id_ciudades;
	}

	public String getCiudades() {
		return ciudades;
	}

	public void setCiudades(String ciudades) {
		this.ciudades = ciudades;
	}

	public boolean isPrincipal() {
		return principal;
	}

	public void setPrincipal(boolean principal) {
		this.principal = principal;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "Ciudades [id_ciudades=" + id_ciudades + ", ciudades=" + ciudades + ", principal=" + principal + "]";
	}
	
}