package com.co.nttdata.ecommerce.daos;

/*import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.co.nttdata.ecommerce.entidades.Auditoria;
import com.co.nttdata.ecommerce.entidades.Marca;
import com.co.nttdata.ecommerce.utils.Conection;

public class AuditoriaDAO {
	

	 Conection con = new Conection();
	    Scanner teclado = new Scanner(System.in);
	    
	    public List<Auditoria> buscarAuditoria(){
	        
	        Connection baseDatos = con.conectarBD();
	        PreparedStatement st = null;
	        ResultSet rs = null;
	        
	        List<Auditoria> auditoria = new ArrayList<Auditoria>();
	        
	        try {
	            
	            st = baseDatos.prepareStatement("SELECT * FROM \"TBL_AUDITORIA\" ORDER BY id_auditoria ASC");
	            rs = st.executeQuery();
	            
	            while (rs.next()) {
	                
	                Auditoria audi = new Auditoria();
	                
	               audi.setIdAuditoria(rs.getInt("id_auditoria"));
	               audi.setUsuario(rs.getString("usuario"));
	               audi.setDocumento(rs.getString("documento"));
	               audi.setAccion(rs.getString("accion"));
	               audi.setFechaAccion(rs.getString("fechaAccion"));
	               audi.setDescripcion(rs.getString("descripcion"));
	               audi.setResultado(rs.getString("resultado"));
	               audi.setIp(rs.getString("ip"));
	                
	                auditoria.add(audi);
	            }
	            
	        } catch (Exception e) {
	            System.err.println(e.getMessage());
	        } finally {
	            try {
	                rs.close();
	                st.close();
	                con.desconectarBD(baseDatos);
	            } catch (Exception e2) {
	                System.err.println(e2.getMessage());
	            }
	        }
	                
	        
	        return auditoria;
	    }
	    public Auditoria buscarAuditoria(int auditoria) {
            Auditoria ad = new Auditoria();
            
            Connection baseDatos = con.conectarBD();
            PreparedStatement st = null;
            ResultSet rs = null;
            
            try {
                st = baseDatos.prepareStatement("SELECT * FROM \"TBL_AUDITORIA\" WHERE id_auditoria = ? ");
                st.setInt(1, auditoria);
                //st.setString(1, marca);
                rs = st.executeQuery();
                
                while (rs.next()) {
                	 ad.setIdAuditoria(rs.getInt("id_auditoria"));
  	               ad.setUsuario(rs.getString("usuario"));
  	               ad.setDocumento(rs.getString("documento"));
  	               ad.setAccion(rs.getString("accion"));
  	               ad.setFechaAccion(rs.getString("fechaAccion"));
  	               ad.setDescripcion(rs.getString("descripcion"));
  	               ad.setResultado(rs.getString("resultado"));
  	               ad.setIp(rs.getString("ip"));
                }
                
            } catch (Exception e) {
                System.err.println(e.getMessage());
            } finally {
                try {
                    rs.close();
                    st.close();
                    con.desconectarBD(baseDatos);
                } catch (Exception e2) {
                    System.err.println(e2.getMessage());
                }
            }
            return ad;        
        }
	    //-----------------------------------------------------------------
	    
public void agregMarca(Marca m) {
	        
	        Connection baseDatos = con.conectarBD();
	        PreparedStatement st = null;
	        
	        try {
	            st = baseDatos.prepareStatement("INSERT INTO \"TBL_MARCAS\" (marca, descripcion) VALUES (?, ?)");
	            st.setString(1, m.getNombreMarca());
	            st.setString(2, m.getDescripcion());
	            int val = st.executeUpdate();
	            
	            if (val > 0)
	                System.out.println("\nRegistro guardado con éxito...");
	            else
	                System.err.println("\nError al guardar el registro... !");
	            
	        } catch (Exception e) {
	            System.err.println(e.getMessage());
	        } finally {
	            try {
	                st.close();
	                con.desconectarBD(baseDatos);
	            } catch (Exception e2) {
	                System.err.println(e2.getMessage());
	            }
	        }        
	    }
	    public Marca elimMarca(int marca) {
	        Marca m = new Marca();
	        
	        Connection baseDatos = con.conectarBD();
	        PreparedStatement st = null;
	                
	        System.out.print("\nDesea eliminar la Marca (s/n) ? : ");
	        String rg = teclado.next();
	        if (rg.equals("s")) {
	            try {
	                st = baseDatos.prepareStatement("DELETE FROM \"TBL_MARCAS\" WHERE id_marca = ? ");
	                st.setInt(1, marca);
	                int val = st.executeUpdate();
	                
	                if (val > 0)
	                    System.out.println("\nRegistro eliminado con éxito...");
	                else
	                    System.err.println("\nError al eliminar el registro... !");
	                
	            } catch (Exception e) {
	                System.err.println(e.getMessage());
	            } finally {
	                try {
	                    st.close();
	                    con.desconectarBD(baseDatos);
	                } catch (Exception e2) {
	                    System.err.println(e2.getMessage());
	                }
	            }
	                
	        } else if (rg.equals("n")) {
	            System.out.println("\nSeleccionó no eliminar Marca... !");
	        }
	        return m;    
	    }
	    
	    public void modMarca(int idmarca, String marca, String descripcion) {
            
	        Connection baseDatos = con.conectarBD();
	        PreparedStatement st = null;
	                
	        try {
	            st = baseDatos.prepareStatement("UPDATE \"TBL_MARCAS\" SET marca = ?, descripcion = ? WHERE id_marca = ?");
	            st.setInt(3, idmarca);
	            st.setString(1, marca);
	            st.setString(2, descripcion);
	            int val = st.executeUpdate();



	           if (val > 0)
	                System.out.println("\nRegistro modificado con éxito...");
	            else
	                System.err.println("\nError al modificar el registro... !");



	       } catch (Exception e) {
	            System.err.println(e.getMessage());
	        } finally {
	            try {
	                st.close();
	                con.desconectarBD(baseDatos);
	            } catch (Exception e2) {
	                System.err.println(e2.getMessage());
	            }
	        }
	    }
	    
}*/
