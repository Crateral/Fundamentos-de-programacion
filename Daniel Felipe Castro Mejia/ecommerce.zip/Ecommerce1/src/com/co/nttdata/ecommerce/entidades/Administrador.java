package com.co.nttdata.ecommerce.entidades;

import java.io.Serializable;

public class Administrador extends Usuario implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private int idAdministrador;
	private String usuario;
	private String contrasenia;
	private String correo;
	private boolean estado;
	private int idTipoIdentificacion;
	private int numIdentificacion;
	
	
	public Administrador() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Administrador(int idAdministrador, String usuario, String contrasenia, String correo, boolean estado,
			int idTipoIdentificacion, int numIdentificacion) {
		super();
		this.idAdministrador = idAdministrador;
		this.usuario = usuario;
		this.contrasenia = contrasenia;
		this.correo = correo;
		this.estado = estado;
		this.idTipoIdentificacion = idTipoIdentificacion;
		this.numIdentificacion = numIdentificacion;
	}


	public int getIdAdministrador() {
		return idAdministrador;
	}


	public void setIdAdministrador(int idAdministrador) {
		this.idAdministrador = idAdministrador;
	}


	public String getUsuario() {
		return usuario;
	}


	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}


	public String getContrasenia() {
		return contrasenia;
	}


	public void setContrasenia(String contrasenia) {
		this.contrasenia = contrasenia;
	}


	public String getCorreo() {
		return correo;
	}


	public void setCorreo(String correo) {
		this.correo = correo;
	}


	public boolean isEstado() {
		return estado;
	}


	public void setEstado(boolean estado) {
		this.estado = estado;
	}


	public int getIdTipoIdentificacion() {
		return idTipoIdentificacion;
	}


	public void setIdTipoIdentificacion(int idTipoIdentificacion) {
		this.idTipoIdentificacion = idTipoIdentificacion;
	}


	public int getNumIdentificacion() {
		return numIdentificacion;
	}


	public void setNumIdentificacion(int numIdentificacion) {
		this.numIdentificacion = numIdentificacion;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	@Override
	public String toString() {
		return "Administrador [idAdministrador=" + idAdministrador + ", usuario=" + usuario + ", contrasenia="
				+ contrasenia + ", correo=" + correo + ", estado=" + estado + ", idTipoIdentificacion="
				+ idTipoIdentificacion + ", numIdentificacion=" + numIdentificacion + "]";
	}



	

	
	
	
}

