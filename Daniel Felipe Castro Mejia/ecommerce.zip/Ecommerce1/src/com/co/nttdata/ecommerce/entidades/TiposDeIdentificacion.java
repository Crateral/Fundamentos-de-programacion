package com.co.nttdata.ecommerce.entidades;

import java.io.Serializable;

public class TiposDeIdentificacion implements Serializable{

	private static final long serialVersionUID = 1L;
	private int idTipoIdentificacion;
	private String tipoIdentificacion;
	
	public TiposDeIdentificacion() {
		super();
	}

	public TiposDeIdentificacion(int idTipoIdentificacion, String tipoIdentificacion) {
		super();
		this.idTipoIdentificacion = idTipoIdentificacion;
		this.tipoIdentificacion = tipoIdentificacion;
	}

	public int getIdTipoIdentificacion() {
		return idTipoIdentificacion;
	}

	public void setIdTipoIdentificacion(int idTipoIdentificacion) {
		this.idTipoIdentificacion = idTipoIdentificacion;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getTipoIdentificacion() {
		return tipoIdentificacion;
	}

	public void setTipoIdentificacion(String tipoIdentificacion) {
		this.tipoIdentificacion = tipoIdentificacion;
	}

	@Override
	public String toString() {
		return "TiposDeIdentificacion [idTipoIdentificacion=" + idTipoIdentificacion + ", tipoIdentificacion="
				+ tipoIdentificacion + "]";
	}
	
	
}
