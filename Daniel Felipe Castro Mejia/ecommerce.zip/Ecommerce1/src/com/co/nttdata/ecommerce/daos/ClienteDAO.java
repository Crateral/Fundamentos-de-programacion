package com.co.nttdata.ecommerce.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.co.nttdata.ecommerce.entidades.Cliente;
import com.co.nttdata.ecommerce.entidades.Marca;
import com.co.nttdata.ecommerce.utils.Conection;

public class ClienteDAO {
	
	 Conection con = new Conection();
	    Scanner teclado = new Scanner(System.in);
	    
	    public List<Cliente> buscarCliente(){
	        
	        Connection baseDatos = con.conectarBD();
	        PreparedStatement st = null;
	        ResultSet rs = null;
	        
	        List<Cliente> clientes = new ArrayList<Cliente>();
	        
	        try {
	            
	            st = baseDatos.prepareStatement("SELECT * FROM \"TBL_CLIENTE\" ORDER BY id_cliente ASC");
	            rs = st.executeQuery();
	            
	            while (rs.next()) {
	                
	            	Cliente cliente = new Cliente();
	                
	               cliente.setId_cliente(rs.getInt("id_cliente"));
	               cliente.setId_ciudad(rs.getInt("id_ciudad"));
	               cliente.setId_forma_de_pago(rs.getInt("id_forma_de_pago"));
	               cliente.setNombreUsuario(rs.getString("usuario"));
	               cliente.setContrasenia(rs.getString("contrasenia"));
	               cliente.setCorreo(rs.getString("correo"));
	               cliente.setTelefono(rs.getString("telefono"));
	               cliente.setDireccion(rs.getString("direccion"));
	               cliente.setEstado(rs.getBoolean("estado"));
	               cliente.setNum_Identificaicon(rs.getInt("num_identificacion"));
	                
	                clientes.add(cliente);
	            }
	            
	        } catch (Exception e) {
	            System.err.println(e.getMessage());
	        } finally {
	            try {
	                rs.close();
	                st.close();
	                con.desconectarBD(baseDatos);
	            } catch (Exception e2) {
	                System.err.println(e2.getMessage());
	            }
	        }
	                
	        return clientes;
	    
	        
	    }
	    public Cliente buscarCliente(int cliente) {
	    	Cliente cl = new Cliente();
            
            Connection baseDatos = con.conectarBD();
            PreparedStatement st = null;
            ResultSet rs = null;
            
            try {
                st = baseDatos.prepareStatement("SELECT * FROM \"TBL_CLIENTE\" WHERE id_cliente = ? ");
                st.setInt(1, cliente);
                //st.setString(1, marca);
                rs = st.executeQuery();
                
                while (rs.next()) {
                	cl.setId_cliente(rs.getInt("id_cliente"));
                	cl.setId_ciudad(rs.getInt("id_ciudad"));
                	cl.setId_forma_de_pago(rs.getInt("id_forma_de_pago"));
                	cl.setNombreUsuario(rs.getString("usuario"));
                	cl.setContrasenia(rs.getString("contrasenia"));
                	cl.setCorreo(rs.getString("correo"));
                	cl.setTelefono(rs.getString("telefono"));
                	cl.setDireccion(rs.getString("direccion"));
                	cl.setEstado(rs.getBoolean("estado"));
                	cl.setNum_Identificaicon(rs.getInt("num_identificacion"));
                }
                
            } catch (Exception e) {
                System.err.println(e.getMessage());
            } finally {
                try {
                    rs.close();
                    st.close();
                    con.desconectarBD(baseDatos);
                } catch (Exception e2) {
                    System.err.println(e2.getMessage());
                }
            }
            return cl;        
        }
	    
	    public void agregCliente(Cliente cl) {
	        
	        Connection baseDatos = con.conectarBD();
	        PreparedStatement st = null;
	        
	        try {
	            st = baseDatos.prepareStatement("INSERT INTO \"TBL_CLIENTE\" (id_cliente ,id_ciudad,id_forma_de_pago,usuario, contrasenia,correo"
	            		+ ",telefono,direccion,estado,num_Identificaicon) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
	            
		            st.setInt(1, cl.getId_cliente());
		            st.setInt(2, cl.getId_ciudad());
		            st.setInt(3, cl.getId_forma_de_pago());
		            st.setString(4, cl.getNombreUsuario());
		            st.setString(5, cl.getContrasenia());
		            st.setString(6, cl.getCorreo());
		            st.setString(7, cl.getTelefono());
		            st.setString(8, cl.getDireccion());
		            st.setBoolean(9, cl.isEstado());
		            st.setInt(10, cl.getNum_Identificaicon());
	            
	            int val = st.executeUpdate();
	            
	            if (val > 0)
	                System.out.println("\nRegistro guardado con éxito...");
	            else
	                System.err.println("\nError al guardar el registro... !");
	            
	        } catch (Exception e) {
	            System.err.println(e.getMessage());
	        } finally {
	            try {
	                st.close();
	                con.desconectarBD(baseDatos);
	            } catch (Exception e2) {
	                System.err.println(e2.getMessage());
	            }
	        }        
	    }
	    public Cliente elimCliente(int cliente) {
	    	Cliente cl = new Cliente();
	        
	        Connection baseDatos = con.conectarBD();
	        PreparedStatement st = null;
	                
	        System.out.print("\nDesea eliminar la Cliente (s/n) ? : ");
	        String rg = teclado.next();
	        if (rg.equals("s")) {
	            try {
	                st = baseDatos.prepareStatement("DELETE FROM \"TBL_CLIENTE\" WHERE id_cliente = ? ");
	                st.setInt(1, cliente);
	                int val = st.executeUpdate();
	                
	                if (val > 0)
	                    System.out.println("\nRegistro eliminado con éxito...");
	                else
	                    System.err.println("\nError al eliminar el registro... !");
	                
	            } catch (Exception e) {
	                System.err.println(e.getMessage());
	            } finally {
	                try {
	                    st.close();
	                    con.desconectarBD(baseDatos);
	                } catch (Exception e2) {
	                    System.err.println(e2.getMessage());
	                }
	            }
	                
	        } else if (rg.equals("n")) {
	            System.out.println("\nSeleccionó no eliminar Cliente... !");
	        }
	        return cl;    
	    }
	    public void modMarca(int id_cliente ,int id_ciudad,int id_forma_de_pago, String usuario,String contrasenia,String correo
	    		,String telefono,String direccion,boolean estado, int num_Identificaicon) {
            
	    		Connection baseDatos = con.conectarBD();
	    		PreparedStatement st = null;
	                
	    		try {
	    			st = baseDatos.prepareStatement("UPDATE \"TBL_CLIENTE\" SET usuario = ?, contrasenia = ?, correo = ?, telefono = ? "
	    					+ " direccion = ? , estado = ?, id_ciudad = ?, id_forma_de_pago = ? , num_Identificaicon = ? WHERE id_cliente = ?");
	    			st.setInt(3, id_cliente);
	    			st.setString(1, usuario);
	    			st.setString(2, contrasenia);
	    			st.setString(4, correo);
	    			st.setString(5, telefono);
	    			st.setBoolean(6, estado);
	    			st.setInt(7, num_Identificaicon);
	    			st.setInt(8, id_forma_de_pago);
	    			st.setInt(9, id_ciudad);
	    			int val = st.executeUpdate();



	    			if (val > 0)
	    				System.out.println("\nRegistro modificado con éxito...");
	    			else
	    				System.err.println("\nError al modificar el registro... !");


		
			       } catch (Exception e) {
			            System.err.println(e.getMessage());
			        } finally {
			            try {
			                st.close();
			                con.desconectarBD(baseDatos);
			            } catch (Exception e2) {
			                System.err.println(e2.getMessage());
			            }
			        }
			    }
	    
}
