package com.co.nttdata.ecommerce.entidades;

import java.io.Serializable;
import java.sql.Date;


public class CarritoDeCompras implements Serializable{

	private static final long serialVersionUID = 1L;
	private int idCarritoDeCompras;
	private int id_productos;
	private Date fecha;
	private double vlrDescuento;
	private double vlrIva;
	private double subTotalConIva;
	private double subTotalSinIva;
	private double vlrEnvio;
	
	public CarritoDeCompras() {
		super();
	}

	

	public CarritoDeCompras(int idCarritoDeCompras, int id_productos, Date fecha, double vlrDescuento, double vlrIva,
			double subTotalConIva, double subTotalSinIva, double vlrEnvio) {
		super();
		this.idCarritoDeCompras = idCarritoDeCompras;
		this.id_productos = id_productos;
		this.fecha = fecha;
		this.vlrDescuento = vlrDescuento;
		this.vlrIva = vlrIva;
		this.subTotalConIva = subTotalConIva;
		this.subTotalSinIva = subTotalSinIva;
		this.vlrEnvio = vlrEnvio;
	}



	public int getIdCarritoDeCompras() {
		return idCarritoDeCompras;
	}

	public void setIdCarritoDeCompras(int idCarritoDeCompras) {
		this.idCarritoDeCompras = idCarritoDeCompras;
	}

	public int getId_productos() {
		return id_productos;
	}

	public void setId_productos(int id_productos) {
		this.id_productos = id_productos;
	}

	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	
	public double getVlrDescuento() {
		return vlrDescuento;
	}

	public void setVlrDescuento(double vlrDescuento) {
		this.vlrDescuento = vlrDescuento;
	}

	public double getVlrIva() {
		return vlrIva;
	}

	public void setVlrIva(double vlrIva) {
		this.vlrIva = vlrIva;
	}

	public double getSubTotalConIva() {
		return subTotalConIva;
	}

	public void setSubTotalConIva(double subTotalConIva) {
		this.subTotalConIva = subTotalConIva;
	}

	public double getSubTotalSinIva() {
		return subTotalSinIva;
	}

	public void setSubTotalSinIva(double subTotalSinIva) {
		this.subTotalSinIva = subTotalSinIva;
	}

	public double getVlrEnvio() {
		return vlrEnvio;
	}

	public void setVlrEnvio(double vlrEnvio) {
		this.vlrEnvio = vlrEnvio;
	}

	@Override
	public String toString() {
		return "CarritoDeCompras [idCarritoDeCompras=" + idCarritoDeCompras + ", id_productos=" + id_productos
				+ ", fecha=" + fecha + ", vlrDescuento=" + vlrDescuento + ", vlrIva=" + vlrIva + ", subTotalConIva="
				+ subTotalConIva + ", subTotalSinIva=" + subTotalSinIva + ", vlrEnvio=" + vlrEnvio + "]";
	}
	

	
	
	
}