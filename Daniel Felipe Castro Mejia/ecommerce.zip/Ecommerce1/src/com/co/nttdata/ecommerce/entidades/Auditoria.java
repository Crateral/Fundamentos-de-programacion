package com.co.nttdata.ecommerce.entidades;

import java.io.Serializable;
public class Auditoria implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private int idAuditoria;
	private String usuario;
	private String documento;
	private String accion;
	private String fechaAccion;
	private String descripcion;
	private String resultado;
	private String ip;
	
	public Auditoria() {
		// TODO Auto-generated constructor stub
	}

	public Auditoria(int idAuditoria, String usuario, String documento, String accion, String fechaAccion,
			String descripcion, String resultado, String ip) {
		super();
		this.idAuditoria = idAuditoria;
		this.usuario = usuario;
		this.documento = documento;
		this.accion = accion;
		this.fechaAccion = fechaAccion;
		this.descripcion = descripcion;
		this.resultado = resultado;
		this.ip = ip;
	}
	
	
	public int getIdAuditoria() {
		return idAuditoria;
	}
	public void setIdAuditoria(int idAuditoria) {
		this.idAuditoria = idAuditoria;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public String getDocumento() {
		return documento;
	}
	public void setDocumento(String documento) {
		this.documento = documento;
	}
	public String getAccion() {
		return accion;
	}
	public void setAccion(String accion) {
		this.accion = accion;
	}
	public String getFechaAccion() {
		return fechaAccion;
	}
	public void setFechaAccion(String fechaAccion) {
		this.fechaAccion = fechaAccion;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public String getResultado() {
		return resultado;
	}
	public void setResultado(String resultado) {
		this.resultado = resultado;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}

	
	
	
}
