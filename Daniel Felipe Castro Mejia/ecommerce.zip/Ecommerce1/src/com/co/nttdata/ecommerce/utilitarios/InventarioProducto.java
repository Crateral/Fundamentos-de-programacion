package com.co.nttdata.ecommerce.utilitarios;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.co.nttdata.ecommerce.entidades.CarritoDeCompras;
import com.co.nttdata.ecommerce.entidades.Cliente;
import com.co.nttdata.ecommerce.entidades.Factura;
import com.co.nttdata.ecommerce.entidades.Producto;


//Instancia
public class InventarioProducto{
	//------- Traer productos
	 
	public void traerProductos(CarritoDeCompras cdc) {
		
	    	try {
	            FileWriter archivo = new FileWriter("C:/EcommercePrueba/Producto.txt");

	            archivo.write(  
	            		
	            		
	            		"--------------------------------------------" + "\n" +
	                    "Ls productos son: "  + "\n" +cdc.getProductos()  + "\n" 
	            		
	                 );

	            
	            for (int i = 0; i <= 0; i++) {
	                archivo.write(i + "\n");
	            }
	            	System.out.println("El archivo se ha escrito con exito");
	            	archivo.close();
	        	}
	        	catch(Exception e) {
	        		System.out.println("Error al escribir el archivo: " + e.getMessage());
	        	}

	}
	
	//-----mostrar los productos
	
	public void mostrarProductos(){
		
		File archivo = new File("C:/EcommercePrueba/Producto.txt" );
    	Scanner s =null;
    	
    	try {
    		s = new Scanner(archivo);
    		while(s.hasNextLine()) {
    			String linea = s.nextLine();
    			System.out.println(linea);
    		}
    		
    	}catch(Exception e) {
    		System.out.println("Error al leer el archivo" + e.getMessage());
    	}finally {
    		try {
    			if(s !=null ) {
    				s.close();
    			}
    			
    		}catch(Exception e) {
    			System.out.println("Error al cerrar el archivo" + e.getMessage());
    		}
    	}
	}
	
	//---------------------------------------------------------------------------------------------------------
	
	
	/*public void DatosProducto() {
			archivo = new File("C:/EcommercePrueba/productosAñadidos.txt");
			if(!archivo.exists()) {
				
				try {
				fw = new FileWriter(archivo,false);
				bw = new BufferedWriter(fw);
				bw.close();
				fw.close();
				}catch(IOException ex) {
				this.mensaje =ex.getMessage();
				
			}
			
		}
	}
	
	public String getMensaje() { 
		return mensaje;
	}
	
	//-
	
public boolean agregarProducto( CarritoDeCompras cdc) {
		boolean agregado = false;
		
		try {
			fw = new FileWriter(archivo,true);
			bw = new BufferedWriter(fw);
			List<Producto> datos =
					cdc.getProductos();
			bw.write(datos);
			bw.close();
			fw.close();
			agregado = true;
			
		}catch(IOException ex) {
			this.mensaje =ex.getMessage();
		}
		
		return agregado;
		
	}*/
}