package com.co.nttdata.ecommerce.utils;
	import java.sql.Connection;
	import java.sql.DriverManager;

	public class Conection {
		
		private static final String URL = "jdbc:postgresql://localhost:5432/Ecommerce";
		private static final String USUARIO = "postgres";
		private static final String CONTRASENA = "35521751M";
		
		public Connection conectarBD() {
			
			Connection baseDatos = null;
			
			try {
				baseDatos = DriverManager.getConnection(URL, USUARIO, CONTRASENA);
			} catch (Exception e) {
				System.out.println("Error : " + e.getMessage());			
			}
			return baseDatos;
		}
		
		public void desconectarBD(Connection baseDatos) {
			
			try {
				baseDatos.close();
			} catch (Exception e) {
				System.out.println("Error : " + e.getMessage());
			}
			
		}

	}

