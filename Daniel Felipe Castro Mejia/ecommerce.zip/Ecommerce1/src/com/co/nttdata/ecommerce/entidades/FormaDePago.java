package com.co.nttdata.ecommerce.entidades;

import java.io.Serializable;

public class FormaDePago implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private int idFormaDePago;
	private String formaDePago;
	
	
	public FormaDePago() {
		super();
	}

	public FormaDePago(int idFormaDePago, String formaDePago) {
		super();
		this.idFormaDePago = idFormaDePago;
		this.formaDePago = formaDePago;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public int getIdFormaDePago() {
		return idFormaDePago;
	}

	public void setIdFormaDePago(int idFormaDePago) {
		this.idFormaDePago = idFormaDePago;
	}

	public String getFormaDePago() {
		return formaDePago;
	}

	public void setFormaDePago(String formaDePago) {
		this.formaDePago = formaDePago;
	}

	@Override
	public String toString() {
		return "FormaDePago [idFormaDePago=" + idFormaDePago + ", formaDePago=" + formaDePago + "]";
	}
	
	
	
}
