package com.co.nttdata.ecommerce.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.co.nttdata.ecommerce.entidades.Marca;
import com.co.nttdata.ecommerce.entidades.TiposDeIdentificacion;
import com.co.nttdata.ecommerce.utils.Conection;

public class TiposDeIdentificacionDAO {
	
	Conection con = new Conection();
    Scanner teclado = new Scanner(System.in);
    
    public List<TiposDeIdentificacion> buscarTiposDeIdentificacion(){
        
        Connection baseDatos = con.conectarBD();
        PreparedStatement st = null;
        ResultSet rs = null;
        
        List<TiposDeIdentificacion> tipoide = new ArrayList<TiposDeIdentificacion>();
        
        try {
            
            st = baseDatos.prepareStatement("SELECT * FROM \"TBL_TIPOIDENTIFICACION\" ORDER BY id_tipoIdentificacion ASC");
            rs = st.executeQuery();
            
            while (rs.next()) {
                
            	TiposDeIdentificacion tipo = new TiposDeIdentificacion();
                
            	tipo.setIdTipoIdentificacion(rs.getInt("id_tipoIdentificacion"));
            	tipo.setTipoIdentificacion(rs.getString("tipo_Identificacion"));
               
                
                tipoide.add(tipo);
            }
            
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                rs.close();
                st.close();
                con.desconectarBD(baseDatos);
            } catch (Exception e2) {
                System.err.println(e2.getMessage());
            }
        }
                
        
        return tipoide;
    }
    public TiposDeIdentificacion buscarTiposDeIdentificacion(int tipoide ) {
    	TiposDeIdentificacion tdi  = new TiposDeIdentificacion();
        
        Connection baseDatos = con.conectarBD();
        PreparedStatement st = null;
        ResultSet rs = null;
        
        try {
            st = baseDatos.prepareStatement("SELECT * FROM \"TBL_TIPOIDENTIFICACION\" WHERE id_tipoIdentificacion = ? ");
            st.setInt(1, tipoide);
            //st.setString(1, marca);
            rs = st.executeQuery();
            
            while (rs.next()) {
            	
            	tdi.setIdTipoIdentificacion(rs.getInt("id_tipoIdentificacion"));
            	tdi.setTipoIdentificacion(rs.getString("tipo_Identificacion"));
            }
            
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                rs.close();
                st.close();
                con.desconectarBD(baseDatos);
            } catch (Exception e2) {
                System.err.println(e2.getMessage());
            }
        }
        return tdi;        
    }
    public void agregTiposDeIdentificacion(TiposDeIdentificacion tdi) {
        
        Connection baseDatos = con.conectarBD();
        PreparedStatement st = null;
        
        try {
            st = baseDatos.prepareStatement("INSERT INTO \"TBL_TIPOIDENTIFICACION\" (id_tipoIdentificacion, tipo_Identificacion) VALUES (?, ?)");
            st.setInt(1, tdi.getIdTipoIdentificacion());
            st.setString(2, tdi.getTipoIdentificacion() );
            int val = st.executeUpdate();
            
            if (val > 0)
                System.out.println("\nRegistro guardado con éxito...");
            else
                System.err.println("\nError al guardar el registro... !");
            
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                st.close();
                con.desconectarBD(baseDatos);
            } catch (Exception e2) {
                System.err.println(e2.getMessage());
            }
        }        
    }
    public TiposDeIdentificacion elimTiposDeIdentificacion(int tipoide) {
    	TiposDeIdentificacion tdi = new TiposDeIdentificacion();
        
        Connection baseDatos = con.conectarBD();
        PreparedStatement st = null;
                
        System.out.print("\nDesea eliminar la TipoIdentificacion (s/n) ? : ");
        String rg = teclado.next();
        if (rg.equals("s")) {
            try {
                st = baseDatos.prepareStatement("DELETE FROM \"TBL_TIPOIDENTIFICACION\" WHERE id_tipoIdentificacion = ? ");
                st.setInt(1, tipoide);
                int val = st.executeUpdate();
                
                if (val > 0)
                    System.out.println("\nRegistro eliminado con éxito...");
                else
                    System.err.println("\nError al eliminar el registro... !");
                
            } catch (Exception e) {
                System.err.println(e.getMessage());
            } finally {
                try {
                    st.close();
                    con.desconectarBD(baseDatos);
                } catch (Exception e2) {
                    System.err.println(e2.getMessage());
                }
            }
                
        } else if (rg.equals("n")) {
            System.out.println("\nSeleccionó no eliminar TipoIdentificacion... !");
        }
        return tdi;  
    }
    
    public void modTipoIdentificacion(int id_tipoIdentificacion, String tipo_Identificacion) {
        
        Connection baseDatos = con.conectarBD();
        PreparedStatement st = null;
                
        try {
            st = baseDatos.prepareStatement("UPDATE \"TBL_TIPOIDENTIFICACION\" SET tipo_Identificacion = ? WHERE id_marca = ?");
            st.setInt(2, id_tipoIdentificacion);
            st.setString(1, tipo_Identificacion);
            
            int val = st.executeUpdate();



           if (val > 0)
                System.out.println("\nRegistro modificado con éxito...");
            else
                System.err.println("\nError al modificar el registro... !");



       } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                st.close();
                con.desconectarBD(baseDatos);
            } catch (Exception e2) {
                System.err.println(e2.getMessage());
            }
        }
    }
}
