package com.co.nttdata.ecommerce.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.co.nttdata.ecommerce.entidades.FormaDePago;

import com.co.nttdata.ecommerce.utils.Conection;

public class FormaDePagoDAO {

	Conection con = new Conection();
    Scanner teclado = new Scanner(System.in);
    
    public List<FormaDePago> buscarFormaDePago(){
        
        Connection baseDatos = con.conectarBD();
        PreparedStatement st = null;
        ResultSet rs = null;
        
        List<FormaDePago> formadepago = new ArrayList<FormaDePago>();
        
        try {
            
            st = baseDatos.prepareStatement("SELECT * FROM \"TBL_FORMASDEPAGO\" ORDER BY id_forma_pago ASC");
            rs = st.executeQuery();
            
            while (rs.next()) {
                
            	FormaDePago fdp = new FormaDePago();
                
            	fdp.setIdFormaDePago(rs.getInt("id_forma_pago"));
            	fdp.setFormaDePago(rs.getString("forma_pago"));
             
               
                
            	formadepago.add(fdp);
            }
            
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                rs.close();
                st.close();
                con.desconectarBD(baseDatos);
            } catch (Exception e2) {
                System.err.println(e2.getMessage());
            }
        }
                
        
        return formadepago;
    
     }
    public FormaDePago buscarFormaDePago(int formapago) {
    	FormaDePago f = new FormaDePago();
        
        Connection baseDatos = con.conectarBD();
        PreparedStatement st = null;
        ResultSet rs = null;
        
        try {
            st = baseDatos.prepareStatement("SELECT * FROM \"TBL_FORMASDEPAGO\" WHERE id_forma_pago = ? ");
            st.setInt(1, formapago);
            //st.setString(1, marca);
            rs = st.executeQuery();
            
            while (rs.next()) {
            	f.setIdFormaDePago(rs.getInt("id_forma_pago"));
            	f.setFormaDePago(rs.getString("forma_pago"));
            }
            
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                rs.close();
                st.close();
                con.desconectarBD(baseDatos);
            } catch (Exception e2) {
                System.err.println(e2.getMessage());
            }
        }
        return f;        
    }
    
    public void agregFormaDePago(FormaDePago fdp) {
        
        Connection baseDatos = con.conectarBD();
        PreparedStatement st = null;
        
        try {
            st = baseDatos.prepareStatement("INSERT INTO \"TBL_FORMASDEPAGO\" ( forma_pago) VALUES (?)");
            
            int val = st.executeUpdate();
            
            if (val > 0)
                System.out.println("\nRegistro guardado con éxito...");
            else
                System.err.println("\nError al guardar el registro... !");
            
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                st.close();
                con.desconectarBD(baseDatos);
            } catch (Exception e2) {
                System.err.println(e2.getMessage());
            }
        }        
    }
    
    public FormaDePago elimFormaDePago( String forma_pago) {
    	FormaDePago fdp = new FormaDePago();
        
        Connection baseDatos = con.conectarBD();
        PreparedStatement st = null;
                
        System.out.print("\nDesea eliminar la FormaDePago (s/n) ? : ");
        String rg = teclado.next();
        if (rg.equals("s")) {
            try {
                st = baseDatos.prepareStatement("DELETE FROM \"TBL_FORMASDEPAGO\" WHERE id_forma_pago = ? ");
                st.setString(1, forma_pago);
                
                int val = st.executeUpdate();
                
                if (val > 0)
                    System.out.println("\nRegistro eliminado con éxito...");
                else
                    System.err.println("\nError al eliminar el registro... !");
                
            } catch (Exception e) {
                System.err.println(e.getMessage());
            } finally {
                try {
                    st.close();
                    con.desconectarBD(baseDatos);
                } catch (Exception e2) {
                    System.err.println(e2.getMessage());
                }
            }
                
        } else if (rg.equals("n")) {
            System.out.println("\nSeleccionó no eliminar FormaDePago... !");
        }
        return fdp;    
    }
    
    public void modMarca(int id_forma_pago, String forma_pago) {
        
        Connection baseDatos = con.conectarBD();
        PreparedStatement st = null;
                
        try {
            st = baseDatos.prepareStatement("UPDATE \"TBL_FORMASDEPAGO\" SET forma_pago = ? WHERE id_forma_pago = ?");
            st.setInt(2, id_forma_pago);
            st.setString(1, forma_pago);
            
            int val = st.executeUpdate();



           if (val > 0)
                System.out.println("\nRegistro modificado con éxito...");
            else
                System.err.println("\nError al modificar el registro... !");



       } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                st.close();
                con.desconectarBD(baseDatos);
            } catch (Exception e2) {
                System.err.println(e2.getMessage());
            }
        }
    }
}
