package com.co.nttdata.ecommerce.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.co.nttdata.ecommerce.entidades.Empresa;
import com.co.nttdata.ecommerce.entidades.Marca;
import com.co.nttdata.ecommerce.utils.Conection;

public class EmpresaDAO {
	Conection con = new Conection();
    Scanner teclado = new Scanner(System.in);
    
    public List<Empresa> buscarEmpresa(){
        
        Connection baseDatos = con.conectarBD();
        PreparedStatement st = null;
        ResultSet rs = null;
        
        List<Empresa> empresas = new ArrayList<Empresa>();
        
        try {
            
            st = baseDatos.prepareStatement("SELECT * FROM \"TBL_EMPRESA\" ORDER BY nit_Empresa ASC");
            rs = st.executeQuery();
            
            while (rs.next()) {
                
            	Empresa empresa = new Empresa();
            	
                empresa.setNit_Empresa(rs.getString("nit_empresa"));
                empresa.setEmpresa(rs.getString("empresa"));
                empresa.setResolucion_dian(rs.getString("resolusion_dian"));
                empresa.setDireccion(rs.getString("direccion"));
                empresa.setTelefono(rs.getString("telefono"));
                
            	empresas.add(empresa);
            	
            }
            
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                rs.close();
                st.close();
                con.desconectarBD(baseDatos);
            } catch (Exception e2) {
                System.err.println(e2.getMessage());
            }
        }
        
        return empresas;  
    }
    
    public Empresa buscarEmpresa(int empresa) {
    	Empresa em = new Empresa();
        
        Connection baseDatos = con.conectarBD();
        PreparedStatement st = null;
        ResultSet rs = null;
        
        try {
            st = baseDatos.prepareStatement("SELECT * FROM \"TBL_EMPRESA\" WHERE nit_empresa = ? ");
            st.setInt(1, empresa);
            //st.setString(1, marca);
            rs = st.executeQuery();
            
            while (rs.next()) {
            	em.setNit_Empresa(rs.getString("nit_empresa"));
                em.setEmpresa(rs.getString("empresa"));
                em.setResolucion_dian(rs.getString("resolusion_dian"));
                em.setDireccion(rs.getString("direccion"));
                em.setTelefono(rs.getString("telefono"));
            }
            
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                rs.close();
                st.close();
                con.desconectarBD(baseDatos);
            } catch (Exception e2) {
                System.err.println(e2.getMessage());
            }
        }
        return em;        
    }
    
    public void agregEmpresa(Empresa em) {
        
        Connection baseDatos = con.conectarBD();
        PreparedStatement st = null;
        
        try {
            st = baseDatos.prepareStatement("INSERT INTO \"TBL_EMPRESA\" (empresa) VALUES (?)");
            st.setString(1, em.getEmpresa());
            int val = st.executeUpdate();
            
            if (val > 0)
                System.out.println("\nRegistro guardado con éxito...");
            else
                System.err.println("\nError al guardar el registro... !");
            
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                st.close();
                con.desconectarBD(baseDatos);
            } catch (Exception e2) {
                System.err.println(e2.getMessage());
            }
        }        
    }
    public Empresa elimEmpresa(int empresa) {
    	Empresa em = new Empresa();
        
        Connection baseDatos = con.conectarBD();
        PreparedStatement st = null;
                
        System.out.print("\nDesea eliminar la Empresa (s/n) ? : ");
        String rg = teclado.next();
        if (rg.equals("s")) {
            try {
                st = baseDatos.prepareStatement("DELETE FROM \"TBL_EMPRESA\" WHERE nit_empresa = ? ");
                st.setInt(1, empresa);
                int val = st.executeUpdate();
                
                if (val > 0)
                    System.out.println("\nRegistro eliminado con éxito...");
                else
                    System.err.println("\nError al eliminar el registro... !");
                
            } catch (Exception e) {
                System.err.println(e.getMessage());
            } finally {
                try {
                    st.close();
                    con.desconectarBD(baseDatos);
                } catch (Exception e2) {
                    System.err.println(e2.getMessage());
                }
            }
                
        } else if (rg.equals("n")) {
            System.out.println("\nSeleccionó no eliminar Empresa... !");
        }
        return em;    
    }
    
    public void modEmpresa(int nit_empresa, String empresa) {
        
        Connection baseDatos = con.conectarBD();
        PreparedStatement st = null;
                
        try {
            st = baseDatos.prepareStatement("UPDATE \"TBL_MARCAS\" SET empresa = ? WHERE nit_empresa = ?");
            st.setInt(2, nit_empresa);
            st.setString(1,empresa);
            int val = st.executeUpdate();



           if (val > 0)
                System.out.println("\nRegistro modificado con éxito...");
            else
                System.err.println("\nError al modificar el registro... !");



       } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                st.close();
                con.desconectarBD(baseDatos);
            } catch (Exception e2) {
                System.err.println(e2.getMessage());
            }
        }
    }
    
}
