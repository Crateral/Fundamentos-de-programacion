package com.co.nttdata.ecommerce.entidades;

import java.io.Serializable;

public class Empresa implements Serializable{
	
	
	private static final long serialVersionUID = 1L;
	
	private String nit_Empresa;
	private String empresa;
	private String resolucion_dian;
	private String direccion;
	private String telefono;
	
	public Empresa() {
		super();
	}

	public Empresa(String nit_Empresa, String empresa, String resolucion_dian, String direccion, String telefono) {
		super();
		this.nit_Empresa = nit_Empresa;
		this.empresa = empresa;
		this.resolucion_dian = resolucion_dian;
		this.direccion = direccion;
		this.telefono = telefono;
	}

	public String getNit_Empresa() {
		return nit_Empresa;
	}

	public void setNit_Empresa(String nit_Empresa) {
		this.nit_Empresa = nit_Empresa;
	}

	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}

	public String getResolucion_dian() {
		return resolucion_dian;
	}

	public void setResolucion_dian(String resolucion_dian) {
		this.resolucion_dian = resolucion_dian;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "Empresa [nit_Empresa=" + nit_Empresa + ", empresa=" + empresa + ", resolucion_dian=" + resolucion_dian
				+ ", direccion=" + direccion + ", telefono=" + telefono + "]";
	}
	
}