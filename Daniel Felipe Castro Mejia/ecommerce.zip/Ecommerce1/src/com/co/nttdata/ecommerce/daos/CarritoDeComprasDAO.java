package com.co.nttdata.ecommerce.daos;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.co.nttdata.ecommerce.entidades.CarritoDeCompras;
import com.co.nttdata.ecommerce.entidades.Marca;
import com.co.nttdata.ecommerce.utils.Conection;

public class CarritoDeComprasDAO {
	Conection con = new Conection();
    Scanner teclado = new Scanner(System.in);
    
    public List<CarritoDeCompras> buscarCarritoDeCompras(){
        
        Connection baseDatos = con.conectarBD();
        PreparedStatement st = null;
        ResultSet rs = null;
        
        List<CarritoDeCompras> carritodecompras = new ArrayList<CarritoDeCompras>();
        
        try {
            
            st = baseDatos.prepareStatement("SELECT * FROM \"TBL_CARRITODECOMPRAS\" ORDER BY id_carrtitodc ASC");
            rs = st.executeQuery();
            
            while (rs.next()) {
                
            	CarritoDeCompras cardc = new CarritoDeCompras();
                	
            	cardc.setIdCarritoDeCompras(rs.getInt("id_carrtitodc"));
            	cardc.setId_productos(rs.getInt("id_producto"));
            	cardc.setFecha(rs.getDate("fecha"));
            	cardc.setVlrDescuento(rs.getDouble("vlr_descuento"));
            	cardc.setVlrIva(rs.getDouble("vlr_iva"));
            	cardc.setSubTotalConIva(rs.getDouble("sub_total_con_iva"));
            	cardc.setSubTotalSinIva(rs.getDouble("sub_total_sin_iva"));
            	cardc.setVlrEnvio(rs.getDouble("vlr_envio"));
               
               
                
            	carritodecompras.add(cardc);
            }
            
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                rs.close();
                st.close();
                con.desconectarBD(baseDatos);
            } catch (Exception e2) {
                System.err.println(e2.getMessage());
            }
        }
                
        
        return carritodecompras;
    }
    
    public CarritoDeCompras buscarMarca(int carritodc) {
    	CarritoDeCompras cdc = new CarritoDeCompras();
        
        Connection baseDatos = con.conectarBD();
        PreparedStatement st = null;
        ResultSet rs = null;
        
        try {
            st = baseDatos.prepareStatement("SELECT * FROM \"TBL_CARRITODECOMPRAS\" WHERE id_carrtitodc = ? ");
            st.setInt(1, carritodc );
            //st.setString(1, marca);
            rs = st.executeQuery();
            
            while (rs.next()) {
            	
            	cdc.setIdCarritoDeCompras(rs.getInt("id_carrtitodc"));
            	cdc.setId_productos(rs.getInt("id_producto"));
            	cdc.setFecha(rs.getDate("fecha"));
            	cdc.setVlrDescuento(rs.getDouble("vlr_descuento"));
            	cdc.setVlrIva(rs.getDouble("vlr_iva"));
            	cdc.setSubTotalConIva(rs.getDouble("sub_total_con_iva"));
            	cdc.setSubTotalSinIva(rs.getDouble("sub_total_sin_iva"));
            	cdc.setVlrEnvio(rs.getDouble("vlr_envio"));
            	
            }
            
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                rs.close();
                st.close();
                con.desconectarBD(baseDatos);
            } catch (Exception e2) {
                System.err.println(e2.getMessage());
            }
        }
        return cdc;        
    }
    
    
    public void agregCarritoDeCompras(CarritoDeCompras cdc ) {
        
        Connection baseDatos = con.conectarBD();
        PreparedStatement st = null;
        
        try {
            st = baseDatos.prepareStatement("INSERT INTO \"TBL_CARRITODECOMPRAS\" (id_carrtitodc) VALUES ( ?)");
            st.setInt(1,cdc.getIdCarritoDeCompras());
    
            int val = st.executeUpdate();
            
            if (val > 0)
                System.out.println("\nRegistro guardado con éxito...");
            else
                System.err.println("\nError al guardar el registro... !");
            
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                st.close();
                con.desconectarBD(baseDatos);
            } catch (Exception e2) {
                System.err.println(e2.getMessage());
            }
        }        
    }
    
    public CarritoDeCompras elimMarca(int id_carrtitodc) {
    	CarritoDeCompras cdc = new CarritoDeCompras();
        
        Connection baseDatos = con.conectarBD();
        PreparedStatement st = null;
                
        System.out.print("\nDesea eliminar la Marca (s/n) ? : ");
        String rg = teclado.next();
        if (rg.equals("s")) {
            try {
                st = baseDatos.prepareStatement("DELETE FROM \"TBL_MARCAS\" WHERE id_carrtitodc = ? ");
                st.setInt(1, id_carrtitodc);
                int val = st.executeUpdate();
                
                if (val > 0)
                    System.out.println("\nRegistro eliminado con éxito...");
                else
                    System.err.println("\nError al eliminar el registro... !");
                
            } catch (Exception e) {
                System.err.println(e.getMessage());
            } finally {
                try {
                    st.close();
                    con.desconectarBD(baseDatos);
                } catch (Exception e2) {
                    System.err.println(e2.getMessage());
                }
            }
                
        } else if (rg.equals("n")) {
            System.out.println("\nSeleccionó no eliminar Marca... !");
        }
        return cdc;    
    }
    
    public void modCarritoDeCompras(int id_carrtitodc,int id_productos,Date fecha,double vlrDescuento,double vlrIva
    		,double subTotalConIva,double subTotalSinnIva,double vlrEnvio) {
        
        Connection baseDatos = con.conectarBD();
        PreparedStatement st = null;
                
        try {
            st = baseDatos.prepareStatement("UPDATE \"TBL_MARCAS\" SET  id_productos = ?, fecha = ?, vlrDescuento = ?, vlrIva = ?"
            		+ ", subTotalConIva = ?, subTotalSinnIva = ?, vlrEnvio  = ?WHERE id_carrtitodc = ?");
            st.setInt(1, id_carrtitodc);
            st.setInt(2, id_productos );
            st.setDate(3, fecha);
            st.setDouble(4, vlrDescuento);
            st.setDouble(5, vlrIva);
            st.setDouble(6, subTotalConIva);
            st.setDouble(7, subTotalSinnIva);
            st.setDouble(8, vlrEnvio);
            int val = st.executeUpdate();



           if (val > 0)
                System.out.println("\nRegistro modificado con éxito...");
            else
                System.err.println("\nError al modificar el registro... !");



       } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                st.close();
                con.desconectarBD(baseDatos);
            } catch (Exception e2) {
                System.err.println(e2.getMessage());
            }
        }
    }
    
}
