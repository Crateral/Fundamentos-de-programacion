package principal;

public class Matas extends Planta
 {
    @Override
    public  void cacularAltura()
    {
        System.out.println("Calculando altura mata ");
       
    }
    @Override
    public  void crearFlor()
    {
        System.out.println("Creando flor mata");
    }
    @Override
    public  void crearFruto()
    {
          System.out.println("Creando fruto mata");
    }
    @Override
    public void calcularTiempodeVida(int tiempodiasquelleva, int tiempodiasdevidaestimado)
    {

        System.out.println("Tiempo de vida en dias: "+(tiempodiasdevidaestimado-tiempodiasquelleva));
    }
}