package principal;

public class Arboles extends Planta
{
    @Override
    public  void cacularAltura(){
        System.out.println("Calculando altura arbol ");
       
    }
    @Override
    public  void crearFlor(){
        System.out.println("Creando flor arbol");
    }
    @Override
    public  void crearFruto(){
          System.out.println("Creando fruto arbol");
    }
    @Override
    public void calcularTiempodeVida(int tiempodiasquelleva, int tiempodiasdevidaestimado){

        System.out.println("Tiempo de vida en dias: "+(tiempodiasdevidaestimado-tiempodiasquelleva));
    }
}
