abstract class Planta {

     public int altura;

     public boolean dafruto;
     public boolean tieneflores;

     public abstract void cacularAltura();
     public abstract void crearFlor();
     public abstract void crearFruto();
     public abstract void calcularTiempodeVida(int tiempodiasquelleva, int tiempodiasdevidaestimado);

}
