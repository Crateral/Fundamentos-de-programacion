
public class Principal {

    
    public static void main(String[] args) {
        

        Hierba hierva= new Hierba();
        hierva.cacularAltura();
        hierva.crearFlor();
        hierva.crearFruto();
        hierva.tieneflores=false;
         System.out.println(hierva.tieneflores);
        //tiempo de vida que lleva transcurrido y el tiempo de vida promedio
        hierva.calcularTiempodeVida(95, 1095);
        
        Arbustos arbusto= new Arbustos();
        arbusto.cacularAltura();
        arbusto.crearFlor();
        arbusto.crearFruto();
        arbusto.tieneflores=false;
         System.out.println(arbusto.tieneflores);
        //tiempo de vida que lleva transcurrido y el tiempo de vida promedio
        arbusto.calcularTiempodeVida(380, 10950);
        
        Matas mata= new Matas();
        mata.cacularAltura();
        mata.crearFlor();
        mata.crearFruto();
        mata.tieneflores=true;
        System.out.println(mata.tieneflores);
        //tiempo de vida que lleva transcurrido y el tiempo de vida promedio
        mata.calcularTiempodeVida(45, 365);
        
        Arboles arbol= new Arboles();
        arbol.cacularAltura();
        arbol.crearFlor();
        arbol.crearFruto();
        arbol.tieneflores=false;
        System.out.println(arbol.tieneflores);
        //tiempo de vida que lleva transcurrido y el tiempo de vida promedio
        arbol.calcularTiempodeVida(465, 365000);
        

    }

}
