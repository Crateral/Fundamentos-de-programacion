package com.co.nttdata.ecommerce.logica;
import java.util.*;

import com.co.nttdata.ecommerce.entidades.*;

public class GestionLogin {
	
	Scanner teclado = new Scanner(System.in);
	Cliente cliente = new Cliente();
	

	public void registrarUsuario() {
		
		System.out.println("Ingrese el Usuario: ");
		String U = teclado.next();
		cliente.setNombreUsuario(U);
		
		System.out.println("Ingrese su Correo: ");
		String co = teclado.next();
		cliente.setCorreo(co);
		
		System.out.println("Ingrese numero de identificacion");
		String ni = teclado.next();
		cliente.setNumeroIdentificacion(ni);
		
		System.out.println("Ingrese su Telefono: ");
		String tl = teclado.next();
		cliente.setTelefono(tl);
		
		System.out.println("Ingrese la Contraseña: ");
		String C = teclado.next();
		cliente.setContrasenia(C);
		
		System.out.println("Ingrese la Direccion");
		String D = teclado.next();
		cliente.setDireccion(D);
		
		System.out.println("Ingrese el Estado true or false");
		boolean est = teclado.nextBoolean();
		cliente.setEstado(est);
		
		System.out.println("Escoja la ciudad");
		for (Ciudades ciu : Ciudades.values()) {
			System.out.println(ciu);
		}
		int nCiu =  teclado.nextInt();
		if (nCiu == 1) {
			cliente.setCiudad(Ciudades.BOGOTA);
		}else if (nCiu == 2) {
			cliente.setCiudad(Ciudades.FACATATIVA);
		}
		
		System.out.println("Escoja el metodo de pago"+ "\n" + "Efectivo"+ "\n" + "TarjetasDB"+ "\n" + "Cheques"+ "\n" + "Transferencia");
		String pg = teclado.next();
		cliente.setMetodoDePago(pg);
	
	}
	
	//---------------------------------------------------

	public void ingreso(){
		int cont = 0, cn = 0;
		
		String intento = "";
		
		System.out.println("Bienvenido al Sistema \n"+"Ingrese sus Datos");
		
		
		while (cont <= 2){
			System.out.println("Ingrese el usuario");
			intento = teclado.nextLine();
			if(intento.equals(cliente.getNombreUsuario())) {
			System.out.println("Usuario Correcto");
			break;
			}else {
				System.out.println("Usuario Incorrecto");
			}
		}
		
		
		do {
			System.out.println("Ingrese el Contraseña");
			intento = teclado.nextLine();
			if(cliente.getContrasenia().equals(intento)){
				System.out.println("Contraseña Correcto");
				System.out.println("Bienvenido al SYSTEM Ecommerce");
				break;
			}else {
				System.out.println("Contraseña Incorrecta");
				cn ++;
			}
		}while(cn != 3 );
		
	}
	
	//-------------------------------------------------------
	
	public void mostrarUsuario() {
		
		System.out.println("Los Datos del Usuario son: ");
		System.out.println("El Usuario es:  " + cliente.getNombreUsuario());
		System.out.println("El Correo es: "+ cliente.getCorreo());
		System.out.println("El Numero de identificacion es: "+cliente.getNumeroIdentificacion());
		System.out.println("El Numero de Telefono es: "+ cliente.getTelefono());
		System.out.println("La contraseña es: "+ cliente.getContrasenia());
		System.out.println("La Direccion es: "+ cliente.getDireccion());
		System.out.println("El Estado es: "+ cliente.isEstado());
		System.out.println("La ciudad es: "+ cliente.getCiudad());
		
	}
	//-------------------------------------------------------------
	public void logout() {
		System.out.println("Salida del System Ecommerce");
		System.out.println("Feliz de haberte conocido mi pes");
	}
}
