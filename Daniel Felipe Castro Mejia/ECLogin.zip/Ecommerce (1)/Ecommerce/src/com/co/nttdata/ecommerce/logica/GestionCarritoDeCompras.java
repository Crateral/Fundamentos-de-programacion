package com.co.nttdata.ecommerce.logica;

import java.util.List;

import com.co.nttdata.ecommerce.entidades.*;


public class GestionCarritoDeCompras {
	
double total = 0.0;
	public CarritoDeCompras añadirAlCarrito(CarritoDeCompras cdc, List<Producto> p) {
		
		cdc.setProductos(p);
		return cdc;
		
	}
	
	public CarritoDeCompras calcularTotalConIva(CarritoDeCompras cdc) {
		
		for (int i = 0; i < cdc.getProductos().size(); i++) {
			       //1100           2000
			total = total + cdc.getProductos().get(i).getPrecio() + 
					(cdc.getProductos().get(i).getPrecio() * 
							(cdc.getProductos().get(i).getIva())/100);
		}
		cdc.setSubTotalConIva(total);
		System.out.println(cdc.getSubTotalConIva());
		return cdc;
	}
	
	public CarritoDeCompras calcularTotalSinIva(CarritoDeCompras cdc) {
		double total =0;
		for(int i = 1; i<cdc.getProductos().size(); i++){
			total= total + cdc.getProductos().get(i).getPrecio();
			
		}
	cdc.setSubTotalSinIva(total);
	return cdc;
	}
	
	//Para el calculo del envio se debe tener en cuenta la ubicacion del cliente
		//Si se encuentra en ciudades principales se debe cobrar el 5%
		//Si se encuentra en ciudades no principales se debe cobrar el 10%
	
	/*public double calcularCostoEnvio(Cliente c, double valor) {
		if(c.getCiudad().isPrincipal()){
			return valor * 0.05;
		}else {
			return valor * 0.1;
		}
	}*/
	
	
}
