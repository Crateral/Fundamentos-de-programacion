import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.co.nttdata.ecommerce.entidades.*;
import com.co.nttdata.ecommerce.logica.*;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Crear 10 prodcutos
		//Añadir 6 al carrito de comprar
		//Crear la factura de ese carrito de compras
		
		 List<Producto> list = new ArrayList<>();
		 Scanner consola =  new Scanner(System.in);
		 
		GestionCarritoDeCompras gcdc = new GestionCarritoDeCompras();
		GestionFactura gf = new GestionFactura();
		Factura f =new Factura();
		CarritoDeCompras cdc = new CarritoDeCompras();
		GestionLogin lg = new GestionLogin();
		Cliente cl = new Cliente();
		//creacion de los 10 productos
		
		Producto Tvs1 = new Producto(1,"TvSamsung 1",20,150000,true,70000,19,"Tv Samsung","Full 4K",Marca.SAMSUNG,Categoria.ELECTRODOMESTICOS);
		Producto Tvs2 = new Producto(2,"TvLG 2",23,200000,true,70000,19,"Tv LG","Full 4K",Marca.LG,Categoria.ELECTRODOMESTICOS);
		Producto Tvs3 = new Producto(3,"TvHiunday 3",20,250000,false,70000,19,"Tv Hiunday","FULL HD",Marca.HIUNDAY,Categoria.ELECTRODOMESTICOS);
		Producto Tvs4 = new Producto(4,"TvSamsung 4",12,300000,true,70000,19,"Tv Samsung","Full 4K",Marca.SAMSUNG,Categoria.ELECTRODOMESTICOS);
		Producto Tvs5 = new Producto(5,"TvLG 5",20,350000,true,70000,19,"Tv Lg","Full 4K",Marca.LG,Categoria.ELECTRODOMESTICOS);
		Producto Tvs6 = new Producto(6,"TvHiunday 6",50,125000,false,70000,19,"Tv Hiunday","Full 8K",Marca.HIUNDAY,Categoria.ELECTRODOMESTICOS);
		Producto Tvs7 = new Producto(7,"TvSamsung 7",10,100000,true,70000,19,"Tv Samsung","Full 8K",Marca.SAMSUNG,Categoria.ELECTRODOMESTICOS);
		Producto Tvs8 = new Producto(8,"TvLG 8",25,105000,true,70000,19,"Tv Lg","FuLL 8K",Marca.LG,Categoria.ELECTRODOMESTICOS);
		Producto Tvs9 = new Producto(9,"TvHiunday 9",12,700000,true,70000,19,"Tv Hiunday","ULTRA HD",Marca.HIUNDAY,Categoria.ELECTRODOMESTICOS);
		Producto Tvs10 = new Producto(10,"TvSamsung 10",24,110000,true,70000,19,"Tv Samsung","Full 8K ULTRA HD",Marca.SAMSUNG,Categoria.ELECTRODOMESTICOS);
		
		list.add(Tvs1);
		list.add(Tvs3);
		list.add(Tvs4);
		list.add(Tvs5);
		list.add(Tvs6);
		list.add(Tvs7);
		
		
		
		
		
			
		/*cdc.setValorEnvio(gcdc.calcularCostoEnvio(null, cdc.getSubTotalConIva()));*/
	
		f = gf.pagar(null, cdc);
		int opcion = 0;
		do {
			System.out.println("\n");
			System.out.println("Menu Principal Ecomercce");
			System.out.println("1. Registrar Usuario");
			System.out.println("2. Ingreso Login");
			System.out.println("3. Mirar productos");
			System.out.println("4. Mostrar Usuario");
			System.out.println("5. Generar Factura");
			System.out.println("6. Salida");
			
			System.out.println("Ingrese la opcion");
		
			System.out.println();
			System.out.println();
			opcion = consola.nextInt();
		
			switch (opcion) {
			case 1:
				lg.registrarUsuario();
				System.out.println("Registro Exitoso!");
				break;
			case 2 :
				lg.ingreso();
				break;
			case 3:
				cdc = gcdc.añadirAlCarrito(cdc, list);
				
		cdc.setProductos(list);
		System.out.println("Los productos añadidos son: ");
		cdc.getProductos().forEach((
				p -> System.out.println("\n"+
				p.getIdProducto()+" "+ 
				p.getNombre()+" "+
				p.getCantidadDiponible()+" "+
				p.getPrecio()+" "+
				p.isDescuento()+" "+
				p.getValorDescuento()+" "+
				p.getIva()+" "+
				p.getDescripcion()+" "+
				p.getImg()+" "+
				p.getMarca()+" "+
				p.getCategoria())));
				break;
			case 4:
				lg.mostrarUsuario();
				break;
			case 5:
				gf.ImprimirFactura();
				break;
			case 6:
				lg.logout();
				break;

			default:
				
				break;
			}
			}while(opcion != 6);
			
	
		
		
	
 	}	
	

}
