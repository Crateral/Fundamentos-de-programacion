import java.util.ArrayList;
import java.util.Scanner;
public class Carrito {

    public static void main(String[] args) {
        String[] producto = {"-> Leche es |1| VALOR ---", "-> Queso es |2| VALOR---", "-> Yogurt es |3| VALOR---", "-> Cerdo es |4| VALOR--- ", "-> Pollo entero es |5| VALOR---"
                , "-> Carne de Res es |6| VALOR---", "-> Chocolate es |7| VALOR---" , "-> Azucar es |8| VALOR---" ,"-> Panela es |9| VALOR---" };
        Double[] precio = {5000.00, 6800.00, 3000.00, 12000.00, 30000.00, 13000.0, 5000.00, 3250.00, 2000.00 };
        String[] categoria = {"-->Lacteos " , "-->Carnes " , "-->Viveres "};
        int opcion = 0;
        double total = 0;

        ArrayList<String> carrito = new ArrayList<>();
        Scanner os = new Scanner(System.in); // para leer

        System.out.println("Welcome to FullAhorro ");
        System.out.println("Elija la Categoria: ");


        for (int i = 0; i<3; i++) {
            System.out.println("Categoria");
            System.out.println(categoria[i]);

        } for(int j=1; j<=1; j++){
            System.out.println("La categoria bebidas  es");
            System.out.println(producto[0] + "$" + precio[0]);
            System.out.println(producto[1] + "$" + precio[1]);
            System.out.println(producto[2] + "$" + precio[2]);

        } for(int k = 1; k <= 1; k++){
            System.out.println("La categoria carnes  es");
            System.out.println(producto[3] + "$" + precio[3]);
            System.out.println(producto[4] + "$" + precio[4]);
            System.out.println(producto[5] + "$" + precio[5]);

        }for(int l =1 ; l <= 1; l++){
            System.out.println("La categoria viveres  es");
            System.out.println(producto[6] + "$" + precio[6]);
            System.out.println(producto[7] + "$" + precio[7]);
            System.out.println(producto[8] + "$" + precio[8]);
        }
        System.out.println("Escoja el Numero de cada producto a comprar:");

        do {
            opcion = os.nextInt();
            switch (opcion) {

                case 1:
                    carrito.add(producto[0]);
                    total = total + precio[0];
                    break;

                case 2:
                    carrito.add(producto[1]);
                    total = total + precio[1];
                    break;

                case 3:
                    carrito.add(producto[2]);
                    total = total + precio[2];
                    break;

                case 4:
                    carrito.add(producto[3]);
                    total = total + precio[3];
                    break;

                case 5:
                    carrito.add(producto[4]);
                    total = total + precio[4];
                    break;


                case 6:
                    carrito.add(producto[5]);
                    total = total + precio[5];
                    break;

                case 7:
                    carrito.add(producto[6]);
                    total = total + precio[6];
                    break;

                case 8:
                    carrito.add(producto[7]);
                    total = total + precio[7];
                    break;

                case 9:
                    carrito.add(producto[8]);
                    total = total + precio[8];
                    break;



                case 10:

                    for (int i=0; i<carrito.size(); i++) {
                        System.out.println(carrito.get(i));
                    }
                    break;
            }
            System.out.println("Quiere comprar otro producto?");
            System.out.println(" Sino escriba 11 para realizar suma de Productos: ");
        } while (opcion !=11) ;
            System.out.println("Su pago total es: " + total);


        }


    }