package main;
import clases.Login;
import java.util.ArrayList;

import java.io.IOException;
import java.util.Collection;
import java.util.Scanner;

public class Registro {
    static Login login[] = null;

    static int cont = 0;

    public static void main(String[] args) throws IOException {
        // inicializar el arreglo
        login = new Login[3];

        //inicializar la opcion
        int option = 0;

        // menu
        do{
        System.out.println("     Menu de Opciones");
        System.out.println("---------------------------");
        System.out.println("1.- Crear  Usuario      ");
        System.out.println("2.- Buscar Usuario      ");
        System.out.println("3.- Cambio de contrasena");
        System.out.println("4.- Listar Usuario");
        System.out.println();
        System.out.println("---------------------------");
        System.out.println("Seleccione la opcion: ");
        option = Leer.datoInt();

        //sw + tab

        switch (option) {
            case 1:
                if (cont < 5) {
                    agregarUsuario();
                } else {
                    System.out.println("Usuario Registrado");
                }
                break;
            case 2:
                String id="";
                buscarUsuario(id);
                break;
            case 3:
                listarUsuario();
                break;
            case 4:
                restablecerContrasena();
                break;
            case 5:
                System.out.println("Saliendo del sistema!! Nooooooooo");
        }
    } while(option !=5);
        System.exit(0);
}




    // metodo agregar usuario
    private static void agregarUsuario() throws IOException {
        //variables locales
        String id="";
        String nombre="";
        String apellido="";
        String contrasena="";
        String estado="";

        //Lectura de datos
        System.out.println("\n");
        System.out.println("----------------------");
        System.out.println("    Crear Usuario");
        System.out.println("----------------------");

        System.out.print("Id: ");
        id = Leer.dato();

        System.out.print("Nombre: ");
        nombre = Leer.dato();

        System.out.print("Apellido: ");
        apellido = Leer.dato();

        System.out.print("Contraseña: ");
        contrasena = Leer.dato();

        System.out.print("Estado Activo o Inactivo: ");
        estado = Leer.dato();

        //mostrar datos
        System.out.println("---------------------------------------");
        System.out.println("Los Datos del Usuario registrado son: ");
        System.out.println("---------------------------------------");
        System.out.println(" Id -→" + id);
        System.out.println(" Nombre -→:" + nombre);
        System.out.println(" Apellido -→:" + apellido);
        System.out.println(" Contraseña -→" + contrasena);
        System.out.println(" Estado -→" + estado);

        //agregar los elementos a las colleccion

        Scanner leer = new Scanner(System.in);
        System.out.println("\n\n--Escriba el Id para ser comprobado:");
        int Id =leer.nextInt();
        ArrayList listado =new ArrayList();
        listado.add(id);

        if (!listado.contains(id)) {
            System.out.println("El Id ah sido registrado");
        } else {
            listado.contains(id);
            System.out.println("El Id esta registrado");
        }
        System.out.println("Lista: " + listado);



    } //lee hasta aca

//Metodo editar
    private static void editarUsuario() throws IOException{
        //variable locales
        Scanner leer = new Scanner(System.in);
        String Id;
        int pos = -1;
        int accion = 0;
        System.out.println("Ingrese el Id:" );
        Id = Leer.dato();
        pos = buscarUsuario(Id);
        if(pos >= 0){
            System.out.println("Datos: " + login[pos].toString());
            System.out.println("1.-Modificar");
            System.out.println("2.-Eliminar");
            System.out.println("Ingrese la Opcion");
            accion = Leer.datoInt();

            switch (accion){
                case 1:
                    modificarDato(pos);
                break;
                case 2:
                    eliminarDatos(pos);
                break;
                default:
                    throw new AssertionError("Opción inválida!");
            }
        }else{
            System.out.println("No esxiste registro!");
        }

}
  //metodo buscar Usuario
  private static int buscarUsuario(String id) throws IOException {
      Scanner leer = new Scanner(System.in);
      int pos = -1;
      for (int i=0; i<cont; i++){
          if (login[i].getId().equals(id)) {
              System.out.println("Registro encontrado!");
              pos = i;
          }else{
              System.out.println("Registro inexistente !?");
          }
      }
      return pos;
  }
    // metodo modificar los datos
    private static void modificarDato(int pos) throws IOException {
        // variables locables
        String Nombre = null;
        String Apellido = null;
        String Contrasena = null;
        String Estado = null;
        int opcion = 0;
        int seguir = 0;

        //condisiones
        while(seguir == 1){
            System.out.println("\n\n--Menu de Opciones");
            System.out.println("--------------------------");
            System.out.println("1.-Modificar Nombre");
            System.out.println("2.-Modificar apellido");
            System.out.println("3-Modificar Contraseña");
            System.out.println("4-Modificar Estado(Activo e Inactivo");
            opcion = Leer.datoInt();

            //manejo de condiciones

               switch (opcion) {
                   case 1:
                       System.out.print("Nombre: ");
                       Nombre = Leer.dato();
                       login[pos].setNombre(Nombre);
                       break;
                   case 2:
                       System.out.print("Apellido: ");
                       Apellido = Leer.dato();
                       login[pos].setApellido(Apellido);
                       break;
                   case 3:
                       System.out.print("Contraseña: ");
                       login[pos].setContraseña(Contrasena);
                       break;
                   case 4:
                       System.out.print("Estado: ");
                       login[pos].setEstado(Estado);
                       break;
                   default:
                       System.out.print("Opcion invalida!");
               }

            System.out.println("-------------------");
            System.out.println("1.-Seguir Modificando");
            System.out.println("2.-Salir");
            System.out.println("Ingrese la Opcion");
            seguir = Leer.datoInt();

            }
        }
    //Metodo eliminar Registro
    private static void eliminarDatos(int pos) throws IOException {

        for (int i=pos;i < cont;i++) {
            login[i] = login[ i + 1];
        }
        System.out.println("Registro Eliminado!!");
    }

    private static void listarUsuario() {
        for (int i=0; i<cont;i++){
            System.out.println("----------------------------------");
            System.out.println("\n\n\n--Registro de Usuarios");
            System.out.println("-----------------------------------");
            System.out.println(login[i].toString());
        }
    }
    //metodo registro de Usuario

    private static void restablecerContrasena() {

    }
}