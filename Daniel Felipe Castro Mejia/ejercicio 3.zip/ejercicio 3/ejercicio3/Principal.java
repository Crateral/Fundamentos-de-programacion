public class Principal {

    public static void main(String[] args) {

        Vehiculo Vehiculo = new Vehiculo("Volkswagen",15,"Furgón");
        Empleado Empleado = new Empleado("Conductor",35,"Carga")


        
        Vehiculo.mostrar();
        System.out.println("--------------------------------------------------");
        Empleado.mostrar();
        System.out.println("--------------------------------------------------");
        
    }