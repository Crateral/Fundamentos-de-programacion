//Realizar la implementacion de la estructura de un Vehiculos

public class Herencia {

    public  static  void  main ( String [] args ) {
        
        Camion  camion = nuevo  Camion ( 17, 17280, "Volkswagen", "2020");
        System.out.println(camion.getId());
        System.out.println(camion.getMarca());
        System.out.println(camion.getModelo());
        System.out.println(camion.getCapacidad());
    }
}
 
class vehiculo
{
    private int id;
    private String marca;
    private String modelo;

    public vehiculo(){  
    }   

    public Vehiculo(String marca, String modelo)
    {
        this.marca = marca;
        this.modelo = modelo;
    }

    public Vehiculo(int id, String marca, String modelo)
    {
        this.id = id;
        this.marca = marca;
        this.modelo = modelo;
    }

    public int getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public String getMarca()
    {
        return marca;
    }

    public void setMarca(String marca)
    {
        this.marca = marca;
    }

    public String getModelo()
    {
        return modelo:
    }
}