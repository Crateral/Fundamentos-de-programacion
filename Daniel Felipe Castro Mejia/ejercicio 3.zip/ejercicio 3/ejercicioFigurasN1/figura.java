public class figura
{
    private String nombre;
    private double area;
    private double perimetro;

    public figura(String n)
    {
        nombre=n;
    }
    public String getnombre()
    {
        return nombre;
    }
    public double getarea()
    {
        return area;
    }
    public double getperimetro()
    {
        return perimetro;
    }
    public void dibujar()
    {
        System.out.println("Nombre: "+this.getnombre());
        System.out.println("area: "+this.getarea());
        System.out,println("perimetro"+this.getperimetro());
    }
}
