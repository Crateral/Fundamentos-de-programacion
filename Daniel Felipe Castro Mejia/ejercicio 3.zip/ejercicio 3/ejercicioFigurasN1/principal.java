//ejercicio no 1
//Realizar la implmentacion y separacion de figuras geometricas


import java.util.Scanner;
public class Principal
{
    public static void main(String[] args)
    {
        Scanner entrada=new Scanner(System.in);
        double wlado, walt , wbas;
        System.out.print("Lado del Cuadrado........");
        wlado=entrada.nextDouble();
        System.out.print("Base del rectangulo......");
        wbas=entrada.nextDouble();
        System.out.print("Altura del rectangulo.....");
        walt=entrada.nextDouble();
        cuadrado objcuad = new cuadrado(wlado);
        rectagulo objrect = new rectagulo(walt, walt);
        objcuad.setarea();
        objcuad.setperimetro();
        objcuad.dibujar();
        objrect.setarea();
        objrect.setperimetro();
        objrect.dibujar();
    }
}