package com.co.nttdata.ecommerce.logica;

import java.util.ArrayList;
import java.util.List;

import com.co.nttdata.ecommerce.entidades.*;


public class GestionCarritoDeCompras {
	
double total = 0.0;
	public CarritoDeCompras añadirAlCarrito(CarritoDeCompras cdc, List<Producto> p) {
		
		cdc.setProductos(p);
		return cdc;
		
	}
	
	public CarritoDeCompras calcularTotalConIva(CarritoDeCompras cdc) {
		
		for (int i = 0; i < cdc.getProductos().size(); i++) {
			       //1100           2000
			total = total + cdc.getProductos().get(i).getPrecio() + 
					(cdc.getProductos().get(i).getPrecio() * 
							(cdc.getProductos().get(i).getIva())/100);
		}
		cdc.setSubTotalConIva(total);
		System.out.println(cdc.getSubTotalConIva());
		return cdc;
	}
	
	public CarritoDeCompras calcularTotalSinIva(CarritoDeCompras cdc) {
		double total =0;
		for(int i = 1; i<cdc.getProductos().size(); i++){
			total= total + cdc.getProductos().get(i).getPrecio();
			
		}
	cdc.setSubTotalSinIva(total);
	return cdc;
	}
	
	//Para el calculo del envio se debe tener en cuenta la ubicacion del cliente
		//Si se encuentra en ciudades principales se debe cobrar el 5%
		//Si se encuentra en ciudades no principales se debe cobrar el 10%
	
	public CarritoDeCompras calcularCostoEnvio(CarritoDeCompras cdc,String direccion) {
		
		
		double totalEnvio = 0, porcentaje = 0;
		
	
		if(direccion.equals("1")) {
			System.out.println("Se debe cobrar el 5% del envio Total, porque es Ciudad Principal" );
			porcentaje = 5;
		}else if(direccion.equals("2")) {
	
			System.out.println("Se debe cobrar el  10 % envio total, porque es Ciudad No  Principal");
			porcentaje = 10;
		}
		
		totalEnvio= (total * porcentaje)/100;
		cdc.setValorEnvio(totalEnvio);
		System.out.println("El valor del envio es: "+ cdc.getValorEnvio());
		return cdc;
		

	}
	
	
}
