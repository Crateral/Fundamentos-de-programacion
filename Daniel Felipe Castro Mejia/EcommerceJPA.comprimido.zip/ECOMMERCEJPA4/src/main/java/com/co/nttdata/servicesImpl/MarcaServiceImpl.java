package com.co.nttdata.servicesImpl;


import java.util.List;

import javax.jws.WebService;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.co.nttdata.daos.MarcaDao;
import com.co.nttdata.intidades.TblMarca;
import com.co.nttdata.services.MarcaService;

 
@WebService(endpointInterface = "com.co.nttdata.services.MarcaService")
public class MarcaServiceImpl  implements MarcaService{

 

    public  final String PERSISTENCE_UNIT_NAME="ECOMMERCE1JPA";
    private  EntityManagerFactory factory;

    @Override
    public TblMarca findById(int idMarca) {
        factory=Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
        EntityManager em=factory.createEntityManager();

        MarcaDao mDao=new MarcaDao(em);

        TblMarca m= new TblMarca(); 
    m= mDao.findById(idMarca);
    
    em.close();
    factory.close();
    
    return m;
    
}

	@Override
	public void update(int id, String mar, String des) {
		factory=Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
        EntityManager em=factory.createEntityManager();
        
        MarcaDao mDao=new MarcaDao(em);

        TblMarca m= new TblMarca(); 
        List<TblMarca> marcas = mDao.findAll();
        
        for (TblMarca tm : marcas) {
			m = tm;
			if(tm.getIdMarca() == id) {
				m.setMarca(mar);
				m.setDescripcion(des);
				mDao.update(m);
				 em.close();
				  factory.close();
				    
			}
		}
        
   
   
    

       }
	@Override
	public void delete(TblMarca marca) {
		factory=Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
        EntityManager em=factory.createEntityManager();
        
        
        
        
        
      
		
	}
    
    
    
    
    
}
