package com.co.nttdata.intidades;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the "TBL_EMPRESA" database table.
 * 
 */
@Entity
@Table(name="\"TBL_EMPRESA\"")
@NamedQuery(name="TblEmpresa.findAll", query="SELECT t FROM TblEmpresa t")
public class TblEmpresa implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private String nit;

	private String direccion;

	private String empresa;

	@Column(name="resolucion_dian")
	private String resolucionDian;

	private String telefono;

	public TblEmpresa() {
	}

	public String getNit() {
		return this.nit;
	}

	public void setNit(String nit) {
		this.nit = nit;
	}

	public String getDireccion() {
		return this.direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getEmpresa() {
		return this.empresa;
	}

	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}

	public String getResolucionDian() {
		return this.resolucionDian;
	}

	public void setResolucionDian(String resolucionDian) {
		this.resolucionDian = resolucionDian;
	}

	public String getTelefono() {
		return this.telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

}