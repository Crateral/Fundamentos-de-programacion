package com.co.nttdata.main;



import javax.xml.ws.Endpoint;

import com.co.nttdata.servicesImpl.CategoriaServiceImpl;
import com.co.nttdata.servicesImpl.MarcaServiceImpl;
import com.co.nttdata.servicesImpl.ProductoServiceImpl;

public class Main {
	public static void main(String[] args) {
		
		
		
    Endpoint.publish("http://localhost:3406/ecommerce/getTblMarca", new MarcaServiceImpl());
    
    
		
    Endpoint.publish("http://localhost:3408/ecommerce/getTblProducto", new ProductoServiceImpl());
	
		
		
		
		
		
	}

}
