package com.co.nttdata.intidades;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the "TBL_TIPOS_IDENTIFICACION" database table.
 * 
 */
@Entity
@Table(name="\"TBL_TIPOS_IDENTIFICACION\"")
@NamedQuery(name="TblTiposIdentificacion.findAll", query="SELECT t FROM TblTiposIdentificacion t")
public class TblTiposIdentificacion implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="\"id_tipoIdentificacion\"")
	private Integer id_tipoIdentificacion;

	@Column(name="tipo_identificacion")
	private String tipoIdentificacion;

	public TblTiposIdentificacion() {
	}

	public Integer getId_tipoIdentificacion() {
		return this.id_tipoIdentificacion;
	}

	public void setId_tipoIdentificacion(Integer id_tipoIdentificacion) {
		this.id_tipoIdentificacion = id_tipoIdentificacion;
	}

	public String getTipoIdentificacion() {
		return this.tipoIdentificacion;
	}

	public void setTipoIdentificacion(String tipoIdentificacion) {
		this.tipoIdentificacion = tipoIdentificacion;
	}

}