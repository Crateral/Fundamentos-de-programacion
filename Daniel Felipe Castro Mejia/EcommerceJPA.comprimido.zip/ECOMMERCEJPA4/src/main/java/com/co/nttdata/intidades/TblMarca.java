package com.co.nttdata.intidades;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the "TBL_MARCA" database table.
 * 
 */
@Entity
@Table(name="\"TBL_MARCA\"")
@NamedQuery(name="TblMarca.findAll", query="SELECT t FROM TblMarca t")
public class TblMarca implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="id_marca")
	private Integer idMarca;

	private String descripcion;

	private String marca;

	public TblMarca() {
	}

	public Integer getIdMarca() {
		return this.idMarca;
	}

	public void setIdMarca(Integer idMarca) {
		this.idMarca = idMarca;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getMarca() {
		return this.marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

}