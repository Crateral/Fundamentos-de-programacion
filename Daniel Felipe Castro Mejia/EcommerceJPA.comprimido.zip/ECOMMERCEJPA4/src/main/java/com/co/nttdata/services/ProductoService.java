package com.co.nttdata.services;

import javax.jws.WebMethod;
import javax.jws.WebService;

import com.co.nttdata.intidades.*;

@WebService
public interface ProductoService {
	@WebMethod
	 public TblProducto findById(int idProducto);
	

}
