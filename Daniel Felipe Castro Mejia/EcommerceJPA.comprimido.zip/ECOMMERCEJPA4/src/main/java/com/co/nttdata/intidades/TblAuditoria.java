package com.co.nttdata.intidades;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the "TBL_AUDITORIA" database table.
 * 
 */
@Entity
@Table(name="\"TBL_AUDITORIA\"")
@NamedQuery(name="TblAuditoria.findAll", query="SELECT t FROM TblAuditoria t")
public class TblAuditoria implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="id_admin")
	private Integer idAdmin;

	private String accion;

	private String descripcion;

	private String documento;

	@Temporal(TemporalType.DATE)
	@Column(name="fecha_accion")
	private Date fechaAccion;

	private String ip;

	private String resultado;

	private String usuario;

	public TblAuditoria() {
	}

	public Integer getIdAdmin() {
		return this.idAdmin;
	}

	public void setIdAdmin(Integer idAdmin) {
		this.idAdmin = idAdmin;
	}

	public String getAccion() {
		return this.accion;
	}

	public void setAccion(String accion) {
		this.accion = accion;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getDocumento() {
		return this.documento;
	}

	public void setDocumento(String documento) {
		this.documento = documento;
	}

	public Date getFechaAccion() {
		return this.fechaAccion;
	}

	public void setFechaAccion(Date fechaAccion) {
		this.fechaAccion = fechaAccion;
	}

	public String getIp() {
		return this.ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getResultado() {
		return this.resultado;
	}

	public void setResultado(String resultado) {
		this.resultado = resultado;
	}

	public String getUsuario() {
		return this.usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

}