package com.co.nttdata.services;

import javax.jws.WebMethod;
import javax.jws.WebService;

import com.co.nttdata.intidades.TblMarca;


@WebService
public interface MarcaService {
	@WebMethod
	
	   public TblMarca findById(int idMarca);
	
	   public void update(int id, String mar, String des );
	   
	   public void delete(TblMarca marca);
	
	
	}
