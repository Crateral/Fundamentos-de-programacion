package com.co.nttdata.servicesImpl;

import javax.jws.WebService;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.co.nttdata.daos.MarcaDao;
import com.co.nttdata.daos.ProductoDao;
import com.co.nttdata.intidades.TblMarca;
import com.co.nttdata.intidades.TblProducto;
import com.co.nttdata.services.ProductoService;


@WebService(endpointInterface = "com.co.nttdata.services.ProductoService")
public class ProductoServiceImpl implements ProductoService{
	
	
	 public  final String PERSISTENCE_UNIT_NAME="ECOMMERCE1JPA";
	    private  EntityManagerFactory factory;

	@Override
	public TblProducto findById(int idProducto) {
		
		 factory=Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
	        EntityManager em=factory.createEntityManager();
	        
	       ProductoDao pDao=new ProductoDao(em);

	        TblProducto m= new TblProducto(); 
	    m= pDao.findById(idProducto);
	    
	    em.close();
	    factory.close();
	    
	    return m;
		
	}

}
