package com.co.nttdata.daos;

import javax.persistence.EntityManager;

import com.co.nttdata.intidades.TblCliente;
import com.co.nttdata.intidades.TblMarca;

public class ClienteDao {
	private EntityManager entityManager;
    //private Object object;


	  public ClienteDao(EntityManager entityManager) {
		
			this.entityManager = entityManager;
		}
   


    public void create(TblCliente cliente) {
        entityManager.getTransaction().begin();
        entityManager.persist(cliente);
        entityManager.getTransaction().commit();


   }
 
//encontrar por id
    public TblCliente findById(int id_cliente) {
       return entityManager.find(TblCliente.class,id_cliente);
   }

    //actualizar

    public void update(TblCliente cliente) {
       entityManager.getTransaction().begin();
       entityManager.merge(cliente);
       entityManager.getTransaction().commit();
   }


    //eliminar

    public void delete(TblCliente cliente) {
       entityManager.getTransaction().begin();
       entityManager.remove(cliente);
       entityManager.getTransaction().commit();
		
		
	}

}
