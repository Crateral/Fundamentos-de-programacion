package com.co.nttdata.intidades;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the "TBL_CARRITO_DE_COMPRAS" database table.
 * 
 */
@Entity
@Table(name="\"TBL_CARRITO_DE_COMPRAS\"")
@NamedQuery(name="TblCarritoDeCompra.findAll", query="SELECT t FROM TblCarritoDeCompra t")
public class TblCarritoDeCompra implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="id_carrito")
	private Integer idCarrito;

	@Temporal(TemporalType.DATE)
	private Date fecha;

	@Column(name="subtotal_con_iva")
	private double subtotalConIva;

	@Column(name="subtotal_sin_iva")
	private double subtotalSinIva;

	@Column(name="valor_descuento")
	private double valorDescuento;

	@Column(name="valor_envio")
	private double valorEnvio;

	@Column(name="valor_iva")
	private double valorIva;

	public TblCarritoDeCompra() {
	}

	public Integer getIdCarrito() {
		return this.idCarrito;
	}

	public void setIdCarrito(Integer idCarrito) {
		this.idCarrito = idCarrito;
	}

	public Date getFecha() {
		return this.fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public double getSubtotalConIva() {
		return this.subtotalConIva;
	}

	public void setSubtotalConIva(double subtotalConIva) {
		this.subtotalConIva = subtotalConIva;
	}

	public double getSubtotalSinIva() {
		return this.subtotalSinIva;
	}

	public void setSubtotalSinIva(double subtotalSinIva) {
		this.subtotalSinIva = subtotalSinIva;
	}

	public double getValorDescuento() {
		return this.valorDescuento;
	}

	public void setValorDescuento(double valorDescuento) {
		this.valorDescuento = valorDescuento;
	}

	public double getValorEnvio() {
		return this.valorEnvio;
	}

	public void setValorEnvio(double valorEnvio) {
		this.valorEnvio = valorEnvio;
	}

	public double getValorIva() {
		return this.valorIva;
	}

	public void setValorIva(double valorIva) {
		this.valorIva = valorIva;
	}

}