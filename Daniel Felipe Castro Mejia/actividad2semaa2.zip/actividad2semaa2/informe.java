import java.util.Arrays;

public class Informe {
    public final String[] tareas={"administrativo", "empresarial" ,"personal"};

    private int codigo;
    private String tarea;

    public Informe() {
    }

    public String[] getTareas() {
        return tareas;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getTarea() {
        return tarea;
    }

    public void setTarea(String tarea) {
        this.tarea = tarea;
    }

    @Override
    public String toString() {
        return "Informe{" +
                "tareas=" + Arrays.toString(tareas) +
                ", codigo=" + codigo +
                ", tarea='" + tarea + '\'' +
                '}';
    }
}