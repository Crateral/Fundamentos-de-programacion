package com.co.nttdata.ecommerce.logica;
import java.net.URI;
import java.util.*;

import com.co.nttdata.ecommerce.entidades.*;
import com.co.nttdata.ecommerce.interfaces.GestionLogin;
import com.co.nttdata.ecommerce.interfaces.GestionCarritoDeCompras;

public class GestionLoginImpl implements GestionLogin{
	
	Scanner teclado = new Scanner(System.in);
	Cliente cliente = new Cliente();
	
	

	public Usuario registrar(String nombreUsuario, String contrasenia, Ciudades ciudad, String numeroIdentificacion,String tipoIdentificacion,
			String telefono, String direccion, String estado, String metodoDePago) {
		
		Cliente usr = new Cliente();
		
		usr.setNombreUsuario(nombreUsuario);
		usr.setContrasenia(contrasenia);
		usr.setCiudad(ciudad);
		usr.setNumeroIdentificacion(numeroIdentificacion);
		usr.setTipoIdentificacion(tipoIdentificacion);
		usr.setTelefono(telefono);
		usr.setDireccion(direccion);
		usr.setEstado(true);
		usr.setEstado(false);
		usr.setMetodoDePago(metodoDePago);
		
		System.out.println("Resgitro de Usuario");
		System.out.println("🧾-----------------------------🧾");
		System.out.println("Ingrese el Nombre del Usuario: ");
		nombreUsuario =teclado.next();
		
		System.out.println("Ingrese la contraseña:");
		contrasenia = teclado.next();
		
		System.out.println("Escoja la Ciudad:" +"\n"+"1-Facatativa no Principal"+"\n"+"2-Bogota-Principal");
		String opcion;
		opcion = teclado.next();
		if (opcion.equals("1")) {
			System.out.println("La ciudad es "+Ciudades.FACATATIVA + ", es ciudad no Principal");
		}else if (opcion.equals("2")) {
			System.out.println("La ciudad es " + Ciudades.BOGOTA +", es ciudad Principal");
		}
		
		System.out.println("Escoja el tipo de identificacion: "+"\n"+"1- CC"+"\n"+"2- TI"+"\n"+"3- CEx" );
		tipoIdentificacion = teclado.next();
		if (tipoIdentificacion.equals("1")) {
			System.out.println("El tipo de Indentificacion es Cedula de Ciudadania");
		}else if (tipoIdentificacion.equals("2")) {
			System.out.println("El tipo de Indentificacion es Tarjeta de Identidad");
		}else if (tipoIdentificacion.equals("3")) {
			System.out.println("El tipo de Indentificacion es Cedula Extranjera");
		}
		
		System.out.println("Ingrese el numero de Identificacion: ");
		numeroIdentificacion = teclado.next();
		
		System.out.println("Ingrese la Direccion: ");
		direccion = teclado.next();
		
		System.out.println("Escoja el estado true o false: ");
		estado = teclado.next();
		if (estado.equals("true")) {
			System.out.println(estado);
		}else if (estado.equals("false")) {
			System.out.println(estado);
		} 
		
		System.out.println("Escoja el Metodo de Pago: "+"\n"+"1- Contado"+"\n"+"2- Efectico"+"\n"+"3- Tarjetas Debito o Credito");
		metodoDePago = teclado.next();
		if (metodoDePago.equals("1")) {
			System.out.println("Metodo de Pago Contado" );
		}else if (metodoDePago.equals("2")) {
			System.out.println("Metodo de Pago Efectivo");
		}else if (metodoDePago.equals("3")) {
			System.out.println("Metodo de Pago Tarjetas Debito o Credito");
		}
		return usr;
	
	}
	
	@Override
	public Usuario ingreso(String nombreUsuario, String contrasenia) {
		
		int u = 0, c = 0;
		
		Usuario ur = new Usuario();
		ur.setNombreUsuario(nombreUsuario);
		ur.setContrasenia(contrasenia);
		
		System.out.println("Bienvenido al IMALAHIA");
		do{
			System.out.println("Ingrese el nombre del Usuario: ");
			nombreUsuario = teclado.nextLine();
			if (ur.getNombreUsuario().equals(nombreUsuario)) {
				System.out.println("Usuario Correcto!");
				break ;
			}else {
				System.out.println("El usuario es incorrecto!"+"\n"+"Vuelvalo a intentar!!☻☠");
				
			}
			
		}while(u <= 3);
			
		 do{
			System.out.println("Ingrese la contraseña: ");
			contrasenia = teclado.nextLine();
			if (ur.getContrasenia().equals(contrasenia)) {
				System.out.println("Contraseña Correcta!");
				break;
			}else {
				System.out.println("La contraseña es incorrecta!"+"\n"+"Vuelvalo a intentar!!☻☠");
			}
			
		}while(u <= 3);
		
		System.out.println("Bienvenido "+ur.getNombreUsuario()+" al Sistema ECOMMERCE");
		return ur;
	}
	

	@Override
	public Usuario logout() {
		System.out.println("Salida del sistema exitoso");
		
		return null;
	}

	@Override
	public Usuario cambioContraseña(String contrasenia) {
		Usuario cc = new Usuario();
		String opcion;
		System.out.println("Desea cambiar contraseña? si/no");
		opcion = teclado.next();
		if(opcion.equals("si")){
			System.out.println("Escriba la nueva contraseña: ");
			contrasenia = teclado.nextLine();
			System.out.println("Contraseña guardada con Exito"+"\n"+"La nueva contraseña es: "+ contrasenia);	
		}else if (opcion.equals("no")) {
			System.out.println("No desea cambiar contraseña");
			
		}
		
		return null;
	}

	@Override
	public Usuario mostrarRegistro(String nombreUsuario, String contrasenia, Ciudades ciudad,
			String numeroIdentificacion, String tipoIdentificacion, String telefono, String direccion, String estado,
			String metodoDePago) {
		
		return cliente;
	}
	

	
	
}
