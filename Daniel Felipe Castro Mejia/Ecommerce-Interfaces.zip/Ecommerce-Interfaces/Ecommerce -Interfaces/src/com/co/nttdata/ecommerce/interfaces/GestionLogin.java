package com.co.nttdata.ecommerce.interfaces;

import com.co.nttdata.ecommerce.entidades.Ciudades;
import com.co.nttdata.ecommerce.entidades.Usuario;

public interface GestionLogin {
	
	public Usuario registrar(String nombreUsuario, String contrasenia, Ciudades ciudad, String numeroIdentificacion,String tipoIdentificacion, String telefono, String direccion, 
			String estado, String metodoDePago);
	
	public Usuario mostrarRegistro(String nombreUsuario, String contrasenia, Ciudades ciudad, String numeroIdentificacion,String tipoIdentificacion, String telefono, String direccion, 
			String estado, String metodoDePago);
	public Usuario ingreso(String nombreUsuario, String contrasenia);
	
	public Usuario logout();
	
	public Usuario cambioContraseña(String contrasenia);
	
}
