//Crear un arreclo con los giuientes valores:
	//2,4,6,6,19,3,1,0,5,2,9
	//2.1 Eliminar los números duplicados
	//2.2 Ordenar el arreglo sin duplicador de menor a mayor
	//2.3 Ordenar el arreglo sin duplicados de mayor a menor

public class Punto2 {

    public static void main(String[] args) {

        int[] numeros = {2, 4, 6, 6, 19, 3, 1, 0, 5, 2, 9};
        int [] b=new int[numeros.length];
        int j, top=0;
        boolean repetido;
        Arrays.sort(numeros);

        for (int i=0; i< numeros.length;i++){
                repetido=false;
                j=0;
                while (!repetido &&(j<top)){
                    if (numeros[i] == b[j]){
                    repetido=true;
                    }
                j++;
                }
                if (!repetido){
                    b[top] = numeros[i];
                    top++;
                }
        }

        System.out.print("Lista de numeros: ");
        for (int i=0; i< numeros.length;i++){
            System.out.print(numeros[i] + " ");
        }
        System.out.println(" ");

        System.out.print("Numeros sin repetir forma Ascendentes : ");

        for (int i=0; i< top;i++){
            System.out.print(b[i] + " ");
        }
        System.out.println(" ");
        System.out.print("Numeros sin repetir forma Descendente : ");

        for (int i=top; i>=0;i--){
            System.out.print(b[i] + " ");
        }

    }