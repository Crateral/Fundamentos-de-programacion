package ejercicio2;

public class Exerc1 {

    public static void main(String[] args) {

        int[] numbers = {2, 4, 6, 6, 19, 3, 1, 0, 5, 2, 9};
        int numbers1[] = new int[numbers.length];
        int time;
        int k,top = 0;
        boolean repeat;
        
        //comprobando si hay numeros o datos repetidos dentro de un arreglo
        for(int i = 0; i < numbers.length; i++){
            repeat = false;
            k = 0;
            while(!repeat && (k<top)){
                if(numbers[i] == numbers1[k]){
                    repeat = true;
                }
                k++;
            }
            if(!repeat){
                numbers1[top] = numbers[i];
                top++;
            }
        }
        System.out.print("Arreglo sin numeros repetidos: ");
        for(int i = 0; i < top; i++){
            System.out.println(numbers1[i]);
           
        }
        for (int i = 0; i < numbers1.length; i++) {
            for (int j = 1; j < (numbers1.length - i); j++) {
                if (numbers1[j - 1] > numbers1[j]) {
                    time = numbers1[j - 1];
                    numbers1[j - 1] = numbers1[j];
                    numbers1[j] = time;
                }
            }
        }
        System.out.println("\nArreglo ordenado en forma creciente: ");
        for (int i = numbers1.length - top; i < numbers1.length; i++) {
            System.out.println(numbers1[i]);
        }
        System.out.println("\nArreglo ordenado de forma decreciente: ");
        for (int i = (numbers1.length - 1); i >= numbers1.length - top; i--) {
            System.out.println(numbers1[i]);
        }
        
  }

}
