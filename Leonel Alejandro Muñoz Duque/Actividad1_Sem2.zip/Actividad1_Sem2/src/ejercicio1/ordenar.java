
package ejercicio1;

public class ordenar {
    public static void main(String[] args) {
        int[] numeros = {7, 4, 2, 1, 10, 5, 6};
        int time = 0;

        //Metodo burbuja
        for (int i = 0; i < numeros.length; i++) {
            for (int j = 1; j < (numeros.length - i); j++) {
                if (numeros[j - 1] > numeros[j]) {
                    time = numeros[j - 1];
                    numeros[j - 1] = numeros[j];
                    numeros[j] = time;
                }
            }
        }
        System.out.println("\nArreglo ordenado en forma creciente: ");
        for (int i = 0; i < numeros.length; i++) {
            System.out.println(numeros[i]);
        }
        System.out.println("\nArreglo ordenado de forma decreciente: ");
        for (int i = (numeros.length - 1); i >= 0; i--) {
            System.out.println(numeros[i]);
        }
    }
}
