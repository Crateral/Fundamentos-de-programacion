CREATE DATABASE semillero1;
USE semillero1;
CREATE TABLE estudiantes(
	id_alum int auto_increment not null,
    nom_alum varchar(30) not null,
    ape_alum varchar(30),
    edad_alum int not null,
    CONSTRAINT pk_id_alum PRIMARY KEY (id_alum)
);

CREATE TABLE profesores(
	id_prof int auto_increment not null,
	nom_prof varchar(30) not null,
    ape_prof varchar(30) not null,
    sal_prof int,
    mat_prof varchar(20),
    CONSTRAINT pk_id_prof PRIMARY KEY (id_prof)
);

CREATE TABLE clases(
	id_clase int,
    nom_clase varchar(20),
    hr_sem_clase float,
    sal_clase int,
    CONSTRAINT pk_id_clas PRIMARY KEY (id_clase)
);

CREATE TABLE notas(
	id_alum1 int,
    id_prof1 int,
    id_clase1 int,
    nota_materia float,
    CONSTRAINT fk_id_alum FOREIGN KEY (id_alum1) REFERENCES estudiantes(id_alum),
    CONSTRAINT fk_id_prof FOREIGN KEY (id_prof1) REFERENCES profesores(id_prof),
    CONSTRAINT fk_id_clas FOREIGN KEY (id_clase1) REFERENCES clases(id_clase)
);

INSERT INTO estudiantes (nom_alum, ape_alum, edad_alum) VALUES ('Carlos', 'Cucaita', 13);
INSERT INTO estudiantes (nom_alum, ape_alum, edad_alum) VALUES ('Laura', 'Guzman', 12);
INSERT INTO estudiantes (nom_alum, ape_alum, edad_alum) VALUES ('George', 'Marin', 13);
INSERT INTO estudiantes (nom_alum, ape_alum, edad_alum) VALUES ('Catalina', 'Rey', 11);

INSERT INTO profesores (nom_prof, ape_prof, sal_prof, mat_prof) VALUES ('Julio', 'Ramirez', 3086, 'Biologia');
INSERT INTO profesores (nom_prof, ape_prof, sal_prof, mat_prof) VALUES ('Patricia', 'Galvis', 3087, 'Matematicas');
INSERT INTO profesores (nom_prof, ape_prof, sal_prof, mat_prof) VALUES ('Paola', 'Avila', 3088, 'Sociales');
INSERT INTO profesores (nom_prof, ape_prof, sal_prof, mat_prof) VALUES ('Marcela', 'Bohorquez', 3089, 'Informatica');

INSERT INTO clases (id_clase, nom_clase, hr_sem_clase, sal_clase) VALUES (9102, 'Biologia', 8.5, 305);
INSERT INTO clases (id_clase, nom_clase, hr_sem_clase, sal_clase) VALUES (9103, 'Sociales', 8.0, 107);
INSERT INTO clases (id_clase, nom_clase, hr_sem_clase, sal_clase) VALUES (9101, 'Matematicas', 12, 201);
INSERT INTO clases (id_clase, nom_clase, hr_sem_clase, sal_clase) VALUES (9205, 'Informatica', 12, 501);

INSERT INTO notas (id_alum1, id_prof1, id_clase1, nota_materia) VALUES (1, 1, 9102, 4.2);
INSERT INTO notas (id_alum1, id_prof1, id_clase1, nota_materia) VALUES (3, 4, 9205, 4.8);
