interface Cliente {

    public void registro();
    public void rutina();
}
