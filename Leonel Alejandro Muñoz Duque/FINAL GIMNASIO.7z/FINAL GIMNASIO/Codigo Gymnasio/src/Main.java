import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int opc1 = 0, telefono = 0, opc2 = 0;
        String salto = "", nombre = "", apellido = "", email, ciudad, direccion, user, pass;

        Scanner entrada = new Scanner(System.in);
        List<User> Registro = new ArrayList<>();

        do{
            System.out.println("********************************");
            System.out.println("*******SmartGymApp-SGA**********");
            System.out.println("********************************");
            System.out.println(" ");
            System.out.println("Elige la opcion a realizar" + "\t\t\t 1. Iniciar sesion \n\t\t\t\t\t\t\t\t\t 2. Registrar Usuario \n\t\t\t\t\t\t\t\t\t 3. Recuperar contraseña");
            System.out.println("____________________________________");

            System.out.print("Ingresa tu opcion: ");
            opc1 = entrada.nextInt();
            System.out.println();
            System.out.println("____________________");

            switch (opc1){
                case 1:
                    System.out.println("*********************");
                    System.out.println("   INICIAR SESION");
                    System.out.println("**********************");
                    System.out.println(" ");
                    System.out.println("Ingresa tus credenciales");
                    System.out.println(" ");
                    salto = entrada.nextLine();
                    System.out.println("Usuario: ");
                    user = entrada.nextLine();
                    System.out.println("Contrasena: ");
                    pass = entrada.nextLine();

                    for(User ingreso: Registro){
                        if(ingreso.getNomUser().equals(user) && ingreso.getContrasena().equals(pass)){
                            System.out.println("*************************");
                            System.out.println("INICIO DE SESION EXITOSO");
                            System.out.println("**************************");
                            System.out.println("Bienvenido a SMARTGYMAPP");
                            do{
                                System.out.println("");
                                System.out.println("¡Hola" + Registro.get(0).getNombreCli() + "!");
                                System.out.println("");
                                System.out.println("Slecciona una opcion: ");
                                System.out.println("\t\t\t 1. Crear rutina");
                                System.out.println("\t\t\t 2. Guardar registro avance");
                                System.out.println("\t\t\t 3. Guardar informacion ectomorfica");
                                System.out.println("\t\t\t 4. Modificar horario");
                                System.out.println("\t\t\t 5. Atras");

                            }while (opc2 == 5);
                        }
                    }



                case 2:
                    User cli = new User();

                    System.out.println("*********************");
                    System.out.println(" REGISTRO DE USUARIO");
                    System.out.println("*********************");

                    System.out.println("");
                    salto = entrada.nextLine();

                    System.out.println("Ingresa tu nombre: ");
                    nombre = entrada.nextLine();
                    cli.setNombreCli(nombre);

                    System.out.println("Ingresa tu apellido: ");
                    apellido = entrada.nextLine();
                    cli.apellidoCli(apellido);

                    System.out.println("Ingrea tu email: ");
                    email = entrada.nextLine();
                    cli.setEmailCli(email);

                    System.out.println("Ingresa ciudad de residencia: ");
                    ciudad = entrada.nextLine();
                    cli.setCiudadCli(ciudad);

                    System.out.println("Ingresa la direccion de tu inmueble: ");
                    direccion = entrada.nextLine();
                    cli.setDireccionCli(direccion);

                    System.out.println("Ingresa el numero de tu linea celular: ");
                    telefono = entrada.nextInt();
                    cli.setTelefonoCli(telefono);

                    salto = entrada.nextLine();

                    System.out.println("Ingresa el nombre de usuario: ");
                    user = entrada.nextLine();
                    cli.setNomUser(user);

                    System.out.println("Ingresa tu contrasena: ");
                    pass = entrada.nextLine();
                    cli.setContrasena(pass);

                    Registro.add(cli);

                    System.out.println("Deseas volver al menu anterior. 1. Si   2. NO");

                    while (opc1 == 1);


            }
        }while(opc1 != 1);
    }
}