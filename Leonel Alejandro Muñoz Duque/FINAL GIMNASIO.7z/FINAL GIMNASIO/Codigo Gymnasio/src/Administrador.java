public interface Administrador {

    default void login(){

    }

}
