public class User implements Cliente, Coach, Administrador{
    private int ID;
    private String nombre;
    private String apellido;
    private String direccion;
    private int telefono;
    private String ciudad;
    private String email;

    //atributosCliente
    String nombreCli, apellidoCli, direccionCli, ciudadCli, emailCli, maquina, ejercicio, nomUser, contrasena;
    int telefonoCli, seg, series;

    //atributosCoach
    String nombreCoach, apellidoCoach, direccionCoach, ciudadCoach, emailCoach;
    int telefonoCoach;

    //atributos administrador

    String nombreAdmin, userAdmin, passAdmin;

    public User(){

    }

    public User(int ID, String nombre, String apellido, int telefono){
        this.ID = ID;
        this.nombre = nombre;
        this.apellido = apellido;
        this.telefono = telefono;
    }
    public void registro(String nombreCli, String apellidoCli, String direccionCli, String ciudadCli, String emailCli, int telefonoCli, String nomUser, String contrasena){
        this.nombreCli = nombreCli;
        this.apellidoCli = apellidoCli;
        this.direccionCli = direccionCli;
        this.ciudadCli = ciudadCli;
        this.emailCli = emailCli;
        this.telefonoCli = telefonoCli;
        this.nomUser = nomUser;
        this.contrasena = contrasena;

    }
    public void rutina(String maquina, String ejercicio, int seg, int series){
        this.maquina = maquina;
        this.ejercicio = ejercicio;
    }

    public void login(String nombreAdmin, String userAdmin, String passAdmin){
        this.nombreAdmin = nombreAdmin;
        this.userAdmin = userAdmin;
        this.passAdmin = passAdmin;

    }

    public String getNombreAdmin() {
        return nombreAdmin;
    }

    public void setNombreAdmin(String nombreAdmin) {
        this.nombreAdmin = nombreAdmin;
    }

    public String getUserAdmin() {
        return userAdmin;
    }

    public void setUserAdmin(String userAdmin) {
        this.userAdmin = userAdmin;
    }

    public String getPassAdmin() {
        return passAdmin;
    }

    public void setPassAdmin(String passAdmin) {
        this.passAdmin = passAdmin;
    }

    public int getID() {

        return ID;
    }

    public void setID(int ID) {

        this.ID = ID;
    }

    public String getNombre() {

        return nombre;
    }

    public void setNombre(String nombre) {

        this.nombre = nombre;
    }

    public String getApellido() {

        return apellido;
    }

    public void setApellido(String apellido) {

        this.apellido = apellido;
    }

    public String getDireccion() {

        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public int getTelefono() {

        return telefono;
    }

    public void setTelefono(int telefono) {

        this.telefono = telefono;
    }

    public String getCiudad() {

        return ciudad;
    }

    public void setCiudad(String ciudad) {

        this.ciudad = ciudad;
    }

    public String getEmail() {

        return email;
    }

    public void setEmail(String email) {

        this.email = email;
    }

    public String getNombreCli() {

        return nombreCli;
    }

    public String getNomUser(){
        return nomUser; }

    public void setNomUser(String nomUser) {
        this.nomUser = nomUser;
    }

    public String getContrasena(){
        return contrasena;
    }

    public void setContrasena(String contrasena){
        this.contrasena = contrasena;
    }

    public void setNombreCli(String nombreCli) {
        this.nombreCli = nombreCli;
    }

    public String getApellidoCli() {
        return apellidoCli;
    }

    public void setApellidoCli(String apellidoCli) {
        this.apellidoCli = apellidoCli;
    }

    public String getDireccionCli() {
        return direccionCli;
    }

    public void setDireccionCli(String direccionCli) {
        this.direccionCli = direccionCli;
    }

    public String getCiudadCli() {
        return ciudadCli;
    }

    public void setCiudadCli(String ciudadCli) {
        this.ciudadCli = ciudadCli;
    }

    public String getEmailCli() {
        return emailCli;
    }

    public void setEmailCli(String emailCli) {
        this.emailCli = emailCli;
    }

    public String getMaquina() {
        return maquina;
    }

    public void setMaquina(String maquina) {
        this.maquina = maquina;
    }

    public String getEjercicio() {

        return ejercicio;
    }

    public void setEjercicio(String ejercicio) {

        this.ejercicio = ejercicio;
    }

    public int getTelefonoCli() {

        return telefonoCli;
    }

    public void setTelefonoCli(int telefonoCli) {

        this.telefonoCli = telefonoCli;
    }

    public int getSeg() {

        return seg;
    }

    public void setSeg(int seg) {

        this.seg = seg;
    }

    public int getSeries() {

        return series;
    }

    public void setSeries(int series) {
        this.series = series;
    }

    public String getNombreCoach() {
        return nombreCoach;
    }

    public void setNombreCoach(String nombreCoach) {

        this.nombreCoach = nombreCoach;
    }

    public String getApellidoCoach() {

        return apellidoCoach;
    }

    public void setApellidoCoach(String apellidoCoach) {

        this.apellidoCoach = apellidoCoach;
    }

    public String getDireccionCoach() {

        return direccionCoach;
    }

    public void setDireccionCoach(String direccionCoach) {

        this.direccionCoach = direccionCoach;
    }

    public String getCiudadCoach() {

        return ciudadCoach;
    }

    public void setCiudadCoach(String ciudadCoach) {

        this.ciudadCoach = ciudadCoach;
    }

    public String getEmailCoach() {

        return emailCoach;
    }

    public void setEmailCoach(String emailCoach) {

        this.emailCoach = emailCoach;
    }

    public int getTelefonoCoach() {

        return telefonoCoach;
    }

    public void setTelefonoCoach(int telefonoCoach) {

        this.telefonoCoach = telefonoCoach;
    }

    @Override
    public void rutina() {

        throw new UnsupportedOperationException();
    }

    @Override
    public void registro() {

        throw new UnsupportedOperationException();
    }
    @Override
    public void login() {
        Administrador.super.login();
    }
    public void apellidoCli(String apellido) {
    }
}
