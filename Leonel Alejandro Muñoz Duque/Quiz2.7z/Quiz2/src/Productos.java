public class Productos implements Comparable<Productos> {

    private Integer cod_prod;
    private String nom_prod;
    private String tip_prod;
    private Integer cant_produc;
    private Integer valor_prod;

    public Integer getCod_prod() {
        return cod_prod;
    }

    public void setCod_prod(Integer cod_prod) {
        this.cod_prod = cod_prod;
    }

    public String getNom_prod() {
        return nom_prod;
    }

    public void setNom_prod(String nom_prod) {
        this.nom_prod = nom_prod;
    }

    public String getTip_prod() {
        return tip_prod;
    }

    public void setTip_prod(String tip_prod) {
        this.tip_prod = tip_prod;
    }

    public Integer getCant_produc() {
        return cant_produc;
    }

    public void setCant_produc(Integer cant_produc) {
        this.cant_produc = cant_produc;
    }

    public Integer getValor_prod() {
        return valor_prod;
    }

    public void setValor_prod(Integer valor_prod) {
        this.valor_prod = valor_prod;
    }

    @Override
    public String toString() {
        return "Productos{" +
                "Codigo del producto = " + cod_prod +
                ", Nombre del producto = " + nom_prod + '\'' +
                ", Tipo de producto = '" + tip_prod + '\'' +
                ", Cantidad = " + cant_produc +
                ", Precio producto=" + valor_prod +
                '}';
    }


    @Override
    public int compareTo(Productos o) {
        return nom_prod.compareTo(o.getNom_prod());
    }
}


