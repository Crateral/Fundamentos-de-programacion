import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {

        List<Productos> lis_produc = new ArrayList<>();
        Scanner entrada = new Scanner(System.in);



        boolean salir = false;
        int opcion;
        do {
            System.out.println("Escoja una opcion del menu: ");
            System.out.println("1. Añadir productos.");
            System.out.println("2. Consultar productos. ");
            System.out.println("3. Ordenar productos. ");

            opcion = entrada.nextInt();

        }while(salir != false);
            switch(opcion){
                case 1:
                    System.out.println("Numero de productos a registrar:" );
                    int cant = entrada.nextInt();
                    String nom_pro;
                    String tip_pro;
                    int i;
                    for(i = 0; i< cant ; i++){
                        Productos produ = new Productos();

                        System.out.println("Ingresa codigo del producto");
                        int codeProd = entrada.nextInt();
                        produ.setCod_prod(codeProd);

                        System.out.println("Ingresa el nombre del producto");
                        String nomProd = entrada.nextLine();
                        produ.setNom_prod(nomProd);

                        System.out.println("Ingresa el tipo de producto");
                        String tipProd = entrada.nextLine();
                        produ.setTip_prod(tipProd);

                        System.out.println("Ingresa el numero de unidades de producto");
                        int canProd = entrada.nextInt();
                        produ.setCant_produc(canProd);

                        System.out.println("Ingresa el valor del producto");
                        int valProd = entrada.nextInt();
                        produ.setValor_prod(valProd);

                        //Agregamos la lista al array
                        lis_produc.add(produ);

                    return;

                        }


                case 2:
                    for(Productos pro: lis_produc){
                        System.out.println("Codigo: " + pro.getCod_prod());
                        System.out.println("Nombre: " + pro.getNom_prod());
                        System.out.println("Tipo: " + pro.getTip_prod());
                        System.out.println("Cantidad: " + pro.getCant_produc());
                        System.out.println("Valor: " + pro.getValor_prod());
                    }

                        System.out.println("");
                        break;
                case 3:
                    System.out.println("Productos ordenados por nombre: ");
                    Collections.sort(lis_produc);

                    break;
                default:
                    System.out.println("El numero ingresado no es valido");
                }

        }
    }



