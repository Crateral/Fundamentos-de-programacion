package FinPlant;

import main.Arboles;
import main.Arbustos;
import main.Hierbas;
import main.Matas;

public  abstract class DatPlant {

    public static void main(String[] args) {

        Hierbas herb = new Hierbas(450, "infundibuliforme", "Baya") {};
        System.out.println(herb);
               
               
        Matas mat = new Matas(350, "Bilabiada", "Peponide") {
            @Override
            public void vida(int siembra, int fin) {
                System.out.println("");
            }
        };
        System.out.println(mat);
        for (int year = 0; year <= 345; year++) {
        System.out.println(year);
    }
        System.out.println(" ");
        
        Arbustos arb = new Arbustos(350, "Bilabiada", "Peponide") {
            @Override
            public void vida(int siembra, int fin) {
                throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            }
        };
        System.out.println(arb);
        for (int year = 0; year <= 345; year++) {
        System.out.println(year);
    }
        System.out.println(" ");
        
        Arboles arbo = new Arboles("Sequoia", "Pinopsida", 135, "Sequoia", "Peponide") {};
        System.out.println(arbo);
        for (int year = 0; year <= 345; year++) {
        System.out.println(year);
    }
    }
}
