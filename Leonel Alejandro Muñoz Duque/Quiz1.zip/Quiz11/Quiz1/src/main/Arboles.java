package main;

public abstract class Arboles extends Planta {
    protected String nombre;
    protected String clase;
    
    @Override
    public void vida(int siembra, int fin){
        
    }
    
    public Arboles(){
        
    }
    
    public Arboles(String nombre, String clase, int calcularAltura, String crearFlor, String crearFruto){
        this.calcularAltura = calcularAltura;
        this.crearFlor = crearFlor;
        this.crearFruto = crearFruto;
        this.nombre = nombre;
        this.clase = clase;
    }
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String crearFruto) {
        this.nombre = nombre;
    }
    public int getCalcularAltura() {
        return calcularAltura;
    }

    public void setCalcularAltura(int calcularAltura) {
        this.calcularAltura = calcularAltura;
    }

    public String getCrearFlor() {
        return crearFlor;
    }

    public void setCrearFlor(String crearFlor) {
        this.crearFlor = crearFlor;
    }

    public String getCrearFruto() {
        return crearFruto;
    }

    public void setCrearFruto(String crearFruto) {
        this.crearFruto = crearFruto;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Arboles: ");
        sb.append("\nNombre de Planta: ").append(nombre);
        sb.append("\nClase a la que pertenece: ").append(clase);
        sb.append("\nAltura=").append(calcularAltura).append(" dm.");
        sb.append("\nFlor=").append(crearFlor);
        sb.append("\nFruto=").append(crearFruto);
        sb.append('}');
        return sb.toString();
    }

     
}
