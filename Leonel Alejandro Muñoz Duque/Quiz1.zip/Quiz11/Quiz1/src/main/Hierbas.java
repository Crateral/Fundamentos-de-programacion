package main;

public class Hierbas extends Planta {
    
    
    @Override
    public void vida(int siembra, int fin){
        
    }
       
    protected int getCalcularAltura(){
        return this.calcularAltura;
    }
    
    protected String getCrearFlor(){
        return this.crearFlor;
    }
    
    protected String getCrearFruto(){
        return this.crearFruto;
    }

    public Hierbas(int calcularAltura, String crearFlor, String crearFruto){
        this.calcularAltura = calcularAltura;
        this.crearFlor = crearFlor;
        this.crearFruto = crearFruto;
    }

    public void setCalcularAltura(int calcularAltura) {
        this.calcularAltura = calcularAltura;
    }

    public void setCrearFlor(String crearFlor) {
        this.crearFlor = crearFlor;
    }


    public void setCrearFruto(String crearFruto) {
        this.crearFruto = crearFruto;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Hierbas{");
        sb.append("Altura: ").append(calcularAltura).append("cm");
        sb.append(", Flor: ").append(crearFlor);
        sb.append(", Fruto: ").append(crearFruto);
        sb.append('}');
        return sb.toString();
    }

    
    
   
    
}
