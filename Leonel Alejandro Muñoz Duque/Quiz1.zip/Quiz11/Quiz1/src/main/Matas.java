package main;

public abstract class Matas extends Planta {
    
    public Matas(int calcularAltura, String crearFlor, String crearFruto){
        
    }

    @Override
    public void vida(int siembra, int fin){
        
    }
    
    public int getCalcularAltura() {
        return calcularAltura;
    }

    public void setCalcularAltura(int calcularAltura) {
        this.calcularAltura = calcularAltura;
    }

    public String getCrearFlor() {
        return crearFlor;
    }

    public void setCrearFlor(String crearFlor) {
        this.crearFlor = crearFlor;
    }

    public String getCrearFruto() {
        return crearFruto;
    }

    public void setCrearFruto(String crearFruto) {
        this.crearFruto = crearFruto;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Matas{");
        sb.append("calcularAltura=").append(calcularAltura);
        sb.append(", crearFlor=").append(crearFlor);
        sb.append(", crearFruto=").append(crearFruto);
        sb.append('}');
        return sb.toString();
    }

    
}
