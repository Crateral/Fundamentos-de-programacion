package main;

public abstract class Arbustos extends Planta {

    
    public Arbustos(){
        
    }
    
    public Arbustos(int calcularAltura, String crearFlor, String crearFruto){
        this.calcularAltura = calcularAltura;
        this.crearFlor = crearFlor;
        this.crearFruto = crearFruto;
    }

    public int getCalcularAltura() {
        return calcularAltura;
    }

    public void setCalcularAltura(int calcularAltura) {
        this.calcularAltura = calcularAltura;
    }

    public String getCrearFlor() {
        return crearFlor;
    }

    public void setCrearFlor(String crearFlor) {
        this.crearFlor = crearFlor;
    }

    public String getCrearFruto() {
        return crearFruto;
    }

    public void setCrearFruto(String crearFruto) {
        this.crearFruto = crearFruto;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Arbustos{");
        sb.append("calcularAltura=").append(calcularAltura);
        sb.append(", crearFlor=").append(crearFlor);
        sb.append(", crearFruto=").append(crearFruto);
        sb.append('}');
        return sb.toString();
    }

    
    
}
