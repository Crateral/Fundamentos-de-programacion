package main;

public abstract class Planta {
    public int altura;
    public boolean daFruto;
    public boolean tieneFlores;
    protected int calcularAltura;
    protected String crearFlor;
    protected String crearFruto;
    public abstract void vida(int siembra, int fin);
    
    
    public Planta(){
        
    }
    
    public Planta(int altura, boolean daFruto, boolean tieneFlores){
        this.altura = altura;
        this.daFruto = daFruto;
        this.tieneFlores = tieneFlores;
    }

    
    
    public int getAltura() {
        return altura;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }

    public boolean isDaFruto() {
        return daFruto;
    }

    public void setDaFruto(boolean daFruto) {
        this.daFruto = daFruto;
    }

    public boolean isTieneFlores() {
        return tieneFlores;
    }

    public void setTieneFlores(boolean tieneFlores) {
        this.tieneFlores = tieneFlores;
    }

    @Override
    public String toString() {
        return "Planta{" + "altura=" + altura + ", daFruto=" + daFruto + ", tieneFlores=" + tieneFlores + '}';
    }
    
}
