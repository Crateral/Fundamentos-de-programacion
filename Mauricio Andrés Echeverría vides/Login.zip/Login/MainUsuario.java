package Login;

import javax.swing.plaf.synth.SynthOptionPaneUI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class MainUsuario {


    public static void main(String[] args) {


        List<Usuario> listusuarios = new ArrayList<>();


        Scanner entrada = new Scanner(System.in);
        String nombre, contraseña, correo;

        int opcion = 0;


        while (true) {

            System.out.println("Registro de usuario 😎");

            System.out.println("1.Crear usuario");
            System.out.println("2.Consultar usuario");
            System.out.println("3.Iniciar Sesion");
            System.out.println("4.Cambiar Contraseña");
            System.out.println("5.Recuperar Contraseña");
            System.out.println("6.Logout");
            System.out.println("|Digite una Opcion|");
            opcion = entrada.nextInt();


            switch (opcion) {

                case 1:
                    Usuario numReg = new Usuario();

                    System.out.println("Digite datos del usuario");
                    System.out.println("Nombre: ");

                    nombre = entrada.next();
                    numReg.setNombre(nombre);

                    System.out.println("Ingrese el correo");
                    correo = entrada.next();
                    numReg.setCorreo(correo);

                    System.out.println("Ingrese contraseña");
                    contraseña = entrada.next();
                    numReg.setContraseña(contraseña);

                    for (int i = 0; i < listusuarios.size(); i++) {

                        if (numReg.getCorreo() == correo) {
                            System.out.println("Correo ya registrado");


                        } else {
                            listusuarios.add(numReg);

                        }


                    }


                    listusuarios.add(numReg);


                    break;
                case 2:
                    if (listusuarios.size() != 0) {


                    } else {

                        System.out.println("No hay usuarios");
                    }

                    for (Usuario personaReg : listusuarios) {
                        System.out.println(personaReg.toString());


                    }


                    break;
                case 3:
                    System.out.println("DIGITE SUS CREDENCIALES");
                    System.out.println("Usuario: ");
                    correo = entrada.next();
                    System.out.println("Contraseña");
                    contraseña = entrada.next();

                    for (Usuario usuario : listusuarios) {

                        if (usuario.getCorreo().equals(correo) && usuario.getContraseña().equals(contraseña)) {
                            System.out.println("----SESION INICIADA----");


                        } else {
                            System.out.println("Los datos no son validos ");

                        }
                    }


                    break;
                case 4:
                    Usuario camContra = new Usuario();

                    System.out.println("¿Desea cambiar su contraseña?(1.SI) (2.NO) ");
                    int cambiContra = entrada.nextInt();

                    if (cambiContra == 1) {
                        System.out.println(" Digite su correo");
                        correo = entrada.next();

                        for (Usuario cambiContra1 : listusuarios) {

                            if (cambiContra1.getCorreo().equals(correo)) {
                                int indice = listusuarios.indexOf(cambiContra1.getCorreo());

                                if (indice != 0) {

                                    System.out.println("Ingrese su nueva contraseña");
                                    contraseña = entrada.next();
                                    camContra.setContraseña(contraseña);

                                }

                            }


                        }


                    } else {
                        System.out.println("Ingrese otra opcion");

                    }


                    break;
                case 5:


                    System.out.println("¿Desea recuperar su contraseña?(1.SI) (2.NO) ");
                    int recuperarcon = 0;
                    recuperarcon = entrada.nextInt();

                    if (recuperarcon == 1) {
                        System.out.println("Digite el correo");
                        recuperarcon = entrada.nextInt();


                        for (Usuario usuario : listusuarios) {
                            int recuperarcon2;

                            recuperarcon2 = listusuarios.indexOf(usuario.getCorreo());

                            if (recuperarcon2 != 0) ;
                            {

                                System.out.println("Digite la nueva contraseña");
                                contraseña = entrada.next();
                                usuario.setContraseña(contraseña);


                            }

                        }


                    }


                    break;
                case 6:

                    System.out.println("Sesion Finalizada");


                    System.exit(0);


                    break;

                default:
                    System.out.println("Opcion no valida");
                    break;


            }


        }


    }


}
