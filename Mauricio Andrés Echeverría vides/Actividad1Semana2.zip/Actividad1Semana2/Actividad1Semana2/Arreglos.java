package Actividad1Semana2;

import java.util.Arrays;

public class Arreglos {

    public static void main(String[] args) {

        System.out.println("En orden ascendente");

        Integer [] numeros = {7, 4, 2, 1,10, 5, 6};

        Arrays.sort(numeros);

        for (int i= 0; i<numeros.length; i++ ){

            System.out.println(""+numeros[i]);

        }

        System.out.println(" ");

        System.out.println("Ahora en orden de descentes");

        for (int i= numeros.length-1; i>=0; i-- ){

            System.out.println(""+numeros[i]);

        }

    }

}
