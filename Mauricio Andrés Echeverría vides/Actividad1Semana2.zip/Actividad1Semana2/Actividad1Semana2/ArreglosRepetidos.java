package Actividad1Semana2;

import java.util.Arrays;

public class ArreglosRepetidos {
    public static void main(String[] args) {


        int[] repetidos = {2, 4, 6, 6, 19, 3, 1, 0, 5, 2, 9};

        Arrays.sort(repetidos);

        int[] repetidos1 = new int[repetidos.length];

        int j, top = 1;
        boolean repetidos2;

        for (int i = 0; i < repetidos.length; i++) {

            repetidos2 = false;
            j = 1;

            while (!repetidos2 && (j < top)) {

                if (repetidos[i] == repetidos1[j]) {

                    repetidos2 = true;

                }
                j++;

            }

            if (!repetidos2) {

                repetidos1[top] = repetidos[i];

                top++;
            }


        }

        System.out.print("Arreglo original: ");
        for (int i = 0; i < repetidos.length; i++) {

            System.out.print(repetidos[i] + "  ");

        }

        System.out.println("  ");

        System.out.print("Arreglo sin repetidos en orden ascendente : ");
        for (int i= 0; i<top; i++ ){

            System.out.print(repetidos1[i]+"  ");

        }

        Arrays.sort(repetidos);

        System.out.println("  ");

        System.out.print("Arreglo sin repetidos en orden descente : ");
        for (int i= repetidos.length-1; i>=0; i-- ){

            System.out.print(repetidos1[i]+"  ");

        }


    }

}
