package Informes;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class InfoMain {

    public static void main(String[] args) {


        List<Informe> indice=new ArrayList<>();



        Informe informe1=new Informe();
        informe1.setCodigo(1);
        informe1.setTarea("Administrativo");

        Informe informe2=new Informe();
        informe2.setCodigo(2);
        informe2.setTarea("Empresarial");

        Informe informe3=new Informe();
        informe3.setCodigo(3);
        informe3.setTarea("Personal");

        Informe informe4=new Informe();
        informe4.setCodigo(4);
        informe4.setTarea("Administrativo");

        Informe informe5=new Informe();
        informe5.setCodigo(5);
        informe5.setTarea("Personal");

        Informe informe6=new Informe();
        informe6.setCodigo(6);
        informe6.setTarea("Administrativo");

        Informe informe7=new Informe();
        informe7.setCodigo(7);
        informe7.setTarea("Empresarial");


        Informe informe8=new Informe();
        informe8.setCodigo(8);
        informe8.setTarea("Personal");

        Informe informe9=new Informe();
        informe9.setCodigo(9);
        informe9.setTarea("Administrativo");

        Informe informe10=new Informe();
        informe10.setCodigo(10);
        informe10.setTarea("Administrativo");

        indice.add(informe1);
        indice.add(informe2);
        indice.add(informe3);
        indice.add(informe4);
        indice.add(informe5);
        indice.add(informe6);
        indice.add(informe7);
        indice.add(informe8);
        indice.add(informe9);
        indice.add(informe10);



        System.out.println("------------------Primeros 10 informes agregados------------------------");

        System.out.println("            ");


        for (Informe informe : indice) {
            System.out.println("El informe con codigo: " +informe.getCodigo()+ " "+
                    "tiene la tarea " +informe.getTarea());
        }


        indice.clear();

        System.out.println("\nInformes eliminados");
        System.out.println("\n-----------5 informes Agregados------------------------------");


        Informe informe11=new Informe();
        informe11.setCodigo(5);
        informe11.setTarea("Personal");

        Informe informe12=new Informe();
        informe12.setCodigo(12);
        informe12.setTarea("Administrativo");

        Informe informe13=new Informe();
        informe13.setCodigo(7);
        informe13.setTarea("Empresarial");


        Informe informe14=new Informe();
        informe14.setCodigo(14);
        informe14.setTarea("Personal");

        Informe informe15=new Informe();
        informe15.setCodigo(15);
        informe15.setTarea("Administrativo");

        Informe informe16=new Informe();
        informe16.setCodigo(16);
        informe16.setTarea("Administrativo");



        indice.add(informe11);
        indice.add(informe12);
        indice.add(informe13);
        indice.add(informe14);
        indice.add(informe15);
        indice.add(informe16);




        for (int i = 0; i <6; i++) {
            System.out.println("El informe con codigo: " + indice.get(i).getCodigo() + " " +
                    "tiene la tarea " + indice.get(i).getTarea());
        }

        System.out.println("\n");
        Scanner pantalla = new Scanner(System.in);
        System.out.println("Digite la tarea a consultar");
        String capsula = pantalla.next();

        int contador = 0;
        for (Informe informe : indice) {
            if (informe.getTarea().equals(capsula)) {
                System.out.println("El informe con codigo: " + informe.getCodigo() + " " +
                        "tiene la tarea " + informe.getTarea());
                contador = contador + 1;
            }
        }

        System.out.println("\n Digite el codigo a consultar");


        int capsula2 = pantalla.nextInt();

        int contador2 = 0;
        for (Informe informe : indice) {
            if (informe.getCodigo()==capsula2) {
                System.out.println("El informe con codigo: " + informe.getCodigo() + " " +
                        "tiene la tarea " + informe.getTarea());
                contador2 = contador2 + 1;
            }
        }

        System.out.println("existen: " + contador2 + " tareas en "+capsula2);


    }



    }







