package ActividadFinal;

public class Coach extends Persona{


    private  boolean clasesAgendadas;
    private String contenidoClases;

    public Coach(){

    }


    public boolean ClasesAgendadas() {
        return clasesAgendadas;
    }

    public void setClasesAgendadas(boolean clasesAgendadas) {
        this.clasesAgendadas = clasesAgendadas;
    }

    public String getContenidoClases() {
        return contenidoClases;
    }

    public void setContenidoClases(String contenidoClases) {
        this.contenidoClases = contenidoClases;
    }
}
