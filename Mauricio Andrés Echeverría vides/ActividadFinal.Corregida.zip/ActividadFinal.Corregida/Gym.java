package ActividadFinal;

public class Gym {

    public static void main(String[] args) {



        Administrador administrador = new Administrador();
        administrador.setNombre("");
        administrador.setApellido("");
        administrador.setCedula(332323);
        administrador.setCorreo("");
        administrador.setDireccion("");
        administrador.setTelefono(22222);
        administrador.setVerInfoUser("");
        administrador.setVerMembresias("");


        Coach coach = new Coach();
        coach.setNombre("");
        coach.setApellido("");
        coach.setCedula(323232);
        coach.setCorreo("");
        coach.setDireccion("");
        coach.setTelefono(32323);
        coach.setClasesAgendadas(true);
        coach.setClasesAgendadas(false);
        coach.setContenidoClases("");


        Usuario usuario = new Usuario();
        usuario.setNombre("");
        usuario.setApellido("");
        usuario.setCedula(32323);
        usuario.setTelefono(4444);
        usuario.setCorreo("");
        usuario.setDireccion("");
        usuario.setContacto("");
        usuario.setPesoRecord(0);
        usuario.setRegistrarInfo("");

    }

}
