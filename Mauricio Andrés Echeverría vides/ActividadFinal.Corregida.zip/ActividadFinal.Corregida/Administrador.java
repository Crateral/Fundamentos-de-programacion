package ActividadFinal;

public class Administrador extends Persona {

    private String verMembresias;
    private String verInfoUser;


    public Administrador() {
    }

    public String getVerMembresias() {
        return verMembresias;
    }

    public void setVerMembresias(String verMembresias) {
        this.verMembresias = verMembresias;
    }

    public String getVerInfoUser() {
        return verInfoUser;
    }

    public void setVerInfoUser(String verInfoUser) {
        this.verInfoUser = verInfoUser;
    }
}
