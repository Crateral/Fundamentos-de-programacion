package ActividadFinal;

public interface   Rutina {

    public void rutina ();

}
