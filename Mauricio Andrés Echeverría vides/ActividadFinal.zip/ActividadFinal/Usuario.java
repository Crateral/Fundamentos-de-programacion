package ActividadFinal;

public class Usuario extends  Persona{

    private String registrarInfo;
    private String contacto;
    private int pesoRecord;


    public Usuario (){

    }

    public String getRegistrarInfo() {
        return registrarInfo;
    }

    public void setRegistrarInfo(String registrarInfo) {
        this.registrarInfo = registrarInfo;
    }

    public String getContacto() {
        return contacto;
    }

    public void setContacto(String contacto) {
        this.contacto = contacto;
    }

    public int getPesoRecord() {
        return pesoRecord;
    }

    public void setPesoRecord(int pesoRecord) {
        this.pesoRecord = pesoRecord;
    }
}
