package ActividadFinal;

public class  Rutina2 implements Rutina {

    public void rutina() {

    }
}
