package EjercicioEvaluacion;

import javax.swing.*;

public class CicloVida2 implements CicloVida{

    @Override
    public void cicloVida() {
        int vida;
        vida= Integer.parseInt(JOptionPane.showInputDialog("digite en dias el tiempo desde el nacimiento"));

        if (vida>=0 && vida<=20){
            JOptionPane.showMessageDialog(null,"Tu planta esta en Germinacion");
        } else if(vida>=21 && vida<=90) {
            JOptionPane.showMessageDialog(null,"Tu planta esta en Crecimiento");
        }else if (vida>=91 && vida<=120){
            JOptionPane.showMessageDialog(null,"Tu planta esta en Reproducción");
        }else if(vida>=121){
            JOptionPane.showMessageDialog(null,"Tu planta esta Muerta");
        }
    }
}
