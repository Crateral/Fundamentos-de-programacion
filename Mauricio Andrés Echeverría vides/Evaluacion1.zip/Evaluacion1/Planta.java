package EjercicioEvaluacion;

public class Planta {

        private Integer altura;
        private Boolean daFruto;
        private Boolean daFlores;
        private Integer tiempoDeVida;

        public Planta() {
        }

        public Integer getAltura() {
                return altura;
        }

        public void setAltura(Integer altura) {
                this.altura = altura;
        }

        public Boolean getDaFruto() {
                return daFruto;
        }

        public void setDaFruto(Boolean daFruto) {
                this.daFruto = daFruto;
        }

        public Boolean getDaFlores() {
                return daFlores;
        }

        public void setDaFlores(Boolean daFlores) {
                this.daFlores = daFlores;
        }

        public Integer getTiempoDeVida() {
                return tiempoDeVida;
        }

        public void setTiempoDeVida(Integer tiempoDeVida) {
                this.tiempoDeVida = tiempoDeVida;
        }

        @Override
        public String toString() {
                return "Planta{" +
                        "altura=" + altura +
                        ", daFruto=" + daFruto +
                        ", daFlores=" + daFlores +
                        ", tiempoDeVida=" + tiempoDeVida +
                        '}';
        }
}
