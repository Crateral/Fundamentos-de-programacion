package EjercicioEvaluacion;

public class Hierbas extends Planta {

    private Integer calcularAltura;
    private String crearFlor;
    private String crearFruto;

    public Hierbas() {
    }

    public Integer getCalcularAltura() {
        return calcularAltura;
    }

    public void setCalcularAltura(Integer calcularAltura) {
        this.calcularAltura = calcularAltura;
    }

    public String getCrearFlor() {
        return crearFlor;
    }

    public void setCrearFlor(String crearFlor) {
        this.crearFlor = crearFlor;
    }

    public String getCrearFruto() {
        return crearFruto;
    }

    public void setCrearFruto(String crearFruto) {
        this.crearFruto = crearFruto;
    }

    @Override
    public String toString() {
        return "Hierbas{" +
                "calcularAltura=" + calcularAltura +
                ", crearFlor='" + crearFlor + '\'' +
                ", crearFruto='" + crearFruto + '\'' +
                '}';
    }
}
