package EjercicioEvaluacion;

public class Arbustos extends Planta{
    private Integer calcularAltura;
    private String crearFlor;
    private String crearFruto;

    public Arbustos() {
    }

    public Integer getCalcularAltura() {
        return calcularAltura;
    }

    public void setCalcularAltura(Integer calcularAltura) {
        this.calcularAltura = calcularAltura;
    }

    public String getCrearFlor() {
        return crearFlor;
    }

    public void setCrearFlor(String crearFlor) {
        this.crearFlor = crearFlor;
    }

    public String getCrearFruto() {
        return crearFruto;
    }

    public void setCrearFruto(String crearFruto) {
        this.crearFruto = crearFruto;
    }

    @Override
    public String toString() {
        return "Arbustos{" +
                "calcularAltura=" + calcularAltura +
                ", crearFlor='" + crearFlor + '\'' +
                ", crearFruto='" + crearFruto + '\'' +
                '}';
    }
}
