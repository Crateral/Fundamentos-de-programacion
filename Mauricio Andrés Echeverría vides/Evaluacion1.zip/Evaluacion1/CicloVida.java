package EjercicioEvaluacion;

public interface CicloVida {

    public void cicloVida();
}
