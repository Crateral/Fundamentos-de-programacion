package EjercicioEvaluacion;


import javax.swing.*;

public class PlantasPrincipal {
    public static void main(String[] args) {

        int opcion;

        String nombrePlanta;

        opcion= Integer.parseInt(JOptionPane.showInputDialog(null,"Seleccione el tipo de planta\n" +
                "1. planta\n" +
                "2. Hierbas\n" +
                "3. Matas\n"+
                "4. Arbustos\n"+
                "5. Arboles\n"));
        switch (opcion) {
            case 1:
                JOptionPane.showMessageDialog(null, "La información de tu planta es: \n"+datos());
                JOptionPane.showMessageDialog(null,"Ciclo de vida " + datos8());
                break;

            case 2:
                JOptionPane.showMessageDialog(null, "La información de tu planta es: \n"+datos2());
                JOptionPane.showMessageDialog(null,"Ciclo de vida " + datos8());
                break;

            case 3:
                JOptionPane.showMessageDialog(null, "La información de tu planta es: \n"+datos3());
                JOptionPane.showMessageDialog(null,"Ciclo de vida " + datos8());
                break;

            case 4:
                JOptionPane.showMessageDialog(null, "La información de tu planta es: \n"+datos4());
                JOptionPane.showMessageDialog(null,"Ciclo de vida " + datos8());
                break;

            case 5:
                JOptionPane.showMessageDialog(null, "La información de tu planta es: \n"+datos5());
                JOptionPane.showMessageDialog(null,"Ciclo de vida " + datos8());
                break;
        }

        }

        public static Planta datos(){

        Planta planta=new Planta();
        planta.setAltura(10);
        planta.setDaFlores(true);
        planta.setDaFruto(false);
        planta.setTiempoDeVida(10);

        return planta;
        }

       public static Hierbas datos2(){

        Hierbas hierbas=new Hierbas();
        hierbas.setAltura(10);
        hierbas.setDaFlores(true);
        hierbas.setDaFruto(false);
        hierbas.setTiempoDeVida(10);
        hierbas.setCalcularAltura(20);
        hierbas.setCrearFlor("No");
        hierbas.setCrearFruto("No");
        return hierbas;
        }

        public static Matas datos3(){

        Matas matas=new Matas();
        matas.setAltura(7);
        matas.setDaFruto(false);
        matas.setDaFlores(true);
        matas.setTiempoDeVida(20);
        matas.setCalcularAltura(10);
        matas.setCrearFlor("No");
        matas.setCrearFruto("No");
        return matas;
        }

        public static Arbustos datos4(){

        Arbustos arbustos=new Arbustos();
        arbustos.setAltura(50);
        arbustos.setDaFruto(false);
        arbustos.setDaFlores(false);
        arbustos.setTiempoDeVida(30);
        arbustos.setCalcularAltura(50);
        arbustos.setCrearFlor("No");
        arbustos.setCrearFruto("No");
        return arbustos;
        }

        public static Arboles datos5(){

        Arboles arboles=new Arboles();
        arboles.setAltura(7000);
        arboles.setDaFruto(true);
        arboles.setDaFlores(true);
        arboles.setTiempoDeVida(500);
        arboles.setCalcularAltura(7000);
        arboles.setCrearFlor("No");
        arboles.setCrearFruto("No");
        return arboles;

        }
        public static CicloVida2 datos8(){
        CicloVida2 cicloVida2=new CicloVida2();
        cicloVida2.cicloVida();
        return cicloVida2;

        }
}



