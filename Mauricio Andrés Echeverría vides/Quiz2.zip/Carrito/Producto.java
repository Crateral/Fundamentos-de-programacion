package Carrito;

public class Producto {

    private String nomProducto;

    private int nomPrecio;


    public Producto(String nomProducto, int nomPrecio) {
        this.nomProducto = nomProducto;
        this.nomPrecio = nomPrecio;
    }

    public String getNomProducto() {
        return nomProducto;
    }

    public void setNomProducto(String nomProducto) {
        this.nomProducto = nomProducto;
    }

    public int getNomPrecio() {
        return nomPrecio;
    }

    public void setNomPrecio(int nomPrecio) {
        this.nomPrecio = nomPrecio;
    }

    @Override
    public String toString() {
        return "Producto{" +
                "nomProducto='" + nomProducto + '\'' +
                ", nomPrecio=" + nomPrecio +
                '}';
    }
}
