package Carrito;

import Informes.Informe;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Carrito {

     static ArrayList<Categoria> categorias = new ArrayList<>();
    static Scanner sc = new Scanner(System.in);
    static Scanner sc1 = new Scanner(System.in);


    public static void main(String[] args) {

        int opcion = 0;

        do {

            System.out.println("1. Agregar Productos");
            System.out.println("2. Consultar productos");
            System.out.println("3. Salir");

            System.out.println("Ingrese una opcion ");
            opcion = sc.nextInt();


            switch (opcion) {

                case 1:

                    System.out.println("Ingrese datos del producto: nombre del producto ");
                    sc.nextLine();
                    String[] datos = sc.nextLine().split(" ");

                    System.out.println("ingrese precio ");
                    int datos1 = sc1.nextInt();
                    Producto producto= new Producto(datos[0],datos1);


                    int numeroCategoria = 0;

                    String nombreCategoria = "";

                    if (categorias.isEmpty()) {

                        nombreCategoria = "";

                        System.out.println("Ingrese el nombre de la categoria");
                        nombreCategoria = sc.nextLine();

                    } else {
                        for (int i = 0; i < categorias.size(); i++) {

                            System.out.println(i + "--->" + categorias.get(i).getNombrecategoria());

                        }
                        System.out.println(categorias.size() + "---> Categoria Disponible");

                        System.out.println("Seleccione el numero de la categoria");
                        numeroCategoria = sc.nextInt();


                        if (numeroCategoria >= categorias.size()) {
                            System.out.println("Ingrese el nombre de la categoria");
                            sc.nextLine();

                            nombreCategoria = sc.nextLine();
                        }

                    }
                    crearProducto(numeroCategoria, nombreCategoria, producto);


                    break;
                case 2:

                    int contador= 0;
                    for (Categoria categoria : categorias) {
                        for (int i = 0; i < categorias.size(); i++) {
                            System.out.println("Las productos son "+ categoria.liscarrito.toString());

                            contador=contador;
                        }
                    }


                    break;
                case 3:

                    break;

                default:
                    System.out.println("Producto Inexistente");
                    break;
            }


        } while (opcion != 3);

    }

    public static void crearProducto(int numeroCategeoria, String nombreCategoria, Producto producto) {

        if (numeroCategeoria < categorias.size()) {

            categorias.get(numeroCategeoria).agregarProducto(producto);

        } else {
            Categoria categoria = new Categoria(nombreCategoria);
            categoria.agregarProducto(producto);
            categorias.add(categoria);
        }

        System.out.println(categorias);

        for (int i = 0; i < categorias.size(); i++) {

            categorias.get(i).mostrarProductos();
        }

    }


}
