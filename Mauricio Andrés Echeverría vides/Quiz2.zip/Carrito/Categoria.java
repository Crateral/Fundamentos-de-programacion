package Carrito;

import java.util.ArrayList;

public class Categoria {

    private String nombrecategoria;

    ArrayList<Producto> liscarrito = new ArrayList<>();

    public Categoria(String nombrecategoria) {

        this.nombrecategoria = nombrecategoria;
    }

    public void agregarProducto(Producto producto1) {

        liscarrito.add(producto1);
    }

    public void mostrarProductos() {

        for (int i = 0; i < liscarrito.size(); i++) {

            System.out.println(liscarrito.get(i));
        }
    }


    public String getNombrecategoria() {
        return nombrecategoria;
    }

    public void setNombrecategoria(String nombrecategoria) {
        this.nombrecategoria = nombrecategoria;
    }

    @Override
    public String toString() {
        return
                "categoria='" + nombrecategoria + '\'' +
                        ", liscarrito=" + liscarrito +
                        '}';
    }
}
