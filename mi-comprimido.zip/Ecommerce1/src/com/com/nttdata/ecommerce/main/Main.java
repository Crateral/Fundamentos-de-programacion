package com.com.nttdata.ecommerce.main;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.co.nttdata.ecommerce.entidades.*;
import com.co.nttdata.ecommerce.logica.*;
import com.co.nttdata.ecommerce.utilitarios.InventarioProducto;
import com.co.nttdata.ecommerce.utilitarios.ReporteFactura;
import com.co.nttdata.ecommerce.interfaces.*;

public class Main {
    static Cliente cli;
    static String metodoDePago;
    static String tipoIdentificacion;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InventarioProducto ip = new InventarioProducto();
		ReporteFactura r = new ReporteFactura();
		//Crear 10 prodcutos
		//Añadir 6 al carrito de comprar
		//Crear la factura de ese carrito de compras
		
		 List<Producto> list = new ArrayList<>();
		 Scanner consola =  new Scanner(System.in);
		
		GestionCarritoDeComprasImpl gcdc = new GestionCarritoDeComprasImpl();
		GestionFacturaImpl gf = new GestionFacturaImpl();
		
		Factura f =new Factura();
		CarritoDeCompras cdc = new CarritoDeCompras();
		Cliente cl = new Cliente();
		Scanner teclado = new Scanner(System.in);
		//creacion de los 10 productos
	
		
		
			
		/*cdc.setValorEnvio(gcdc.calcularCostoEnvio(null, cdc.getSubTotalConIva()));*/
	
		f = gf.pagar(null, cdc);
		int opcion = 0;
		do {
			System.out.println("\n");
			System.out.println("Menu Principal Ecomercce");
			System.out.println("1. Registrar Usuario");
			System.out.println("2. Mostrar Registro Usuario ");
			System.out.println("3. Ingreso Login");
			System.out.println("4. Agregar productos");
			System.out.println("5. AgregarPRoductos.txt");
			System.out.println("6. mostrar productos txt");
			System.out.println("7. guardar archivo txt");
			System.out.println("8. Imprimir archivo txt");
			System.out.println("9. Salida");
			
			System.out.println("Ingrese la opcion");
		
			System.out.println();
			System.out.println();
			opcion = consola.nextInt();
			GestionLogin gl = new GestionLoginImpl();
			Ciudades ciudad = null;
			switch (opcion) {
			case 1:
				
				
				System.out.println("Resgitro de Usuario");
				System.out.println("🧾-----------------------------🧾");
				System.out.println("Ingrese el Nombre del Usuario: ");
				String nombreUsuario =teclado.next();
				
				System.out.println("Ingrese la contraseña:");
				String contrasenia = teclado.next();
				
				System.out.println("Escoja la Ciudad:" +"\n"+"1-Facatativa no Principal"+"\n"+"2-Bogota-Principal");
				String cd= teclado.next();
				if (cd == "1") {
					System.out.println("La ciudad es "+Ciudades.FACATATIVA + ", es ciudad no Principal");
					ciudad = Ciudades.FACATATIVA;
				}else if (cd == "2") {
					System.out.println("La ciudad es " + Ciudades.BOGOTA +", es ciudad Principal");
					ciudad = Ciudades.BOGOTA;
				}
				
				System.out.println("Escoja el tipo de identificacion: "+"\n"+" 1 cc"+"\n"+"2- TI"+"\n"+"3- CEx" );
				int tipo = teclado.nextInt();
				if (tipo == 1) {
					tipoIdentificacion = "CC";
				}else if (tipo == 2) {
					tipoIdentificacion = "TI";
				}else if (tipo == 3) {
					tipoIdentificacion = "CEx";
				}
				
				System.out.println("Ingrese el numero de Identificacion: ");
				String numeroIdentificacion = teclado.next();
				
				System.out.println("Ingrese el Numero de Telefono: ");
				String telefono = teclado.next();
				
				System.out.println("Ingrese la Direccion: ");
				String direccion = teclado.next();
				
				System.out.println("Escoja el Metodo de Pago: "+"\n"+"1- Contado"+"\n"+"2- Efectico"+"\n"+"3- Tarjetas Debito o Credito");
				int mdp = teclado.nextInt();
				if (mdp==1) {
					 metodoDePago = "Contado";
				}else if (mdp==2) {
					metodoDePago ="Efectivo";
				}else if (mdp == 3) {
					metodoDePago =" Tarjetas Debito o Credito";
				}
				
				System.out.println("Escoja el estado true o false: ");
				boolean estado = teclado.nextBoolean();
				
				
				
				cli= (Cliente)gl.registrar(nombreUsuario, contrasenia, ciudad, tipoIdentificacion, numeroIdentificacion,telefono,direccion,estado, metodoDePago);
				break;
			case 2:
				
				System.out.println("Los datos de Usuario registrados son: ");
				System.out.println("El nombre Usuario es: " + cli.getNombreUsuario());
				System.out.println("La contraseña es: "+ cli.getContrasenia());
				System.out.println("La Ciudad es: "+cli.getCiudad());
				System.out.println("El tipo de identificacion es: "+cli.getTipoIdentificacion());
				System.out.println("EL numero de Identificacion es: "+ cli.getNumeroIdentificacion());
				System.out.println("El numero de Telefono es: " + cli.getTelefono());
				System.out.println("La direccion es: "+ cli.getDireccion());
				System.out.println("EL estado es: " + cli.isEstado());
				System.out.println("El metodo de pago es  "+ cli.getMetodoDePago());
				System.out.println("Bienvedido newUser");	
				
				break;
				
			case 3 :
				System.out.println("Ingrese el nombre del Usuario: ");
				String nusu = teclado.next();
				
				System.out.println("Ingrese la contraseña: ");
				String contra = teclado.next();
				
			    gl.ingreso(nusu, contra);		
				break;
				
			case 4:
				
				gcdc.mostrarProducto(null, cdc, gcdc);
				
				System.out.println("");
				break;
				
			case 5:
				ip.traerProductos(cdc);
				break;
			case 6:
				
				ip.mostrarProductos();
				break;
			case 7:
				r.escribirArchivo(cl, cdc, f);
				break;
				
			case 8:
				r.leerArchivo();
				break;
					
			case 9:
				gl.logout();
				break;

			default:
				
				break;
			}
			}while(opcion != 9);
		
 	}	
	
  
	
}


