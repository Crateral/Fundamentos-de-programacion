package com.co.nttdata.ecommerce.logica;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.co.nttdata.ecommerce.entidades.*;

import com.co.nttdata.ecommerce.interfaces.GestionCarritoDeCompras;



public class GestionCarritoDeComprasImpl implements GestionCarritoDeCompras{
	double total = 0.0;

List<Producto> list = new ArrayList<>();
Scanner consola =  new Scanner(System.in);


GestionFacturaImpl gf = new GestionFacturaImpl();

Factura f =new Factura();
CarritoDeCompras cdc = new CarritoDeCompras();
Cliente cl = new Cliente();
Scanner teclado = new Scanner(System.in);
//creacion de los 10 productos

/*cdc.setValorEnvio(gcdc.calcularCostoEnvio(null, cdc.getSubTotalConIva()));*/



	@Override
	public CarritoDeCompras añadirAlCarrito(CarritoDeCompras cdc, List<Producto> list) {
		// TODO Auto-generated method stub
		cdc.setProductos(list);
		return cdc;

	}


	
	@Override
	public CarritoDeCompras calcularTotalConIva(CarritoDeCompras cdc) {
		
		for (int i = 0; i < cdc.getProductos().size(); i++) {
			//1100           2000
			total = total + cdc.getProductos().get(i).getPrecio() +
			(cdc.getProductos().get(i).getPrecio() *
			(cdc.getProductos().get(i).getIva()/100));

			}
			cdc.setSubTotalConIva(total);
			return cdc;

	}

	

	@Override
	public CarritoDeCompras calcularCostoEnvio(CarritoDeCompras cdc, Ciudades ciudad) {
		//Para el calculo del envio se debe tener en cuenta la ubicacion del cliente
				//Si se encuentra en ciudades principales se debe cobrar el 5%
				//Si se encuentra en ciudades no principales se debe cobrar el 10%
               
				double total = 0;
				double totalEnvio = 0;
           
                
				for (int i = 0; i < cdc.getProductos().size(); i++) {
				//1100           2000
				total = total + cdc.getProductos().get(i).getPrecio() +
				(cdc.getProductos().get(i).getPrecio() *
				(cdc.getProductos().get(i).getIva()/100));
				}

				if(ciudad.isPrincipal()) {
				System.out.println("Se debe cobrar el 5% del envio Total, porque es Ciudad Principal" );
				totalEnvio= (total * 5)/100;
				
				}else  {

				System.out.println("Se debe cobrar el  10 % envio total, porque es Ciudad No  Principal");
				totalEnvio= (total * 10)/100;
				}


				System.out.println("El valor del envio es: "+ totalEnvio);
				cdc.setValorEnvio(totalEnvio);
				return cdc;
	}




	


	
	/*
double total = 0.0;
	@overrider
	public CarritoDeCompras añadirAlCarrito(CarritoDeCompras cdc, List<Producto> p) {
		
		cdc.setProductos(p);
		return cdc;
		
	}
	
	public CarritoDeCompras calcularTotalConIva(CarritoDeCompras cdc) {
		
		for (int i = 0; i < cdc.getProductos().size(); i++) {
			       //1100           2000
			total = total + cdc.getProductos().get(i).getPrecio() + 
					(cdc.getProductos().get(i).getPrecio() * 
							(cdc.getProductos().get(i).getIva())/100);
		}
		cdc.setSubTotalConIva(total);
		System.out.println(cdc.getSubTotalConIva());
		return cdc;
	}
	
	public CarritoDeCompras calcularTotalSinIva(CarritoDeCompras cdc) {
		double total =0;
		for(int i = 1; i<cdc.getProductos().size(); i++){
			total= total + cdc.getProductos().get(i).getPrecio();
			
		}
	cdc.setSubTotalSinIva(total);
	return cdc;
	}
	
	//Para el calculo del envio se debe tener en cuenta la ubicacion del cliente
		//Si se encuentra en ciudades principales se debe cobrar el 5%
		//Si se encuentra en ciudades no principales se debe cobrar el 10%
	
	/* public double calcularCostoEnvio(Cliente c, double valor) {
		if(c.getCiudad().isPrincipal()){
			return valor * 0.05;
		}else {
			return valor * 0.1;
		}
	}*/

	
	



int opcion = 0;
boolean continuar = true;
Scanner product = new Scanner(System.in);
int lecturaProducto, lecturaCantidad;
int num = 0;
Producto pd = new Producto();
	public CarritoDeCompras mostrarProducto(Producto pd,CarritoDeCompras cdc, GestionCarritoDeComprasImpl gcdc,int idProducto, int cantidadDisponible) {
		// TODO Auto-generated method stub
		cdc = gcdc.añadirAlCarrito(cdc, list);
		cdc.setProductos(list);
		Producto Tvs1 = new Producto(1,"TvSamsung 1",20,150000,true,7000,19,"Tv Samsung","Full 4K",Marca.SAMSUNG,Categoria.ELECTRODOMESTICOS);
		Producto Tvs2 = new Producto(2,"TvLG 2",23,200000,true,70000,19,"Tv LG","Full 4K",Marca.LG,Categoria.ELECTRODOMESTICOS);
		Producto Tvs3 = new Producto(3,"TvHiunday 3",20,250000,false,7000,19,"Tv Hiunday","FULL HD",Marca.HIUNDAY,Categoria.ELECTRODOMESTICOS);
		Producto Tvs4 = new Producto(4,"TvSamsung 4",12,300000,true,7000,19,"Tv Samsung","Full 4K",Marca.SAMSUNG,Categoria.ELECTRODOMESTICOS);
		Producto Tvs5 = new Producto(5,"TvLG 5",20,350000,true,70000,19,"Tv Lg","Full 4K",Marca.LG,Categoria.ELECTRODOMESTICOS);
		Producto Tvs6 = new Producto(6,"TvHiunday 6",50,125000,false,7000,19,"Tv Hiunday","Full 8K",Marca.HIUNDAY,Categoria.ELECTRODOMESTICOS);
		Producto Tvs7 = new Producto(7,"TvSamsung 7",10,100000,true,7000,19,"Tv Samsung","Full 8K",Marca.SAMSUNG,Categoria.ELECTRODOMESTICOS);
		Producto Tvs8 = new Producto(8,"TvLG 8",25,105000,true,7000,19,"Tv Lg","FuLL 8K",Marca.LG,Categoria.ELECTRODOMESTICOS);
		Producto Tvs9 = new Producto(9,"TvHiunday 9",12,700000,true,7000,19,"Tv Hiunday","ULTRA HD",Marca.HIUNDAY,Categoria.ELECTRODOMESTICOS);
		Producto Tvs10 = new Producto(10,"TvSamsung 10",24,110000,true,7000,19,"Tv Samsung","Full 8K ULTRA HD",Marca.SAMSUNG,Categoria.ELECTRODOMESTICOS);
		pd.setIdProducto(idProducto);
		pd.setCantidadDiponible(cantidadDisponible);
		
		System.out.println("Escriba el numero de producto que va a Añadir");
		idProducto = product.nextInt();
		int valor;
			do{
				
				if (idProducto == 1) {
					
					list.add(Tvs1);
					System.out.println("Producto Añadido!");
					System.out.println("Escriba cuando va a añadir"+"\n"+"Los cadtidad diponible son " + pd.getCantidadDiponible());
					cantidadDisponible =product.nextInt();
					valor = cantidadDisponible-pd.getCantidadDiponible();
					System.out.println("El valor escogido fue"+ product+ "las cantidaades restantes son: " + valor);
					break ;
				}else {
					System.out.println("El producto ya ah sido agregado");
				}
				
			}while(idProducto == 1);
			
			do{				
				if (idProducto == 2) {
					list.add(Tvs2);
					System.out.println("Producto Añadido!");
					System.out.println("Escriba cuando va a añadir"+"\n"+"Los cadtidad diponible son " + pd.getCantidadDiponible());
					cantidadDisponible =product.nextInt();
					valor = cantidadDisponible-pd.getCantidadDiponible();
					System.out.println("El valor escogido fue"+ product+ "las cantidaades restantes son: " + valor);
					break ;
				}else {
					System.out.println("El producto ya ah sido agregado");
				}
			}while(idProducto == 2);
			
do{
				
				if (idProducto == 3) {
					list.add(Tvs3);
					System.out.println("Producto Añadido!");
					System.out.println("Escriba cuando va a añadir"+"\n"+"Los cadtidad diponible son " + pd.getCantidadDiponible());
					cantidadDisponible =product.nextInt();
					valor = cantidadDisponible-pd.getCantidadDiponible();
					System.out.println("El valor escogido fue"+ product+ "las cantidaades restantes son: " + valor);
					break ;
				}else {
					System.out.println("El producto ya ah sido agregado");
				}			
			}while(idProducto == 3);
			do{
	
				if (idProducto == 4) {
					list.add(Tvs4);
					System.out.println("Producto Añadido!");
					System.out.println("Escriba cuando va a añadir"+"\n"+"Los cadtidad diponible son " + pd.getCantidadDiponible());
					cantidadDisponible =product.nextInt();
					valor = cantidadDisponible-pd.getCantidadDiponible();
					System.out.println("El valor escogido fue"+ product+ "las cantidaades restantes son: " + valor);
					break ;
				}else {
					System.out.println("El producto ya ah sido agregado");
				}			
			}while(idProducto == 4);
			
			do{
				
				if (idProducto == 5) {
					list.add(Tvs5);
					System.out.println("Producto Añadido!");
					System.out.println("Escriba cuando va a añadir"+"\n"+"Los cadtidad diponible son " + pd.getCantidadDiponible());
					cantidadDisponible =product.nextInt();
					valor = cantidadDisponible-pd.getCantidadDiponible();
					System.out.println("El valor escogido fue"+ product+ "las cantidaades restantes son: " + valor);
					break ;
				}else {
					System.out.println("El producto ya ah sido agregado");
				}			
			}while(idProducto == 5);
			
			do{
				
				if (idProducto == 6) {
					list.add(Tvs6);
					System.out.println("Producto Añadido!");
					System.out.println("Escriba cuando va a añadir"+"\n"+"Los cadtidad diponible son " + pd.getCantidadDiponible());
					cantidadDisponible =product.nextInt();
					valor = cantidadDisponible-pd.getCantidadDiponible();
					System.out.println("El valor escogido fue"+ product+ "las cantidaades restantes son: " + valor);
					break ;
				}else {
					System.out.println("El producto ya ah sido agregado");
				}			
			}while(idProducto == 6);
			do{
				
				if (idProducto == 7) {
					list.add(Tvs7);
					System.out.println("Producto Añadido!");
					System.out.println("Escriba cuando va a añadir"+"\n"+"Los cadtidad diponible son " + pd.getCantidadDiponible());
					cantidadDisponible =product.nextInt();
					valor = cantidadDisponible-pd.getCantidadDiponible();
					System.out.println("El valor escogido fue"+ product+ "las cantidaades restantes son: " + valor);
					break ;
				}else {
					System.out.println("El producto ya ah sido agregado");
				}			
			}while(idProducto == 7);
			
			do{
				
				if (idProducto == 8) {
					list.add(Tvs8);
					System.out.println("Producto Añadido!");
					System.out.println("Escriba cuando va a añadir"+"\n"+"Los cadtidad diponible son " + pd.getCantidadDiponible());
					cantidadDisponible =product.nextInt();
					valor = cantidadDisponible-pd.getCantidadDiponible();
					System.out.println("El valor escogido fue"+ product+ "las cantidaades restantes son: " + valor);
					break ;
				}else {
					System.out.println("El producto ya ah sido agregado");
				}			
			}while(idProducto == 8);
			
do{
				
				if (idProducto == 9) {
					list.add(Tvs9);
					System.out.println("Producto Añadido!");
					System.out.println("Escriba cuando va a añadir"+"\n"+"Los cadtidad diponible son " + pd.getCantidadDiponible());
					cantidadDisponible =product.nextInt();
					valor = cantidadDisponible-pd.getCantidadDiponible();
					System.out.println("El valor escogido fue"+ product+ "las cantidaades restantes son: " + valor);
					break ;
				}else {
					System.out.println("El producto ya ah sido agregado");
				}			
			}while(idProducto == 9);
		do{
	
			if (idProducto == 10) {
				list.add(Tvs10);
				System.out.println("Producto Añadido!");
				System.out.println("Escriba cuando va a añadir"+"\n"+"Los cadtidad diponible son " + pd.getCantidadDiponible());
				cantidadDisponible =product.nextInt();
				valor = cantidadDisponible-pd.getCantidadDiponible();
				System.out.println("El valor escogido fue"+ product+ "las cantidaades restantes son: " + valor);
				break ;
			}else {
		System.out.println("El producto ya ah sido agregado");
			}			
		}while(idProducto == 10);	
		
		list.add(Tvs1);
		list.add(Tvs2);
		list.add(Tvs3);
		list.add(Tvs4);
		list.add(Tvs5);
		list.add(Tvs6);
		list.add(Tvs7);
		list.add(Tvs8);
		list.add(Tvs9);
		list.add(Tvs10);
			System.out.println("---- Gracias por usar la aplicación. ----");
		System.out.println("Los productos añadidos son: ");
		cdc.getProductos().forEach((
				p -> System.out.println("\n"+
						p.getIdProducto()+" "+ 
						p.getNombre()+" "+
						p.getCantidadDiponible()+" "+
						p.getPrecio()+" "+
						p.isDescuento()+" "+
						p.getValorDescuento()+" "+
						p.getIva()+" "+
						p.getDescripcion()+" "+
						p.getImg()+" "+
						p.getMarca()+" "+
						p.getCategoria())));
		return cdc;
	}



	@Override
	public CarritoDeCompras agregarCantidad(CarritoDeCompras cdc, List<Producto> p, Producto pd) {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public CarritoDeCompras mostrarProducto(Producto pd, CarritoDeCompras cdc, GestionCarritoDeComprasImpl gcdc) {
		// TODO Auto-generated method stub
		return null;
	}
		
		

	


}

