
public class Animal {
	
	
	int cantidadPatas;
	
	String color;
	

}
