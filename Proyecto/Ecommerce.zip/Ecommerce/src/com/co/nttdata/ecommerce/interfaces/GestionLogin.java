package com.co.nttdata.ecommerce.interfaces;

import com.co.nttdata.ecommerce.entidades.Usuario;

public interface GestionLogin {

	public Usuario registar(String nombre, String pws, String tipoDocumento, String documento,
			String correo, String direccion);
	
	public boolean login(String usr, String pws);
	
	public String recuperarContraseña(String usr);
	
	public boolean logout();
	
}
