package com.co.nttdata.ecommerce.logica;

import java.util.ArrayList;
import java.util.List;

import com.co.nttdata.ecommerce.entidades.CarritoDeCompras;
import com.co.nttdata.ecommerce.entidades.Producto;

public class GestionCarritoDeCompras {

	public CarritoDeCompras añadirAlCarrito(CarritoDeCompras cdc, List<Producto> p) {
		
		cdc.setProductos(p);
		return cdc;
		
	}
	
	public CarritoDeCompras calcularTotalConIva(CarritoDeCompras cdc) {
		
		double total = 0.0;
		
		for (int i = 0; i < cdc.getProductos().size(); i++) {
			       //1100           2000
			total = total + cdc.getProductos().get(i).getPrecio() + 
					(cdc.getProductos().get(i).getPrecio() * 
							cdc.getProductos().get(i).getIva());
			
		}
		cdc.setSubTotal(total);
		return cdc;
	
	}
	
	public void calcularCostoEnvio() {
		//Para el calculo del envio se debe tener en cuenta la ubicacion del cliente
		//Si se encuentra en ciudades principales se debe cobrar el 5%
		//Si se encuentra en ciudades no principales se debe cobrar el 10%
	}
	
}
