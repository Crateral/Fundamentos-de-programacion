package com.co.nttdata.ecommerce.logica;

import com.co.nttdata.ecommerce.entidades.Administrador;
import com.co.nttdata.ecommerce.entidades.Usuario;
import com.co.nttdata.ecommerce.interfaces.GestionLogin;

public class GestionLoginAdmImpl implements GestionLogin{

	@Override
	public Usuario registar(String nombre, String pws, String tipoDocumento, 
			String documento, String correo, String direccion) {
		// TODO Auto-generated method stub
		Administrador adm = new Administrador();
		adm.setNombreUsuario(nombre);
		adm.setNumeroIdentificacion(documento);
		adm.setTipoIdentificacion(tipoDocumento);
		adm.setContrasenia(pws);
		return adm;
	}

	@Override
	public boolean login(String usr, String pws) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String recuperarContraseña(String usr) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean logout() {
		// TODO Auto-generated method stub
		return false;
	}

}
