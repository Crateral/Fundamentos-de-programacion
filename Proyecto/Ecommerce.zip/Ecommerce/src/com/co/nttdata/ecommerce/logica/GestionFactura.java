package com.co.nttdata.ecommerce.logica;

import com.co.nttdata.ecommerce.entidades.CarritoDeCompras;
import com.co.nttdata.ecommerce.entidades.Cliente;
import com.co.nttdata.ecommerce.entidades.Factura;

public class GestionFactura {

	public Factura pagar(Cliente cliente, CarritoDeCompras cdc) {
		Factura f = new Factura();
		f.setCliente(cliente);
		f.setDescripcion("Mi primera factura");
		f.setIdFactura(123123);
		f.setProductos(cdc);
		f.setValorTotalConIva(cdc.getSubTotal() + cdc.getValorEnvio());
		return f;
	}
	
}
