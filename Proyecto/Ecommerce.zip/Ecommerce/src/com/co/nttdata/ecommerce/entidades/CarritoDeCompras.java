package com.co.nttdata.ecommerce.entidades;

import java.util.Date;

public class CarritoDeCompras {

	private int idCarritoDeCompras;
	private Date fecha;
	private Producto[] productos;
	private double subTotal;
	private double valorEnvio;
	
	public CarritoDeCompras(int idCarritoDeCompras, Date fecha, Producto[] productos, double subTotal, double valorEnvio) {
		super();
		this.idCarritoDeCompras = idCarritoDeCompras;
		this.fecha = fecha;
		this.productos = productos;
		this.subTotal = subTotal;
		this.valorEnvio = valorEnvio;
	}

	public int getIdCarritoDeCompras() {
		return idCarritoDeCompras;
	}

	public void setIdCarritoDeCompras(int idCarritoDeCompras) {
		this.idCarritoDeCompras = idCarritoDeCompras;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public Producto[] getProductos() {
		return productos;
	}

	public void setProductos(Producto[] productos) {
		this.productos = productos;
	}

	public double getSubTotal() {
		return subTotal;
	}

	public void setSubTotal(double subTotal) {
		this.subTotal = subTotal;
	}

	public double getValorEnvio() {
		return valorEnvio;
	}

	public void setValorEnvio(double valorEnvio) {
		this.valorEnvio = valorEnvio;
	}
	
}
