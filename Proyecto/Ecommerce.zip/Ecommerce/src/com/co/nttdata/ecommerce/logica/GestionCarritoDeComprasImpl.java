package com.co.nttdata.ecommerce.logica;

import java.util.ArrayList;
import java.util.List;

import com.co.nttdata.ecommerce.entidades.CarritoDeCompras;
import com.co.nttdata.ecommerce.entidades.Ciudades;
import com.co.nttdata.ecommerce.entidades.Cliente;
import com.co.nttdata.ecommerce.entidades.Producto;
import com.co.nttdata.ecommerce.interfaces.GestionCarritoDeCompras;

public class GestionCarritoDeComprasImpl implements GestionCarritoDeCompras{

	@Override
	public CarritoDeCompras añadirAlCarrito(CarritoDeCompras cdc, List<Producto> p) {
		
		cdc.setProductos(p);
		return cdc;
		
	}
	
	@Override
	public double calcularTotalConIva(List<Producto> cdc) {
		
		double total = 0.0;
		
		for (int i = 0; i < cdc.size(); i++) {
			       //1100           2000
			total = total + cdc.get(i).getPrecio() + 
					(cdc.get(i).getPrecio() * 
							cdc.get(i).getIva());
			
		}
		return total;
	
	}
	
	@Override
	public double calcularCostoEnvio(Ciudades c, double valor) {
		
		if(c.getPrincipal()) {
			return valor * 0.05;
		}else {
			return valor * 0.1;
		}
	}
	
}
