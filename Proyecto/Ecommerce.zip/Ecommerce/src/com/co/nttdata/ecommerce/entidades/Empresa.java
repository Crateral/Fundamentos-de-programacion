package com.co.nttdata.ecommerce.entidades;

public class Empresa {

}
