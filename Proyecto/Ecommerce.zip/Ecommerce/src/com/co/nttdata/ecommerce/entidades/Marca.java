package com.co.nttdata.ecommerce.entidades;

public class Marca {
	
	private int idMarca;
	private String nombre;
	private String descipcion;
	
	public Marca() {
		
	}

	public Marca(int idMarca, String nombre, String descipcion) {
		super();
		this.idMarca = idMarca;
		this.nombre = nombre;
		this.descipcion = descipcion;
	}

	public int getIdMarca() {
		return idMarca;
	}

	public void setIdMarca(int idMarca) {
		this.idMarca = idMarca;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDescipcion() {
		return descipcion;
	}

	public void setDescipcion(String descipcion) {
		this.descipcion = descipcion;
	}

}
