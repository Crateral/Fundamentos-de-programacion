package com.co.nttdata.ecommerce.logica;

import com.co.nttdata.ecommerce.entidades.Cliente;
import com.co.nttdata.ecommerce.entidades.Usuario;
import com.co.nttdata.ecommerce.interfaces.GestionLogin;

public class GestionLoginImpl implements GestionLogin{

	@Override
	public Usuario registar(String nombre, String pws, String tipoDocumento, 
			String documento, String correo, String direccion) {

		Cliente usr = new Cliente();
		usr.setNombreUsuario(nombre);
		usr.setContrasenia(pws);
		usr.setCorreo(correo);
		usr.setTipoIdentificacion(tipoDocumento);
		usr.setNumeroIdentificacion(documento);
		usr.setDireccion(direccion);
		
		return usr;
	}

	@Override
	public boolean login(String usr, String pws) {
		// TODO Auto-generated method stub
		String usuario = "147896324";
		String contra = "1234";
		
		if(usuario.equalsIgnoreCase(usr) && pws.equalsIgnoreCase(contra)) {
			System.out.println("Inicio de sesion exitoso!");
			return true;
		}else {
			System.out.println("Usuario o Contraseña Erroneos");
			return false;
		}
	}

	@Override
	public String recuperarContraseña(String usr) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean logout() {
		// TODO Auto-generated method stub
		return false;
	}

	
}
