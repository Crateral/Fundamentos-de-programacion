package com.co.nttdata.ecommerce.entidades;

public enum Ciudades {

	BOGOTA(true),
	MEDELLIN(true),
	MADIRD(false);
	
	private boolean principal;
	
	private Ciudades(boolean pincipal) {
		this.principal = principal;
	}

	public boolean getPrincipal() {
		return principal;
	}

	public void setPrincipal(boolean principal) {
		this.principal = principal;
	}
	
}
