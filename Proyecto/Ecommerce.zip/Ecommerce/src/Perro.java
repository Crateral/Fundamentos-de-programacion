
public class Perro extends Animal{
	
	String nombre;
	
}
