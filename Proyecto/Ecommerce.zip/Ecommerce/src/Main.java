import java.util.Iterator;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Arreglo unidimencionales
		int[] arr = {1,2,3,4,5};
		int arr2[] = new int[10];
		
		arr2[0] = 10;
		arr2[5] = 5;
		
		System.out.println("Tamaño arreglo: " + arr.length);
		
		
		for (int i = 0; i < arr2.length; i++) {
			System.out.println(arr2[i]);
		}
		
		String arrS[] = new String[5];
		
		
		//Arreglos bidimencionales
		int[][] biarr = {{1,2,3,4},{5,6,7,8}};
		
		for (int i = 0; i < 2; i++) {
			for (int j = 0; j < 4; j++) {
				System.out.println(biarr[i][j]);
			}
		}
		
		int biarr2[][] = new int[2][2];
		biarr2[0][0] = 1;
		biarr2[0][1] = 2;
		biarr2[1][0] = 3;
		biarr2[1][1] = 4;
		
		
 	}

}
