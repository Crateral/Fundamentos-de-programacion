import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

import com.co.nttdata.ecommerce.entidades.*;
import com.co.nttdata.ecommerce.interfaces.GestionLogin;
import com.co.nttdata.ecommerce.logica.GestionLoginAdmImpl;
import com.co.nttdata.ecommerce.logica.GestionLoginImpl;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String nombreArchivo = "factura2.txt";
		escribirArchivo(nombreArchivo);
		leerArchivo(nombreArchivo);
	}
	
	public static void escribirArchivo(String nombreArchivo) {
		Cliente c = new Cliente();
		c.setNombreUsuario("Cesar");
		c.setCorreo("chidalgo@gmail.com");
		c.setDireccion("Calle 1 #1-1");
		FileWriter archivo = null;
		
		try {
			archivo = new FileWriter("C:\\Users\\zarce\\Documents\\NTTDATA\\"+nombreArchivo, false);
			
			archivo.write(c.getNombreUsuario() + "\n" +
						c.getCorreo() + "\n" + 
						c.getDireccion());
			for (int i = 0; i <= 3; i++) {
				archivo.write(i + "\n");
			}
			System.out.println("El archivo se ha escrito con exito");
			archivo.close();
		}
		catch(Exception e) {
			System.out.println("Error al escribir el archivo: " + e.getMessage());
		}
		
		
	}
	
	public static void leerArchivo(String nombreArchivo) {
		File archivo = new File("C:\\Users\\zarce\\Documents\\NTTDATA\\" + nombreArchivo);
		Scanner s = null;
		
		try {
			s = new Scanner(archivo);
			while(s.hasNextLine()) {
				String linea = s.nextLine();
				System.out.println(linea);
			}
			
		}catch(Exception e) {
			System.out.println("Error al leer el archivo: " + e.getMessage());
		}finally {
			try {
				if(s != null) {
					s.close();
				}
			}catch(Exception e) {
				System.out.println("Error al cerrar la lectura del archivo: " + e.getMessage());
			}
		}
	}

}
