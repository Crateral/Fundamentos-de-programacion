package com.co.nttdata.ecommerce.entidades;

public class Cliente extends Usuario{

	private String correo;
	private String telefono;
	private String direccion;
	private Ciudades ciudad;
	private boolean estado;
	private String numeroIdentificacion;
	private String tipoIdentificacion;
	private String metodoDePago;
	
	private String digUsuario;
	private String digContrasenia;
	
		
	public Cliente() {
		
	}
	
	public Cliente(String correo, String telefono, String direccion, Ciudades ciudad, boolean estado, String numeroIdentificacion,
			String tipoIdentificacion, String metodoDePago) {
		super();
		this.correo = correo;
		this.telefono = telefono;
		this.direccion = direccion;
		this.ciudad = ciudad;
		this.estado = estado;
		this.numeroIdentificacion = numeroIdentificacion;
		this.tipoIdentificacion = tipoIdentificacion;
		this.metodoDePago = metodoDePago;
	}

	public Cliente(int id, String nombreUsuario, String contrasenia) {
		super(id, nombreUsuario, contrasenia);
	}
	
	public Cliente(String digUsuario, String digContrasenia) {
		this.digUsuario = digUsuario;
		this.digContrasenia = digContrasenia;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public Ciudades getCiudad() {
		return ciudad;
	}

	public void setCiudad(Ciudades ciudad) {
		this.ciudad = ciudad;
	}

	public boolean isEstado() {
		return estado;
	}

	public void setEstado(boolean estado) {
		this.estado = estado;
	}

	public String getNumeroIdentificacion() {
		return numeroIdentificacion;
	}

	public void setNumeroIdentificacion(String numeroIdentificacion) {
		this.numeroIdentificacion = numeroIdentificacion;
	}

	public String getTipoIdentificacion() {
		return tipoIdentificacion;
	}

	public void setTipoIdentificacion(String tipoIdentificacion) {
		this.tipoIdentificacion = tipoIdentificacion;
	}

	public String getMetodoDePago() {
		return metodoDePago;
	}

	public void setMetodoDePago(String metodoDePago) {
		this.metodoDePago = metodoDePago;
	}

	public String getDigUsuario() {
		return digUsuario;
	}

	public void setDigUsuario(String digUsuario) {
		this.digUsuario = digUsuario;
	}

	public String getDigContrasenia() {
		return digContrasenia;
	}

	public void setDigContrasenia(String digContrasenia) {
		this.digContrasenia = digContrasenia;
	}

	@Override
	public String toString() {
		return "Correo= " + correo + "   Telefono= " + telefono + "\nDireccion= " + direccion + "         Estado= "
				+ estado + "\nNúmero Ident= " + numeroIdentificacion + "       Tipo Ident= "
				+ tipoIdentificacion + "\n\nMetodo Pago= " + metodoDePago + "\n";
	}
}
