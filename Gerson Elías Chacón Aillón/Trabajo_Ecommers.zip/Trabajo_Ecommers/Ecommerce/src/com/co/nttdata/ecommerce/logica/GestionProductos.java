package com.co.nttdata.ecommerce.logica;

import java.util.ArrayList;
import java.util.List;

import com.co.nttdata.ecommerce.entidades.CarritoDeCompras;
import com.co.nttdata.ecommerce.entidades.Categoria;
import com.co.nttdata.ecommerce.entidades.Marca;
import com.co.nttdata.ecommerce.entidades.Producto;

public class GestionProductos {
	
	List<Producto> lisProd = new ArrayList<>();
	CarritoDeCompras cdc = new CarritoDeCompras();
	
	public void agregarProd() {
		Producto prUno = new Producto(1, "nevera", 4, 450000, false, 0, 0, "nevera frost", "imgnev", Marca.LG, Categoria.ELECTRODOMESTICOS);
		Producto prDos = new Producto(2, "tv", 1, 300000, true, 50000, 19, "tv 32", "imgtv", Marca.SAMSUNG, Categoria.ELECTRODOMESTICOS);
		Producto prTres = new Producto(3, "monitor", 1, 450000, true, 30000, 19, "monitor 22", "imgmon", Marca.SAMSUNG, Categoria.ELECTRODOMESTICOS);
		Producto prCuatro = new Producto(4, "licuadora", 2, 150000, true, 15000, 19, "licuadora 100", "imglic", Marca.KIA, Categoria.ELECTRODOMESTICOS);
		Producto prCinco = new Producto(5, "lavadora", 1, 600000, false, 0, 19, "lavadora l12", "imglav", Marca.LG, Categoria.ELECTRODOMESTICOS);
		Producto prSeis = new Producto(6, "ventilador", 3, 300000, true, 10000, 19, "ventilador", "imgven", Marca.SAMSUNG, Categoria.ELECTRODOMESTICOS);
		Producto prSiete = new Producto(7, "aspiradora", 3, 200000, true, 50000, 19, "aspiradora", "imgasp", Marca.LG, Categoria.ELECTRODOMESTICOS);
		Producto prOcho = new Producto(8, "horno", 2, 700000, false, 0, 5, "horno p25", "imghor", Marca.SAMSUNG, Categoria.ELECTRODOMESTICOS);
		Producto prNueve = new Producto(9, "estufa", 1, 480000, true, 80000, 19, "estufa t147", "imgest", Marca.LG, Categoria.ELECTRODOMESTICOS);
		Producto prDiez = new Producto(10, "plancha", 1, 50000, false, 0, 19, "plancha r9", "imgplan", Marca.KIA, Categoria.ELECTRODOMESTICOS);
		
		
		lisProd.add(prUno);
		lisProd.add(prOcho);
		lisProd.add(prSiete);
		lisProd.add(prCuatro);
		lisProd.add(prDiez);
		lisProd.add(prSeis);
		
		
		// LLENA CARRITO CON PRODUCTOS
		cdc.setProductos(lisProd);
	}

}
