package com.co.nttdata.ecommerce.logica;


import java.util.List;

import com.co.nttdata.ecommerce.entidades.CarritoDeCompras;
import com.co.nttdata.ecommerce.entidades.Ciudades;
import com.co.nttdata.ecommerce.entidades.Producto;

public class GestionCarritoDeCompras {
	double total = 0, vrCant = 0, vrDcto = 0, vrIva = 0, subTot = 0;
	

	public CarritoDeCompras añadirAlCarrito(CarritoDeCompras cdc, List<Producto> p) {

		cdc.setProductos(p);
		return cdc;
	}

	
	public CarritoDeCompras calcularTotalConIva(CarritoDeCompras cdc) {

		for (int i = 0; i < cdc.getProductos().size(); i++) {
			
			vrCant = cdc.getProductos().get(i).getPrecio() * cdc.getProductos().get(i).getCantidadDiponible(); 
			
			/*total += cdc.getProductos().get(i).getPrecio()
					+ (cdc.getProductos().get(i).getPrecio() * (cdc.getProductos().get(i).getIva() / 100));*/
			
			total += vrCant + (vrCant * (cdc.getProductos().get(i).getIva() / 100));
			vrDcto += cdc.getProductos().get(i).getValorDescuento();
			vrIva += vrCant * (cdc.getProductos().get(i).getIva() / 100);
		}
		subTot = total - vrIva;
		cdc.setSubTotalConIva(total);
		cdc.setValorDcto(vrDcto);
		cdc.setValorIva(vrIva);
		cdc.setSubTotalSinIva(subTot);
		//System.out.println("Valor Factura = " + cdc.getSubTotalConIva());
		return cdc;
	}
	
	
	// METODO ENVIO 1 (CLIENTE 1 MAIN)
	/*public CarritoDeCompras calcularCostoEnvio(CarritoDeCompras cdc, String ubic) {
		
		// Para el calculo del envio se debe tener en cuenta la ubicacion del cliente
		// Si se encuentra en ciudades principales se debe cobrar el 5%
		// Si se encuentra en ciudades no principales se debe cobrar el 10%
		
		double por_env = 0, sub = 0;
		
		if (ubic.equals("s")) {
			por_env = 5;
		} else if (ubic.equals("n")) {
			por_env = 10;
		}
		
		System.out.println("Porcentaje Envio = " + por_env);
		sub = (total * por_env)/100; 
		cdc.setValorEnvio(sub);
		System.out.println("Valor envio = " + cdc.getValorEnvio());
		return cdc;
	}*/
	
	
	// METODO ENVIO 2 (CLIENTE 2 MAIN)
	public CarritoDeCompras calcularCostoEnvio(CarritoDeCompras cdc, Ciudades ciud) {

		// Para el calculo del envio se debe tener en cuenta la ubicacion del cliente
		// Si se encuentra en ciudades principales se debe cobrar el 5%
		// Si se encuentra en ciudades no principales se debe cobrar el 10%
		
		double por_env = 0, sub = 0;

		if (ciud.isPrincipal()) {
			por_env = 5;
		} else {
			por_env = 10;
		}
		
		//System.out.println("Porcentaje Envio = " + por_env);
		sub = (total * por_env) / 100;
		cdc.setValorEnvio(sub);
		//System.out.println("Valor envio = " + cdc.getValorEnvio());
		return cdc;
	}

}
