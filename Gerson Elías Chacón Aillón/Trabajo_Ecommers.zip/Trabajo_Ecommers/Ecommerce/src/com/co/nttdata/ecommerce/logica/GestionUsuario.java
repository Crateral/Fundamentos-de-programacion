package com.co.nttdata.ecommerce.logica;

import java.util.Scanner;

import com.co.nttdata.ecommerce.entidades.Ciudades;
import com.co.nttdata.ecommerce.entidades.Cliente;

public class GestionUsuario {
	
	Scanner teclado = new Scanner(System.in);
	Cliente cli = new Cliente();
	int w = 1;
	
	private int iniSess;
	
	public GestionUsuario() {
		
	}
	
	public GestionUsuario(int iniSess) {
		this.iniSess = 0;
	}
	
	public int getIniSess() {
		return iniSess;
	}

	public void setIniSess(int iniSess) {
		this.iniSess = iniSess;
	}

	public Cliente registarUsuario(Cliente cli) {
		int ct = 1, opc;
		while (w == 1) {
			System.out.print("\nDesea registrarse (s/n) ? : ");
			String reg = teclado.next();
			if (reg.equals("s")) {
				System.out.print("Digte ID            : ");
				int id = teclado.nextInt();
				cli.setId(id);
				System.out.print("Nombre Usuario      : ");
				String nom = teclado.next();
				cli.setNombreUsuario(nom);
				System.out.print("Contraseña          : ");
				String con = teclado.next();
				cli.setContrasenia(con);

				System.out.print("Tipo Ident          : ");
				String ti = teclado.next();
				cli.setTipoIdentificacion(ti);
				System.out.print("Número Ident        : ");
				String ni = teclado.next();
				cli.setNumeroIdentificacion(ni);
				System.out.print("Correo              : ");
				String cor = teclado.next();
				cli.setCorreo(cor);
				System.out.print("Dirección           : ");
				String dir = teclado.next();
				cli.setDireccion(dir);
				System.out.print("Teléfono            : ");
				String tel = teclado.next();
				cli.setTelefono(tel);
				System.out.print("\nSeleccione Ciudad   : \n");
				for (Ciudades mostCiu : Ciudades.values()) {
					System.out.println(ct++ + ". " + mostCiu);
				}
				System.out.print("Opción : ");
				opc = teclado.nextInt();
				if (opc == 1) {
					cli.setCiudad(Ciudades.BOGOTA);
				} else if (opc == 2) {
					cli.setCiudad(Ciudades.MEDELLIN);
				} else if (opc == 3) {
					cli.setCiudad(Ciudades.OTRAS);
				}
				System.out.print("Metodo pago         : ");
				String mp = teclado.next();
				cli.setMetodoDePago(mp);
				System.out.print("Estado (true/false) : ");
				boolean est = teclado.nextBoolean();
				cli.setEstado(est);
				
				System.out.print("\nUsuario registrado con éxito\n");
				break;
			} else if (reg.equals("n")) {
				System.out.println("\nSeleccionó no registrarse");
				break;
			}
		}
		return cli;
	}

	public Cliente mostrarUsuario(Cliente cli) {
		System.out.print("\nDigte ID            : " + cli.getId());
		System.out.print("\nNombre Usuario      : " + cli.getNombreUsuario());
		System.out.print("\nContraseña          : " + cli.getContrasenia());
		System.out.print("\nTipo Ident          : " + cli.getTipoIdentificacion());
		System.out.print("\nNúmero Ident        : " + cli.getNumeroIdentificacion());
		System.out.print("\nCorreo              : " + cli.getCorreo());
		System.out.print("\nDirección           : " + cli.getDireccion());
		System.out.print("\nTeléfono            : " + cli.getTelefono());
		System.out.print("\nCiudad              : " + cli.getCiudad());
		System.out.print("\nMétodo pago         : " + cli.getMetodoDePago());
		System.out.print("\nEstado (true/false) : " + cli.isEstado());
		System.out.println();
		return cli;
	}
	
	public Cliente digUsu(Cliente user) {
		System.out.print("\nDigite Usuario    : ");
		String du = teclado.next();
		user.setDigUsuario(du); 
		return user;
	}
	
	public Cliente digCont(Cliente contra) {
		System.out.print("Digite contraseña : ");
		String dc = teclado.next();
		contra.setDigContrasenia(dc);
		return contra;
	}
	
	public void inicioSesion(String usu, String ct, Cliente cli) {
		if (cli.getNombreUsuario().equals(usu) && cli.getContrasenia().equals(ct)) {
			System.out.print("\nSesión iniciada con éxito\n");
			setIniSess(1);
		} else if (!cli.getNombreUsuario().equals(usu) && !cli.getContrasenia().equals(ct)) {
			System.out.print("\nUsuario y Contraseña incorrectos\n");
		} else if (!cli.getNombreUsuario().equals(usu)) {
			System.out.print("\nUsuario incorrecto\n");
		} else if (!cli.getContrasenia().equals(ct)) {
			System.out.print("\nContraseña incorrecta\n");
		}
	}
	
	public void cierreSesion() {
		while (w == 1) {
			if (getIniSess() == 1) {
				System.out.print("\nDesea cerrar sesion ? s/n : ");
				String opc = teclado.next();
				if (opc.equals("s")) {
					System.out.println("\nSesión cerrada con éxito");
					setIniSess(0);
					break;
				} else if (opc.equals("n")) {
					System.out.println("\nSeleccionó no cerrar sesión");
					break;
				}
			} else {
				System.out.println("\nInicie sesión");
				break;
			}
		}
	}
	
	public void recuperaContrasenia(String us, Cliente cli) {
		while (w == 1) {
			if (getIniSess() == 1) {
				if (cli.getNombreUsuario().equals(us)) {
					System.out.print("\nDesea recuperar la contraseña (s/n) ? : ");
					String opc = teclado.next();
					if (opc.equals("s")) {
						System.out.print("Digite la nueva contraseña : ");
						String nvcont = teclado.next();
						cli.setContrasenia(nvcont);
						System.out.println("\nContraseña cambiada con éxito\n");
						break;
					} else if (opc.equals("n")) {
						System.out.println("\nSeleccionó no recuperar la contraseña\n");
						break;
					}
				} else {
					System.out.println("\nUsuario no existe\n");
					break;
				}
			} else {
				System.out.println("\nInicie sesión\n");
				break;
			}
		}
	}
}
