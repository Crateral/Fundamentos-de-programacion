import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.co.nttdata.ecommerce.entidades.*;
import com.co.nttdata.ecommerce.logica.*;

public class Main {
	
	static int op;
	static String gusu, gcont;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
				
		List<Producto> lisProd = new ArrayList<>();
		GestionCarritoDeCompras gdcd = new GestionCarritoDeCompras();
		CarritoDeCompras cdc = new CarritoDeCompras();
		Factura f = new Factura();
		GestionFactura gdf = new GestionFactura();
		GestionUsuario gdu = new GestionUsuario(); 
		Cliente cli = new Cliente();
		GestionProductos gdp = new GestionProductos();
		
		
		// CIUDAD = princ 5% - noPrinc 10%
		//Cliente cl = new Cliente("sa@hotmail.com", "31123", "Cl 32", Ciudades.MEDELLIN, true, "8824", "CC", "CONTADO");
		
		
		//Crear 10 prodcutos
		//Añadir 6 al carrito de comprar
		//Crear la factura de ese carrito de compras
		
		Producto prUno = new Producto(1, "nevera", 4, 450000, false, 0, 0, "nevera frost", "imgnev", Marca.LG, Categoria.ELECTRODOMESTICOS);
		Producto prDos = new Producto(2, "tv", 1, 300000, true, 50000, 19, "tv 32", "imgtv", Marca.SAMSUNG, Categoria.ELECTRODOMESTICOS);
		Producto prTres = new Producto(3, "monitor", 1, 450000, true, 30000, 19, "monitor 22", "imgmon", Marca.SAMSUNG, Categoria.ELECTRODOMESTICOS);
		Producto prCuatro = new Producto(4, "licuadora", 2, 150000, true, 15000, 19, "licuadora 100", "imglic", Marca.KIA, Categoria.ELECTRODOMESTICOS);
		Producto prCinco = new Producto(5, "lavadora", 1, 600000, false, 0, 19, "lavadora l12", "imglav", Marca.LG, Categoria.ELECTRODOMESTICOS);
		Producto prSeis = new Producto(6, "ventilador", 3, 300000, true, 10000, 19, "ventilador", "imgven", Marca.SAMSUNG, Categoria.ELECTRODOMESTICOS);
		Producto prSiete = new Producto(7, "aspiradora", 3, 200000, true, 50000, 19, "aspiradora", "imgasp", Marca.LG, Categoria.ELECTRODOMESTICOS);
		Producto prOcho = new Producto(8, "horno", 2, 700000, false, 0, 5, "horno p25", "imghor", Marca.SAMSUNG, Categoria.ELECTRODOMESTICOS);
		Producto prNueve = new Producto(9, "estufa", 1, 480000, true, 80000, 19, "estufa t147", "imgest", Marca.LG, Categoria.ELECTRODOMESTICOS);
		Producto prDiez = new Producto(10, "plancha", 1, 50000, false, 0, 19, "plancha r9", "imgplan", Marca.KIA, Categoria.ELECTRODOMESTICOS);
		
		
		lisProd.add(prUno);
		lisProd.add(prOcho);
		lisProd.add(prSiete);
		lisProd.add(prCuatro);
		lisProd.add(prDiez);
		lisProd.add(prSeis);
		
		
		// LLENA CARRITO CON PRODUCTOS
		cdc.setProductos(lisProd);
		
		
		// MUESTRA PRODUCTOS EN EL CARRITO
		/*cdc.getProductos().forEach((p) -> System.out.println("ID Prod= " + p.getIdProducto() + ", Nomb= " + p.getNombre() + 
				", Cant= " + p.getCantidadDiponible() + ", PVP= " + p.getPrecio() + ", Tiene Dcto= " + p.isDescuento() + 
				", Vr Dcto= " + p.getValorDescuento() +	", IVA= " + p.getIva() + ", Descrip= " + p.getDescripcion() + 
				", Imagen= " + p.getImg() + ", Marca= " + p.getMarca() + ", Categoria= " + p.getCategoria()));*/
		
		
		// VALOR FACTURA
		/*System.out.println();
		gdcd.calcularTotalConIva(cdc);*/
		
		
		// VALOR - UBICACION CLIENTE 1
		/*System.out.println();
		System.out.print("Ubicación Ciudad Principal (s/n) ? : ");
		String ubic = teclado.next();
		gdcd.calcularCostoEnvio(cdc, ubic);*/
		
		
		// VALOR - UBICACION CLIENTE 2
		/*System.out.println();
		gdcd.calcularCostoEnvio(cdc, cl.getCiudad());*/
		
		
		// FACTURA
		/*System.out.println();
		f = gdf.pagar(cl, cdc);
		gdf.mostFact(); */
		
		try {
			do {
				System.out.println();
				System.out.print("Seleccione... \n1. Registrar Usuario \n2. Mostrar Usuario \n3. Iniciar Sesión "
						+ "\n4. Cerrar Sesión \n5. Recuperar contraseña \n6. Facturar \n7. Salir \nOpcion : ");
				op = teclado.nextInt();
				switch (op) {
				case 1:
					try {
						gdu.registarUsuario(cli);
						break;
					} catch (Exception e) {
						System.out.println("\nError al digitar información");
					}
				case 2:
					gdu.mostrarUsuario(cli);
					break;
				case 3:
					try {
						gdu.digUsu(cli);
						gdu.digCont(cli);
						gusu = cli.getDigUsuario();
						gcont = cli.getDigContrasenia();
						gdu.inicioSesion(gusu, gcont, cli);
						break;
					} catch (Exception e) {
						System.out.println("\nNo se encontró información");
					}
				case 4:
					try {
						gdu.cierreSesion();
						break;
					} catch (Exception e) {
						System.out.println("\nNo se encontró información");
					}
				case 5:
					try {
						gdu.digUsu(cli);
						gusu = cli.getDigUsuario();
						gdu.recuperaContrasenia(gusu, cli);
						break;
					} catch (Exception e) {
						System.out.println("\nNo se encontró información");
					}
				case 6:
					try {
						if (gdu.getIniSess() == 1) {
							gdcd.calcularTotalConIva(cdc);
							gdcd.calcularCostoEnvio(cdc, cli.getCiudad());
							f = gdf.pagar(cli, cdc);
							gdf.mostFact();
							System.exit(0);
						} else {
							System.out.print("\nInicie Sesión\n");
						}
					} catch (Exception e) {
						System.out.print("Inicie Sesión para Facturar");
					}
				case 7:
					break;
				default:
					System.out.print("\nError al digitar opción\n");
					break;
				}

			} while (op != 7);
		} catch (Exception e) {
			System.out.println("\nError al digitar información");
		}
	}
}
