import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.co.nttdata.ecommerce.entidades.*;
import com.co.nttdata.ecommerce.interfaces.GestionLogin;
import com.co.nttdata.ecommerce.logica.*;

public class Main {
	
	static int op, w = 1, id;
	static String nomb, contra, tipIdent, numIdent, correo;
	static boolean estado;
	static List<Producto> lisProd = new ArrayList<>();
	static CarritoDeCompras cdc = new CarritoDeCompras();
	static Cliente cl;
	static Administrador adm;
	static Scanner teclado = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		
				
		GestionCarritoDeComprasImpl gdcd = new GestionCarritoDeComprasImpl();
		Factura f = new Factura();
		GestionFacturaImpl gdf = new GestionFacturaImpl();
		GestionLogin gl = new GestionLoginImpl();
		GestionLoginImpl gdu = new GestionLoginImpl();
			
		
		try {
			do {
				System.out.println();
				System.out.print("Seleccione... \n1. Registrar Usuario \n2. Mostrar Usuario \n3. Iniciar Sesión "
						+ "\n4. Cerrar Sesión \n5. Recuperar contraseña \n6. Agregar productos \n7. Facturar \n8. Salir \nOpcion : ");
				op = teclado.nextInt();
				switch (op) {
				case 1:
					try {
						int ct = 1, opc, w = 1;
						Ciudades ciudad = null;
						FormaPago forPago = null;
						while (w == 1) {
							System.out.print("\nDesea registrarse (s/n) ? : ");
							String reg = teclado.next();
							if (reg.equals("s")) {
								ingDatosUsu();
								System.out.print("Dirección           : ");
								String direccion = teclado.next();
								System.out.print("Teléfono            : ");
								String telefono = teclado.next();
								System.out.print("\nSeleccione Ciudad   : \n");
								for (Ciudades mostCiu : Ciudades.values()) {
									System.out.println(ct++ + ". " + mostCiu);
								}
								System.out.print("Opción : ");
								opc = teclado.nextInt();
								if (opc == 1) {
									ciudad = Ciudades.BOGOTA;
								} else if (opc == 2) {
									ciudad = Ciudades.MEDELLIN;
								} else if (opc == 3) {
									ciudad = Ciudades.OTRAS;
								}
								System.out.print("\nMetodo pago         : \n");
								ct = 1;
								for (FormaPago mostForPag : FormaPago.values()) {
									System.out.println(ct++ + ". " + mostForPag);
								}
								System.out.print("Opción : ");
								opc = teclado.nextInt();
								if (opc == 1) {
									forPago = FormaPago.CONTADO;
								} else if (opc == 2) {
									forPago = FormaPago.CREDITO;
								} else if (opc == 3) {
									forPago = FormaPago.TARJETA_DEBITO;
								} else if (opc == 4) {
									forPago = FormaPago.TARJETA_CREDITO;
								}
								
								cl = (Cliente) gl.registarUsuario(id, nomb, contra, tipIdent, numIdent, correo, 
										estado, direccion, telefono, ciudad, forPago);
								
								/*adm = (Administrador) gl.registarUsuario(id, nomb, contra, tipIdent, numIdent, correo, 
										estado, direccion, telefono, ciudad, forPago);*/
								break;
							} else if (reg.equals("n")) {
								System.out.println("\nSeleccionó no registrarse");
								break;
							}
						}
					} catch (Exception e) {
						System.out.println("\nError al digitar información");
					}
					break;
				case 2:
					System.out.print("\n*** DATOS DEL CLIENTE ***");
					System.out.print("\nDigte ID            : " + cl.getId());
					System.out.print("\nNombre Usuario      : " + cl.getNombreUsuario());
					System.out.print("\nContraseña          : " + cl.getContrasenia());
					System.out.print("\nTipo Ident          : " + cl.getTipoIdentificacion());
					System.out.print("\nNúmero Ident        : " + cl.getNumeroIdentificacion());
					System.out.print("\nCorreo              : " + cl.getCorreo());
					System.out.print("\nDirección           : " + cl.getDireccion());
					System.out.print("\nTeléfono            : " + cl.getTelefono());
					System.out.print("\nCiudad              : " + cl.getCiudad());
					System.out.print("\nMétodo pago         : " + cl.getMetodoDePago());
					System.out.print("\nEstado (true/false) : " + cl.isEstado());
					System.out.println();
					break;
				case 3:
					try {
						if ( ((GestionLoginImpl) gl).getIniSess() == 0) {
							System.out.print("\nDigite Usuario    : ");
							String user = teclado.next();
							System.out.print("Digite contraseña : ");
							String contra = teclado.next();
							gl.login(user, contra);
							break;
						} else {
							System.out.print("\nTiene la sesión iniciada\n");
							break;
						}
					} catch (Exception e) {
						System.out.println("\nNo se encontró información");
					}
					break;
				case 4:
					try {
						while (w == 1) {
							if ( ((GestionLoginImpl) gl).getIniSess() == 1) {
								System.out.print("\nDesea cerrar sesion ? s/n : ");
								String cerSes = teclado.next();
								gl.logout(cerSes);
								break;
							} else {
								System.out.println("\nInicie sesión");
								break;
							}
						}
						break;
					} catch (Exception e) {
						System.out.println("\nNo se encontró información");
					}
					break;
				case 5:
					try {
						if (((GestionLoginImpl) gl).getIniSess() == 1) {
							System.out.print("\nDigite Usuario    : ");
							String user = teclado.next();
							gl.recuperContrasenia(user);
							break;
						} else {
							System.out.println("\nInicie sesión");
							break;
						}
					} catch (Exception e) {
						System.out.println("\nNo se encontró información");
					}
					break;
				case 6:
					agregarProd();
					System.out.print("Productos agregados al carrito con éxito\n");
					break;
				case 7:
					try {
						if ( ((GestionLoginImpl) gl).getIniSess() == 1) {
							gdcd.calcularTotalConIva(cdc);
							gdcd.calcularCostoEnvio(cdc, cl.getCiudad());
							f = gdf.pagar(cl, cdc);
							gdf.mostFact();
							System.exit(0);
						} else {
							System.out.print("\nInicie Sesión\n");
						}
					} catch (Exception e) {
						System.out.print("Inicie Sesión para Facturar");
					}
				case 8:
					break;
				default:
					System.out.print("\nError al digitar opción\n");
					break;
				}
			} while (op != 8);
		} catch (Exception e) {
			System.out.println("\nError al digitar información");
		}
	}
	
	
	public static void ingDatosUsu() {
		System.out.print("Digte ID            : ");
		id = teclado.nextInt();
		System.out.print("Nombre Usuario      : ");
		nomb = teclado.next();
		System.out.print("Contraseña          : ");
		contra = teclado.next();
		System.out.print("Tipo Ident          : ");
		tipIdent = teclado.next();
		System.out.print("Número Ident        : ");
		numIdent = teclado.next();
		System.out.print("Correo              : ");
		correo = teclado.next();
		System.out.print("Estado (true/false) : ");
		estado = teclado.nextBoolean();
	}

	public static void agregarProd() {

		Producto prUno = new Producto(1, "nevera", 4, 450000, false, 0, 0, "nevera frost", "imgnev", Marca.LG,
				Categoria.ELECTRODOMESTICOS);
		Producto prDos = new Producto(2, "tv", 1, 300000, true, 50000, 19, "tv 32", "imgtv", Marca.SAMSUNG,
				Categoria.ELECTRODOMESTICOS);
		Producto prTres = new Producto(3, "monitor", 1, 450000, true, 30000, 19, "monitor 22", "imgmon", Marca.SAMSUNG,
				Categoria.ELECTRODOMESTICOS);
		Producto prCuatro = new Producto(4, "licuadora", 2, 150000, true, 15000, 19, "licuadora 100", "imglic",
				Marca.KIA, Categoria.ELECTRODOMESTICOS);
		Producto prCinco = new Producto(5, "lavadora", 1, 600000, false, 0, 19, "lavadora l12", "imglav", Marca.LG,
				Categoria.ELECTRODOMESTICOS);
		Producto prSeis = new Producto(6, "ventilador", 3, 300000, true, 10000, 19, "ventilador", "imgven",
				Marca.SAMSUNG, Categoria.ELECTRODOMESTICOS);
		Producto prSiete = new Producto(7, "aspiradora", 3, 200000, true, 50000, 19, "aspiradora", "imgasp", Marca.LG,
				Categoria.ELECTRODOMESTICOS);
		Producto prOcho = new Producto(8, "horno", 2, 700000, false, 0, 5, "horno p25", "imghor", Marca.SAMSUNG,
				Categoria.ELECTRODOMESTICOS);
		Producto prNueve = new Producto(9, "estufa", 1, 480000, true, 80000, 19, "estufa t147", "imgest", Marca.LG,
				Categoria.ELECTRODOMESTICOS);
		Producto prDiez = new Producto(10, "plancha", 1, 50000, false, 0, 19, "plancha r9", "imgplan", Marca.KIA,
				Categoria.ELECTRODOMESTICOS);

		lisProd.add(prUno);
		lisProd.add(prOcho);
		lisProd.add(prSiete);
		lisProd.add(prCuatro);
		lisProd.add(prDiez);
		lisProd.add(prSeis);

		// LLENA CARRITO CON PRODUCTOS
		cdc.setProductos(lisProd);
		
		for (Producto mostprod : lisProd) {
			System.out.println(mostprod);
		}
	}

}