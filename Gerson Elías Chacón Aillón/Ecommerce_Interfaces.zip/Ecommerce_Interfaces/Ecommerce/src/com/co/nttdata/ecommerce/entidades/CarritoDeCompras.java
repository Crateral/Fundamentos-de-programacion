package com.co.nttdata.ecommerce.entidades;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CarritoDeCompras {

	private int idCarritoDeCompras;
	private Date fecha;
	private List<Producto> productos;
	//private double subTotal;
	private double valorEnvio;
	
	//Se debe cambiar los artibutos del subTotal a:
	// - subTotalConIva y subTotaSinIva
	private double subTotalConIva;
	private double subTotalSinIva;
	private double valorDcto;
	private double valorIva;
	
	
	public CarritoDeCompras() {
		this.productos = new ArrayList<>();	
	}
	
	public CarritoDeCompras(int idCarritoDeCompras, Date fecha, List<Producto> productos, double valorEnvio, 
			double subTotalConIva, double subTotalSinIva, double valorDcto, double valorIva) {
		super();
		this.idCarritoDeCompras = idCarritoDeCompras;
		this.fecha = fecha;
		this.productos = productos;
		this.valorEnvio = valorEnvio;
		this.subTotalConIva = subTotalConIva;
		this.subTotalSinIva = subTotalSinIva;
		this.valorDcto = valorDcto;
		this.valorIva = valorIva;
	}

	public int getIdCarritoDeCompras() {
		return idCarritoDeCompras;
	}

	public void setIdCarritoDeCompras(int idCarritoDeCompras) {
		this.idCarritoDeCompras = idCarritoDeCompras;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public List<Producto> getProductos() {
		return productos;
	}

	public void setProductos(List<Producto> productos) {
		this.productos = productos;
	}

	public double getValorEnvio() {
		return valorEnvio;
	}

	public void setValorEnvio(double valorEnvio) {
		this.valorEnvio = valorEnvio;
	}

	public double getSubTotalConIva() {
		return subTotalConIva;
	}

	public void setSubTotalConIva(double subTotalConIva) {
		this.subTotalConIva = subTotalConIva;
	}

	public double getSubTotalSinIva() {
		return subTotalSinIva;
	}

	public void setSubTotalSinIva(double subTotalSinIva) {
		this.subTotalSinIva = subTotalSinIva;
	}

	public double getValorDcto() {
		return valorDcto;
	}

	public void setValorDcto(double valorDcto) {
		this.valorDcto = valorDcto;
	}

	public double getValorIva() {
		return valorIva;
	}

	public void setValorIva(double valorIva) {
		this.valorIva = valorIva;
	}
	
}
