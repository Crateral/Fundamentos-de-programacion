package com.co.nttdata.colegioRest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ColegioRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
