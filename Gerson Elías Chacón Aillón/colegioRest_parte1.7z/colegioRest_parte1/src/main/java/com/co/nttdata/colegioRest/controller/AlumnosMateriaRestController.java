package com.co.nttdata.colegioRest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.co.nttdata.colegioRest.entity.TblAlumnosMateria;
import com.co.nttdata.colegioRest.services.AlumnosMateriaService;

//@CrossOrigin(origins = "http://localhost:1516")
@RestController  // Inidcamos que es controlador rest
@RequestMapping("/colegioRest/AlumnosMaterias") // URL - http://localhost:1516/colegioRest/AlumnosMaterias
public class AlumnosMateriaRestController {
	
	//Inyectamos el servicio para poder hacer uso de el
	@Autowired
	private AlumnosMateriaService alumnosMateriaService;
	
	
	@GetMapping
	public List<TblAlumnosMateria> findAll() {
		return alumnosMateriaService.findAll();
	}
	
	
	@GetMapping("{idAlmMat}")
	public TblAlumnosMateria getTblAlumnosMateria(@PathVariable int idAlmMat) {
		
		TblAlumnosMateria almMat = alumnosMateriaService.findById(idAlmMat);

		if (almMat == null) {
			throw new RuntimeException("ID Alumnos Materias " + idAlmMat + " no existe...!!");
		}

		return almMat;
	}
	
		
	@DeleteMapping("{idAlmMat}")
	public String delete(@PathVariable int idAlmMat) {
		
		TblAlumnosMateria almMat = alumnosMateriaService.findById(idAlmMat);

		if (almMat == null) {
			throw new RuntimeException("Alumnos Materias " + idAlmMat + " no existe...!");
		} else {
			alumnosMateriaService.delete(idAlmMat);
			return "ID Alumnos Materia " + idAlmMat + " borrado con éxito...!";
		}
	}
	
	
	@PostMapping
	public TblAlumnosMateria create(@RequestBody TblAlumnosMateria almMat) {
		
		//alm.setIdAlm(0);
		
		alumnosMateriaService.create(almMat);
		
		return almMat;
	}
	
	
	@PutMapping("{idAlmMat}")
	public TblAlumnosMateria update(@RequestBody TblAlumnosMateria almMat, @PathVariable int idAlmMat) {
		
		List<TblAlumnosMateria> lisAlumMat = alumnosMateriaService.findAll();
		TblAlumnosMateria alMat = new TblAlumnosMateria();
		
		for (TblAlumnosMateria mosAlmMat : lisAlumMat) {
			alMat = mosAlmMat;
			if (mosAlmMat.getIdAlmMat() == idAlmMat) {
				alMat.setTblAlumno(almMat.getTblAlumno());
				alMat.setTblMateria(alMat.getTblMateria());
				alumnosMateriaService.create(alMat);
				break;
			}
		}
		return almMat;	
	}

}
