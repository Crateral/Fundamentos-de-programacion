package com.co.nttdata.colegioRest.services;

import java.util.List;

import com.co.nttdata.colegioRest.entity.TblProfesores;

public interface ProfesoresService {
	
	public TblProfesores findById(int id);
	
	public List<TblProfesores> findAll();
	
	public void delete(int id);
	
	public void create(TblProfesores prof);
	
}
