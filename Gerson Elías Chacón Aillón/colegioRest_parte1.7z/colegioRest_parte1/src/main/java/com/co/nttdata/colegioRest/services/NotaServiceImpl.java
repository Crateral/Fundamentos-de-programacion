package com.co.nttdata.colegioRest.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.co.nttdata.colegioRest.daos.NotaDAO;
import com.co.nttdata.colegioRest.entity.TblNota;

@Service
public class NotaServiceImpl implements NotaService{
	
	@Autowired
	private NotaDAO notaDAO;

	@Override
	@Transactional(readOnly = true)
	public TblNota findById(int id) {
		
		TblNota nota = notaDAO.findById(id);
		
		return nota;
	}

	@Override
	@Transactional(readOnly = true)
	public List<TblNota> findAll() {
		
		List<TblNota> lisNota = notaDAO.findAll();
		
		return lisNota;
	}

	@Override
	@Transactional
	public void delete(int id) {
		notaDAO.delete(id);				
	}

	@Override
	@Transactional
	public void create(TblNota nota) {
		notaDAO.create(nota);		
	}

}
