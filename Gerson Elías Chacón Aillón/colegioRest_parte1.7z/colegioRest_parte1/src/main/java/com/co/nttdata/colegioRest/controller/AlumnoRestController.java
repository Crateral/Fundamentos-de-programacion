package com.co.nttdata.colegioRest.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.co.nttdata.colegioRest.entity.TblAlumno;
import com.co.nttdata.colegioRest.services.AlumnoService;

//@CrossOrigin(origins = "http://localhost:1516")
@RestController  // Inidcamos que es controlador rest
@RequestMapping("/colegioRest/Alumnos") // URL - http://localhost:1516/colegioRest/Alumnos
public class AlumnoRestController {
	
	//Inyectamos el servicio para poder hacer uso de el
	@Autowired
	private AlumnoService alumnoService;
	
	
	@GetMapping
	public List<TblAlumno> findAll() {
		return alumnoService.findAll();
	}
	
	
	@GetMapping("{idAlm}")
	public TblAlumno getTblAlumno(@PathVariable int idAlm) {
		
		TblAlumno alm = alumnoService.findById(idAlm);

		if (alm == null) {
			throw new RuntimeException("ID Alumno " + idAlm + " no existe...!!");
		}

		return alm;
	}
	
		
	@DeleteMapping("{idAlm}")
	public String delete(@PathVariable int idAlm) {
		
		TblAlumno alm = alumnoService.findById(idAlm);

		if (alm == null) {
			throw new RuntimeException("Alumno " + idAlm + " no existe...!");
		} else {
			alumnoService.delete(idAlm);
			return "ID Alumno " + idAlm + " borrado con éxito...!";
		}
	}
	
	
	@PostMapping
	public TblAlumno create(@RequestBody TblAlumno alm) {
		
		//alm.setIdAlm(0);
		
		alumnoService.create(alm);
		
		return alm;
	}
	
	
	@PutMapping("{idAlm}")
	public TblAlumno update(@RequestBody TblAlumno alm, @PathVariable int idAlm) {
		
		List<TblAlumno> lisAlum = alumnoService.findAll();
		TblAlumno al = new TblAlumno();
		
		for (TblAlumno mosAlm : lisAlum) {
			al = mosAlm;
			if (mosAlm.getIdAlm() == idAlm) {
				al.setNumIdentAlm(alm.getNumIdentAlm());
				al.setNomAlm(alm.getNomAlm());
				alumnoService.create(al);
				break;
			}
		}
		return al;	
	}

}
