package com.co.nttdata.colegioRest.services;

import java.util.List;

import com.co.nttdata.colegioRest.entity.TblNota;

public interface NotaService {
	
	public TblNota findById(int id);
	
	public List<TblNota> findAll();
	
	public void delete(int id);
	
	public void create(TblNota nota);
	
}
