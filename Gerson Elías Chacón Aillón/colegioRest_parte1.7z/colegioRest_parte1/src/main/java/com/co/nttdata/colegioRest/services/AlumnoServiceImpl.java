package com.co.nttdata.colegioRest.services;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.co.nttdata.colegioRest.daos.AlumnoDAO;
import com.co.nttdata.colegioRest.entity.TblAlumno;

@Service
public class AlumnoServiceImpl implements AlumnoService{
	
	@Autowired
	private AlumnoDAO alumnoDAO;

	@Override
	@Transactional(readOnly = true)
	public TblAlumno findById(int id) {
		
		TblAlumno alm = alumnoDAO.findById(id);
		
		return alm;
	}

	@Override
	@Transactional(readOnly = true)
	public List<TblAlumno> findAll() {
		
		List<TblAlumno> lisAlum = alumnoDAO.findAll();
		
		return lisAlum;
	}

	@Override
	@Transactional
	public void delete(int id) {
		alumnoDAO.delete(id);				
	}

	@Override
	@Transactional
	public void create(TblAlumno alm) {
		alumnoDAO.create(alm);		
	}

}
