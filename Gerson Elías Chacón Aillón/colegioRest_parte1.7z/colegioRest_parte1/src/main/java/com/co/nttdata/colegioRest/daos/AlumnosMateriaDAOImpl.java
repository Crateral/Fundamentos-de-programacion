package com.co.nttdata.colegioRest.daos;

import java.util.List;

import javax.persistence.EntityManager;
import org.hibernate.Session;
import org.hibernate.query.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.co.nttdata.colegioRest.entity.TblAlumnosMateria;


@Repository
public class AlumnosMateriaDAOImpl implements AlumnosMateriaDAO {
	
	@Autowired
	private EntityManager entityManager;

	@Override
	public TblAlumnosMateria findById(int id) {
		
		Session currentSession = entityManager.unwrap(Session.class);
		
		TblAlumnosMateria almMat = currentSession.get(TblAlumnosMateria.class, id);
		
		return almMat;
	}

	@Override
	public List<TblAlumnosMateria> findAll() {
		
		Session currentSession = entityManager.unwrap(Session.class);
		
		Query<TblAlumnosMateria> theQuery = currentSession.createQuery("from TblAlumnosMateria order by id_alm_mat asc", TblAlumnosMateria.class);
		
		List<TblAlumnosMateria> almMat = theQuery.getResultList();
		
		return almMat;
	}

	@Override
	public void delete(int id) {
		
		Session currentSession = entityManager.unwrap(Session.class);
		
		Query<TblAlumnosMateria> theQuery = currentSession.createQuery("delete from TblAlumnosMateria where id_alm_mat = :idalmMat");
		
		theQuery.setParameter("idalmMat", id);
		
		int vr = theQuery.executeUpdate();
		if (vr > 0)
			System.out.println("Registro eliminado con éxito...!");
	}

	@Override
	public void create(TblAlumnosMateria almMat) {
		
		Session currSession = entityManager.unwrap(Session.class);
		
		currSession.saveOrUpdate(almMat);
	}
	
}
