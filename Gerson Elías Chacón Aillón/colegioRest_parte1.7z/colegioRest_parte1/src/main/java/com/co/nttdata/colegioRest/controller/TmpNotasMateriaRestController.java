package com.co.nttdata.colegioRest.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.co.nttdata.colegioRest.services.TmpNotasMateriaService;
import com.co.nttdata.colegioRest.tmp.TmpNotasMateria;



//@CrossOrigin(origins = "http://localhost:1516")
@RestController  // Inidcamos que es controlador rest
@RequestMapping("/colegioRest/TmpNotasMateria") // URL - http://localhost:1516/colegioRest/TmpNotasMateria
public class TmpNotasMateriaRestController {
	
	//Inyectamos el servicio para poder hacer uso de el
	@Autowired
	private TmpNotasMateriaService tmpNotasMateriaService;
	
		
	@GetMapping("{idtmpNotMat}")
	public List<TmpNotasMateria> getTmpNotasMaterias(@PathVariable int idtmpNotMat) {
		
		List<TmpNotasMateria> tmpNotMat = tmpNotasMateriaService.findById(idtmpNotMat);

		if (tmpNotMat == null) {
			throw new RuntimeException("ID Notas Alumno " + idtmpNotMat + " no existe...!!");
		}

		return tmpNotMat;
	}
}