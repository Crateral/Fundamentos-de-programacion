package com.co.nttdata.colegioRest.daos;

import java.util.List;


import javax.persistence.EntityManager;
import org.hibernate.Session;
import org.hibernate.query.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.co.nttdata.colegioRest.tmp.TmpNotasAlumno;

@Repository
public class TmpNotasAlumnoDAOImpl implements TmpNotasAlumnoDAO {
	
	@Autowired
	private EntityManager entityManager;

	@Override
	public List<TmpNotasAlumno> findById(int id) {
		
		Session currentSession = entityManager.unwrap(Session.class);
		
		Query qd =currentSession.createQuery("delete from TmpNotasAlumno");
		qd.executeUpdate();
		
		Query qis = currentSession.createQuery("insert into TmpNotasAlumno (nomAlm, nota) select a.nomAlm, n.nota "
				+ "from TblAlumno a inner join TblNota n on a.idAlm = n.idAlm "
				+ "where a.idAlm =:id");
		
		qis.setParameter("id", id);
		qis.executeUpdate();
						
		Query<TmpNotasAlumno> theQuery = currentSession.createQuery("from TmpNotasAlumno", TmpNotasAlumno.class);
		
		List<TmpNotasAlumno> tmp = theQuery.getResultList();
		
		return tmp;
	}
}
