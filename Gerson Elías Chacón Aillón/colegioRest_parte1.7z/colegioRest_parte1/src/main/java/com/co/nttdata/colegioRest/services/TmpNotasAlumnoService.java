package com.co.nttdata.colegioRest.services;

import java.util.List;

import com.co.nttdata.colegioRest.tmp.TmpNotasAlumno;

public interface TmpNotasAlumnoService {
	
	public List<TmpNotasAlumno> findById(int id);
	
	}
