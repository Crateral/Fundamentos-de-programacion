package com.co.nttdata.colegioRest.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.*;

/**
 * The persistent class for the "TBL_ALUMNOS" database table.
 * 
 */
@Entity
@Table(name="\"TBL_ALUMNOS\"")
@NamedQuery(name="TblAlumno.findAll", query="SELECT t FROM TblAlumno t")
public class TblAlumno implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="id_alm")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idAlm;

	@Column(name = "num_ident_alm")
	private Integer numIdentAlm;
	
	@Column(name = "nom_alm")
	private String nomAlm;

	

	//bi-directional many-to-one association to TblAlumnosMateria
	/*@OneToMany(mappedBy="tblAlumno")
	private List<TblAlumnosMateria> tblAlumnosMaterias;

	//bi-directional many-to-one association to TblNota
	@OneToMany(mappedBy="tblAlumno")
	private List<TblNota> tblNotas;*/

	public TblAlumno() {
	}

	public Integer getIdAlm() {
		return this.idAlm;
	}

	public void setIdAlm(Integer idAlm) {
		this.idAlm = idAlm;
	}
	
	public Integer getNumIdentAlm() {
		return this.numIdentAlm;
	}

	public void setNumIdentAlm(Integer numIdentAlm) {
		this.numIdentAlm = numIdentAlm;
	}

	public String getNomAlm() {
		return this.nomAlm;
	}

	public void setNomAlm(String nomAlm) {
		this.nomAlm = nomAlm;
	}
	
	/*public List<TblAlumnosMateria> getTblAlumnosMaterias() {
		return this.tblAlumnosMaterias;
	}

	public void setTblAlumnosMaterias(List<TblAlumnosMateria> tblAlumnosMaterias) {
		this.tblAlumnosMaterias = tblAlumnosMaterias;
	}

	public TblAlumnosMateria addTblAlumnosMateria(TblAlumnosMateria tblAlumnosMateria) {
		getTblAlumnosMaterias().add(tblAlumnosMateria);
		tblAlumnosMateria.setTblAlumno(this);

		return tblAlumnosMateria;
	}

	public TblAlumnosMateria removeTblAlumnosMateria(TblAlumnosMateria tblAlumnosMateria) {
		getTblAlumnosMaterias().remove(tblAlumnosMateria);
		tblAlumnosMateria.setTblAlumno(null);

		return tblAlumnosMateria;
	}

	public List<TblNota> getTblNotas() {
		return this.tblNotas;
	}

	public void setTblNotas(List<TblNota> tblNotas) {
		this.tblNotas = tblNotas;
	}*/

	@Override
	public String toString() {
		return "ID = " + idAlm + ", Num Ident Alm = " + numIdentAlm + ", Nom Alm = " + nomAlm;
	}	
}