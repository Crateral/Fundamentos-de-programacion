package com.co.nttdata.colegioRest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ColegioRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(ColegioRestApplication.class, args);
	}

}
