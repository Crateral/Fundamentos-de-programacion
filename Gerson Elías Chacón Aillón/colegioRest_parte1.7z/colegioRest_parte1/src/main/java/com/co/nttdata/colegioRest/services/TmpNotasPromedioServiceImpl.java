package com.co.nttdata.colegioRest.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.co.nttdata.colegioRest.daos.TmpNotasPromedioDAO;
import com.co.nttdata.colegioRest.tmp.TmpNotasPromedio;

@Service
public class TmpNotasPromedioServiceImpl implements TmpNotasPromedioService{
	
	@Autowired
	private TmpNotasPromedioDAO tmpNotasPromedioDAO;

	@Override
	@Transactional
	public List<TmpNotasPromedio> findById(int id) {
		
		List<TmpNotasPromedio> tmNot = tmpNotasPromedioDAO.findById(id);
		
		return tmNot;
	}
}
