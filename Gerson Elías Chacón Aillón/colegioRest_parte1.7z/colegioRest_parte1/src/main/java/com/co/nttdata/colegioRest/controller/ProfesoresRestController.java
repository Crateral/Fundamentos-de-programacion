package com.co.nttdata.colegioRest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.co.nttdata.colegioRest.entity.TblProfesores;
import com.co.nttdata.colegioRest.services.ProfesoresService;

//@CrossOrigin(origins = "http://localhost:1516")
@RestController  // Inidcamos que es controlador rest
@RequestMapping("/colegioRest/Profesores") // URL - http://localhost:1516/colegioRest/Profesores
public class ProfesoresRestController {
	
	//Inyectamos el servicio para poder hacer uso de el
	@Autowired
	private ProfesoresService profesoresService;
	
	
	@GetMapping
	public List<TblProfesores> findAll() {
		return profesoresService.findAll();
	}
	
	
	@GetMapping("{idPf}")
	public TblProfesores getTblProfesores(@PathVariable int idPf) {
		
		TblProfesores prof = profesoresService.findById(idPf);

		if (prof == null) {
			throw new RuntimeException("ID Profesor " + idPf + " no existe...!!");
		}

		return prof;
	}
	
		
	@DeleteMapping("{idPf}")
	public String delete(@PathVariable int idPf) {
		
		TblProfesores prof = profesoresService.findById(idPf);

		if (prof == null) {
			throw new RuntimeException("Profesor " + idPf + " no existe...!");
		} else {
			profesoresService.delete(idPf);
			return "ID Profesor " + idPf + " borrado con éxito...!";
		}
	}
	
	
	@PostMapping
	public TblProfesores create(@RequestBody TblProfesores prof) {
		
		//alm.setIdAlm(0);
		
		profesoresService.create(prof);
		
		return prof;
	}
	
	
	@PutMapping("{idPf}")
	public TblProfesores update(@RequestBody TblProfesores prof, @PathVariable int idPf) {
		
		List<TblProfesores> lisProf = profesoresService.findAll();
		TblProfesores pf = new TblProfesores();
		
		for (TblProfesores mosProf : lisProf) {
			pf = mosProf;
			if (mosProf.getIdPf() == idPf) {
				pf.setNumIdentPf(prof.getNumIdentPf());
				pf.setNomPf(prof.getNomPf());
				profesoresService.create(pf);
				break;
			}
		}
		return pf;	
	}

}
