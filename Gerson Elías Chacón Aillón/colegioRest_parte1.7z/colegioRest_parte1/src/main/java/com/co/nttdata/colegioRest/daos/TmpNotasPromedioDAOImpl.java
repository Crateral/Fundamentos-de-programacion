package com.co.nttdata.colegioRest.daos;

import java.util.List;


import javax.persistence.EntityManager;
import org.hibernate.Session;
import org.hibernate.query.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.co.nttdata.colegioRest.tmp.TmpNotasPromedio;

@Repository
public class TmpNotasPromedioDAOImpl implements TmpNotasPromedioDAO {
	
	@Autowired
	private EntityManager entityManager;

	@Override
	public List<TmpNotasPromedio> findById(int id) {
		
		Session currentSession = entityManager.unwrap(Session.class);
		
		Query qd =currentSession.createQuery("delete from TmpNotasPromedio");
		qd.executeUpdate();
		
		Query qis = currentSession.createQuery("insert into TmpNotasPromedio (nomAlm, promedio, materia) select a.nomAlm, avg(n.nota), m.materia "
				+ "from TblNota n inner join TblAlumno a on a.idAlm = n.idAlm inner join TblMateria m on m.idMateria = n.idMateria "
				+ "where a.idAlm =:id group by a.nomAlm, m.materia");
		
		qis.setParameter("id", id);
		qis.executeUpdate();
		
		Query<TmpNotasPromedio> theQuery = currentSession.createQuery("from TmpNotasPromedio", TmpNotasPromedio.class);
		
		List<TmpNotasPromedio> tmp = theQuery.getResultList();
		
		return tmp;
	}
}
