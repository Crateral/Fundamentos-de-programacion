package com.co.nttdata.colegioRest.daos;

import java.util.List;

import javax.persistence.EntityManager;
import org.hibernate.Session;
import org.hibernate.query.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.co.nttdata.colegioRest.entity.TblAlumno;

@Repository
public class AlumnoDAOImpl implements AlumnoDAO {
	
	@Autowired
	private EntityManager entityManager;

	@Override
	public TblAlumno findById(int id) {
		
		Session currentSession = entityManager.unwrap(Session.class);
		
		TblAlumno alm = currentSession.get(TblAlumno.class, id);
		
		return alm;
	}

	@Override
	public List<TblAlumno> findAll() {
		
		Session currentSession = entityManager.unwrap(Session.class);
		
		Query<TblAlumno> theQuery = currentSession.createQuery("from TblAlumno order by id_alm asc", TblAlumno.class);
		
		List<TblAlumno> alm = theQuery.getResultList();
		
		return alm;
	}

	@Override
	public void delete(int id) {
		
		Session currentSession = entityManager.unwrap(Session.class);
		
		Query<TblAlumno> theQuery = currentSession.createQuery("delete from TblAlumno where id_alm = :idalm");
		
		theQuery.setParameter("idalm", id);
		
		int vr = theQuery.executeUpdate();
		if (vr > 0)
			System.out.println("Registro eliminado con éxito...!");
	}

	@Override
	public void create(TblAlumno alm) {
		
		Session currSession = entityManager.unwrap(Session.class);
		
		currSession.saveOrUpdate(alm);
	}
	
}
