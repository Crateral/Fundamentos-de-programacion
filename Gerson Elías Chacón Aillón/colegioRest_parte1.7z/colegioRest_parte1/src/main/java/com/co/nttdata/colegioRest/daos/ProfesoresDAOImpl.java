package com.co.nttdata.colegioRest.daos;

import java.util.List;

import javax.persistence.EntityManager;
import org.hibernate.Session;
import org.hibernate.query.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.co.nttdata.colegioRest.entity.TblProfesores;


@Repository
public class ProfesoresDAOImpl implements ProfesoresDAO {
	
	@Autowired
	private EntityManager entityManager;

	@Override
	public TblProfesores findById(int id) {
		
		Session currentSession = entityManager.unwrap(Session.class);
		
		TblProfesores prof = currentSession.get(TblProfesores.class, id);
		
		return prof;
	}

	@Override
	public List<TblProfesores> findAll() {
		
		Session currentSession = entityManager.unwrap(Session.class);
		
		Query<TblProfesores> theQuery = currentSession.createQuery("from TblProfesores order by id_pf asc", TblProfesores.class);
		
		List<TblProfesores> prof = theQuery.getResultList();
		
		return prof;
	}

	@Override
	public void delete(int id) {
		
		Session currentSession = entityManager.unwrap(Session.class);
		
		Query<TblProfesores> theQuery = currentSession.createQuery("delete from TblProfesores where id_pf = :idpf");
		
		theQuery.setParameter("idpf", id);
		
		int vr = theQuery.executeUpdate();
		if (vr > 0)
			System.out.println("Registro eliminado con éxito...!");
	}

	@Override
	public void create(TblProfesores prof) {
		
		Session currSession = entityManager.unwrap(Session.class);
		
		currSession.saveOrUpdate(prof);
	}
	
}
