package com.co.nttdata.colegioRest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.co.nttdata.colegioRest.entity.TblNota;
import com.co.nttdata.colegioRest.services.NotaService;

//@CrossOrigin(origins = "http://localhost:1516")
@RestController  // Inidcamos que es controlador rest
@RequestMapping("/colegioRest/Notas") // URL - http://localhost:1516/colegioRest/Notas
public class NotaRestController {
	
	//Inyectamos el servicio para poder hacer uso de el
	@Autowired
	private NotaService notaService;
	
	
	@GetMapping
	public List<TblNota> findAll() {
		return notaService.findAll();
	}
	
	
	@GetMapping("{idNota}")
	public TblNota getTblNota(@PathVariable int idNota) {
		
		TblNota nota = notaService.findById(idNota);

		if (nota == null) {
			throw new RuntimeException("ID Nota " + idNota + " no existe...!!");
		}

		return nota;
	}
	
		
	@DeleteMapping("{idNota}")
	public String delete(@PathVariable int idNota) {
		
		TblNota nota = notaService.findById(idNota);

		if (nota == null) {
			throw new RuntimeException("Nota " + idNota + " no existe...!");
		} else {
			notaService.delete(idNota);
			return "ID Nota " + idNota + " borrado con éxito...!";
		}
	}
	
	
	@PostMapping
	public TblNota create(@RequestBody TblNota nota) {
		
		//alm.setIdAlm(0);
		
		notaService.create(nota);
		
		return nota;
	}
	
	
	@PutMapping("{idNota}")
	public TblNota update(@RequestBody TblNota nota, @PathVariable int idNota) {
		
		List<TblNota> lisNota = notaService.findAll();
		TblNota nt = new TblNota();
		
		for (TblNota mosNota : lisNota) {
			nt = mosNota;
			if (mosNota.getIdNota() == idNota) {
				nt.setNota(nota.getNota());
				nt.setIdAlm(nota.getIdAlm());
				nt.setIdMateria(nota.getIdMateria());
				notaService.create(nt);
				break;
			}
		}
		return nt;	
	}

}
