package com.co.nttdata.colegioRest.services;

import java.util.List;

import com.co.nttdata.colegioRest.tmp.TmpNotasPromedio;


public interface TmpNotasPromedioService {
	
	public List<TmpNotasPromedio> findById(int id);
	
	}
