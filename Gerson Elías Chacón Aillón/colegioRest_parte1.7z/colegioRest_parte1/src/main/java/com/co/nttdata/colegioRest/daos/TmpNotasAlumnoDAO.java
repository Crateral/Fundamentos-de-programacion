package com.co.nttdata.colegioRest.daos;

import java.util.List;

import com.co.nttdata.colegioRest.tmp.TmpNotasAlumno;

public interface TmpNotasAlumnoDAO {
	
	public List<TmpNotasAlumno> findById(int id);
	
	}
