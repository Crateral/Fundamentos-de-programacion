package com.co.nttdata.colegioRest.entity;

import java.io.Serializable;

import javax.persistence.*;

/**
 * The persistent class for the "TBL_PROFESORES" database table.
 * 
 */
@Entity
@Table(name="\"TBL_PROFESORES\"")
@NamedQuery(name="TblProfesores.findAll", query="SELECT t FROM TblProfesores t")
public class TblProfesores implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id_pf")
	private Integer idPf;

	@Column(name="num_ident_pf", nullable = false, unique = true)
	private Integer numIdentPf;
	
	@Column(name="nom_pf", nullable = false)
	private String nomPf;
	

	/*//bi-directional many-to-one association to TblAlumnosProfesore
	@OneToMany(mappedBy="tblProfesore")
	private List<TblAlumnosProfesore> tblAlumnosProfesores;

	//bi-directional many-to-one association to TblProfesoresMateria
	@OneToMany(mappedBy="tblProfesore")
	private List<TblProfesoresMateria> tblProfesoresMaterias;*/

	public TblProfesores() {
	}

	public Integer getIdPf() {
		return this.idPf;
	}

	public void setIdPf(Integer idPf) {
		this.idPf = idPf;
	}

	public String getNomPf() {
		return this.nomPf;
	}

	public void setNomPf(String nomPf) {
		this.nomPf = nomPf;
	}

	public Integer getNumIdentPf() {
		return this.numIdentPf;
	}

	public void setNumIdentPf(Integer numIdentPf) {
		this.numIdentPf = numIdentPf;
	}

	/*public List<TblAlumnosProfesore> getTblAlumnosProfesores() {
		return this.tblAlumnosProfesores;
	}

	public void setTblAlumnosProfesores(List<TblAlumnosProfesore> tblAlumnosProfesores) {
		this.tblAlumnosProfesores = tblAlumnosProfesores;
	}

	public TblAlumnosProfesore addTblAlumnosProfesore(TblAlumnosProfesore tblAlumnosProfesore) {
		getTblAlumnosProfesores().add(tblAlumnosProfesore);
		tblAlumnosProfesore.setTblProfesore(this);

		return tblAlumnosProfesore;
	}

	public TblAlumnosProfesore removeTblAlumnosProfesore(TblAlumnosProfesore tblAlumnosProfesore) {
		getTblAlumnosProfesores().remove(tblAlumnosProfesore);
		tblAlumnosProfesore.setTblProfesore(null);

		return tblAlumnosProfesore;
	}

	public List<TblProfesoresMateria> getTblProfesoresMaterias() {
		return this.tblProfesoresMaterias;
	}

	public void setTblProfesoresMaterias(List<TblProfesoresMateria> tblProfesoresMaterias) {
		this.tblProfesoresMaterias = tblProfesoresMaterias;
	}

	public TblProfesoresMateria addTblProfesoresMateria(TblProfesoresMateria tblProfesoresMateria) {
		getTblProfesoresMaterias().add(tblProfesoresMateria);
		tblProfesoresMateria.setTblProfesore(this);

		return tblProfesoresMateria;
	}

	public TblProfesoresMateria removeTblProfesoresMateria(TblProfesoresMateria tblProfesoresMateria) {
		getTblProfesoresMaterias().remove(tblProfesoresMateria);
		tblProfesoresMateria.setTblProfesore(null);

		return tblProfesoresMateria;
	}*/

	@Override
	public String toString() {
		return "ID = " + idPf + ", Num Ident Pf = " + numIdentPf + ", Nom Pf = " + nomPf;
	}

}