package com.co.nttdata.colegioRest.services;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.co.nttdata.colegioRest.daos.MateriaDAO;
import com.co.nttdata.colegioRest.entity.TblMateria;


@Service
public class MateriaServiceImpl implements MateriaService{
	
	@Autowired
	private MateriaDAO materiaDAO;

	@Override
	@Transactional(readOnly = true)
	public TblMateria findById(int id) {
		
		TblMateria mat = materiaDAO.findById(id);
		
		return mat;
	}

	@Override
	@Transactional(readOnly = true)
	public List<TblMateria> findAll() {
		
		List<TblMateria> lisMat = materiaDAO.findAll();
		
		return lisMat;
	}

	@Override
	@Transactional
	public void delete(int id) {
		materiaDAO.delete(id);				
	}

	@Override
	@Transactional
	public void create(TblMateria mat) {
		materiaDAO.create(mat);		
	}

}
