package com.co.nttdata.colegioRest.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.co.nttdata.colegioRest.daos.TmpNotasMateriaDAO;
import com.co.nttdata.colegioRest.tmp.TmpNotasMateria;

@Service
public class TmpNotasMateriaServiceImpl implements TmpNotasMateriaService{
	
	@Autowired
	private TmpNotasMateriaDAO tmpNotasMateriaDAO;

	@Override
	@Transactional
	public List<TmpNotasMateria> findById(int id) {
		
		List<TmpNotasMateria> tmNot = tmpNotasMateriaDAO.findById(id);
		
		return tmNot;
	}
}
