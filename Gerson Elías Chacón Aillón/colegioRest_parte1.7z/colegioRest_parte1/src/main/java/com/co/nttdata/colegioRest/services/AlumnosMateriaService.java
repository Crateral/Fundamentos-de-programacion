package com.co.nttdata.colegioRest.services;

import java.util.List;

import com.co.nttdata.colegioRest.entity.TblAlumnosMateria;

public interface AlumnosMateriaService {
	
	public TblAlumnosMateria findById(int id);
	
	public List<TblAlumnosMateria> findAll();
	
	public void delete(int id);
	
	public void create(TblAlumnosMateria almMat);
	
}
