package com.co.nttdata.colegioRest.entity;

import java.io.Serializable;

import javax.persistence.*;


/**
 * The persistent class for the "TBL_ALUMNOS_MATERIAS" database table.
 * 
 */
@Entity
@Table(name="\"TBL_ALUMNOS_MATERIAS\"")
@NamedQuery(name="TblAlumnosMateria.findAll", query="SELECT t FROM TblAlumnosMateria t")
public class TblAlumnosMateria implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id_alm_mat")
	private Integer idAlmMat;

	//bi-directional many-to-one association to TblAlumno
	@ManyToOne
	@JoinColumn(name="id_alm")
	private TblAlumno tblAlumno;

	//bi-directional many-to-one association to TblMateria
	@ManyToOne
	@JoinColumn(name="id_materia")
	private TblMateria tblMateria;

	public TblAlumnosMateria() {
	}

	public Integer getIdAlmMat() {
		return this.idAlmMat;
	}

	public void setIdAlmMat(Integer idAlmMat) {
		this.idAlmMat = idAlmMat;
	}

	public TblAlumno getTblAlumno() {
		return this.tblAlumno;
	}

	public void setTblAlumno(TblAlumno tblAlumno) {
		this.tblAlumno = tblAlumno;
	}

	public TblMateria getTblMateria() {
		return this.tblMateria;
	}

	public void setTblMateria(TblMateria tblMateria) {
		this.tblMateria = tblMateria;
	}

	@Override
	public String toString() {
		return "TblAlumnosMateria [idAlmMat=" + idAlmMat + ", tblAlumno=" + tblAlumno + ", tblMateria=" + tblMateria
				+ "]";
	}

}