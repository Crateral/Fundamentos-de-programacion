package com.co.nttdata.colegioRest.services;

import java.util.List;

import com.co.nttdata.colegioRest.entity.TblAlumno;

public interface AlumnoService {
	
	public TblAlumno findById(int id);
	
	public List<TblAlumno> findAll();
	
	public void delete(int id);
	
	public void create(TblAlumno alm);
	
}
