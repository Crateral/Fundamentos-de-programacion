package com.co.nttdata.colegioRest.daos;

import java.util.List;


import javax.persistence.EntityManager;
import org.hibernate.Session;
import org.hibernate.query.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.co.nttdata.colegioRest.tmp.TmpNotasMateria;

@Repository
public class TmpNotasMateriaDAOImpl implements TmpNotasMateriaDAO {
	
	@Autowired
	private EntityManager entityManager;

	@Override
	public List<TmpNotasMateria> findById(int id) {
		
		Session currentSession = entityManager.unwrap(Session.class);
		
		Query qd =currentSession.createQuery("delete from TmpNotasMateria");
		qd.executeUpdate();
		
		// PROMEDIO MATERIA
		/*Query qis = currentSession.createQuery("insert into TmpNotasMateria (materia, nota) select m.materia, avg(n.nota) "
				+ "from TblMateria m inner join TblNota n on m.idMateria = n.idMateria "
				+ "where m.idMateria =:id group by m.materia");
		
		qis.setParameter("id", id);
		qis.executeUpdate();*/
		
		// MATERIA
		Query qisi = currentSession.createQuery("insert into TmpNotasMateria (materia, nota) select m.materia, n.nota "
				+ "from TblMateria m inner join TblNota n on m.idMateria = n.idMateria "
				+ "where m.idMateria =:id");
		
		qisi.setParameter("id", id);
		qisi.executeUpdate();
		
		Query<TmpNotasMateria> theQuery = currentSession.createQuery("from TmpNotasMateria", TmpNotasMateria.class);
		
		List<TmpNotasMateria> tmp = theQuery.getResultList();
		
		return tmp;
	}
}
