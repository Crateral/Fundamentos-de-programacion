package com.co.nttdata.colegioRest.daos;

import java.util.List;

import com.co.nttdata.colegioRest.tmp.TmpNotasMateria;


public interface TmpNotasMateriaDAO {
	
	public List<TmpNotasMateria> findById(int id);
	
	}
