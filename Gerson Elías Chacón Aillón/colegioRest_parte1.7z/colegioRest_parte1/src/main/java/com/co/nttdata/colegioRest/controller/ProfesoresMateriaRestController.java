package com.co.nttdata.colegioRest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.co.nttdata.colegioRest.entity.TblProfesoresMateria;
import com.co.nttdata.colegioRest.services.ProfesoresMateriaService;

//@CrossOrigin(origins = "http://localhost:1516")
@RestController  // Inidcamos que es controlador rest
@RequestMapping("/colegioRest/ProfesoresMaterias") // URL - http://localhost:1516/colegioRest/ProfesoresMaterias
public class ProfesoresMateriaRestController {
	
	//Inyectamos el servicio para poder hacer uso de el
	@Autowired
	private ProfesoresMateriaService profesoresMateriaService;
	
	
	@GetMapping
	public List<TblProfesoresMateria> findAll() {
		return profesoresMateriaService.findAll();
	}
	
	
	@GetMapping("{idPfMat}")
	public TblProfesoresMateria getTblProfesoresMateria(@PathVariable int idPfMat) {
		
		TblProfesoresMateria pfMat = profesoresMateriaService.findById(idPfMat);

		if (pfMat == null) {
			throw new RuntimeException("ID Alumnos Materias " + idPfMat + " no existe...!!");
		}

		return pfMat;
	}
	
		
	@DeleteMapping("{idPfMat}")
	public String delete(@PathVariable int idPfMat) {
		
		TblProfesoresMateria pfMat = profesoresMateriaService.findById(idPfMat);

		if (pfMat == null) {
			throw new RuntimeException("Profesores Materias " + idPfMat + " no existe...!");
		} else {
			profesoresMateriaService.delete(idPfMat);
			return "ID Alumnos Materia " + idPfMat + " borrado con éxito...!";
		}
	}
	
	
	@PostMapping
	public TblProfesoresMateria create(@RequestBody TblProfesoresMateria pfMat) {
		
		//alm.setIdAlm(0);
		
		profesoresMateriaService.create(pfMat);
		
		return pfMat;
	}
	
	
	@PutMapping("{idPfMat}")
	public TblProfesoresMateria update(@RequestBody TblProfesoresMateria pfMat, @PathVariable int idPfMat) {
		
		List<TblProfesoresMateria> lisPfMat = profesoresMateriaService.findAll();
		TblProfesoresMateria prfMat = new TblProfesoresMateria();
		
		for (TblProfesoresMateria mosPfMat : lisPfMat) {
			prfMat = mosPfMat;
			if (mosPfMat.getIdPfMaterias() == idPfMat) {
				prfMat.setTblProfesore(pfMat.getTblProfesore());
				prfMat.setTblMateria(pfMat.getTblMateria());
				profesoresMateriaService.create(prfMat);
				break;
			}
		}
		return prfMat;	
	}

}
