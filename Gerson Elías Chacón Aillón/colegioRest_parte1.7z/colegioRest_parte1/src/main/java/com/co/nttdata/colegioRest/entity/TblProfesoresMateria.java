package com.co.nttdata.colegioRest.entity;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the "TBL_PROFESORES_MATERIAS" database table.
 * 
 */
@Entity
@Table(name="\"TBL_PROFESORES_MATERIAS\"")
@NamedQuery(name="TblProfesoresMateria.findAll", query="SELECT t FROM TblProfesoresMateria t")
public class TblProfesoresMateria implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id_pf_materias")
	private Integer idPfMaterias;

	//bi-directional many-to-one association to TblMateria
	@ManyToOne
	@JoinColumn(name="id_materia")
	private TblMateria tblMateria;

	//bi-directional many-to-one association to TblProfesore
	@ManyToOne
	@JoinColumn(name="id_pf")
	private TblProfesores tblProfesore;

	public TblProfesoresMateria() {
	}

	public Integer getIdPfMaterias() {
		return this.idPfMaterias;
	}

	public void setIdPfMaterias(Integer idPfMaterias) {
		this.idPfMaterias = idPfMaterias;
	}

	public TblMateria getTblMateria() {
		return this.tblMateria;
	}

	public void setTblMateria(TblMateria tblMateria) {
		this.tblMateria = tblMateria;
	}

	public TblProfesores getTblProfesore() {
		return this.tblProfesore;
	}

	public void setTblProfesore(TblProfesores tblProfesore) {
		this.tblProfesore = tblProfesore;
	}

	@Override
	public String toString() {
		return "TblProfesoresMateria [idPfMaterias=" + idPfMaterias + ", tblMateria=" + tblMateria + ", tblProfesore="
				+ tblProfesore + "]";
	}

}