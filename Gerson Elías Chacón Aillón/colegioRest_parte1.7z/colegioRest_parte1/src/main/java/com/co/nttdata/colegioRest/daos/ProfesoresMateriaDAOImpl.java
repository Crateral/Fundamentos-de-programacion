package com.co.nttdata.colegioRest.daos;

import java.util.List;

import javax.persistence.EntityManager;
import org.hibernate.Session;
import org.hibernate.query.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.co.nttdata.colegioRest.entity.TblProfesoresMateria;

@Repository
public class ProfesoresMateriaDAOImpl implements ProfesoresMateriaDAO {
	
	@Autowired
	private EntityManager entityManager;

	@Override
	public TblProfesoresMateria findById(int id) {
		
		Session currentSession = entityManager.unwrap(Session.class);
		
		TblProfesoresMateria pfMat = currentSession.get(TblProfesoresMateria.class, id);
		
		return pfMat;
	}

	@Override
	public List<TblProfesoresMateria> findAll() {
		
		Session currentSession = entityManager.unwrap(Session.class);
		
		Query<TblProfesoresMateria> theQuery = currentSession.createQuery("from TblProfesoresMateria order by id_pf_materias asc", TblProfesoresMateria.class);
		
		List<TblProfesoresMateria> pfMat = theQuery.getResultList();
		
		return pfMat;
	}

	@Override
	public void delete(int id) {
		
		Session currentSession = entityManager.unwrap(Session.class);
		
		Query<TblProfesoresMateria> theQuery = currentSession.createQuery("delete from TblProfesoresMateria where id_pf_materias = :idpfMat");
		
		theQuery.setParameter("idpfMat", id);
		
		int vr = theQuery.executeUpdate();
		if (vr > 0)
			System.out.println("Registro eliminado con éxito...!");
	}

	@Override
	public void create(TblProfesoresMateria pfMat) {
		
		Session currSession = entityManager.unwrap(Session.class);
		
		currSession.saveOrUpdate(pfMat);
	}
	
}
