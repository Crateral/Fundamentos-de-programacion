package com.co.nttdata.colegioRest.daos;

import java.util.List;

import com.co.nttdata.colegioRest.entity.TblAlumnosMateria;


public interface AlumnosMateriaDAO {
	
	public TblAlumnosMateria findById(int id);
	
	public List<TblAlumnosMateria> findAll();
	
	public void delete(int id);
	
	public void create(TblAlumnosMateria almMat);
	
}
