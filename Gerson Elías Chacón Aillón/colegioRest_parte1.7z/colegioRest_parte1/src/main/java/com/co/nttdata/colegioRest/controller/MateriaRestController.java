package com.co.nttdata.colegioRest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.co.nttdata.colegioRest.entity.TblMateria;
import com.co.nttdata.colegioRest.services.MateriaService;

//@CrossOrigin(origins = "http://localhost:1516")
@RestController  // Inidcamos que es controlador rest
@RequestMapping("/colegioRest/Materias") // URL - http://localhost:1516/colegioRest/Materias
public class MateriaRestController {
	
	//Inyectamos el servicio para poder hacer uso de el
	@Autowired
	private MateriaService materiaService;
	
	
	@GetMapping
	public List<TblMateria> findAll() {
		return materiaService.findAll();
	}
	
	
	@GetMapping("{idMat}")
	public TblMateria getTblMateria(@PathVariable int idMat) {
		
		TblMateria mat = materiaService.findById(idMat);

		if (mat == null) {
			throw new RuntimeException("ID Materia " + idMat + " no existe...!!");
		}

		return mat;
	}
	
		
	@DeleteMapping("{idMat}")
	public String delete(@PathVariable int idMat) {
		
		TblMateria mat = materiaService.findById(idMat);

		if (mat == null) {
			throw new RuntimeException("Materia " + idMat + " no existe...!");
		} else {
			materiaService.delete(idMat);
			return "ID Materia " + idMat + " borrada con éxito...!";
		}
	}
	
	
	@PostMapping
	public TblMateria create(@RequestBody TblMateria mat) {
		
		//alm.setIdAlm(0);
		
		materiaService.create(mat);
		
		return mat;
	}
	
	
	@PutMapping("{idMat}")
	public TblMateria update(@RequestBody TblMateria mat, @PathVariable int idMat) {
		
		List<TblMateria> lisMat = materiaService.findAll();
		TblMateria mt = new TblMateria();
		
		for (TblMateria mosMat : lisMat) {
			mt = mosMat;
			if (mosMat.getIdMateria() == idMat) {
				mt.setMateria(mat.getMateria());
				materiaService.create(mt);
				break;
			}
		}
		return mt;	
	}

}
