package com.co.nttdata.colegioRest.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.co.nttdata.colegioRest.daos.AlumnosMateriaDAO;
import com.co.nttdata.colegioRest.entity.TblAlumnosMateria;


@Service
public class AlumnosMateriaServiceImpl implements AlumnosMateriaService{
	
	@Autowired
	private AlumnosMateriaDAO alumnosMateriaDAO;

	@Override
	@Transactional(readOnly = true)
	public TblAlumnosMateria findById(int id) {
		
		TblAlumnosMateria almMat = alumnosMateriaDAO.findById(id);
		
		return almMat;
	}

	@Override
	@Transactional(readOnly = true)
	public List<TblAlumnosMateria> findAll() {
		
		List<TblAlumnosMateria> lisAlumMat = alumnosMateriaDAO.findAll();
		
		return lisAlumMat;
	}

	@Override
	@Transactional
	public void delete(int id) {
		alumnosMateriaDAO.delete(id);				
	}

	@Override
	@Transactional
	public void create(TblAlumnosMateria almMat) {
		alumnosMateriaDAO.create(almMat);		
	}

}
