package com.co.nttdata.colegioRest.tmp;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the "TMP_NOTAS_MATERIAS" database table.
 * 
 */
@Entity
@Table(name="\"TMP_NOTAS_MATERIAS\"", schema = "public")
@NamedQuery(name="TmpNotasMateria.findAll", query="SELECT t FROM TmpNotasMateria t")
public class TmpNotasMateria implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "materia")
	private String materia;

	@Column(name = "nota")
	private double nota;

	public TmpNotasMateria() {
	}

	public String getMateria() {
		return this.materia;
	}

	public void setMateria(String materia) {
		this.materia = materia;
	}

	public double getNota() {
		return this.nota;
	}

	public void setNota(double nota) {
		this.nota = nota;
	}

	@Override
	public String toString() {
		return "Materia = " + materia + ", Nota = " + nota;
	}

}