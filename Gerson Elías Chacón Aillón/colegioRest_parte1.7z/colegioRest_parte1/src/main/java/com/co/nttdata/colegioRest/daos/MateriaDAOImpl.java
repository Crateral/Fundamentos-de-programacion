package com.co.nttdata.colegioRest.daos;

import java.util.List;

import javax.persistence.EntityManager;
import org.hibernate.Session;
import org.hibernate.query.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.co.nttdata.colegioRest.entity.TblMateria;

@Repository
public class MateriaDAOImpl implements MateriaDAO {
	
	@Autowired
	private EntityManager entityManager;

	@Override
	public TblMateria findById(int id) {
		
		Session currentSession = entityManager.unwrap(Session.class);
		
		TblMateria mat = currentSession.get(TblMateria.class, id);
		
		return mat;
	}

	@Override
	public List<TblMateria> findAll() {
		
		Session currentSession = entityManager.unwrap(Session.class);
		
		Query<TblMateria> theQuery = currentSession.createQuery("from TblMateria order by id_materia asc", TblMateria.class);
		
		List<TblMateria> mat = theQuery.getResultList();
		
		return mat;
	}

	@Override
	public void delete(int id) {
		
		Session currentSession = entityManager.unwrap(Session.class);
		
		Query<TblMateria> theQuery = currentSession.createQuery("delete from TblMateria where id_materia = :idmat");
		
		theQuery.setParameter("idmat", id);
		
		int vr = theQuery.executeUpdate();
		if (vr > 0)
			System.out.println("Registro eliminado con éxito...!");
	}

	@Override
	public void create(TblMateria mat) {
		
		Session currSession = entityManager.unwrap(Session.class);
		
		currSession.saveOrUpdate(mat);
	}
	
}
