package com.co.nttdata.colegioRest.tmp;

import java.io.Serializable;

import javax.persistence.*;

/**
 * The persistent class for the "TMP_NOTAS_ALUMNOS" database table.
 * 
 */
@Entity
@Table(name="\"TMP_NOTAS_ALUMNOS\"", schema = "public")
@NamedQuery(name="TmpNotasAlumno.findAll", query="SELECT t FROM TmpNotasAlumno t")
public class TmpNotasAlumno implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="nom_alm")
	private String nomAlm;

	@Column(name = "nota")
	private double nota;
	
	public TmpNotasAlumno() {
	}

	public String getNomAlm() {
		return this.nomAlm;
	}

	public void setNomAlm(String nomAlm) {
		this.nomAlm = nomAlm;
	}

	public double getNota() {
		return this.nota;
	}

	public void setNota(double nota) {
		this.nota = nota;
	}

	@Override
	public String toString() {
		return "Nom Alm = " + nomAlm + ", Nota = " + nota;
	}

}