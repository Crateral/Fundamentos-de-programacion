package com.co.nttdata.colegioRest.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.co.nttdata.colegioRest.daos.ProfesoresDAO;
import com.co.nttdata.colegioRest.entity.TblProfesores;

@Service
public class ProfesoresServiceImpl implements ProfesoresService{
	
	@Autowired
	private ProfesoresDAO profesoresDAO;

	@Override
	@Transactional(readOnly = true)
	public TblProfesores findById(int id) {
		
		TblProfesores prof = profesoresDAO.findById(id);
		
		return prof;
	}

	@Override
	@Transactional(readOnly = true)
	public List<TblProfesores> findAll() {
		
		List<TblProfesores> lisprof = profesoresDAO.findAll();
		
		return lisprof;
	}

	@Override
	@Transactional
	public void delete(int id) {
		profesoresDAO.delete(id);				
	}

	@Override
	@Transactional
	public void create(TblProfesores prof) {
		profesoresDAO.create(prof);		
	}

}
