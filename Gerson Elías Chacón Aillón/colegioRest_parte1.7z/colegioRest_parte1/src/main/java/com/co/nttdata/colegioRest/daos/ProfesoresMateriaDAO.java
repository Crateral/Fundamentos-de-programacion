package com.co.nttdata.colegioRest.daos;

import java.util.List;

import com.co.nttdata.colegioRest.entity.TblProfesoresMateria;


public interface ProfesoresMateriaDAO {
	
	public TblProfesoresMateria findById(int id);
	
	public List<TblProfesoresMateria> findAll();
	
	public void delete(int id);
	
	public void create(TblProfesoresMateria pfMat);
	
}
