package com.co.nttdata.colegioRest.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.co.nttdata.colegioRest.daos.ProfesoresMateriaDAO;
import com.co.nttdata.colegioRest.entity.TblProfesoresMateria;


@Service
public class ProfesoresMateriaServiceImpl implements ProfesoresMateriaService{
	
	@Autowired
	private ProfesoresMateriaDAO profesoresMateriaDAO;

	@Override
	@Transactional(readOnly = true)
	public TblProfesoresMateria findById(int id) {
		
		TblProfesoresMateria pfMat = profesoresMateriaDAO.findById(id);
		
		return pfMat;
	}

	@Override
	@Transactional(readOnly = true)
	public List<TblProfesoresMateria> findAll() {
		
		List<TblProfesoresMateria> lisPfMat = profesoresMateriaDAO.findAll();
		
		return lisPfMat;
	}

	@Override
	@Transactional
	public void delete(int id) {
		profesoresMateriaDAO.delete(id);				
	}

	@Override
	@Transactional
	public void create(TblProfesoresMateria pfMat) {
		profesoresMateriaDAO.create(pfMat);		
	}

}
