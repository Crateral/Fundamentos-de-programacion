package com.co.nttdata.colegioRest.tmp;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the "TMP_NOTAS_PROMEDIO" database table.
 * 
 */
@Entity
@Table(name="\"TMP_NOTAS_PROMEDIO\"", schema = "public")
@NamedQuery(name="TmpNotasPromedio.findAll", query="SELECT t FROM TmpNotasPromedio t")
public class TmpNotasPromedio implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="nom_alm")
	private String nomAlm;

	@Column(name = "promedio")
	private double promedio;
	
	@Column(name = "materia")
	private String materia;
	
	public TmpNotasPromedio() {
	}

	public String getMateria() {
		return this.materia;
	}

	public void setMateria(String materia) {
		this.materia = materia;
	}

	public String getNomAlm() {
		return this.nomAlm;
	}

	public void setNomAlm(String nomAlm) {
		this.nomAlm = nomAlm;
	}

	public double getPromedio() {
		return this.promedio;
	}

	public void setPromedio(double promedio) {
		this.promedio = promedio;
	}

	@Override
	public String toString() {
		return "Nom Alm = " + nomAlm + ", Promedio = " + promedio + ", Materia = " + materia;
	}

}