package com.co.nttdata.colegioRest.entity;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the "TBL_NOTAS" database table.
 * 
 */
@Entity
@Table(name="\"TBL_NOTAS\"")
@NamedQuery(name="TblNota.findAll", query="SELECT t FROM TblNota t")
public class TblNota implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_nota")
	private Integer idNota;

	@Column(name = "nota", nullable = false)
	private double nota;
	
	@Column(name = "id_alm")
	private Integer idAlm;
	
	@Column(name = "id_materia")
	private Integer idMateria;

	//bi-directional many-to-one association to TblAlumno
	/*@ManyToOne
	@JoinColumn(name="id_alm")
	private TblAlumno tblAlumno;

	//bi-directional many-to-one association to TblMateria
	@ManyToOne
	@JoinColumn(name="id_materia")
	private TblMateria tblMateria;*/

	public TblNota() {
	}

	public Integer getIdNota() {
		return this.idNota;
	}

	public void setIdNota(Integer idNota) {
		this.idNota = idNota;
	}

	public double getNota() {
		return this.nota;
	}

	public void setNota(double nota) {
		this.nota = nota;
	}

	/*public TblAlumno getTblAlumno() {
		return this.tblAlumno;
	}

	public void setTblAlumno(TblAlumno tblAlumno) {
		this.tblAlumno = tblAlumno;
	}

	public TblMateria getTblMateria() {
		return this.tblMateria;
	}

	public void setTblMateria(TblMateria tblMateria) {
		this.tblMateria = tblMateria;
	}*/

	public Integer getIdAlm() {
		return idAlm;
	}

	public void setIdAlm(Integer idAlm) {
		this.idAlm = idAlm;
	}

	public Integer getIdMateria() {
		return idMateria;
	}

	public void setIdMateria(Integer idMateria) {
		this.idMateria = idMateria;
	}

	@Override
	public String toString() {
		return "ID = " + idNota + ", Nota = " + nota + ", ID Alm = " + idAlm + ", ID Materia = " + idMateria;
	}

}