package com.co.nttdata.colegioRest.daos;

import java.util.List;

import javax.persistence.EntityManager;
import org.hibernate.Session;
import org.hibernate.query.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.co.nttdata.colegioRest.entity.TblNota;

@Repository
public class NotaDAOImpl implements NotaDAO {
	
	@Autowired
	private EntityManager entityManager;

	@Override
	public TblNota findById(int id) {
		
		Session currentSession = entityManager.unwrap(Session.class);
		
		TblNota nota = currentSession.get(TblNota.class, id);
		
		return nota;
	}

	@Override
	public List<TblNota> findAll() {
		
		Session currentSession = entityManager.unwrap(Session.class);
		
		Query<TblNota> theQuery = currentSession.createQuery("from TblNota order by id_nota asc", TblNota.class);
		
		List<TblNota> nota = theQuery.getResultList();
		
		return nota;
	}

	@Override
	public void delete(int id) {
		
		Session currentSession = entityManager.unwrap(Session.class);
		
		Query<TblNota> theQuery = currentSession.createQuery("delete from TblNota where id_nota = :idnot");
		
		theQuery.setParameter("idnot", id);
		
		int vr = theQuery.executeUpdate();
		if (vr > 0)
			System.out.println("Registro eliminado con éxito...!");
	}

	@Override
	public void create(TblNota nota) {
		
		Session currSession = entityManager.unwrap(Session.class);
		
		currSession.saveOrUpdate(nota);
	}
	
}
