package com.co.nttdata.colegioRest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.co.nttdata.colegioRest.services.TmpNotasAlumnoService;
import com.co.nttdata.colegioRest.tmp.TmpNotasAlumno;


//@CrossOrigin(origins = "http://localhost:1516")
@RestController  // Inidcamos que es controlador rest
@RequestMapping("/colegioRest/TmpNotasAlumno") // URL - http://localhost:1516/colegioRest/TmpNotasAlumno
public class TmpNotasAlumnoRestController {
	
	//Inyectamos el servicio para poder hacer uso de el
	@Autowired
	private TmpNotasAlumnoService tmpNotasAlumnoService;
	
		
	@GetMapping("{idtmpNotAlum}")
	public List<TmpNotasAlumno> getTmpNotasAlumno(@PathVariable int idtmpNotAlum) {
		
		List<TmpNotasAlumno> tmpNotAlm = tmpNotasAlumnoService.findById(idtmpNotAlum);

		if (tmpNotAlm == null) {
			throw new RuntimeException("ID Notas Alumno " + idtmpNotAlum + " no existe...!!");
		}

		return tmpNotAlm;
	}
}