package com.co.nttdata.colegioRest.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.co.nttdata.colegioRest.daos.TmpNotasAlumnoDAO;
import com.co.nttdata.colegioRest.tmp.TmpNotasAlumno;

@Service
public class TmpNotasAlumnoServiceImpl implements TmpNotasAlumnoService{
	
	@Autowired
	private TmpNotasAlumnoDAO tmpNotasAlumnoDAO;

	@Override
	@Transactional
	public List<TmpNotasAlumno> findById(int id) {
		
		List<TmpNotasAlumno> tmNotAlm = tmpNotasAlumnoDAO.findById(id);
		
		return tmNotAlm;
	}
}
