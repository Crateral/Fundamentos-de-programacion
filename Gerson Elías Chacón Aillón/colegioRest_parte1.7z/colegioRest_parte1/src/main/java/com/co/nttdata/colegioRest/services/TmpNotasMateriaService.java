package com.co.nttdata.colegioRest.services;

import java.util.List;

import com.co.nttdata.colegioRest.tmp.TmpNotasMateria;


public interface TmpNotasMateriaService {
	
	public List<TmpNotasMateria> findById(int id);
	
	}
