package com.co.nttdata.colegioRest.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.*;


/**
 * The persistent class for the "TBL_MATERIAS" database table.
 * 
 */
@Entity
@Table(name="\"TBL_MATERIAS\"")
@NamedQuery(name="TblMateria.findAll", query="SELECT t FROM TblMateria t")
public class TblMateria implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id_materia")
	private Integer idMateria;

	@Column(name="materia", nullable = false)
	private String materia;

	//bi-directional many-to-one association to TblAlumnosMateria
	/*@OneToMany(mappedBy="tblMateria")
	private List<TblAlumnosMateria> tblAlumnosMaterias;

	//bi-directional many-to-one association to TblNota
	@OneToMany(mappedBy="tblMateria")
	private List<TblNota> tblNotas;

	//bi-directional many-to-one association to TblProfesoresMateria
	@OneToMany(mappedBy="tblMateria")
	private List<TblProfesoresMateria> tblProfesoresMaterias;*/

	public TblMateria() {
	}

	public Integer getIdMateria() {
		return this.idMateria;
	}

	public void setIdMateria(Integer idMateria) {
		this.idMateria = idMateria;
	}

	public String getMateria() {
		return this.materia;
	}

	public void setMateria(String materia) {
		this.materia = materia;
	}

	/*public List<TblAlumnosMateria> getTblAlumnosMaterias() {
		return this.tblAlumnosMaterias;
	}

	public void setTblAlumnosMaterias(List<TblAlumnosMateria> tblAlumnosMaterias) {
		this.tblAlumnosMaterias = tblAlumnosMaterias;
	}

	public TblAlumnosMateria addTblAlumnosMateria(TblAlumnosMateria tblAlumnosMateria) {
		getTblAlumnosMaterias().add(tblAlumnosMateria);
		tblAlumnosMateria.setTblMateria(this);

		return tblAlumnosMateria;
	}

	public TblAlumnosMateria removeTblAlumnosMateria(TblAlumnosMateria tblAlumnosMateria) {
		getTblAlumnosMaterias().remove(tblAlumnosMateria);
		tblAlumnosMateria.setTblMateria(null);

		return tblAlumnosMateria;
	}

	public List<TblNota> getTblNotas() {
		return this.tblNotas;
	}

	public void setTblNotas(List<TblNota> tblNotas) {
		this.tblNotas = tblNotas;
	}

	public List<TblProfesoresMateria> getTblProfesoresMaterias() {
		return this.tblProfesoresMaterias;
	}

	public void setTblProfesoresMaterias(List<TblProfesoresMateria> tblProfesoresMaterias) {
		this.tblProfesoresMaterias = tblProfesoresMaterias;
	}

	public TblProfesoresMateria addTblProfesoresMateria(TblProfesoresMateria tblProfesoresMateria) {
		getTblProfesoresMaterias().add(tblProfesoresMateria);
		tblProfesoresMateria.setTblMateria(this);

		return tblProfesoresMateria;
	}

	public TblProfesoresMateria removeTblProfesoresMateria(TblProfesoresMateria tblProfesoresMateria) {
		getTblProfesoresMaterias().remove(tblProfesoresMateria);
		tblProfesoresMateria.setTblMateria(null);

		return tblProfesoresMateria;
	}*/

	@Override
	public String toString() {
		return "ID = " + idMateria + ", Materia = " + materia;
	}
}