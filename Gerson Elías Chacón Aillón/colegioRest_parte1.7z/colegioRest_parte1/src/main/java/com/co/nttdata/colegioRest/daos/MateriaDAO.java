package com.co.nttdata.colegioRest.daos;

import java.util.List;

import com.co.nttdata.colegioRest.entity.TblMateria;

public interface MateriaDAO {
	
	public TblMateria findById(int id);
	
	public List<TblMateria> findAll();
	
	public void delete(int id);
	
	public void create(TblMateria mat);
	
}
