package com.co.nttdata.colegioRest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.co.nttdata.colegioRest.services.TmpNotasPromedioService;
import com.co.nttdata.colegioRest.tmp.TmpNotasPromedio;


//@CrossOrigin(origins = "http://localhost:1516")
@RestController  // Inidcamos que es controlador rest
@RequestMapping("/colegioRest/TmpNotasPromedio") // URL - http://localhost:1516/colegioRest/TmpNotasPromedio
public class TmpNotasPromedioRestController {
	
	//Inyectamos el servicio para poder hacer uso de el
	@Autowired
	private TmpNotasPromedioService tmpNotasPromedioService;
	
		
	@GetMapping("{idtmpNotPro}")
	public List<TmpNotasPromedio> getTmpNotasPromedios(@PathVariable int idtmpNotPro) {
		
		List<TmpNotasPromedio> tmpNot = tmpNotasPromedioService.findById(idtmpNotPro);

		if (tmpNot == null) {
			throw new RuntimeException("ID Notas Alumno " + idtmpNotPro + " no existe...!!");
		}

		return tmpNot;
	}
}