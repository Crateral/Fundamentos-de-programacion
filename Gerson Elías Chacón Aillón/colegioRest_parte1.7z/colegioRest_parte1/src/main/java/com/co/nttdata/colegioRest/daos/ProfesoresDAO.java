package com.co.nttdata.colegioRest.daos;

import java.util.List;

import com.co.nttdata.colegioRest.entity.TblProfesores;

public interface ProfesoresDAO {
	
	public TblProfesores findById(int id);
	
	public List<TblProfesores> findAll();
	
	public void delete(int id);
	
	public void create(TblProfesores prof);
	
}
