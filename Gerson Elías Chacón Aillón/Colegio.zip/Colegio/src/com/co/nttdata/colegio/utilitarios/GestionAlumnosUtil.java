package com.co.nttdata.colegio.utilitarios;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class GestionAlumnosUtil {
	
	/*public void escribirArchivo(String nombreArchivo, String codAlum, String nomb, Materias materias, double ntU, 
			double ntD, double ntT, double ntC, double pro) {
		
		alm.setCodAlum(codAlum);
		alm.setNombre(nomb);
		alm.setMaterias(materias);
		alm.setNotaUno(ntU);
		alm.setNotaDos(ntD);
		alm.setNotaTres(ntT);
		alm.setNotaCuatro(ntC);
		alm.setPromedio(pro);
		
		String res = (pro >= 3)? "APROBÓ la materia":"REPROBÓ la materia";
						
		FileWriter archivo = null;
		
		try {
			archivo = new FileWriter("C:\\Users\\gchacona\\eclipse-workspace\\Colegio\\" + nombreArchivo, false);
			
			archivo.write("Cod Alum = " + alm.getCodAlum() + ", Nombre = " + alm.getNombre() + ", Materia = " + 
			alm.getMaterias() + ", Nota Uno = " + alm.getNotaUno() + ", Nota Dos = " + alm.getNotaDos() + ", Nota Tres = "+ 
					alm.getNotaTres() + ", Nota Cuatro = " + alm.getNotaCuatro() + ", Promedio = " + alm.getPromedio() + ", " + res + "\n");
			
			
			System.out.println("\nEl archivo se generó correctamente\n");
			archivo.close();
			
		} catch (Exception e) {
			System.out.println("Error al escribir el archivo : " + e.getMessage() );
		}
	}*/
	
public List<String> leerArchivo(String nombreArchivo) {
		
		File archivo = new File("C:\\Users\\gchacona\\eclipse-workspace\\Colegio\\" + nombreArchivo);
		Scanner s = null;
		
		List<String> lismateria = new ArrayList<>();
					
		try {
			s = new Scanner(archivo);
			while (s.hasNextLine()) {
				String linea = s.nextLine();
				System.out.println(linea);
				lismateria.add(linea);
			}
		} catch (Exception e) {
			System.out.println("Error al leer el archivo : " + e.getMessage());
		} finally {
			try {
				if (s != null) {
					s.close();
				}
			} catch (Exception e) {
				System.out.println("Error al cerrar la lectura del archivo : " + e.getMessage());
			}
		}
		return lismateria;
	}
}
