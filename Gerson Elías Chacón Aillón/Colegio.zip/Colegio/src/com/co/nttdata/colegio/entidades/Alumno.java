package com.co.nttdata.colegio.entidades;

import java.util.List;

public class Alumno {
	
	private int idAlum;
	private String nomAlum;
	private List<Notas> notas;
	private double promedio;
		
	public Alumno() {
		
	}

	public Alumno(int idAlum, String nomAlum, List<Notas> notas, double promedio) {
		super();
		this.idAlum = idAlum;
		this.nomAlum = nomAlum;
		this.notas = notas;
		this.promedio = promedio;
	}

	public int getIdAlum() {
		return idAlum;
	}

	public void setIdAlum(int idAlum) {
		this.idAlum = idAlum;
	}

	public String getNomAlum() {
		return nomAlum;
	}

	public void setNomAlum(String nomAlum) {
		this.nomAlum = nomAlum;
	}

	public List<Notas> getNotas() {
		return notas;
	}

	public void setNotas(List<Notas> notas) {
		this.notas = notas;
	}

	public double getPromedio() {
		return promedio;
	}

	public void setPromedio(double promedio) {
		this.promedio = promedio;
	}

	@Override
	public String toString() {
		return "Alumno [idAlum=" + idAlum + ", nomAlum=" + nomAlum + ", notas=" + notas + ", promedio=" + promedio
				+ "]";
	}
	
	
}
