package com.co.nttdata.colegio.interfaces;

import java.util.List;

import com.co.nttdata.colegio.entidades.Alumno;
import com.co.nttdata.colegio.entidades.Profesor;

public interface GestionNotasAlumnos {
	
	public List<Profesor> agrAlm(List<String> notAlm);
	
	public List<String> modNotas(List<String> lisAlm, String idAlum);  
	
	public Alumno promNot(List<String> lisNot, String idAlum);
}
