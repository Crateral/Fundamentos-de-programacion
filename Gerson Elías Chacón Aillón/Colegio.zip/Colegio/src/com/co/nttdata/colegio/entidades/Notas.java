package com.co.nttdata.colegio.entidades;

public class Notas {
	
	private double notas;
	private String observacion;
	
	public Notas() {
		
	}
	
	public Notas(double notas, String observacion) {
		this.notas = notas;
		this.observacion = observacion;
	}
	
	public double getNotas() {
		return notas;
	}
	
	public void setNotas(double notas) {
		this.notas = notas;
	}
	
	public String getObservacion() {
		return observacion;
	}
	
	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}

	@Override
	public String toString() {
		return "Notas [notas=" + notas + ", observacion=" + observacion + "]";
	}
	
	
}
