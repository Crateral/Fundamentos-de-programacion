package com.co.nttdata.colegio.principal;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.co.nttdata.colegio.entidades.Materias;
import com.co.nttdata.colegio.logica.GestionNotasAlumnosImpl;
import com.co.nttdata.colegio.utilitarios.GestionAlumnosUtil;

public class Principal {
	
	static Scanner teclado = new Scanner(System.in);
	static int opc, op;
	
	public static void main(String[] args) {
		
		List<String> lisMat = new ArrayList<>();
		List<String> lisIng = new ArrayList<>();
		List<String> lisFis = new ArrayList<>();
		GestionAlumnosUtil gdau = new GestionAlumnosUtil();
		GestionNotasAlumnosImpl gdnai = new GestionNotasAlumnosImpl();
			
		do {
			System.out.print("\nSeleccione... \n1. Materias \n2. Promedio Notas "
					+ "\n3. Modificar Nota \n4. Notas modificadas "
					+ "\n5. Salir \nOpción : ");
			op = teclado.nextInt();
			int ct = 1;
			switch (op) {
				case 1:
					System.out.print("\nSeleccione la materia : \n");
					for (Materias mostMat : Materias.values()) {
						System.out.print(ct++ + ". " + mostMat + "\n");
					}
					System.out.print("\nOpción : ");
					opc = teclado.nextInt();
					switch (opc) {
						case 1:
							// MATERIAS
							System.out.println("\n*** MATEMATICAS ***\n");
							String nombreArchivoMat = "Lista_Matematicas.txt";
							lisMat = gdau.leerArchivo(nombreArchivoMat);
							gdnai.agrAlm(lisMat);										
							break;
						case 2:
							System.out.println("\n*** INGLES ***\n");
							String nombreArchivoIng = "Lista_Ingles.txt";
							lisIng = gdau.leerArchivo(nombreArchivoIng);
							gdnai.agrAlm(lisIng);
							break;
						case 3:
							System.out.println("\n*** FISICA ***\n");
							String nombreArchivoFis = "Lista_Fisica.txt";
							lisFis = gdau.leerArchivo(nombreArchivoFis);
							gdnai.agrAlm(lisFis);
							break;
						default:
							System.out.println("\nSeleccionó mal la opción");
							break;
					}
					break;
				case 2:
					// PROMEDIO NOTAS
					System.out.print("\nSeleccione la materia : \n");
					for (Materias mostMat : Materias.values()) {
						System.out.print(ct++ + ". " + mostMat + "\n");
					}
					System.out.print("\nOpción : ");
					opc = teclado.nextInt();
					System.out.print("\nSeleccione Alumno : ");
					op = teclado.nextInt();
					switch (opc) {
						case 1:
							String alm = lisMat.get(op);
							gdnai.promNot(lisMat, alm);
							break;
						case 2:
							String ali = lisIng.get(op);
							gdnai.promNot(lisIng, ali);
							break;
						case 3:
							String alf = lisFis.get(op);
							gdnai.promNot(lisFis, alf);
							break;
						default:
							System.out.println("\nSeleccionó mal la opción");
							break;
					}
					break;
				case 3:
					// MODIFICAR NOTA
					System.out.print("\nSeleccione la materia : \n");
					for (Materias mostMat : Materias.values()) {
						System.out.print(ct++ + ". " + mostMat + "\n");
					}
					System.out.print("\nOpción : ");
					opc = teclado.nextInt();
					System.out.print("\nSeleccione Alumno : ");
					op = teclado.nextInt();
					switch (opc) {
						case 1:
							String alm = lisMat.get(op);
							gdnai.modNotas(lisMat, alm);
							break;
						case 2:
							String ali = lisIng.get(op);
							gdnai.modNotas(lisIng, ali);
							break;
						case 3:
							String alf = lisFis.get(op);
							gdnai.modNotas(lisFis, alf);
							break;
						default:
							System.out.println("\nSeleccionó mal la opción");
							break;
					}
					break;
				case 4:
					// NOTAS MODIFICADAS
					System.out.print("\nSeleccione la materia : \n");
					for (Materias mostMat : Materias.values()) {
						System.out.print(ct++ + ". " + mostMat + "\n");
					}
					System.out.print("\nOpción : ");
					opc = teclado.nextInt();
					switch (opc) {
						case 1:
							for (String mostNtMat : lisMat) {
								System.out.print(mostNtMat + "\n");
							}							
							break;
						case 2:
							for (String mostNtIng : lisIng) {
								System.out.print(mostNtIng + "\n");
							}
							break;
						case 3:
							for (String mostNtFis : lisFis) {
								System.out.print(mostNtFis + "\n");
							}
							break;
					}
					break;
				case 5:
					break;
				default:
					System.out.println("\nDigito mal la opción");
					break;
			}
		} while(op != 5);
	}
}


