package com.co.nttdata.colegio.entidades;

public enum Materias {
	
	MATEMATICAS,
	INGLES,
	FISICA;

}
