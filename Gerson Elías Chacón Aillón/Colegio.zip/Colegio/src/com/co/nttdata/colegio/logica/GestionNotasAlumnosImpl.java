package com.co.nttdata.colegio.logica;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.co.nttdata.colegio.entidades.Alumno;
import com.co.nttdata.colegio.entidades.Materias;
import com.co.nttdata.colegio.entidades.Notas;
import com.co.nttdata.colegio.entidades.Profesor;
import com.co.nttdata.colegio.interfaces.GestionNotasAlumnos;

public class GestionNotasAlumnosImpl implements GestionNotasAlumnos{
	
	Scanner teclado = new Scanner(System.in);
	Notas nta1;
	Notas nta2;
	Notas nta3;
	Notas nta4;
	Alumno alm;
	List<Notas> lisNotas;
	double sumNot = 0;
	
	@Override
	public List<Profesor> agrAlm(List<String> notAlm) {
		
		
			
		List<Alumno> lisAlm = new ArrayList<>();
		lisNotas = new ArrayList<>();
		List<Profesor> lisprf = new ArrayList<>();
		
		for (String mostDatos : notAlm) {
			String est[] = mostDatos.split(",");
			
			Profesor prf = new Profesor();			
			alm = new Alumno();
			nta1 = new Notas();
			nta2 = new Notas();
			nta3 = new Notas();
			nta4 = new Notas();
			
			prf.setCodProf(Integer.parseInt(est[0]));
			prf.setMaterias(Materias.valueOf(est[1]));
			alm.setIdAlum(Integer.parseInt(est[2]));
			alm.setNomAlum((est[3]));
			nta1.setNotas(Double.parseDouble(est[4]));
			nta1.setObservacion(est[5]);
			nta2.setNotas(Double.parseDouble(est[6]));
			nta2.setObservacion(est[7]);
			nta3.setNotas(Double.parseDouble(est[8]));
			nta3.setObservacion(est[9]);
			nta4.setNotas(Double.parseDouble(est[10]));
			nta4.setObservacion(est[11]);
							
			lisprf.add(prf);
			lisAlm.add(alm);
			lisNotas.add(nta1);
			lisNotas.add(nta2);
			lisNotas.add(nta3);
			lisNotas.add(nta4);
					
			/*System.out.println(prf.getCodProf() + "," + prf.getMaterias() + "," +alm.getIdAlum() + "," + alm.getNomAlum() + ","
					+ ", " + nta1.getNotas() + "," + nta1.getObservacion() + ", " + nta2.getNotas() + "," + nta2.getObservacion() +
					", " + nta3.getNotas() + "," + nta3.getObservacion() + ", " + nta4.getNotas() + "," + nta4.getObservacion());*/
		}
		return lisprf;
	}

	@Override
	public List<String> modNotas(List<String> lisAlm, String idAlum) {
		
		for (int i = 0; i < lisAlm.size(); i++) {
			if (lisAlm.get(i).equals(idAlum)) {
				System.out.print("\n" + lisAlm.get(i) + "\n");
				System.out.print("\nSeleccione la nota a modificar : ");
				int op = teclado.nextInt();
				
				System.out.print("\nDigite la Nota : ");
				double ntMd = teclado.nextDouble();
								
				System.out.print("Observación    : ");
				String obMd = teclado.next();
				
				if (op == 1) {
					System.out.println(nta1.getNotas());
					nta1.setNotas(ntMd);
					System.out.println(nta1.getNotas());
					nta1.setObservacion(obMd);
				} else if(op == 2) {
					nta2.setNotas(ntMd);
					nta2.setObservacion(obMd);
				} else if (op == 3) {
					nta3.setNotas(ntMd);
					nta3.setObservacion(obMd);
				} else if(op == 4) {
					nta4.setNotas(ntMd);
					nta4.setObservacion(obMd);
				}
			}
		}
		return lisAlm;
	}

	@Override
	public Alumno promNot(List<String> lisNot, String idAlum) {
		
		double pro = 0;
		for (int i = 0; i < lisNot.size(); i++) {
			if (lisNot.get(i).equals(idAlum)) {
				System.out.print("\n" + lisNot.get(i) + "\n");
				pro = (nta1.getNotas() + nta2.getNotas() + nta3.getNotas() + nta4.getNotas())/4;
			}
		}
				
		alm.setPromedio(pro);
		System.out.println("\nNota Final : " + alm.getPromedio());
		
		if (pro >= 3 && pro <= 5)
			System.out.println("APROBÓ la materia");
		else
			System.out.println("REPROBÓ la materia");
		
		return null;
	}
}
