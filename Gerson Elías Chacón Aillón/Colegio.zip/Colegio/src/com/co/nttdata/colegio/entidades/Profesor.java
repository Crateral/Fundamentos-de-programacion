package com.co.nttdata.colegio.entidades;

import java.util.List;

public class Profesor {
	
	private int codProf;
	private Materias materias;
	private List<Alumno> alumnos;
	
	public Profesor() {
		
	}

	public Profesor(int codProf, Materias materias,List<Alumno> alumnos) {
		super();
		this.codProf = codProf;
		this.materias = materias;
		this.alumnos = alumnos;
	}

	public int getCodProf() {
		return codProf;
	}

	public void setCodProf(int codProf) {
		this.codProf = codProf;
	}

	public Materias getMaterias() {
		return materias;
	}

	public void setMaterias(Materias materias) {
		this.materias = materias;
	}

	public List<Alumno> getAlumnos() {
		return alumnos;
	}

	public void setAlumnos(List<Alumno> alumnos) {
		this.alumnos = alumnos;
	}

	@Override
	public String toString() {
		return "Profesor [codProf=" + codProf + ", materias=" + materias + ", alumnos=" + alumnos + "]";
	}
	
	
}
