
import java.nio.channels.NoConnectionPendingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import com.co.nttdata.ecommerce.entidades.*;
import com.co.nttdata.ecommerce.interfaces.GestionLogin;
import com.co.nttdata.ecommerce.logica.*;
import com.co.nttdata.ecommerce.utilitarios.GestionFacturaUtil;
import com.co.nttdata.ecommerce.utilitarios.GestionProductosUtil;

public class Main {
	
	static int op, w = 1, id, fg = 0,  idpr;
	static String nomb, contra, tipIdent, numIdent, correo, reg;
	static boolean estado;
	static List<Producto> lisProd = new ArrayList<>();
	static CarritoDeCompras cdc = new CarritoDeCompras();
	static Cliente cl;
	static Administrador adm;
	static Scanner teclado = new Scanner(System.in);
	static Producto prUno;
	static Producto prDos;
	static Producto prTres;
	static Producto prCuatro;
	static Producto prCinco;
	static Producto prSeis;
	static Producto prSiete;
	static Producto prOcho;
	static Producto prNueve;
	static Producto prDiez;
	
	
	public static void main(String[] args) {
		
		listadoProd();				
		GestionCarritoDeComprasImpl gdcd = new GestionCarritoDeComprasImpl();
		Factura f = new Factura();
		GestionFacturaImpl gdf = new GestionFacturaImpl();
		GestionLogin gl = new GestionLoginImpl();
		//GestionLoginImpl gdu = new GestionLoginImpl();
		GestionProductosUtil gdp = new GestionProductosUtil();
		GestionFacturaUtil gdfu = new GestionFacturaUtil();
		List<String> lista = new ArrayList<>();
			
		
		try {
			do {
				System.out.println();
				System.out.print("Seleccione... \n1. Registrar Usuario \n2. Mostrar Usuario \n3. Iniciar Sesión "
						+ "\n4. Cerrar Sesión \n5. Recuperar contraseña \n6. Mostrar Productos "
						+ "\n7. Agregar producto al carro de compras \n8. Generar Factura "
						+ "\n9. Generar archivo productos \n10. Mostrar archivo factura \n11. Salir \nOpcion : ");
				op = teclado.nextInt();
				switch (op) {
				case 1:
					// REGISTRAR USUARIO
					try {
						int ct = 1, opc, w = 1;
						Ciudades ciudad = null;
						FormaPago forPago = null;
						while (w == 1) {
							System.out.print("\nDesea registrarse (s/n) ? : ");
							reg = teclado.next();
							if (reg.equals("s")) {
								ingDatosUsu();
								System.out.print("Dirección           : ");
								String direccion = teclado.next();
								System.out.print("Teléfono            : ");
								String telefono = teclado.next();
								System.out.print("\nSeleccione Ciudad   : \n");
								for (Ciudades mostCiu : Ciudades.values()) {
									System.out.println(ct++ + ". " + mostCiu);
								}
								System.out.print("Opción : ");
								opc = teclado.nextInt();
								if (opc == 1) {
									ciudad = Ciudades.BOGOTA;
								} else if (opc == 2) {
									ciudad = Ciudades.MEDELLIN;
								} else if (opc == 3) {
									ciudad = Ciudades.OTRAS;
								}
								System.out.print("\nMetodo pago         : \n");
								ct = 1;
								for (FormaPago mostForPag : FormaPago.values()) {
									System.out.println(ct++ + ". " + mostForPag);
								}
								System.out.print("Opción : ");
								opc = teclado.nextInt();
								if (opc == 1) {
									forPago = FormaPago.CONTADO;
								} else if (opc == 2) {
									forPago = FormaPago.CREDITO;
								} else if (opc == 3) {
									forPago = FormaPago.TARJETA_DEBITO;
								} else if (opc == 4) {
									forPago = FormaPago.TARJETA_CREDITO;
								}
								
								cl = (Cliente) gl.registarUsuario(id, nomb, contra, tipIdent, numIdent, correo, 
										estado, direccion, telefono, ciudad, forPago);
								
								/*adm = (Administrador) gl.registarUsuario(id, nomb, contra, tipIdent, numIdent, correo, 
										estado, direccion, telefono, ciudad, forPago);*/
								break;
							} else if (reg.equals("n")) {
								System.out.println("\nSeleccionó no registrarse");
								break;
							}
						}
					} catch (Exception e) {
						System.out.println("\nError al digitar información : " + e.getMessage());
					}
					break;
				case 2:
					// MOSTRAR USUARIO
					System.out.print("\n*** DATOS DEL CLIENTE ***");
					System.out.print("\nDigte ID            : " + cl.getId());
					System.out.print("\nNombre Usuario      : " + cl.getNombreUsuario());
					System.out.print("\nContraseña          : " + cl.getContrasenia());
					System.out.print("\nTipo Ident          : " + cl.getTipoIdentificacion());
					System.out.print("\nNúmero Ident        : " + cl.getNumeroIdentificacion());
					System.out.print("\nCorreo              : " + cl.getCorreo());
					System.out.print("\nDirección           : " + cl.getDireccion());
					System.out.print("\nTeléfono            : " + cl.getTelefono());
					System.out.print("\nCiudad              : " + cl.getCiudad());
					System.out.print("\nMétodo pago         : " + cl.getMetodoDePago());
					System.out.print("\nEstado (true/false) : " + cl.isEstado());
					System.out.println();
					break;
				case 3:
					// INICIAR SESIÓN
					try {
						if ( ((GestionLoginImpl) gl).getIniSess() == 0) {
							System.out.print("\nDigite Usuario    : ");
							String user = teclado.next();
							System.out.print("Digite contraseña : ");
							String contra = teclado.next();
							gl.login(user, contra);
							break;
						} else {
							System.out.print("\nTiene la sesión iniciada\n");
							break;
						}
					} catch (Exception e) {
						System.out.println("\nNo se encontró información : " + e.getMessage());
					}
					break;
				case 4:
					// CERRAR SESIÓN
					try {
						while (w == 1) {
							if ( ((GestionLoginImpl) gl).getIniSess() == 1) {
								System.out.print("\nDesea cerrar sesion ? s/n : ");
								String cerSes = teclado.next();
								gl.logout(cerSes);
								break;
							} else {
								System.out.println("\nInicie sesión");
								break;
							}
						}
						break;
					} catch (Exception e) {
						System.out.println("\nNo se encontró información : " + e.getMessage());
					}
					break;
				case 5:
					// RECUPERAR CONTRASEÑA
					try {
						if (((GestionLoginImpl) gl).getIniSess() == 1) {
							System.out.print("\nDigite Usuario    : ");
							String user = teclado.next();
							gl.recuperContrasenia(user);
							break;
						} else {
							System.out.println("\nInicie sesión");
							break;
						}
					} catch (Exception e) {
						System.out.println("\nNo se encontró información : " + e.getMessage());
					}
					break;
				case 6:
					// MOSTRAR PRODUCTOS
					/*System.out.println("\n** PRODUCTOS **\n");
					for (Producto mostprod : lisProd) {
						System.out.println(mostprod);
					}*/
					
					System.out.println("\n** PRODUCTOS **\n");
					String nombreArchivoProd = "Lista_Productos.txt";
					gdp.leerArchivo(nombreArchivoProd);
					
					//lista = gdp.leerArchivo(nombreArchivoProd);
					//gdp.separaProd(lista);
															
					/*for (int i = 0; i < lista.size(); i++) {
						System.out.println(lista.get(i));
					}*/
					
					//cdc.setProductos(gdp.separaProd(lista));
					break;
				case 7:
					// AGREGAR PRODUCTOS AL CARRO DE COMPRAS
					//gdp.agregarCarrito();
					agregarCarrito();
					break;
				case 8:
					// GENERAR FACTURA
					try {
						if ( ((GestionLoginImpl) gl).getIniSess() == 1) {
							/*gdcd.calcularTotalConIva(cdc);
							gdcd.calcularCostoEnvio(cdc, cl.getCiudad());
							f = gdf.pagar(cl, cdc);
							gdf.mostFact();*/
							String nombreArchivoFac = "Factura.txt";
							gdcd.calcularTotalConIva(cdc);
							gdcd.calcularCostoEnvio(cdc, cl.getCiudad());
							f = gdf.pagar(cl, cdc);
							gdfu.escribirArchivo(nombreArchivoFac, cl, cdc);
							fg = 1;
							break;
						} else {
							System.out.print("\nInicie Sesión\n");
							break;
						}
					} catch (Exception e) {
						System.out.print("Inicie Sesión para Facturar : " + e.getMessage());
					}
					break;
				case 9:
					// GENERA ARCHIVO PRODUCTO
					String nombreArchivoProdAct = "Lista_Productos.txt";
					gdp.escribirArchivo(nombreArchivoProdAct, prUno, prDos, prTres, prCuatro, prCinco, 
							prSeis, prSiete, prOcho, prNueve, prDiez);
					
					break;
				case 10:
					// MOSTRAR FACTURA
					if (fg == 1) {
						gdfu.leerArchivo();
						break;
					} else {
						System.out.println("\nGenere la factura");
						break;
					}
					// SALIR
					case 11:
					break;
				default:
					System.out.print("\nError al digitar opción\n");
					break;
				}
			} while (op != 11);
		} catch (Exception e) {
			System.out.println("\nError al digitar información : " + e.getMessage());
		}
	}
	
	
	public static void ingDatosUsu() {
		System.out.print("Digte ID            : ");
		id = teclado.nextInt();
		System.out.print("Nombre Usuario      : ");
		nomb = teclado.next();
		System.out.print("Contraseña          : ");
		contra = teclado.next();
		System.out.print("Tipo Ident          : ");
		tipIdent = teclado.next();
		System.out.print("Número Ident        : ");
		numIdent = teclado.next();
		System.out.print("Correo              : ");
		correo = teclado.next();
		System.out.print("Estado (true/false) : ");
		estado = teclado.nextBoolean();
	}

	public static void listadoProd() {

		prUno = new Producto(1, "nevera", 6, 450000, false, 0, 0, "nevera frost", "imgnev", Marca.LG,
				Categoria.ELECTRODOMESTICOS);
		prDos = new Producto(2, "tv", 4, 300000, true, 50000, 19, "tv 32", "imgtv", Marca.SAMSUNG,
				Categoria.ELECTRODOMESTICOS);
		prTres = new Producto(3, "monitor", 1, 450000, true, 30000, 19, "monitor 22", "imgmon", Marca.SAMSUNG,
				Categoria.EQUIPO_COMPUTO);
		prCuatro = new Producto(4, "servidor", 2, 1500000, true, 15000, 19, "licuadora 100", "imglic",
				Marca.LENOVO, Categoria.EQUIPO_COMPUTO);
		prCinco = new Producto(5, "lavadora", 1, 600000, false, 0, 19, "lavadora l12", "imglav", Marca.LG,
				Categoria.ELECTRODOMESTICOS);
		prSeis = new Producto(6, "ventilador", 4, 300000, true, 10000, 5, "ventilador", "imgven",
				Marca.SAMSUNG, Categoria.ELECTRODOMESTICOS);
		prSiete = new Producto(7, "aspiradora", 3, 200000, true, 50000, 19, "aspiradora", "imgasp", Marca.LG,
				Categoria.ELECTRODOMESTICOS);
		prOcho = new Producto(8, "horno", 0, 700000, false, 0, 5, "horno p25", "imghor", Marca.SAMSUNG,
				Categoria.ELECTRODOMESTICOS);
		prNueve = new Producto(9, "estufa", 4, 480000, true, 80000, 19, "estufa t147", "imgest", Marca.LG,
				Categoria.ELECTRODOMESTICOS);
		prDiez = new Producto(10, "plancha", 6, 50000, false, 0, 19, "plancha r9", "imgplan", Marca.LENOVO,
				Categoria.ELECTRODOMESTICOS);

		
		lisProd.add(prUno);
		lisProd.add(prDos);
		lisProd.add(prTres);
		lisProd.add(prCuatro);
		lisProd.add(prCinco);
		lisProd.add(prSeis);
		lisProd.add(prSiete);
		lisProd.add(prOcho);
		lisProd.add(prNueve);
		lisProd.add(prDiez);
		
	}
	
	
	public static void agregarCarrito() {
		HashMap<Integer, Producto> inv = new HashMap<>();
		while (w == 1) {
			int cant = 0, ca = 0;
			System.out.print("\nDesea agregar productos (s/n) ? : ");
			reg = teclado.next();
			if (reg.equals("s") ) {
				
				System.out.print("\nSeleccione Producto : ");
				idpr = teclado.nextInt();
								
				inv.put(prUno.getIdProducto(), prUno);
				inv.put(prDos.getIdProducto(), prDos);
				inv.put(prTres.getIdProducto(), prTres);
				inv.put(prCuatro.getIdProducto(), prCuatro);
				inv.put(prCinco.getIdProducto(), prCinco);
				inv.put(prSeis.getIdProducto(), prSeis);
				inv.put(prSiete.getIdProducto(), prSiete);
				inv.put(prOcho.getIdProducto(), prOcho);
				inv.put(prNueve.getIdProducto(), prNueve);
				inv.put(prDiez.getIdProducto(), prDiez);
				
				switch (idpr) {
				case 1:
					System.out.print("Digite la cantidad : ");
					cant = teclado.nextInt();
					if (cant > 0 && cant <= prUno.getCantidadDiponible()) {
						prUno.setDigCant(cant);
						ca = prUno.getCantidadDiponible() - cant;
						cdc.getProductos().add(inv.get(idpr));
						prUno.setCantidadDiponible(ca);
						System.out.print("\nProducto... " + prUno.getNombre() + ", agregado al carrito con éxito\n");
						break;
					} else {
						System.out.print("\nCantidad en 0 ó Excede la cantidad\n");
						break;
					}
				case 2:
					System.out.print("Digite la cantidad : ");
					cant = teclado.nextInt();
					if (cant > 0 && cant <= prDos.getCantidadDiponible()) {
						prDos.setDigCant(cant);
						ca = prDos.getCantidadDiponible() - cant;
						cdc.getProductos().add(inv.get(idpr));
						prDos.setCantidadDiponible(ca);
						System.out.print("\nProducto... " + prDos.getNombre() + ", agregado al carrito con éxito\n");
						break;
					} else {
						System.out.print("\nCantidad en 0 ó Excede la cantidad\n");
						break;
					}
				case 3:
					System.out.print("Digite la cantidad : ");
					cant = teclado.nextInt();
					if (cant > 0 && cant <= prTres.getCantidadDiponible()) {
						prTres.setDigCant(cant);
						ca = prTres.getCantidadDiponible() - cant;
						cdc.getProductos().add(inv.get(idpr));
						prTres.setCantidadDiponible(ca);
						System.out.print("\nProducto... " + prTres.getNombre() + ", agregado al carrito con éxito\n");
						break;
					} else {
						System.out.print("\nCantidad en 0 ó Excede la cantidad\n");
						break;
					}
				case 4:
					System.out.print("Digite la cantidad : ");
					cant = teclado.nextInt();
					if (cant > 0 && cant <= prCuatro.getCantidadDiponible()) {
						prCuatro.setDigCant(cant);
						ca = prCuatro.getCantidadDiponible() - cant;
						cdc.getProductos().add(inv.get(idpr));
						prCuatro.setCantidadDiponible(ca);
						System.out.print("\nProducto... " + prCuatro.getNombre() + ", agregado al carrito con éxito\n");
						break;
					} else {
						System.out.print("\nCantidad en 0 ó Excede la cantidad\n");
						break;
					}
				case 5:
					System.out.print("Digite la cantidad : ");
					cant = teclado.nextInt();
					if (cant > 0 && cant <= prCinco.getCantidadDiponible()) {
						prCinco.setDigCant(cant);
						ca = prCinco.getCantidadDiponible() - cant;
						cdc.getProductos().add(inv.get(idpr));
						prCinco.setCantidadDiponible(ca);
						System.out.print("\nProducto... " + prCinco.getNombre() + ", agregado al carrito con éxito\n");
						break;
					} else {
						System.out.print("\nCantidad en 0 ó Excede la cantidad\n");
						break;
					}
				case 6:
					System.out.print("Digite la cantidad : ");
					cant = teclado.nextInt();
					if (cant > 0 && cant <= prSeis.getCantidadDiponible()) {
						prSeis.setDigCant(cant);
						ca = prSeis.getCantidadDiponible() - cant;
						cdc.getProductos().add(inv.get(idpr));
						prSeis.setCantidadDiponible(ca);
						System.out.print("\nProducto... " + prSeis.getNombre() + ", agregado al carrito con éxito\n");
						break;
					} else {
						System.out.print("\nCantidad en 0 ó Excede la cantidad\n");
						break;
					}
				case 7:
					System.out.print("Digite la cantidad : ");
					cant = teclado.nextInt();
					if (cant > 0 && cant <= prSiete.getCantidadDiponible()) {
						prSiete.setDigCant(cant);
						ca = prSiete.getCantidadDiponible() - cant;
						cdc.getProductos().add(inv.get(idpr));
						prSiete.setCantidadDiponible(ca);
						System.out.print("\nProducto... " + prSiete.getNombre() + ", agregado al carrito con éxito\n");
						break;
					} else {
						System.out.print("\nCantidad en 0 ó Excede la cantidad\n");
						break;
					}
				case 8:
					System.out.print("Digite la cantidad : ");
					cant = teclado.nextInt();
					if (cant > 0 && cant <= prOcho.getCantidadDiponible()) {
						prOcho.setDigCant(cant);
						ca = prOcho.getCantidadDiponible() - cant;
						cdc.getProductos().add(inv.get(idpr));
						prOcho.setCantidadDiponible(ca);
						System.out.print("\nProducto... " + prOcho.getNombre() + ", agregado al carrito con éxito\n");
						break;
					} else {
						System.out.print("\nCantidad en 0 ó Excede la cantidad\n");
						break;
					}
				case 9:
					System.out.print("Digite la cantidad : ");
					cant = teclado.nextInt();
					if (cant > 0 && cant <= prNueve.getCantidadDiponible()) {
						prNueve.setDigCant(cant);
						ca = prNueve.getCantidadDiponible() - cant;
						cdc.getProductos().add(inv.get(idpr));
						prNueve.setCantidadDiponible(ca);
						System.out.print("\nProducto... " + prNueve.getNombre() + ", agregado al carrito con éxito\n");
						break;
					} else {
						System.out.print("\nCantidad en 0 ó Excede la cantidad\n");
						break;
					}
				case 10:
					System.out.print("Digite la cantidad : ");
					cant = teclado.nextInt();
					if (cant > 0 && cant <= prDiez.getCantidadDiponible()) {
						prDiez.setDigCant(cant);
						ca = prDiez.getCantidadDiponible() - cant;
						cdc.getProductos().add(inv.get(idpr));
						prDiez.setCantidadDiponible(ca);
						System.out.print("\nProducto... " + prDiez.getNombre() + ", agregado al carrito con éxito\n");
						break;
					} else {
						System.out.print("\nCantidad en 0 ó Excede la cantidad\n");
						break;
					}
				}
					
				/*for (Producto mostProd : lisProd) {
					if (prDos.getIdProducto() == idpr) {
						cdc.setProductos(lisProd);
						System.out.println("\nProducto agregado al carrito con éxito\n");
						break;
					} else {
						
						break;
					}
				}*/
				
			} else if (reg.equals("n")) {
				break;
			}
		}
		
		// LLENA CARRITO CON PRODUCTOS
		//cdc.setProductos(lisProd);
	}
	
}