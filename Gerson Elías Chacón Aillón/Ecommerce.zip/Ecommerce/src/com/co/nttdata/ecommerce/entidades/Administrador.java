package com.co.nttdata.ecommerce.entidades;

import java.io.Serializable;

public class Administrador extends Usuario implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int numeroIdentificacion;
	private int idTipoIdentificacion;
	private String correo;
	private boolean estado;
	
	public Administrador() {
		
	}

	public Administrador(int id, String nombreUsuario, String contrasenia) {
		super(id, nombreUsuario, contrasenia);
	}

	public int getNumeroIdentificacion() {
		return numeroIdentificacion;
	}

	public void setNumeroIdentificacion(int numeroIdentificacion) {
		this.numeroIdentificacion = numeroIdentificacion;
	}

	public int getIdTipoIdentificacion() {
		return idTipoIdentificacion;
	}

	public void setIdTipoIdentificacion(int idTipoIdentificacion) {
		this.idTipoIdentificacion = idTipoIdentificacion;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public boolean isEstado() {
		return estado;
	}

	public void setEstado(boolean estado) {
		this.estado = estado;
	}

	@Override
	public String toString() {
		return "ID = " + getIdUsuario() + ", Número Identificacion = " + numeroIdentificacion + ", ID Tipo Identificacion = "
				+ idTipoIdentificacion + ", Nombre Usuario = " + getNombreUsuario() + ", Contraseña = " + getContrasenia() +
				", Correo = " + correo + ", Estado = " + estado;
	}	
}
