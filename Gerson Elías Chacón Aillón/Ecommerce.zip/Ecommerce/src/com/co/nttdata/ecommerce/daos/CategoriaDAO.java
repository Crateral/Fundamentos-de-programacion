package com.co.nttdata.ecommerce.daos;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.co.nttdata.ecommerce.entidades.Categoria;
import com.co.nttdata.ecommerce.utils.Conexion;

public class CategoriaDAO {
	
	Conexion con = new Conexion();
	Scanner teclado = new Scanner(System.in);
	
	public List<Categoria> buscarCategoria(){
		
		Connection baseDatos = con.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		List<Categoria> categorias = new ArrayList<Categoria>();
		
		try {
			
			st = baseDatos.prepareStatement("SELECT * FROM \"TBL_CATEGORIAS\" ORDER BY id_categoria ASC");
			rs = st.executeQuery();
			
			while (rs.next()) {
				
				Categoria categoria = new Categoria();
				
				categoria.setIdCategoria(rs.getInt("id_categoria"));
				categoria.setCategoria(rs.getString("categoria"));
				categoria.setDescripcion(rs.getString("descripcion"));
				categoria.setIva(rs.getDouble("iva"));
				
				categorias.add(categoria);
			}
			
		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				rs.close();
				st.close();
				con.desconectarBD(baseDatos);
			} catch (Exception e2) {
				System.err.println(e2.getMessage());
			}
		}
				
		
		return categorias;
	}
	
	public Categoria buscarCategoria(int categoria) {
		Categoria ct = new Categoria();
		
		Connection baseDatos = con.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			st = baseDatos.prepareStatement("SELECT * FROM \"TBL_CATEGORIAS\" WHERE id_categoria = ? ");
			st.setInt(1, categoria);
			//st.setString(1, categoria);
			rs = st.executeQuery();
			
			while (rs.next()) {
				ct.setIdCategoria(rs.getInt("id_categoria"));
				ct.setCategoria(rs.getString("categoria"));
				ct.setDescripcion(rs.getString("descripcion"));
				ct.setIva(rs.getDouble("iva"));
			}
			
		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				rs.close();
				st.close();
				con.desconectarBD(baseDatos);
			} catch (Exception e2) {
				System.err.println(e2.getMessage());
			}
		}
		return ct;		
	}
	
	public void agregCategoria(Categoria ct) {
		
		Connection baseDatos = con.conectarBD();
		PreparedStatement st = null;
		
		try {
			st = baseDatos.prepareStatement("INSERT INTO \"TBL_CATEGORIAS\" (categoria, descripcion, iva) VALUES (?, ?, ?)");
			st.setString(1, ct.getCategoria());
			st.setString(2, ct.getDescripcion());
			st.setDouble(3, ct.getIva());
			int val = st.executeUpdate();
			
			if (val > 0) 
				System.out.println("\nRegistro guardado con éxito...");
			else
				System.err.println("\nError al guardar el registro... !");
			
		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				st.close();
				con.desconectarBD(baseDatos);
			} catch (Exception e2) {
				System.err.println(e2.getMessage());
			}
		}		
	}
	
	public Categoria elimCategoria(int categoria) {
		Categoria ct = new Categoria();
		
		Connection baseDatos = con.conectarBD();
		PreparedStatement st = null;
				
		System.out.print("\nDesea eliminar la Categoria (s/n) ? : ");
		String rg = teclado.next();
		if (rg.equals("s")) {
			try {
				st = baseDatos.prepareStatement("DELETE FROM \"TBL_CATEGORIAS\" WHERE id_categoria = ? ");
				st.setInt(1, categoria);
				int val = st.executeUpdate();
				
				if (val > 0) 
					System.out.println("\nRegistro eliminado con éxito...");
				else
					System.err.println("\nError al eliminar el registro... !");
				
			} catch (Exception e) {
				System.err.println(e.getMessage());
			} finally {
				try {
					st.close();
					con.desconectarBD(baseDatos);
				} catch (Exception e2) {
					System.err.println(e2.getMessage());
				}
			}
				
		} else if (rg.equals("n")) {
			System.out.println("\nSeleccionó no eliminar Categoria... !");
		}
		return ct;	
	}
	
	public void modCategoria(int idcategoria, String categoria, String descripcion, double iva) {
		
		Connection baseDatos = con.conectarBD();
		PreparedStatement st = null;
				
		try {
			st = baseDatos.prepareStatement("UPDATE \"TBL_CATEGORIAS\" SET categoria = ?, descripcion = ?, iva = ? WHERE id_categoria = ? ");
			st.setInt(4, idcategoria);
			st.setString(1, categoria);
			st.setString(2, descripcion);
			st.setDouble(3, iva);
			int val = st.executeUpdate();

			if (val > 0)
				System.out.println("\nRegistro modificado con éxito...");
			else
				System.err.println("\nError al modificar el registro... !");

		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				st.close();
				con.desconectarBD(baseDatos);
			} catch (Exception e2) {
				System.err.println(e2.getMessage());
			}
		}
	}		
}
