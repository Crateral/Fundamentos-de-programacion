package com.co.nttdata.ecommerce.logica;

import com.co.nttdata.ecommerce.entidades.Administrador;

import com.co.nttdata.ecommerce.entidades.Ciudades;
import com.co.nttdata.ecommerce.entidades.FormaPago;
import com.co.nttdata.ecommerce.entidades.Usuario;
import com.co.nttdata.ecommerce.interfaces.GestionLogin;

public class GestionLoginAdmImpl implements GestionLogin{
	
	Administrador adm = new Administrador();

	@Override
	public Usuario registarUsuario(int id, String nomb, String contra, String tipIdent, String numIdent, String correo,
			boolean estado, String direccion, String telefono, Ciudades ciudad, FormaPago forPago) {
		
		adm.setId(id);
		adm.setNombreUsuario(nomb);
		adm.setContrasenia(contra);
		adm.setTipoIdentificacion(tipIdent);
		adm.setNumeroIdentificacion(numIdent);
		adm.setCorreo(correo);
		adm.setEstado(estado);
		System.out.print("\nAdministrador registrado con éxito\n");
		return adm;
	}

	@Override
	public boolean login(String user, String contra) {
		
		return false;
	}

	@Override
	public boolean logout(String ceSes) {
		
		return false;
	}

	@Override
	public String recuperContrasenia(String user) {
		
		return null;
	}

	

}
