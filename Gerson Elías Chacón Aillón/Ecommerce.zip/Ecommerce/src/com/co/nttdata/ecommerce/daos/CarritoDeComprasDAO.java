package com.co.nttdata.ecommerce.daos;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.co.nttdata.ecommerce.entidades.CarritoDeCompras;
import com.co.nttdata.ecommerce.utils.Conexion;

public class CarritoDeComprasDAO {
	
	Conexion con = new Conexion();
	Scanner teclado = new Scanner(System.in);
	
	public List<CarritoDeCompras> buscarCarrito(){
		
		Connection baseDatos = con.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		List<CarritoDeCompras> carritos = new ArrayList<CarritoDeCompras>();
		
		try {
			
			st = baseDatos.prepareStatement("SELECT * FROM \"TBL_CARRITODECOMPRAS\" ORDER BY id_carrito ASC");
			rs = st.executeQuery();
			
			while (rs.next()) {
				
				CarritoDeCompras cdc = new CarritoDeCompras();
				
				cdc.setIdProducto(rs.getInt("id_producto"));
				cdc.setFecha(rs.getDate("fecha"));
				cdc.setValorEnvio(rs.getDouble("vr_envio"));
				cdc.setValorDcto(rs.getDouble("vr_descuento"));
				cdc.setValorIva(rs.getDouble("vr_iva"));
				cdc.setSubTotSinIva(rs.getDouble("sub_total_sin_iva"));
				cdc.setSubTotConIva(rs.getDouble("sub_total_con_iva"));
				cdc.setNumIdentificacion(rs.getInt("num_identificacion"));
				
				carritos.add(cdc);
			}
			
		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				rs.close();
				st.close();
				con.desconectarBD(baseDatos);
			} catch (Exception e2) {
				System.err.println(e2.getMessage());
			}
		}
				
		
		return carritos;
	}
	
	public CarritoDeCompras buscarCarrito(int carro) {
		CarritoDeCompras cr = new CarritoDeCompras();
		
		Connection baseDatos = con.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			st = baseDatos.prepareStatement("SELECT * FROM \"TBL_CARRITODECOMPRAS\" WHERE id_carrito = ? ");
			st.setInt(1, carro);
			//st.setString(1, categoria);
			rs = st.executeQuery();
			
			while (rs.next()) {
				cr.setIdProducto(rs.getInt("id_producto"));
				cr.setFecha(rs.getDate("fecha"));
				cr.setValorEnvio(rs.getDouble("vr_envio"));
				cr.setValorDcto(rs.getDouble("vr_descuento"));
				cr.setValorIva(rs.getDouble("vr_iva"));
				cr.setSubTotSinIva(rs.getDouble("sub_total_sin_iva"));
				cr.setSubTotConIva(rs.getDouble("sub_total_con_iva"));
				cr.setNumIdentificacion(rs.getInt("num_identificacion"));
			}
			
		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				rs.close();
				st.close();
				con.desconectarBD(baseDatos);
			} catch (Exception e2) {
				System.err.println(e2.getMessage());
			}
		}
		return cr;		
	}
	
	public void agregCarrito(CarritoDeCompras cdc) {
		
		Connection baseDatos = con.conectarBD();
		PreparedStatement st = null;
		
		try {
			st = baseDatos.prepareStatement("INSERT INTO \"TBL_CARRITODECOMPRAS\" (id_producto, fecha, vr_envio,"
					+ "vr_descuento, vr_iva, sub_total_sin_iva, sub_total_con_iva, num_identificacion) "
					+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
			st.setInt(1, cdc.getIdProducto());
			st.setDate(2, (Date) cdc.getFecha());
			st.setDouble(3, cdc.getValorEnvio());
			st.setDouble(4, cdc.getValorDcto());
			st.setDouble(5, cdc.getValorIva());
			st.setDouble(6, cdc.getSubTotSinIva());
			st.setDouble(7, cdc.getSubTotConIva());
			st.setInt(8, (int) cdc.getNumIdentificacion());
			int val = st.executeUpdate();
			
			if (val > 0) 
				System.out.println("\nRegistro guardado con éxito...");
			else
				System.err.println("\nError al guardar el registro... !");
			
		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				st.close();
				con.desconectarBD(baseDatos);
			} catch (Exception e2) {
				System.err.println(e2.getMessage());
			}
		}		
	}
	
	public CarritoDeCompras elimCarrito(int carro) {
		CarritoDeCompras cc = new CarritoDeCompras();
		
		Connection baseDatos = con.conectarBD();
		PreparedStatement st = null;
				
		System.out.print("\nDesea eliminar el Carrito (s/n) ? : ");
		String rg = teclado.next();
		if (rg.equals("s")) {
			try {
				st = baseDatos.prepareStatement("DELETE FROM \"TBL_CARRITODECOMPRAS\" WHERE id_carrito = ? ");
				st.setInt(1, carro);
				int val = st.executeUpdate();
				
				if (val > 0) 
					System.out.println("\nRegistro eliminado con éxito...");
				else
					System.err.println("\nError al eliminar el registro... !");
				
			} catch (Exception e) {
				System.err.println(e.getMessage());
			} finally {
				try {
					st.close();
					con.desconectarBD(baseDatos);
				} catch (Exception e2) {
					System.err.println(e2.getMessage());
				}
			}
				
		} else if (rg.equals("n")) {
			System.out.println("\nSeleccionó no eliminar Carrito... !");
		}
		return cc;	
	}
	
	public void modProducto(int idCarro, int idProd, Date fecha, double vrEnv, double vrDcto, 
			double vrIva, double subSinIva, double subConIva, int numIdent) {
		
		Connection baseDatos = con.conectarBD();
		PreparedStatement st = null;
				
		try {
			st = baseDatos.prepareStatement("UPDATE \"TBL_CARRITODECOMPRAS\" SET id_producto = ?, fecha = ?,"
					+ "vr_envio = ?, vr_descuento = ?, vr_iva = ?, sub_total_sin_iva = ?, sub_total_con_iva = ?"
					+ "num_identificacion = ? "
					+ "WHERE id_carrito = ? ");
			st.setInt(1, idProd);
			st.setDate(2, fecha);
			st.setDouble(3, vrEnv);
			st.setDouble(4, vrDcto);
			st.setDouble(5, vrIva);
			st.setDouble(6, subSinIva);
			st.setDouble(7, subConIva);
			st.setInt(8, numIdent);
			st.setInt(9, idCarro);
			int val = st.executeUpdate();

			if (val > 0)
				System.out.println("\nRegistro modificado con éxito...");
			else
				System.err.println("\nError al modificar el registro... !");

		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				st.close();
				con.desconectarBD(baseDatos);
			} catch (Exception e2) {
				System.err.println(e2.getMessage());
			}
		}
	}		
}
