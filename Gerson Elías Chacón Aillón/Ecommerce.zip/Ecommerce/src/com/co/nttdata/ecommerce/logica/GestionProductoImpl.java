package com.co.nttdata.ecommerce.logica;

import com.co.nttdata.ecommerce.entidades.Categoria;
import com.co.nttdata.ecommerce.entidades.Marca;

public class GestionProductoImpl {
	
	public Marca valMarca(String marca) {
		if (marca.trim().equalsIgnoreCase(String.valueOf(Marca.LG)))
			return Marca.LG;
		else if (marca.trim().equalsIgnoreCase(String.valueOf(Marca.SAMSUNG)))
			return Marca.SAMSUNG;
		else if (marca.trim().equalsIgnoreCase(String.valueOf(Marca.LENOVO)))
			return Marca.LENOVO;
		return null;
	}
	
	public Categoria valCategoria(String categoria) {
		if (categoria.trim().equalsIgnoreCase(String.valueOf(Categoria.ELECTRODOMESTICOS)))
			return Categoria.ELECTRODOMESTICOS;
		else if (categoria.trim().equalsIgnoreCase(String.valueOf(Categoria.EQUIPO_COMPUTO)))
			return Categoria.EQUIPO_COMPUTO;
		return null;
	}

}
