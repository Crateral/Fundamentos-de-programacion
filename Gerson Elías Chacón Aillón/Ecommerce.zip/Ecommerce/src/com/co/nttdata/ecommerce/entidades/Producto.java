package com.co.nttdata.ecommerce.entidades;

import java.io.Serializable;

public class Producto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int idProducto;
	private int idMarca;
	private int idCategoria;
	private String nomProducto;
	private int cantidadDiponible;
	private double precio;
	private boolean descuento;
	private double valorDescuento;
	private String descripcion;
	private String img;
	
	public Producto() {

	}

	public int getIdProducto() {
		return idProducto;
	}

	public void setIdProducto(int idProducto) {
		this.idProducto = idProducto;
	}

	public int getIdMarca() {
		return idMarca;
	}

	public void setIdMarca(int idMarca) {
		this.idMarca = idMarca;
	}

	public int getIdCategoria() {
		return idCategoria;
	}

	public void setIdCategoria(int idCategoria) {
		this.idCategoria = idCategoria;
	}

	public String getNomProducto() {
		return nomProducto;
	}

	public void setNomProducto(String nomProducto) {
		this.nomProducto = nomProducto;
	}

	public int getCantidadDiponible() {
		return cantidadDiponible;
	}

	public void setCantidadDiponible(int cantidadDiponible) {
		this.cantidadDiponible = cantidadDiponible;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public boolean isDescuento() {
		return descuento;
	}

	public void setDescuento(boolean descuento) {
		this.descuento = descuento;
	}

	public double getValorDescuento() {
		return valorDescuento;
	}

	public void setValorDescuento(double valorDescuento) {
		this.valorDescuento = valorDescuento;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	@Override
	public String toString() {
		return "ID = " + idProducto + ", ID Marca = " + idMarca + ", ID Categoria = " + idCategoria
				+ ", Nom Producto = " + nomProducto + ", Cant Diponible = " + cantidadDiponible + 
				", Precio = " + precio + ", Dcto = " + descuento + ", Vr Dcto = " + valorDescuento + 
				", Descrip = " + descripcion + ", Img=" + img;
	}

	
	/*@Override
	public String toString() {
		return "ID= " + idProducto + ", Nomb= " + nombre + ", Cant= " + cantidadDiponible
				+ ", Prec= " + precio + "\nDcto= " + descuento + ", Vr Dcto= " + valorDescuento + ", IVA= "
				+ iva + "\nDescrip=" + descripcion + ", Img=" + img + "\nMarca= " + marca + ", Categoria= "
				+ categoria + "\n\n";
	}*/
	
	/*@Override
	public String toString() {
		return "ID        = " + idProducto + "\nNombre    = " + nombre + "\nCantidad  = " + cantidadDiponible
				+ "\nPrecio    = " + precio + "\nDcto      = " + descuento + "\nVr Dcto   = " + valorDescuento + 
				"\nIVA       = " + iva + "\nDescrip   = " + descripcion + "\nImagen    = " + img +
				"\nMarca     = " + marca + "\nCategoria = "	+ categoria + "\n\n";
	}*/
	
	/*@Override
	public String toString() {
		return "Nombre    = " + nombre + "\nCantidad  = " + digCant
				+ "\nPrecio    = " + precio  + "\nVr Dcto   = " + valorDescuento + 
				"\nIVA       = " + iva + "\nDescrip   = " + descripcion + 
				"\nMarca     = " + marca + "\nCategoria = "	+ categoria + "\n\n";
	}*/
	
	
	
	/*@Override
	public String toString() {
		return  idProducto + ", " + nombre + ", " + cantidadDiponible + ", "
				+ precio + ", " + descuento + ", " + valorDescuento + ", "
				+ iva + ", " + descripcion + ", " + img + ", " + marca + ", "
				+ categoria;
	}*/
}
