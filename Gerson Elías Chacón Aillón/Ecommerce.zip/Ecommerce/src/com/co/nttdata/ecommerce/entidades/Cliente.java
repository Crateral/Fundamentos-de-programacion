package com.co.nttdata.ecommerce.entidades;

import java.io.Serializable;

public class Cliente extends Usuario implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int numeroIdentificacion;
	private int idTipoIdentificacion;
	private int idCiudad;
	private int idFormaPago;
	private String correo;
	private String telefono;
	private String direccion;
	private boolean estado;
	
	public Cliente() {
		
	}
	
	public Cliente(int id, String nombreUsuario, String contrasenia) {
		super(id, nombreUsuario, contrasenia);
	}

	public int getNumeroIdentificacion() {
		return numeroIdentificacion;
	}

	public void setNumeroIdentificacion(int numeroIdentificacion) {
		this.numeroIdentificacion = numeroIdentificacion;
	}

	public int getIdTipoIdentificacion() {
		return idTipoIdentificacion;
	}

	public void setIdTipoIdentificacion(int idTipoIdentificacion) {
		this.idTipoIdentificacion = idTipoIdentificacion;
	}

	public int getIdCiudad() {
		return idCiudad;
	}

	public void setIdCiudad(int idCiudad) {
		this.idCiudad = idCiudad;
	}

	public int getIdFormaPago() {
		return idFormaPago;
	}

	public void setIdFormaPago(int idFormaPago) {
		this.idFormaPago = idFormaPago;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public boolean isEstado() {
		return estado;
	}

	public void setEstado(boolean estado) {
		this.estado = estado;
	}

	@Override
	public String toString() {
		return "ID = " + getIdUsuario() + ", Número Identificacion = " + numeroIdentificacion + ", ID Tipo Identificacion = "
				+ idTipoIdentificacion + ", ID Ciudad = " + idCiudad + ", ID Forma Pago = " + idFormaPago +
				", Nombre Usuario = " + getNombreUsuario() + ", Contraseña = " + getContrasenia() + ", Correo = " + correo + 
				", Teléfono = " + telefono + ", Dirección = " + direccion + ", Estado = " + estado;
	}	
}
