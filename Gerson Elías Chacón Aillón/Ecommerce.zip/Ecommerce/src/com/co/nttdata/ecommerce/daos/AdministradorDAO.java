package com.co.nttdata.ecommerce.daos;

import java.sql.Connection;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.co.nttdata.ecommerce.entidades.Administrador;
import com.co.nttdata.ecommerce.utils.Conexion;

public class AdministradorDAO {
	
	Conexion con = new Conexion();
	Scanner teclado = new Scanner(System.in);
	
	public List<Administrador> buscarAdmin(){
		
		Connection baseDatos = con.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		List<Administrador> admin = new ArrayList<Administrador>();
		
		try {
			
			st = baseDatos.prepareStatement("SELECT * FROM \"TBL_ADMINISTRADORES\" ORDER BY id_admin ASC");
			rs = st.executeQuery();
			
			while (rs.next()) {
				
				Administrador administrar = new Administrador();
				
				administrar.setIdUsuario(rs.getInt("id_Admin"));
				administrar.setNumeroIdentificacion(rs.getInt("num_identificacion"));
				administrar.setIdTipoIdentificacion(rs.getInt("id_tipo_identificacion"));
				administrar.setNombreUsuario(rs.getString("usuario"));
				administrar.setContrasenia(rs.getString("contrasenia"));
				administrar.setCorreo(rs.getString("correo"));
				administrar.setEstado(rs.getBoolean("estado"));
				
				admin.add(administrar);
			}
			
		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				rs.close();
				st.close();
				con.desconectarBD(baseDatos);
			} catch (Exception e2) {
				System.err.println(e2.getMessage());
			}
		}
				
		
		return admin;
	}
	
	public Administrador buscarAdmin(int admin) {
		Administrador adm = new Administrador();
		
		Connection baseDatos = con.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			st = baseDatos.prepareStatement("SELECT * FROM \"TBL_ADMINISTRADORES\" WHERE id_admin = ? ");
			st.setInt(1, admin);
			//st.setString(1, categoria);
			rs = st.executeQuery();
			
			while (rs.next()) {
				adm.setIdUsuario(rs.getInt("id_Admin"));
				adm.setNumeroIdentificacion(rs.getInt("num_identificacion"));
				adm.setIdTipoIdentificacion(rs.getInt("id_tipo_identificacion"));
				adm.setNombreUsuario(rs.getString("usuario"));
				adm.setContrasenia(rs.getString("contrasenia"));
				adm.setCorreo(rs.getString("correo"));
				adm.setEstado(rs.getBoolean("estado"));
			}
			
		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				rs.close();
				st.close();
				con.desconectarBD(baseDatos);
			} catch (Exception e2) {
				System.err.println(e2.getMessage());
			}
		}
		return adm;		
	}
	
	public void agregAdmin(Administrador ad) {
		
		Connection baseDatos = con.conectarBD();
		PreparedStatement st = null;
		
		try {
			st = baseDatos.prepareStatement("INSERT INTO \"TBL_ADMINISTRADORES\" (num_identificacion, id_tipo_identificacion,"
					+ "usuario, contrasenia, correo, estado) VALUES (?, ?, ?, ?, ?, ?)");
			st.setInt(1, ad.getNumeroIdentificacion());
			st.setInt(2, ad.getIdTipoIdentificacion());
			st.setString(3, ad.getNombreUsuario());
			st.setString(4, ad.getContrasenia());
			st.setString(5, ad.getCorreo());
			st.setBoolean(6, ad.isEstado());
			int val = st.executeUpdate();
			
			if (val > 0) 
				System.out.println("\nRegistro guardado con éxito...");
			else
				System.err.println("\nError al guardar el registro... !");
			
		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				st.close();
				con.desconectarBD(baseDatos);
			} catch (Exception e2) {
				System.err.println(e2.getMessage());
			}
		}		
	}
	
	public Administrador elimAdmin(int administrador) {
		Administrador ad = new Administrador();
		
		Connection baseDatos = con.conectarBD();
		PreparedStatement st = null;
				
		System.out.print("\nDesea eliminar el Administrador (s/n) ? : ");
		String rg = teclado.next();
		if (rg.equals("s")) {
			try {
				st = baseDatos.prepareStatement("DELETE FROM \"TBL_ADMINISTRADORES\" WHERE id_admin = ? ");
				st.setInt(1, administrador);
				int val = st.executeUpdate();
				
				if (val > 0) 
					System.out.println("\nRegistro eliminado con éxito...");
				else
					System.err.println("\nError al eliminar el registro... !");
				
			} catch (Exception e) {
				System.err.println(e.getMessage());
			} finally {
				try {
					st.close();
					con.desconectarBD(baseDatos);
				} catch (Exception e2) {
					System.err.println(e2.getMessage());
				}
			}
				
		} else if (rg.equals("n")) {
			System.out.println("\nSeleccionó no eliminar Administrador... !");
		}
		return ad;	
	}
	
	public void modAdmin(int idAdmin, int numIdent, int idTipIdent, String usuario, String contrasenia,
			String correo, boolean estado) {
		
		Connection baseDatos = con.conectarBD();
		PreparedStatement st = null;
				
		try {
			st = baseDatos.prepareStatement("UPDATE \"TBL_ADMINISTRADORES\" SET num_identificacion = ?, id_tipo_identificacion = ?,"
					+ "usuario = ?, contrasenia = ?, correo = ?, estado = ? WHERE id_admin = ? ");
			st.setInt(1, numIdent);
			st.setInt(2, idTipIdent);
			st.setString(3, usuario);
			st.setString(4, contrasenia);
			st.setString(5, correo);
			st.setBoolean(6, estado);
			st.setInt(7, idAdmin);
			int val = st.executeUpdate();

			if (val > 0)
				System.out.println("\nRegistro modificado con éxito...");
			else
				System.err.println("\nError al modificar el registro... !");

		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				st.close();
				con.desconectarBD(baseDatos);
			} catch (Exception e2) {
				System.err.println(e2.getMessage());
			}
		}
	}		
}
