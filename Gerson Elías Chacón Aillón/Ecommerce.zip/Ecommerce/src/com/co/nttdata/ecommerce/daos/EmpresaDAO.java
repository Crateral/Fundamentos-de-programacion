package com.co.nttdata.ecommerce.daos;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.co.nttdata.ecommerce.entidades.Empresa;
import com.co.nttdata.ecommerce.utils.Conexion;

public class EmpresaDAO {
	
	Conexion con = new Conexion();
	Scanner teclado = new Scanner(System.in);
	
	public List<Empresa> buscarEmpresa(){
		
		Connection baseDatos = con.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		List<Empresa> empresas = new ArrayList<Empresa>();
		
		try {
			
			st = baseDatos.prepareStatement("SELECT * FROM \"TBL_EMPRESA\" ");
			rs = st.executeQuery();
			
			while (rs.next()) {
				
				Empresa emp = new Empresa();
				
				emp.setNit(rs.getString("nit"));
				emp.setEmpresa(rs.getString("empresa"));
				emp.setResolucionDian(rs.getString("resolucion_dian"));
				emp.setDireccion(rs.getString("direccion"));
				emp.setTelefono(rs.getString("telefono"));
				
				empresas.add(emp);
			}
			
		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				rs.close();
				st.close();
				con.desconectarBD(baseDatos);
			} catch (Exception e2) {
				System.err.println(e2.getMessage());
			}
		}
				
		
		return empresas;
	}
	
	public Empresa buscarEmpresa(String empresa) {
		Empresa em = new Empresa();
		
		Connection baseDatos = con.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			st = baseDatos.prepareStatement("SELECT * FROM \"TBL_EMPRESA\" WHERE nit = ? ");
			st.setString(1, empresa);
			rs = st.executeQuery();
			
			while (rs.next()) {
				em.setNit(rs.getString("nit"));
				em.setEmpresa(rs.getString("empresa"));
				em.setResolucionDian(rs.getString("resolucion_dian"));
				em.setDireccion(rs.getString("direccion"));
				em.setTelefono(rs.getString("telefono"));
			}
			
		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				rs.close();
				st.close();
				con.desconectarBD(baseDatos);
			} catch (Exception e2) {
				System.err.println(e2.getMessage());
			}
		}
		return em;		
	}
	
	public void agregEmpresa(Empresa em) {
		
		Connection baseDatos = con.conectarBD();
		PreparedStatement st = null;
		
		try {
			st = baseDatos.prepareStatement("INSERT INTO \"TBL_EMPRESA\" (nit, empresa, resolucion_dian, direccion,"
					+ "telefono) VALUES (?, ?, ?, ?, ?)");
			st.setString(1, em.getNit());
			st.setString(2, em.getEmpresa());
			st.setString(3, em.getResolucionDian());
			st.setString(4, em.getDireccion());
			st.setString(5, em.getTelefono());
			int val = st.executeUpdate();
			
			if (val > 0) 
				System.out.println("\nRegistro guardado con éxito...");
			else
				System.err.println("\nError al guardar el registro... !");
			
		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				st.close();
				con.desconectarBD(baseDatos);
			} catch (Exception e2) {
				System.err.println(e2.getMessage());
			}
		}		
	}
	
	public Empresa elimEmpresa(String empresa) {
		Empresa em = new Empresa();
		
		Connection baseDatos = con.conectarBD();
		PreparedStatement st = null;
				
		System.out.print("\nDesea eliminar la Empresa (s/n) ? : ");
		String rg = teclado.next();
		if (rg.equals("s")) {
			try {
				st = baseDatos.prepareStatement("DELETE FROM \"TBL_EMPRESA\" WHERE nit = ? ");
				st.setString(1, empresa);
				int val = st.executeUpdate();
				
				if (val > 0) 
					System.out.println("\nRegistro eliminado con éxito...");
				else
					System.err.println("\nError al eliminar el registro... !");
				
			} catch (Exception e) {
				System.err.println(e.getMessage());
			} finally {
				try {
					st.close();
					con.desconectarBD(baseDatos);
				} catch (Exception e2) {
					System.err.println(e2.getMessage());
				}
			}
				
		} else if (rg.equals("n")) {
			System.out.println("\nSeleccionó no eliminar Empresa... !");
		}
		return em;	
	}
	
	public void modEmpresa(String nit, String empresa, String resolucion, String direccion, String telefono) {
			
		Connection baseDatos = con.conectarBD();
		PreparedStatement st = null;
				
		try {
			st = baseDatos.prepareStatement("UPDATE \"TBL_EMPRESA\" SET empresa = ?, resolucion_dian = ?,"
					+ "direccion = ?, telefono = ? WHERE nit = ? ");
			st.setString(1, empresa);
			st.setString(2, resolucion);
			st.setString(3, direccion);
			st.setString(4, telefono);
			st.setString(5, nit);
			int val = st.executeUpdate();

			if (val > 0)
				System.out.println("\nRegistro modificado con éxito...");
			else
				System.err.println("\nError al modificar el registro... !");

		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				st.close();
				con.desconectarBD(baseDatos);
			} catch (Exception e2) {
				System.err.println(e2.getMessage());
			}
		}
	}
	
}
