package com.co.nttdata.ecommerce.principal;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import com.co.nttdata.ecommerce.daos.AdministradorDAO;
import com.co.nttdata.ecommerce.daos.CategoriaDAO;
import com.co.nttdata.ecommerce.daos.CiudadesDAO;
import com.co.nttdata.ecommerce.daos.ClienteDAO;
import com.co.nttdata.ecommerce.daos.EmpresaDAO;
import com.co.nttdata.ecommerce.daos.FormaPagoDAO;
import com.co.nttdata.ecommerce.daos.MarcaDAO;
import com.co.nttdata.ecommerce.daos.ProductoDAO;
import com.co.nttdata.ecommerce.daos.TipoIdentificacionDAO;
import com.co.nttdata.ecommerce.entidades.*;
import com.co.nttdata.ecommerce.interfaces.GestionLogin;
import com.co.nttdata.ecommerce.logica.*;
import com.co.nttdata.ecommerce.utilitarios.GestionFacturaUtil;
import com.co.nttdata.ecommerce.utilitarios.GestionProductosUtil;

public class Main {
	
	static int op, w = 1, id, fg = 0, gp = 0, ic = 0, idpr;
	static String nomb, contra, numIdent, correo, reg;
	static boolean estado;
	static List<Producto> lisProd = new ArrayList<>();
	static CarritoDeCompras cdc = new CarritoDeCompras();
	static Cliente cl;
	static Administrador adm;
	static Scanner teclado = new Scanner(System.in);
	static Producto prUno;
	static Producto prDos;
	static Producto prTres;
	static Producto prCuatro;
	static Producto prCinco;
	static Producto prSeis;
	static Producto prSiete;
	static Producto prOcho;
	static Producto prNueve;
	static Producto prDiez;
	
	
	public static void main(String[] args) {
		
		//listadoProd();				
		GestionCarritoDeComprasImpl gdcd = new GestionCarritoDeComprasImpl();
		Factura f = new Factura();
		GestionFacturaImpl gdf = new GestionFacturaImpl();
		GestionLogin gl = new GestionLoginImpl();
		//GestionLoginImpl gdu = new GestionLoginImpl();
		GestionProductosUtil gdp = new GestionProductosUtil();
		GestionFacturaUtil gdfu = new GestionFacturaUtil();
			
		
		try {
			do {
				System.out.println();
				System.out.print("Seleccione... \n1. Registrar Usuario \n2. Mostrar Usuario \n3. Iniciar Sesión "
						+ "\n4. Cerrar Sesión \n5. Recuperar contraseña \n6. Mostrar Productos "
						+ "\n7. Agregar producto al carro de compras \n8. Generar Factura "
						+ "\n9. Generar archivo productos \n10. Mostrar archivo factura \n11. Mantenimiento"
						+ "\n12. Salir \nOpcion : ");
				op = teclado.nextInt();
				switch (op) {
				case 1:
					// REGISTRAR USUARIO
					try {
						int ct = 1, opc, w = 1;
						Ciudades ciudad = null;
						FormaPago forPago = null;
						TipoIdentificacion tipIdent = null;
						while (w == 1) {
							System.out.print("\nDesea registrarse (s/n) ? : ");
							reg = teclado.next();
							if (reg.equals("s")) {
								ingDatosUsu();
								System.out.print("Digte ID            : ");
								id = teclado.nextInt();
								System.out.print("Nombre Usuario      : ");
								nomb = teclado.next();
								System.out.print("Contraseña          : ");
								contra = teclado.next();
								/*System.out.print("\nSeleccione Tipo Ident : \n");
								for (TipoIdentificacion mostTipIden : TipoIdentificacion.values()) {
									System.out.println(ct++ + ". " + mostTipIden);
								}
								System.out.print("Opción : ");
								opc = teclado.nextInt();
								if(opc == 1)
									tipIdent = TipoIdentificacion.CC;
								else if (opc == 2)
									tipIdent = TipoIdentificacion.TI;
								else if (opc == 3)
									tipIdent = TipoIdentificacion.PASAPORTE;
								else if (opc == 4)
									tipIdent = TipoIdentificacion.NUIP;*/
								
								System.out.print("Número Ident        : ");
								numIdent = teclado.next();
								System.out.print("Correo              : ");
								correo = teclado.next();
								System.out.print("Estado (true/false) : ");
								estado = teclado.nextBoolean();
								System.out.print("Dirección           : ");
								String direccion = teclado.next();
								System.out.print("Teléfono            : ");
								String telefono = teclado.next();
								/*System.out.print("\nSeleccione Ciudad   : \n");
								ct = 1;
								for (Ciudades mostCiu : Ciudades.values()) {
									System.out.println(ct++ + ". " + mostCiu);
								}
								System.out.print("Opción : ");
								opc = teclado.nextInt();
								if (opc == 1) {
									ciudad = Ciudades.BOGOTA;
								} else if (opc == 2) {
									ciudad = Ciudades.MEDELLIN;
								} else if (opc == 3) {
									ciudad = Ciudades.OTRAS;
								}*/
								/*System.out.print("\nMetodo pago         : \n");
								ct = 1;
								for (FormaPago mostForPag : FormaPago.values()) {
									System.out.println(ct++ + ". " + mostForPag);
								}
								System.out.print("Opción : ");
								opc = teclado.nextInt();
								if (opc == 1) {
									forPago = FormaPago.CONTADO;
								} else if (opc == 2) {
									forPago = FormaPago.CREDITO;
								} else if (opc == 3) {
									forPago = FormaPago.TARJETA_DEBITO;
								} else if (opc == 4) {
									forPago = FormaPago.TARJETA_CREDITO;
								}*/
								
								cl = (Cliente) gl.registarUsuario(id, nomb, contra, tipIdent, numIdent, correo, 
										estado, direccion, telefono, ciudad, forPago);
								ic = 1;
								
								/*adm = (Administrador) gl.registarUsuario(id, nomb, contra, tipIdent, numIdent, correo, 
										estado, direccion, telefono, ciudad, forPago);*/
								break;
							} else if (reg.equals("n")) {
								System.out.println("\nSeleccionó no registrarse");
								break;
							}
						}
					} catch (Exception e) {
						System.out.println("\nError al digitar información : " + e.getMessage());
					}
					break;
				case 2:
					// MOSTRAR USUARIO
					try {
						System.out.print("\n*** DATOS DEL CLIENTE ***");
						System.out.print("\nDigte ID            : " + cl.getIdUsuario());
						System.out.print("\nNombre Usuario      : " + cl.getNombreUsuario());
						System.out.print("\nContraseña          : " + cl.getContrasenia());
						//System.out.print("\nTipo Ident          : " + cl.getTipoIdentificacion());
						System.out.print("\nNúmero Ident        : " + cl.getNumeroIdentificacion());
						System.out.print("\nCorreo              : " + cl.getCorreo());
						System.out.print("\nDirección           : " + cl.getDireccion());
						System.out.print("\nTeléfono            : " + cl.getTelefono());
						//System.out.print("\nCiudad              : " + cl.getCiudad());
						//System.out.print("\nMétodo pago         : " + cl.getMetodoDePago());
						System.out.print("\nEstado (true/false) : " + cl.isEstado());
						System.out.println();
						break;
					} catch (Exception e) {
						System.out.println("\nNo hay usuario registrado\n");
						break;
					}
				case 3:
					// INICIAR SESIÓN
					try {
						if (ic == 1) {
							if ( ((GestionLoginImpl) gl).getIniSess() == 0) {
								System.out.print("\nINICIO DE SESIÓN...");
								System.out.print("\nDigite Usuario    : ");
								String user = teclado.next();
								System.out.print("Digite contraseña : ");
								String contra = teclado.next();
								gl.login(user, contra);
								break;
							} else {
								System.out.print("\nTiene la sesión iniciada\n");
								break;
							}
						} else {
							System.out.println("\nNo hay usuario registrado\n");
							break;
						}
					} catch (Exception e) {
						System.out.println("\nNo se encontró información : " + e.getMessage());
					}
					break;
				case 4:
					// CERRAR SESIÓN
					try {
						while (w == 1) {
							if ( ((GestionLoginImpl) gl).getIniSess() == 1) {
								System.out.print("\nDesea cerrar sesion ? s/n : ");
								String cerSes = teclado.next();
								gl.logout(cerSes);
								break;
							} else {
								System.out.println("\nInicie sesión");
								break;
							}
						}
						break;
					} catch (Exception e) {
						System.out.println("\nNo se encontró información : " + e.getMessage());
					}
					break;
				case 5:
					// RECUPERAR CONTRASEÑA
					try {
						if (((GestionLoginImpl) gl).getIniSess() == 1) {
							System.out.print("\nDigite Usuario    : ");
							String user = teclado.next();
							gl.recuperContrasenia(user);
							break;
						} else {
							System.out.println("\nInicie sesión");
							break;
						}
					} catch (Exception e) {
						System.out.println("\nNo se encontró información : " + e.getMessage());
					}
					break;
				case 6:
					// MOSTRAR PRODUCTOS
					System.out.println("\n*** PRODUCTOS ***\n");
					String nombreArchivoProd = "Lista_Productos.txt";
					gdp.leerArchivo(nombreArchivoProd);
					gp = 1;
					
					//lista = gdp.leerArchivo(nombreArchivoProd);
					//gdp.separaProd(lista);
										
					//cdc.setProductos(gdp.separaProd(lista));
					break;
				case 7:
					// AGREGAR PRODUCTOS AL CARRO DE COMPRAS
					
					if (gp == 1)
						//gdp.agregarCarrito();
						agregarCarrito();
					else 
						System.out.print("\nGenere el listado de los productos\n");
					break;
				case 8:
					// GENERAR FACTURA
					try {
						if ( ((GestionLoginImpl) gl).getIniSess() == 1) {
							/*gdcd.calcularTotalConIva(cdc);
							gdcd.calcularCostoEnvio(cdc, cl.getCiudad());
							f = gdf.pagar(cl, cdc);
							gdf.mostFact();*/
							String nombreArchivoFac = "Factura.txt";
							//gdcd.calcularTotalConIva(cdc);
							//gdcd.calcularCostoEnvio(cdc, cl.getCiudad());
							f = gdf.pagar(cl, cdc);
							gdfu.escribirArchivo(nombreArchivoFac, cl, cdc);
							fg = 1;
							break;
						} else {
							System.out.print("\nInicie Sesión ó agregue productos al carrito\n");
							break;
						}
					} catch (Exception e) {
						System.out.print("Inicie Sesión para Facturar : " + e.getMessage());
					}
					break;
				case 9:
					// GENERA ARCHIVO PRODUCTO
					String nombreArchivoProdAct = "Lista_Productos.txt";
					gdp.escribirArchivo(nombreArchivoProdAct, prUno, prDos, prTres, prCuatro, prCinco, 
							prSeis, prSiete, prOcho, prNueve, prDiez);
					break;
				case 10:
					// MOSTRAR FACTURA
					if (fg == 1) {
						gdfu.leerArchivo();
						break;
					} else {
						System.out.println("\nGenere la factura");
						break;
					}
					// SALIR
				case 11:
					System.out.print("\nSeleccione... \n1. Marcas \n2. Categorias \n3. Tipos Identificación"
							+ "\n4. Ciudades \n5. Formas PAgo \n6. Administrador \n7. Clientes \n8. Empresa "
							+ "\n9. Productos \n10. Carro de Compras \n11. Salir \nOpción : ");
					op = teclado.nextInt();
					switch (op) {
						case 1:
							while (w == 1) {
								MarcaDAO mdo = new MarcaDAO();
								Marca buscarm = new Marca();
								Marca nuevam = new Marca();
								Marca eliminarm = new Marca();
								Marca modificarm = new Marca();
								
								List<Marca> marcas = mdo.buscarMarca();
								
								System.out.print("\nSeleccione... \n1. Mostrar Marca \n2. Buscar Marca "
										+ "\n3. Ingresar Marca \n4. Eliminar Marca"
										+ "\n5. Modificar Marca \n6. Salir \nOpción : ");
								op = teclado.nextInt();
								switch (op) {
									case 1:
										for (Marca marca : marcas) {
											System.out.print("\n" + marca);
										}
										System.out.println();
										break;
									case 2:
										System.out.print("\nSeleccione ID Marca a buscar : ");
										op = teclado.nextInt();
										buscarm = mdo.buscarMarca(op);
										System.out.println(buscarm);
										break;
									case 3:
										System.out.println("\nIngresar nueva Marca...");
										System.out.print("Marca       : ");
										String mar = teclado.next();
										nuevam.setMarca(mar);
										System.out.print("Descripción : ");
										String ds = teclado.next();
										nuevam.setDescripcion(ds);
										mdo.agregMarca(nuevam);
										break;
									case 4:
										System.out.println("\nEliminar Marca...");
										System.out.print("Digite ID Marca a eliminar : ");
										op = teclado.nextInt();
										eliminarm = mdo.elimMarca(op);
										break;
									case 5:
										System.out.println("\nModificar Marca...");
										System.out.print("\nDigite ID Marca a modificar : ");
										op = teclado.nextInt();
										System.out.print("Marca       : ");
										String marc = teclado.next();
										modificarm.setMarca(marc);
										System.out.print("Descripción : ");
										String dsc = teclado.next();
										modificarm.setDescripcion(dsc);
										mdo.modMarca(op, marc, dsc);
										break;
									case 6:
										w = 2;
										break;
									default:
										System.err.println("\nDigito mal la opción");
										break;
								}
							}
							break;
						case 2:
							int w = 1;
							while (w == 1) {
								CategoriaDAO ctdo = new CategoriaDAO();
								Categoria buscarct = new Categoria();
								Categoria nuevact = new Categoria();
								Categoria eliminarct = new Categoria();
								Categoria modificarct = new Categoria();
								
								List<Categoria> categorias = ctdo.buscarCategoria();
								
								System.out.print("\nSeleccione... \n1. Mostrar Categoria \n2. Buscar Categoria "
										+ "\n3. Ingresar Categoria \n4. Eliminar Categoria"
										+ "\n5. Modificar Categoria \n6. Salir \nOpción : ");
								op = teclado.nextInt();
								switch (op) {
									case 1:
										for (Categoria categoria : categorias) {
											System.out.print("\n" + categoria);
										}
										System.out.println();
										break;
									case 2:
										System.out.print("\nSeleccione ID Categoria a buscar : ");
										op = teclado.nextInt();
										buscarct = ctdo.buscarCategoria(op);
										System.out.println(buscarct);
										break;
									case 3:
										System.out.println("\nIngresar nueva Categoria...");
										System.out.print("Categoria   : ");
										String cat = teclado.next();
										nuevact.setCategoria(cat);
										System.out.print("Descripción : ");
										String ds = teclado.next();
										nuevact.setDescripcion(ds);
										System.out.print("IVA         : ");
										double iva = teclado.nextDouble();
										nuevact.setIva(iva);
										ctdo.agregCategoria(nuevact);
										break;
									case 4:
										System.out.println("\nEliminar Categoria...");
										System.out.print("Digite ID Categoria a eliminar : ");
										op = teclado.nextInt();
										eliminarct = ctdo.elimCategoria(op);
										break;
									case 5:
										System.out.println("\nModificar Categoria...");
										System.out.print("\nDigite ID Categoria a modificar : ");
										op = teclado.nextInt();
										System.out.print("Categoria       : ");
										String marct = teclado.next();
										modificarct.setCategoria(marct);
										System.out.print("Descripción : ");
										String dsct = teclado.next();
										modificarct.setDescripcion(dsct);
										System.out.print("IVA         : ");
										double ivact = teclado.nextDouble();
										nuevact.setIva(ivact);
										ctdo.modCategoria(op, marct, dsct, ivact);
										break;
									case 6:
										w = 2;
										break;
									default:
										System.err.println("\nDigito mal la opción");
										break;
								}
							}
							break;
						case 3:
							int tp = 1;
							while (tp == 1) {
								TipoIdentificacionDAO tido = new TipoIdentificacionDAO();
								TipoIdentificacion buscarti = new TipoIdentificacion();
								TipoIdentificacion nuevati = new TipoIdentificacion();
								TipoIdentificacion eliminarti = new TipoIdentificacion();
								TipoIdentificacion modificarti = new TipoIdentificacion();
								
								List<TipoIdentificacion> tipoIdent = tido.buscarTipoIdentificacion();
								
								System.out.print("\nSeleccione... \n1. Mostrar Tipo Identificación \n2. Buscar Tipo Identificación "
										+ "\n3. Ingresar Tipo Identificación \n4. Eliminar Tipo Identificación"
										+ "\n5. Modificar Tipo Identificación \n6. Salir \nOpción : ");
								op = teclado.nextInt();
								switch (op) {
									case 1:
										for (TipoIdentificacion tipIden : tipoIdent) {
											System.out.print("\n" + tipIden);
										}
										System.out.println();
										break;
									case 2:
										System.out.print("\nSeleccione ID Tipo Identificación a buscar : ");
										op = teclado.nextInt();
										buscarti = tido.buscarTipoIdentificacion(op);
										System.out.println(buscarti);
										break;
									case 3:
										System.out.println("\nIngresar nuevo Tipo Identificación...");
										System.out.print("Tipo Identificación : ");
										String cati = teclado.next();
										nuevati.setTipoIdentificacion(cati);
										tido.agregTipoIdentificacion(nuevati);
										break;
									case 4:
										System.out.println("\nEliminar Tipo Identificación...");
										System.out.print("Digite ID Tipo Identificación a eliminar : ");
										op = teclado.nextInt();
										eliminarti = tido.elimTipoIdentificacion(op);
										break;
									case 5:
										System.out.println("\nModificar Tipo Identificación...");
										System.out.print("\nDigite ID Tipo Identificación a modificar : ");
										op = teclado.nextInt();
										System.out.print("Tipo Identificación : ");
										String marti = teclado.next();
										modificarti.setTipoIdentificacion(marti);
										tido.modTipoIdent(op, marti);
										break;
									case 6:
										tp = 2;
										break;
									default:
										System.err.println("\nDigito mal la opción");
										break;
								}
							}
							break;
						case 4:
							int ciup = 1;
							while (ciup == 1) {
								CiudadesDAO cido = new CiudadesDAO();
								Ciudades buscarci = new Ciudades();
								Ciudades nuevaci = new Ciudades();
								Ciudades eliminarci = new Ciudades();
								Ciudades modificarci = new Ciudades();
								
								List<Ciudades> ciudad = cido.buscarCiudades();
								
								System.out.print("\nSeleccione... \n1. Mostrar Ciudades \n2. Buscar Ciudades "
										+ "\n3. Ingresar Ciudades \n4. Eliminar Ciudades"
										+ "\n5. Modificar Ciudades \n6. Salir \nOpción : ");
								op = teclado.nextInt();
								switch (op) {
									case 1:
										for (Ciudades ciud : ciudad) {
											System.out.print("\n" + ciud);
										}
										System.out.println();
										break;
									case 2:
										System.out.print("\nSeleccione ID Ciudad a buscar : ");
										op = teclado.nextInt();
										buscarci = cido.buscarCiudades(op);
										System.out.println(buscarci);
										break;
									case 3:
										System.out.println("\nIngresar nueva Ciudad...");
										System.out.print("Ciudad    : ");
										String catci = teclado.next();
										nuevaci.setCiudad(catci);
										System.out.print("Principal : ");
										boolean pr = teclado.nextBoolean();
										nuevaci.setPrincipal(pr);
										cido.agregCiudades(nuevaci);
										break;
									case 4:
										System.out.println("\nEliminar Ciudad...");
										System.out.print("Digite ID Ciudad a eliminar : ");
										op = teclado.nextInt();
										eliminarci = cido.elimCiudades(op);
										break;
									case 5:
										System.out.println("\nModificar Ciudad...");
										System.out.print("\nDigite ID Ciudad a modificar : ");
										op = teclado.nextInt();
										System.out.print("Ciudad : ");
										String marci = teclado.next();
										modificarci.setCiudad(marci);
										System.out.print("Principal : ");
										boolean prn = teclado.nextBoolean();
										modificarci.setPrincipal(prn);
										cido.modCiudades(op, marci, prn);
										break;
									case 6:
										ciup = 2;
										break;
									default:
										System.err.println("\nDigito mal la opción");
										break;
								}
							}
							break;
						case 5:
							int fpo = 1;
							while (fpo == 1) {
								FormaPagoDAO fpdo = new FormaPagoDAO();
								FormaPago buscarfp = new FormaPago();
								FormaPago nuevafp = new FormaPago();
								FormaPago eliminarfp = new FormaPago();
								FormaPago modificarfp = new FormaPago();
								
								List<FormaPago> formPag = fpdo.buscarFormaPago();
								
								System.out.print("\nSeleccione... \n1. Mostrar Forma Pago \n2. Buscar Forma Pago "
										+ "\n3. Ingresar Forma Pago \n4. Eliminar Forma Pago"
										+ "\n5. Modificar Forma Pago \n6. Salir \nOpción : ");
								op = teclado.nextInt();
								switch (op) {
									case 1:
										for (FormaPago forPg : formPag) {
											System.out.print("\n" + forPg);
										}
										System.out.println();
										break;
									case 2:
										System.out.print("\nSeleccione ID Forma Pago a buscar : ");
										op = teclado.nextInt();
										buscarfp = fpdo.buscarFormaPago(op);
										System.out.println(buscarfp);
										break;
									case 3:
										System.out.println("\nIngresar nuevo Forma Pago...");
										System.out.print("Forma Pago : ");
										String cati = teclado.next();
										nuevafp.setFormaPago(cati);
										fpdo.agregFormaPago(nuevafp);
										break;
									case 4:
										System.out.println("\nEliminar Forma Pago...");
										System.out.print("Digite ID Forma Pago a eliminar : ");
										op = teclado.nextInt();
										eliminarfp = fpdo.elimFormaPago(op);
										break;
									case 5:
										System.out.println("\nModificar Forma Pago...");
										System.out.print("\nDigite ID Forma Pago a modificar : ");
										op = teclado.nextInt();
										System.out.print("Forma Pago : ");
										String marti = teclado.next();
										modificarfp.setFormaPago(marti);
										fpdo.modFormaPago(op, marti);
										break;
									case 6:
										fpo = 2;
										break;
									default:
										System.err.println("\nDigito mal la opción");
										break;
								}
							}
							break;
						case 6:
							int am = 1;
							while (am == 1) {
								AdministradorDAO addo = new AdministradorDAO();
								Administrador buscarad = new Administrador();
								Administrador nuevaad = new Administrador();
								Administrador eliminarad = new Administrador();
								Administrador modificarad = new Administrador();
								
								List<Administrador> admin = addo.buscarAdmin();
								
								System.out.print("\nSeleccione... \n1. Mostrar Administrador \n2. Buscar Administrador "
										+ "\n3. Ingresar Administrador \n4. Eliminar Administrador"
										+ "\n5. Modificar Administrador \n6. Salir \nOpción : ");
								op = teclado.nextInt();
								switch (op) {
									case 1:
										for (Administrador adm : admin) {
											System.out.print("\n" + adm);
										}
										System.out.println();
										break;
									case 2:
										System.out.print("\nSeleccione ID Administrador a buscar : ");
										op = teclado.nextInt();
										buscarad = addo.buscarAdmin(op);
										System.out.println(buscarad);
										break;
									case 3:
										System.out.println("\nIngresar nuevo Administrador...");
										System.out.print("Número Identificación  : ");
										int nuid = teclado.nextInt();
										nuevaad.setNumeroIdentificacion(nuid);
										System.out.print("ID Tipo Identificación : ");
										int itid = teclado.nextInt();
										nuevaad.setIdTipoIdentificacion(itid);
										System.out.print("Nombre Usuario         : ");
										String nmu = teclado.next();
										nuevaad.setNombreUsuario(nmu);
										System.out.print("Contraseña             : ");
										String cont = teclado.next();
										nuevaad.setContrasenia(cont);
										System.out.print("Correo                 : ");
										String cor = teclado.next();
										nuevaad.setCorreo(cor);
										System.out.print("Estado                 : ");
										boolean est = teclado.nextBoolean();
										nuevaad.setEstado(est);
										addo.agregAdmin(nuevaad);
										break;
									case 4:
										System.out.println("\nEliminar Administrador...");
										System.out.print("Digite ID Administrador a eliminar : ");
										op = teclado.nextInt();
										eliminarad = addo.elimAdmin(op);
										break;
									case 5:
										System.out.println("\nModificar Administrador...");
										System.out.print("\nDigite ID Administrador a modificar : ");
										op = teclado.nextInt();
										System.out.print("Número Identificación  : ");
										int nuidm = teclado.nextInt();
										nuevaad.setNumeroIdentificacion(nuidm);
										System.out.print("ID Tipo Identificación : ");
										int itidm = teclado.nextInt();
										nuevaad.setIdTipoIdentificacion(itidm);
										System.out.print("Nombre Usuario         : ");
										String nmum = teclado.next();
										nuevaad.setNombreUsuario(nmum);
										System.out.print("Contraseña             : ");
										String contm = teclado.next();
										nuevaad.setContrasenia(contm);
										System.out.print("Correo                 : ");
										String corm = teclado.next();
										nuevaad.setCorreo(corm);
										System.out.print("Estado                 : ");
										boolean estm = teclado.nextBoolean();
										nuevaad.setEstado(estm);
										addo.modAdmin(op, nuidm, itidm, nmum, contm, corm, estm);
										break;
									case 6:
										am = 2;
										break;
									default:
										System.err.println("\nDigito mal la opción");
										break;
								}
							}
							break;
						case 7:
							int ct = 1;
							while (ct == 1) {
								ClienteDAO cldo = new ClienteDAO();
								Cliente buscarcl = new Cliente();
								Cliente nuevacl = new Cliente();
								Cliente eliminarcl = new Cliente();
								Cliente modificarcl = new Cliente();
								
								List<Cliente> clientes = cldo.buscarCliente();
								
								System.out.print("\nSeleccione... \n1. Mostrar Clientes \n2. Buscar Clientes "
										+ "\n3. Ingresar Clientes \n4. Eliminar Clientes"
										+ "\n5. Modificar Clientes \n6. Salir \nOpción : ");
								op = teclado.nextInt();
								switch (op) {
									case 1:
										for (Cliente clin : clientes) {
											System.out.print("\n" + clin);
										}
										System.out.println();
										break;
									case 2:
										System.out.print("\nSeleccione ID Clientes a buscar : ");
										op = teclado.nextInt();
										buscarcl = cldo.buscarCliente(op);
										System.out.println(buscarcl);
										break;
									case 3:
										System.out.println("\nIngresar nuevo Cliente...");
										System.out.print("Número Identificación  : ");
										int nuid = teclado.nextInt();
										nuevacl.setNumeroIdentificacion(nuid);
										System.out.print("ID Tipo Identificación : ");
										int itid = teclado.nextInt();
										nuevacl.setIdTipoIdentificacion(itid);
										System.out.print("ID Ciudad              : ");
										int ciu = teclado.nextInt();
										nuevacl.setIdCiudad(ciu);
										System.out.print("ID Forma Pago          : ");
										int fp = teclado.nextInt();
										nuevacl.setIdFormaPago(fp);
										System.out.print("Nombre Usuario         : ");
										String nmu = teclado.next();
										nuevacl.setNombreUsuario(nmu);
										System.out.print("Contraseña             : ");
										String cont = teclado.next();
										nuevacl.setContrasenia(cont);
										System.out.print("Correo                 : ");
										String cor = teclado.next();
										nuevacl.setCorreo(cor);
										System.out.print("Telefono               : ");
										String tf = teclado.next();
										nuevacl.setTelefono(tf);
										System.out.print("Dirección              : ");
										String dir = teclado.next();
										nuevacl.setDireccion(dir);
										System.out.print("Estado                 : ");
										boolean est = teclado.nextBoolean();
										nuevacl.setEstado(est);
										cldo.agregCliente(nuevacl);
										break;
									case 4:
										System.out.println("\nEliminar Cliente...");
										System.out.print("Digite ID Cliente a eliminar : ");
										op = teclado.nextInt();
										eliminarcl = cldo.elimCliente(op);
										break;
									case 5:
										System.out.println("\nModificar Cliente...");
										System.out.print("\nDigite ID Cliente a modificar : ");
										op = teclado.nextInt();
										System.out.print("Número Identificación  : ");
										int nuidc = teclado.nextInt();
										nuevacl.setNumeroIdentificacion(nuidc);
										System.out.print("ID Tipo Identificación : ");
										int itidc = teclado.nextInt();
										nuevacl.setIdTipoIdentificacion(itidc);
										System.out.print("ID Ciudad              : ");
										int ciuc = teclado.nextInt();
										nuevacl.setIdCiudad(ciuc);
										System.out.print("ID Forma Pago          : ");
										int fpc= teclado.nextInt();
										nuevacl.setIdFormaPago(fpc);
										System.out.print("Nombre Usuario         : ");
										String nmuc= teclado.next();
										nuevacl.setNombreUsuario(nmuc);
										System.out.print("Contraseña             : ");
										String contc = teclado.next();
										nuevacl.setContrasenia(contc);
										System.out.print("Correo                 : ");
										String corc = teclado.next();
										nuevacl.setCorreo(corc);
										System.out.print("Telefono               : ");
										String tfc = teclado.next();
										nuevacl.setTelefono(tfc);
										System.out.print("Dirección              : ");
										String dirc = teclado.next();
										nuevacl.setDireccion(dirc);
										System.out.print("Estado                 : ");
										boolean estc = teclado.nextBoolean();
										nuevacl.setEstado(estc);
										cldo.modCliente(op, nuidc, itidc, ciuc, fpc, nmuc, contc, corc, tfc, dirc, estc);
										break;
									case 6:
										ct = 2;
										break;
									default:
										System.err.println("\nDigito mal la opción");
										break;
								}
							}
							break;
						case 8:
							int ep = 1;
							while (ep == 1) {
								EmpresaDAO epdo = new EmpresaDAO();
								Empresa buscarep = new Empresa();
								Empresa nuevaep = new Empresa();
								Empresa eliminarep = new Empresa();
								Empresa modificarep = new Empresa();
								
								List<Empresa> empresa = epdo.buscarEmpresa();
								
								System.out.print("\nSeleccione... \n1. Mostrar Empresa \n2. Buscar Empresa "
										+ "\n3. Ingresar Empresa \n4. Eliminar Empresa"
										+ "\n5. Modificar Empresa \n6. Salir \nOpción : ");
								op = teclado.nextInt();
								switch (op) {
									case 1:
										for (Empresa emp : empresa) {
											System.out.print("\n" + emp);
										}
										System.out.println();
										break;
									case 2:
										System.out.print("\nSeleccione Nit Empresa a buscar : ");
										String opnit = teclado.next();
										buscarep = epdo.buscarEmpresa(opnit);
										System.out.println(buscarep);
										break;
									case 3:
										System.out.println("\nIngresar nueva Empresa...");
										System.out.print("Nit             : ");
										String nit = teclado.next();
										nuevaep.setNit(nit);
										System.out.print("Empresa         : ");
										String emp = teclado.next();
										nuevaep.setEmpresa(emp);
										System.out.print("Resolucion Dian : ");
										String rdi = teclado.next();
										nuevaep.setResolucionDian(rdi);
										System.out.print("Dirección       : ");
										String dir = teclado.next();
										nuevaep.setDireccion(dir);
										System.out.print("Teléfono        : ");
										String tel = teclado.next();
										nuevaep.setTelefono(tel);
										epdo.agregEmpresa(nuevaep);
										break;
									case 4:
										System.out.println("\nEliminar Empresa...");
										System.out.print("Digite Nit Empresa a eliminar : ");
										String opel = teclado.next();
										eliminarep = epdo.elimEmpresa(opel);
										break;
									case 5:
										System.out.println("\nModificar Empresa...");
										System.out.print("Nit             : ");
										String nite = teclado.next();
										nuevaep.setNit(nite);
										System.out.print("Empresa         : ");
										String empe = teclado.next();
										nuevaep.setEmpresa(empe);
										System.out.print("Resolucion Dian : ");
										String rdie = teclado.next();
										nuevaep.setResolucionDian(rdie);
										System.out.print("Dirección       : ");
										String dire = teclado.next();
										nuevaep.setDireccion(dire);
										System.out.print("Teléfono        : ");
										String tele = teclado.next();
										nuevaep.setTelefono(tele);
										epdo.modEmpresa(nite, empe, rdie, dire, tele);
										break;
									case 6:
										ep = 2;
										break;
									default:
										System.err.println("\nDigito mal la opción");
										break;
								}
							}
							break;
						case 9:
							int pd = 1;
							while (pd == 1) {
								ProductoDAO pddo = new ProductoDAO();
								Producto buscarpd = new Producto();
								Producto nuevapd = new Producto();
								Producto eliminarpd = new Producto();
								Producto modificarpd = new Producto();
								
								List<Producto> productos = pddo.buscarProducto();
								
								System.out.print("\nSeleccione... \n1. Mostrar Productos \n2. Buscar Productos "
										+ "\n3. Ingresar Productos \n4. Eliminar Productos"
										+ "\n5. Modificar Productos \n6. Salir \nOpción : ");
								op = teclado.nextInt();
								switch (op) {
									case 1:
										for (Producto prd : productos) {
											System.out.print("\n" + prd);
										}
										System.out.println();
										break;
									case 2:
										System.out.print("\nSeleccione ID Productos a buscar : ");
										op = teclado.nextInt();
										buscarpd = pddo.buscarProducto(op);
										System.out.println(buscarpd);
										break;
									case 3:
										System.out.println("\nIngresar nuevo Producto...");
										System.out.print("ID Marca          : ");
										int idma = teclado.nextInt();
										nuevapd.setIdMarca(idma);
										System.out.print("ID CAtgegoria     : ");
										int idca = teclado.nextInt();
										nuevapd.setIdCategoria(idca);
										System.out.print("Nombre Producto   : ");
										String npr = teclado.next();
										nuevapd.setNomProducto(npr);
										System.out.print("Cantidad disp     : ");
										int ctd = teclado.nextInt();
										nuevapd.setCantidadDiponible(ctd);
										System.out.print("Precio            : ");
										double pre = teclado.nextDouble();
										nuevapd.setPrecio(pre);
										System.out.print("Dcto (true/false) : ");
										boolean dct= teclado.nextBoolean();
										nuevapd.setDescuento(dct);
										System.out.print("Vr Descuento      : ");
										double vrdc = teclado.nextDouble();
										nuevapd.setValorDescuento(vrdc);
										System.out.print("Descripcion       : ");
										String desc = teclado.next();
										nuevapd.setDescripcion(desc);
										System.out.print("Imagen            : ");
										String im = teclado.next();
										nuevapd.setImg(im);
										pddo.agregProducto(nuevapd);
										break;
									case 4:
										System.out.println("\nEliminar Producto...");
										System.out.print("Digite ID Producto a eliminar : ");
										op = teclado.nextInt();
										eliminarpd = pddo.elimProducto(op);
										break;
									case 5:
										System.out.println("\nModificar Producto...");
										System.out.print("\nDigite ID Producto a modificar : ");
										op = teclado.nextInt();
										System.out.print("ID Marca          : ");
										int idmap = teclado.nextInt();
										nuevapd.setIdMarca(idmap);
										System.out.print("ID CAtgegoria     : ");
										int idcap = teclado.nextInt();
										nuevapd.setIdCategoria(idcap);
										System.out.print("Nombre Producto   : ");
										String nprp = teclado.next();
										nuevapd.setNomProducto(nprp);
										System.out.print("Cantidad disp     : ");
										int ctdp = teclado.nextInt();
										nuevapd.setCantidadDiponible(ctdp);
										System.out.print("Precio            : ");
										double prep = teclado.nextDouble();
										nuevapd.setPrecio(prep);
										System.out.print("Dcto (true/false) : ");
										boolean dctp = teclado.nextBoolean();
										nuevapd.setDescuento(dctp);
										System.out.print("Vr Descuento      : ");
										double vrdcp = teclado.nextDouble();
										nuevapd.setValorDescuento(vrdcp);
										System.out.print("Descripcion       : ");
										String descp = teclado.next();
										nuevapd.setDescripcion(descp);
										System.out.print("Imagen            : ");
										String imp = teclado.next();
										nuevapd.setImg(imp);
										pddo.modProducto(op, idmap, idcap, nprp, ctdp, prep, dctp, vrdcp, descp, imp);
										break;
									case 6:
										pd = 2;
										break;
									default:
										System.err.println("\nDigito mal la opción");
										break;
								}
							}
							break;
						case 10:
							System.out.println("\nEn proceso....");
							break;
						case 11:
							break;
						default:
							System.err.println("\nError al digitar la opción");
							break;
					}
					break;
				case 12:
					break;
				default:
					System.out.print("\nError al digitar opción\n");
					break;
				}
			} while (op != 12);
		} catch (Exception e) {
			System.out.println("\nError al digitar información : " + e.getMessage());
		}
	}
	
	
	public static void ingDatosUsu() {
		
	}

	/*public static void listadoProd() {

		prUno = new Producto(1, "nevera", 6, 450000, false, 0, 0, "nevera frost", "imgnev", Marca.LG,
				Categoria.ELECTRODOMESTICOS);
		prDos = new Producto(2, "tv", 4, 300000, true, 50000, 19, "tv 32", "imgtv", Marca.SAMSUNG,
				Categoria.ELECTRODOMESTICOS);
		prTres = new Producto(3, "monitor", 8, 450000, true, 30000, 19, "monitor 22", "imgmon", Marca.SAMSUNG,
				Categoria.EQUIPO_COMPUTO);
		prCuatro = new Producto(4, "servidor", 2, 1500000, true, 15000, 19, "licuadora 100", "imglic",
				Marca.LENOVO, Categoria.EQUIPO_COMPUTO);
		prCinco = new Producto(5, "lavadora", 1, 600000, false, 0, 19, "lavadora l12", "imglav", Marca.LG,
				Categoria.ELECTRODOMESTICOS);
		prSeis = new Producto(6, "ventilador", 4, 300000, true, 10000, 5, "ventilador", "imgven",
				Marca.SAMSUNG, Categoria.ELECTRODOMESTICOS);
		prSiete = new Producto(7, "aspiradora", 3, 200000, true, 50000, 19, "aspiradora", "imgasp", Marca.LG,
				Categoria.ELECTRODOMESTICOS);
		prOcho = new Producto(8, "horno", 0, 700000, false, 0, 5, "horno p25", "imghor", Marca.SAMSUNG,
				Categoria.ELECTRODOMESTICOS);
		prNueve = new Producto(9, "estufa", 4, 480000, true, 80000, 19, "estufa t147", "imgest", Marca.LG,
				Categoria.ELECTRODOMESTICOS);
		prDiez = new Producto(10, "plancha", 6, 50000, false, 0, 19, "plancha r9", "imgplan", Marca.LENOVO,
				Categoria.ELECTRODOMESTICOS);

		
		lisProd.add(prUno);
		lisProd.add(prDos);
		lisProd.add(prTres);
		lisProd.add(prCuatro);
		lisProd.add(prCinco);
		lisProd.add(prSeis);
		lisProd.add(prSiete);
		lisProd.add(prOcho);
		lisProd.add(prNueve);
		lisProd.add(prDiez);
		
	}*/
	
	
	public static void agregarCarrito() {
		HashMap<Integer, Producto> inv = new HashMap<>();
		while (w == 1) {
			int cant = 0, ca = 0;
			System.out.print("\nDesea agregar productos (s/n) ? : ");
			reg = teclado.next();
			if (reg.equals("s") ) {
				
				System.out.print("\nSeleccione Producto : ");
				idpr = teclado.nextInt();
								
				inv.put(prUno.getIdProducto(), prUno);
				inv.put(prDos.getIdProducto(), prDos);
				inv.put(prTres.getIdProducto(), prTres);
				inv.put(prCuatro.getIdProducto(), prCuatro);
				inv.put(prCinco.getIdProducto(), prCinco);
				inv.put(prSeis.getIdProducto(), prSeis);
				inv.put(prSiete.getIdProducto(), prSiete);
				inv.put(prOcho.getIdProducto(), prOcho);
				inv.put(prNueve.getIdProducto(), prNueve);
				inv.put(prDiez.getIdProducto(), prDiez);
				
				switch (idpr) {
				case 1:
					System.out.print("Digite la cantidad : ");
					cant = teclado.nextInt();
					if (cant > 0 && cant <= prUno.getCantidadDiponible()) {
						//prUno.setDigCant(cant);
						ca = prUno.getCantidadDiponible() - cant;
						//cdc.getProductos().add(inv.get(idpr));
						prUno.setCantidadDiponible(ca);
						//System.out.print("\nProducto... " + prUno.getNombre() + ", agregado al carrito con éxito\n");
						break;
					} else {
						System.out.print("\nCantidad en 0 ó Excede la cantidad\n");
						break;
					}
				case 2:
					System.out.print("Digite la cantidad : ");
					cant = teclado.nextInt();
					if (cant > 0 && cant <= prDos.getCantidadDiponible()) {
						//prDos.setDigCant(cant);
						ca = prDos.getCantidadDiponible() - cant;
						//cdc.getProductos().add(inv.get(idpr));
						prDos.setCantidadDiponible(ca);
						//System.out.print("\nProducto... " + prDos.getNombre() + ", agregado al carrito con éxito\n");
						break;
					} else {
						System.out.print("\nCantidad en 0 ó Excede la cantidad\n");
						break;
					}
				case 3:
					System.out.print("Digite la cantidad : ");
					cant = teclado.nextInt();
					if (cant > 0 && cant <= prTres.getCantidadDiponible()) {
						//prTres.setDigCant(cant);
						ca = prTres.getCantidadDiponible() - cant;
						//cdc.getProductos().add(inv.get(idpr));
						prTres.setCantidadDiponible(ca);
						//System.out.print("\nProducto... " + prTres.getNombre() + ", agregado al carrito con éxito\n");
						break;
					} else {
						System.out.print("\nCantidad en 0 ó Excede la cantidad\n");
						break;
					}
				case 4:
					System.out.print("Digite la cantidad : ");
					cant = teclado.nextInt();
					if (cant > 0 && cant <= prCuatro.getCantidadDiponible()) {
						//prCuatro.setDigCant(cant);
						ca = prCuatro.getCantidadDiponible() - cant;
						//cdc.getProductos().add(inv.get(idpr));
						prCuatro.setCantidadDiponible(ca);
						//System.out.print("\nProducto... " + prCuatro.getNombre() + ", agregado al carrito con éxito\n");
						break;
					} else {
						System.out.print("\nCantidad en 0 ó Excede la cantidad\n");
						break;
					}
				case 5:
					System.out.print("Digite la cantidad : ");
					cant = teclado.nextInt();
					if (cant > 0 && cant <= prCinco.getCantidadDiponible()) {
						//prCinco.setDigCant(cant);
						ca = prCinco.getCantidadDiponible() - cant;
						//cdc.getProductos().add(inv.get(idpr));
						prCinco.setCantidadDiponible(ca);
						//System.out.print("\nProducto... " + prCinco.getNombre() + ", agregado al carrito con éxito\n");
						break;
					} else {
						System.out.print("\nCantidad en 0 ó Excede la cantidad\n");
						break;
					}
				case 6:
					System.out.print("Digite la cantidad : ");
					cant = teclado.nextInt();
					if (cant > 0 && cant <= prSeis.getCantidadDiponible()) {
						//prSeis.setDigCant(cant);
						ca = prSeis.getCantidadDiponible() - cant;
						//cdc.getProductos().add(inv.get(idpr));
						prSeis.setCantidadDiponible(ca);
						//System.out.print("\nProducto... " + prSeis.getNombre() + ", agregado al carrito con éxito\n");
						break;
					} else {
						System.out.print("\nCantidad en 0 ó Excede la cantidad\n");
						break;
					}
				case 7:
					System.out.print("Digite la cantidad : ");
					cant = teclado.nextInt();
					if (cant > 0 && cant <= prSiete.getCantidadDiponible()) {
						//prSiete.setDigCant(cant);
						ca = prSiete.getCantidadDiponible() - cant;
						//cdc.getProductos().add(inv.get(idpr));
						prSiete.setCantidadDiponible(ca);
						//System.out.print("\nProducto... " + prSiete.getNombre() + ", agregado al carrito con éxito\n");
						break;
					} else {
						System.out.print("\nCantidad en 0 ó Excede la cantidad\n");
						break;
					}
				case 8:
					System.out.print("Digite la cantidad : ");
					cant = teclado.nextInt();
					if (cant > 0 && cant <= prOcho.getCantidadDiponible()) {
						//prOcho.setDigCant(cant);
						ca = prOcho.getCantidadDiponible() - cant;
						//cdc.getProductos().add(inv.get(idpr));
						prOcho.setCantidadDiponible(ca);
						//System.out.print("\nProducto... " + prOcho.getNombre() + ", agregado al carrito con éxito\n");
						break;
					} else {
						System.out.print("\nCantidad en 0 ó Excede la cantidad\n");
						break;
					}
				case 9:
					System.out.print("Digite la cantidad : ");
					cant = teclado.nextInt();
					if (cant > 0 && cant <= prNueve.getCantidadDiponible()) {
						//prNueve.setDigCant(cant);
						ca = prNueve.getCantidadDiponible() - cant;
						//cdc.getProductos().add(inv.get(idpr));
						prNueve.setCantidadDiponible(ca);
						//System.out.print("\nProducto... " + prNueve.getNombre() + ", agregado al carrito con éxito\n");
						break;
					} else {
						System.out.print("\nCantidad en 0 ó Excede la cantidad\n");
						break;
					}
				case 10:
					System.out.print("Digite la cantidad : ");
					cant = teclado.nextInt();
					if (cant > 0 && cant <= prDiez.getCantidadDiponible()) {
						//prDiez.setDigCant(cant);
						ca = prDiez.getCantidadDiponible() - cant;
						///cdc.getProductos().add(inv.get(idpr));
						prDiez.setCantidadDiponible(ca);
						//System.out.print("\nProducto... " + prDiez.getNombre() + ", agregado al carrito con éxito\n");
						break;
					} else {
						System.out.print("\nCantidad en 0 ó Excede la cantidad\n");
						break;
					}
				}
					
				/*for (Producto mostProd : lisProd) {
					if (prDos.getIdProducto() == idpr) {
						cdc.setProductos(lisProd);
						System.out.println("\nProducto agregado al carrito con éxito\n");
						break;
					} else {
						
						break;
					}
				}*/
				
			} else if (reg.equals("n")) {
				break;
			}
		}
		
		// LLENA CARRITO CON PRODUCTOS
		//cdc.setProductos(lisProd);
	}
	
}