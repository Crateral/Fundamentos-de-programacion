package com.co.nttdata.ecommerce.entidades;

import java.io.Serializable;

public class TipoIdentificacion implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int idTipoIdentificacion;
	private String tipoIdentificacion;
	
	public TipoIdentificacion() {
		
	}

	public int getIdTipoIdentificacion() {
		return idTipoIdentificacion;
	}

	public void setIdTipoIdentificacion(int idTipoIdentificacion) {
		this.idTipoIdentificacion = idTipoIdentificacion;
	}

	public String getTipoIdentificacion() {
		return tipoIdentificacion;
	}

	public void setTipoIdentificacion(String tipoIdentificacion) {
		this.tipoIdentificacion = tipoIdentificacion;
	}

	@Override
	public String toString() {
		return "ID = " + idTipoIdentificacion + ", Tipo Identificacion = "
				+ tipoIdentificacion;
	}
}
