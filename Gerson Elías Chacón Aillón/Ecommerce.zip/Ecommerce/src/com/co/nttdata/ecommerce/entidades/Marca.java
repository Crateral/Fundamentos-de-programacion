package com.co.nttdata.ecommerce.entidades;

import java.io.Serializable;

public class Marca implements Serializable {
		
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int id_marca;
	private String marca;
	private String descripcion;
	
	public Marca() {
		
	}
	
	
	public int getId_marca() {
		return id_marca;
	}


	public void setId_marca(int id_marca) {
		this.id_marca = id_marca;
	}


	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	/*@Override
	public String toString() {
		return "ID          = " + id + "\nMarca       = " + marca + "\nDescripcion = " + descripcion;
	}	*/
	
	@Override
	public String toString() {
		return "ID = " + id_marca + ", Marca = " + marca + ", Descripcion = " + descripcion;
	}
}
