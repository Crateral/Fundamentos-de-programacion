package com.co.nttdata.ecommerce.daos;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.co.nttdata.ecommerce.entidades.Cliente;
import com.co.nttdata.ecommerce.utils.Conexion;

public class ClienteDAO {
	
	Conexion con = new Conexion();
	Scanner teclado = new Scanner(System.in);
	
	public List<Cliente> buscarCliente(){
		
		Connection baseDatos = con.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		List<Cliente> clientes = new ArrayList<Cliente>();
		
		try {
			
			st = baseDatos.prepareStatement("SELECT * FROM \"TBL_CLIENTES\" ORDER BY id_cliente ASC");
			rs = st.executeQuery();
			
			while (rs.next()) {
				
				Cliente cli = new Cliente();
				
				cli.setIdUsuario(rs.getInt("id_cliente"));
				cli.setNumeroIdentificacion(rs.getInt("num_identificacion"));
				cli.setIdTipoIdentificacion(rs.getInt("id_tipo_identificacion"));
				cli.setIdCiudad(rs.getInt("id_ciudad"));
				cli.setIdFormaPago(rs.getInt("id_forma_pago"));
				cli.setNombreUsuario(rs.getString("usuario"));
				cli.setContrasenia(rs.getString("contrasenia"));
				cli.setCorreo(rs.getString("correo"));
				cli.setTelefono(rs.getString("telefono"));
				cli.setDireccion(rs.getString("direccion"));
				cli.setEstado(rs.getBoolean("estado"));
				
				clientes.add(cli);
			}
			
		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				rs.close();
				st.close();
				con.desconectarBD(baseDatos);
			} catch (Exception e2) {
				System.err.println(e2.getMessage());
			}
		}
				
		
		return clientes;
	}
	
	public Cliente buscarCliente(int cliente) {
		Cliente cl = new Cliente();
		
		Connection baseDatos = con.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			st = baseDatos.prepareStatement("SELECT * FROM \"TBL_CLIENTES\" WHERE id_cliente = ? ");
			st.setInt(1, cliente);
			//st.setString(1, categoria);
			rs = st.executeQuery();
			
			while (rs.next()) {
				cl.setIdUsuario(rs.getInt("id_cliente"));
				cl.setNumeroIdentificacion(rs.getInt("num_identificacion"));
				cl.setIdTipoIdentificacion(rs.getInt("id_tipo_identificacion"));
				cl.setIdCiudad(rs.getInt("id_ciudad"));
				cl.setIdFormaPago(rs.getInt("id_forma_pago"));
				cl.setNombreUsuario(rs.getString("usuario"));
				cl.setContrasenia(rs.getString("contrasenia"));
				cl.setCorreo(rs.getString("correo"));
				cl.setTelefono(rs.getString("telefono"));
				cl.setDireccion(rs.getString("direccion"));
				cl.setEstado(rs.getBoolean("estado"));
			}
			
		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				rs.close();
				st.close();
				con.desconectarBD(baseDatos);
			} catch (Exception e2) {
				System.err.println(e2.getMessage());
			}
		}
		return cl;		
	}
	
	public void agregCliente(Cliente cli) {
		
		Connection baseDatos = con.conectarBD();
		PreparedStatement st = null;
		
		try {
			st = baseDatos.prepareStatement("INSERT INTO \"TBL_CLIENTES\" (num_identificacion, id_tipo_identificacion,"
					+ "id_ciudad, id_forma_pago, usuario, contrasenia, correo, telefono, direccion, estado) "
					+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			st.setInt(1, cli.getNumeroIdentificacion());
			st.setInt(2, cli.getIdTipoIdentificacion());
			st.setInt(3, cli.getIdCiudad());
			st.setInt(4, cli.getIdFormaPago());
			st.setString(5, cli.getNombreUsuario());
			st.setString(6, cli.getContrasenia());
			st.setString(7, cli.getCorreo());
			st.setString(8, cli.getTelefono());
			st.setString(9, cli.getDireccion());
			st.setBoolean(10, cli.isEstado());
			int val = st.executeUpdate();
			
			if (val > 0) 
				System.out.println("\nRegistro guardado con éxito...");
			else
				System.err.println("\nError al guardar el registro... !");
			
		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				st.close();
				con.desconectarBD(baseDatos);
			} catch (Exception e2) {
				System.err.println(e2.getMessage());
			}
		}		
	}
	
	public Cliente elimCliente(int cliente) {
		Cliente cl = new Cliente();
		
		Connection baseDatos = con.conectarBD();
		PreparedStatement st = null;
				
		System.out.print("\nDesea eliminar el Cliente (s/n) ? : ");
		String rg = teclado.next();
		if (rg.equals("s")) {
			try {
				st = baseDatos.prepareStatement("DELETE FROM \"TBL_CLIENTES\" WHERE id_cliente = ? ");
				st.setInt(1, cliente);
				int val = st.executeUpdate();
				
				if (val > 0) 
					System.out.println("\nRegistro eliminado con éxito...");
				else
					System.err.println("\nError al eliminar el registro... !");
				
			} catch (Exception e) {
				System.err.println(e.getMessage());
			} finally {
				try {
					st.close();
					con.desconectarBD(baseDatos);
				} catch (Exception e2) {
					System.err.println(e2.getMessage());
				}
			}
				
		} else if (rg.equals("n")) {
			System.out.println("\nSeleccionó no eliminar Cliente... !");
		}
		return cl;	
	}
	
	public void modCliente(int idCliente, int numIdent, int idTipIdent, int idCiudad, int idForPago, 
			String usuario, String contrasenia, String correo, String telefono, String direccion, 
			boolean estado) {
		
		Connection baseDatos = con.conectarBD();
		PreparedStatement st = null;
				
		try {
			st = baseDatos.prepareStatement("UPDATE \"TBL_CLIENTES\" SET num_identificacion = ?, id_tipo_identificacion = ?,"
					+ "id_ciudad = ?, id_forma_pago = ?, usuario = ?, contrasenia = ?, correo = ?, telefono = ?, "
					+ "direccion = ?, estado = ? WHERE id_cliente = ? ");
			st.setInt(1, numIdent);
			st.setInt(2, idTipIdent);
			st.setInt(3, idCiudad);
			st.setInt(4, idForPago);
			st.setString(5, usuario);
			st.setString(6, contrasenia);
			st.setString(7, correo);
			st.setString(8, telefono);
			st.setString(9, direccion);
			st.setBoolean(10, estado);
			st.setInt(11, idCliente);
			int val = st.executeUpdate();

			if (val > 0)
				System.out.println("\nRegistro modificado con éxito...");
			else
				System.err.println("\nError al modificar el registro... !");

		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				st.close();
				con.desconectarBD(baseDatos);
			} catch (Exception e2) {
				System.err.println(e2.getMessage());
			}
		}
	}		
}
