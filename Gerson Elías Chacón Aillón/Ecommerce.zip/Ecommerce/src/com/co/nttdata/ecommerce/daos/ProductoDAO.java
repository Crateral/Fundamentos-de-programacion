package com.co.nttdata.ecommerce.daos;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.co.nttdata.ecommerce.entidades.Producto;
import com.co.nttdata.ecommerce.utils.Conexion;

public class ProductoDAO {
	
	Conexion con = new Conexion();
	Scanner teclado = new Scanner(System.in);
	
	public List<Producto> buscarProducto(){
		
		Connection baseDatos = con.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		List<Producto> productos = new ArrayList<Producto>();
		
		try {
			
			st = baseDatos.prepareStatement("SELECT * FROM \"TBL_PRODUCTOS\" ORDER BY id_producto ASC");
			rs = st.executeQuery();
			
			while (rs.next()) {
				
				Producto pr = new Producto();
				
				pr.setIdProducto(rs.getInt("id_producto"));
				pr.setIdMarca(rs.getInt("id_marca"));
				pr.setIdCategoria(rs.getInt("id_categoria"));
				pr.setNomProducto(rs.getString("producto"));
				pr.setCantidadDiponible(rs.getInt("cant_disponible"));
				pr.setPrecio(rs.getDouble("precio"));
				pr.setDescuento(rs.getBoolean("descuento"));
				pr.setValorDescuento(rs.getDouble("vr_descuento"));
				pr.setDescripcion(rs.getString("descripcion"));
				pr.setImg(rs.getString("imagen"));
				
				productos.add(pr);
			}
			
		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				rs.close();
				st.close();
				con.desconectarBD(baseDatos);
			} catch (Exception e2) {
				System.err.println(e2.getMessage());
			}
		}
				
		
		return productos;
	}
	
	public Producto buscarProducto(int producto) {
		Producto pr = new Producto();
		
		Connection baseDatos = con.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			st = baseDatos.prepareStatement("SELECT * FROM \"TBL_PRODUCTOS\" WHERE id_producto = ? ");
			st.setInt(1, producto);
			//st.setString(1, categoria);
			rs = st.executeQuery();
			
			while (rs.next()) {
				pr.setIdProducto(rs.getInt("id_producto"));
				pr.setIdMarca(rs.getInt("id_marca"));
				pr.setIdCategoria(rs.getInt("id_categoria"));
				pr.setNomProducto(rs.getString("producto"));
				pr.setCantidadDiponible(rs.getInt("cant_disponible"));
				pr.setPrecio(rs.getDouble("precio"));
				pr.setDescuento(rs.getBoolean("descuento"));
				pr.setValorDescuento(rs.getDouble("vr_descuento"));
				pr.setDescripcion(rs.getString("descripcion"));
				pr.setImg(rs.getString("imagen"));
			}
			
		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				rs.close();
				st.close();
				con.desconectarBD(baseDatos);
			} catch (Exception e2) {
				System.err.println(e2.getMessage());
			}
		}
		return pr;		
	}
	
	public void agregProducto(Producto prod) {
		
		Connection baseDatos = con.conectarBD();
		PreparedStatement st = null;
		
		try {
			st = baseDatos.prepareStatement("INSERT INTO \"TBL_PRODUCTOS\" (id_marca, id_categoria, producto,"
					+ "cant_disponible, precio, descuento, vr_descuento, descripcion, imagen) "
					+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
			st.setInt(1, prod.getIdMarca());
			st.setInt(2, prod.getIdCategoria());
			st.setString(3, prod.getNomProducto());
			st.setInt(4, prod.getCantidadDiponible());
			st.setDouble(5, prod.getPrecio());
			st.setBoolean(6, prod.isDescuento());
			st.setDouble(7, prod.getValorDescuento());
			st.setString(8, prod.getDescripcion());
			st.setString(9, prod.getImg());
			int val = st.executeUpdate();
			
			if (val > 0) 
				System.out.println("\nRegistro guardado con éxito...");
			else
				System.err.println("\nError al guardar el registro... !");
			
		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				st.close();
				con.desconectarBD(baseDatos);
			} catch (Exception e2) {
				System.err.println(e2.getMessage());
			}
		}		
	}
	
	public Producto elimProducto(int producto) {
		Producto pr = new Producto();
		
		Connection baseDatos = con.conectarBD();
		PreparedStatement st = null;
				
		System.out.print("\nDesea eliminar el Producto (s/n) ? : ");
		String rg = teclado.next();
		if (rg.equals("s")) {
			try {
				st = baseDatos.prepareStatement("DELETE FROM \"TBL_PRODUCTOS\" WHERE id_producto = ? ");
				st.setInt(1, producto);
				int val = st.executeUpdate();
				
				if (val > 0) 
					System.out.println("\nRegistro eliminado con éxito...");
				else
					System.err.println("\nError al eliminar el registro... !");
				
			} catch (Exception e) {
				System.err.println(e.getMessage());
			} finally {
				try {
					st.close();
					con.desconectarBD(baseDatos);
				} catch (Exception e2) {
					System.err.println(e2.getMessage());
				}
			}
				
		} else if (rg.equals("n")) {
			System.out.println("\nSeleccionó no eliminar Producto... !");
		}
		return pr;	
	}
	
	public void modProducto(int idProd, int idMarca, int idCategoria, String producto, int cantDisp, 
			double precio, boolean dcto, double vrDcto, String descripcion, String img) {
		
		Connection baseDatos = con.conectarBD();
		PreparedStatement st = null;
				
		try {
			st = baseDatos.prepareStatement("UPDATE \"TBL_PRODUCTOS\" SET id_marca = ?, id_categoria = ?, producto = ?,"
					+ "cant_disponible = ?, precio = ?, descuento = ?, vr_descuento = ?, descripcion = ?, imagen = ?"
					+ "WHERE id_producto = ? ");
			st.setInt(1, idMarca);
			st.setInt(2, idCategoria);
			st.setString(3, producto);
			st.setInt(4, cantDisp);
			st.setDouble(5, precio);
			st.setBoolean(6, dcto);
			st.setDouble(7, vrDcto);
			st.setString(8, descripcion);
			st.setString(9, img);
			st.setInt(10, idProd);
			int val = st.executeUpdate();

			if (val > 0)
				System.out.println("\nRegistro modificado con éxito...");
			else
				System.err.println("\nError al modificar el registro... !");

		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				st.close();
				con.desconectarBD(baseDatos);
			} catch (Exception e2) {
				System.err.println(e2.getMessage());
			}
		}
	}		
}
