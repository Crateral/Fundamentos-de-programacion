package com.co.nttdata.ecommerce.entidades;

import java.util.Date;

public class CarritoDeCompras {

	private int idCarritoDeCompras;
	private int idProducto;
	private Date fecha;
	private double valorEnvio;
	private double valorDcto;
	private double valorIva;
	private double subTotSinIva;
	private double subTotConIva;
	private double numIdentificacion;
		
	public CarritoDeCompras() {
		
	}

	public int getIdCarritoDeCompras() {
		return idCarritoDeCompras;
	}

	public void setIdCarritoDeCompras(int idCarritoDeCompras) {
		this.idCarritoDeCompras = idCarritoDeCompras;
	}

	public int getIdProducto() {
		return idProducto;
	}

	public void setIdProducto(int idProducto) {
		this.idProducto = idProducto;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public double getValorEnvio() {
		return valorEnvio;
	}

	public void setValorEnvio(double valorEnvio) {
		this.valorEnvio = valorEnvio;
	}

	public double getValorDcto() {
		return valorDcto;
	}

	public void setValorDcto(double valorDcto) {
		this.valorDcto = valorDcto;
	}

	public double getValorIva() {
		return valorIva;
	}

	public void setValorIva(double valorIva) {
		this.valorIva = valorIva;
	}

	public double getSubTotSinIva() {
		return subTotSinIva;
	}

	public void setSubTotSinIva(double subTotSinIva) {
		this.subTotSinIva = subTotSinIva;
	}

	public double getSubTotConIva() {
		return subTotConIva;
	}

	public void setSubTotConIva(double subTotConIva) {
		this.subTotConIva = subTotConIva;
	}

	public double getNumIdentificacion() {
		return numIdentificacion;
	}

	public void setNumIdentificacion(double numIdentificacion) {
		this.numIdentificacion = numIdentificacion;
	}

	@Override
	public String toString() {
		return "ID = " + idCarritoDeCompras + ", ID Producto = " + idProducto + ", Fecha = "
				+ fecha + ", Valor Envio = " + valorEnvio + ", Valor Dcto = " + valorDcto + ", "
						+ "Valor Iva = " + valorIva + ", SubTotSinIva = " + subTotSinIva + ", "
								+ "SubTotConIva = " + subTotConIva + ", Num Identificacion = "
				+ numIdentificacion;
	}	
}
