package com.co.nttdata.ecommerce.utilitarios;

import java.io.File;

import java.io.FileWriter;
import java.util.Scanner;

import com.co.nttdata.ecommerce.entidades.CarritoDeCompras;
import com.co.nttdata.ecommerce.entidades.Cliente;
import com.co.nttdata.ecommerce.entidades.Empresa;
import com.co.nttdata.ecommerce.entidades.Factura;

public class GestionFacturaUtil {
	
	public void escribirArchivo(String nombreArchivoFac, Cliente cliente, CarritoDeCompras cdc) {
		Factura f = new Factura();
					
		//f.setEmpresa(Empresa.EMP_SANGER);
		f.setDescripcion("FACTURA DE VENTA");
		f.setIdFactura(100001);
		f.setCliente(cliente);
		f.setProductos(cdc);
		f.setValorIva(cdc.getValorIva());
		f.setValorDescFact(cdc.getValorDcto());
		f.setValorEnvio(cdc.getValorEnvio());
		//f.setValorFactura(cdc.getSubTotalConIva());
		//f.setValorTotalSinIva(cdc.getSubTotalSinIva());
		//f.setValorTotalConIva(cdc.getSubTotalConIva() + cdc.getValorEnvio() - cdc.getValorDcto());
				
		FileWriter archivo = null;
		
		try {
			archivo = new FileWriter("C:\\Users\\gchacona\\Downloads\\Ecommerce\\" + nombreArchivoFac, false);
			
			archivo.write("\n\n" + "         **** " + f.getEmpresa() + " ****\n" + "           "+ f.getDescripcion() + "\n\nID Factura : " 
					+ f.getIdFactura() + "\n\n               CLIENTE \n" + f.getCliente() + "\n               PRODUCTOS \n " + 
					//f.getProductos().getProductos() + "\n\nSubtotal      : " + f.getValorTotalSinIva() +"\nValor Iva     : " + " "+
					f.getValorIva() + "\n\nValor Factura : " + f.getValorFactura() + "\nValor Envío   : " + " " + f.getValorEnvio() + 
					"\nDescuento     : " + "  " + f.getValorDescFact() + "\n\nTotal a Pagar : " + f.getValorTotalConIva());
			
			System.out.println("\nLa factura se generó correctamente...\n");
			archivo.close();
			
		} catch (Exception e) {
			System.out.println("Error al escribir el archivo : " + e.getMessage() );
		}
	}
	
	public void leerArchivo() {
		File archivo = new File("C:\\Users\\gchacona\\Downloads\\Ecommerce\\Factura.txt");
		Scanner s = null;
		
		try {
			s = new Scanner(archivo);
			while (s.hasNextLine()) {
				String linea = s.nextLine();
				System.out.println(linea);
			}
		} catch (Exception e) {
			System.out.println("Error al leer el archivo : " + e.getMessage());
		} finally {
			try {
				if (s != null) {
					s.close();
				}
			} catch (Exception e) {
				System.out.println("Error al cerrar la lectura del archivo : " + e.getMessage());
			}
		}
	}
}
