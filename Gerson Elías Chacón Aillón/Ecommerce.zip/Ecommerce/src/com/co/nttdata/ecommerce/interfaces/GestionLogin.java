package com.co.nttdata.ecommerce.interfaces;

import com.co.nttdata.ecommerce.entidades.Ciudades;
import com.co.nttdata.ecommerce.entidades.FormaPago;
import com.co.nttdata.ecommerce.entidades.TipoIdentificacion;
import com.co.nttdata.ecommerce.entidades.Usuario;

public interface GestionLogin {
	
	public Usuario registarUsuario(int id, String nomb, String contra, TipoIdentificacion tipIdent, String numIdent, String correo,
			boolean estado, String direccion, String telefono, Ciudades ciudad, FormaPago forPago);
	
	
	public boolean login(String user, String contra);
	
	public boolean logout(String cerSes);
	
	public String recuperContrasenia(String user);
		
}
