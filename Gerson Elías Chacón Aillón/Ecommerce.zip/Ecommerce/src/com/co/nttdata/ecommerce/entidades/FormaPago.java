package com.co.nttdata.ecommerce.entidades;

import java.io.Serializable;

public class FormaPago implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int idFormaPago;
	private String FormaPago;
	
	public FormaPago() {
		
	}

	public int getIdFormaPago() {
		return idFormaPago;
	}

	public void setIdFormaPago(int idFormaPago) {
		this.idFormaPago = idFormaPago;
	}

	public String getFormaPago() {
		return FormaPago;
	}

	public void setFormaPago(String formaPago) {
		FormaPago = formaPago;
	}

	@Override
	public String toString() {
		return "ID = " + idFormaPago + ", FormaPago = " + FormaPago;
	}		
}
