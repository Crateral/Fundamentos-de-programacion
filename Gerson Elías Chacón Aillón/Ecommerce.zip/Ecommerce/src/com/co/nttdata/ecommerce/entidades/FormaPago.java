package com.co.nttdata.ecommerce.entidades;

public enum FormaPago {
	
	CONTADO,
	CREDITO,
	TARJETA_DEBITO,
	TARJETA_CREDITO;
	
}
