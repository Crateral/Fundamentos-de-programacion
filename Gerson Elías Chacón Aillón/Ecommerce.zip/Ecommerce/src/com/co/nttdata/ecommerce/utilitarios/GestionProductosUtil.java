package com.co.nttdata.ecommerce.utilitarios;

import java.io.File;


import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import com.co.nttdata.ecommerce.entidades.CarritoDeCompras;
import com.co.nttdata.ecommerce.entidades.Producto;
//import com.co.nttdata.ecommerce.logica.GestionProductoImpl;

public class GestionProductosUtil {
	
	Scanner teclado = new Scanner(System.in);
	Producto prod = new Producto();
	CarritoDeCompras cdc = new CarritoDeCompras();
	List<Producto> lisInv = new ArrayList<>();
				
	public void escribirArchivo(String nombreArchivoProd, Producto prUno, Producto prDos, Producto prTres, 
			Producto prCuatro, Producto prCinco, Producto prSeis, Producto prSiete,
			Producto prOcho, Producto prNueve, Producto prDiez) {
		
		List<Producto> lisProdAct = new ArrayList<>();
		
		lisProdAct.add(prUno);
		lisProdAct.add(prDos);
		lisProdAct.add(prTres);
		lisProdAct.add(prCuatro);
		lisProdAct.add(prCinco);
		lisProdAct.add(prSeis);
		lisProdAct.add(prSiete);
		lisProdAct.add(prOcho);
		lisProdAct.add(prNueve);
		lisProdAct.add(prDiez);
				
		FileWriter archivo = null;
		
		try {
			archivo = new FileWriter("C:\\Users\\gchacona\\Downloads\\Ecommerce\\" + nombreArchivoProd, false);
			
			/*for (Producto prodAct : lisProdAct) {
				archivo.write(prodAct.getIdProducto() + ", " + prodAct.getNombre() + ", " + prodAct.getCantidadDiponible() + ", "
						+ prodAct.getPrecio() + ", " + prodAct.isDescuento() + ", " + prodAct.getValorDescuento() + ", "
						+ prodAct.getIva() + ", " + prodAct.getDescripcion() + ", " + prodAct.getImg() + ", " + prodAct.getMarca() + ", "
						+ prodAct.getCategoria() + "\n");
			}*/
			
			System.out.println("\nEl archivo se generó correctamente\n");
			archivo.close();
			
		} catch (Exception e) {
			System.out.println("Error al escribir el archivo : " + e.getMessage() );
		}
	}
	
	
	public List<String> leerArchivo(String nombreArchivoProd) {
		
		File archivo = new File("C:\\Users\\gchacona\\Downloads\\Ecommerce\\" + nombreArchivoProd);
		Scanner s = null;
		
		List<String> lisProd = new ArrayList<>();
					
		try {
			s = new Scanner(archivo);
			while (s.hasNextLine()) {
				String linea = s.nextLine();
				System.out.println(linea);
				lisProd.add(linea);
			}
		} catch (Exception e) {
			System.out.println("Error al leer el archivo : " + e.getMessage());
		} finally {
			try {
				if (s != null) {
					s.close();
				}
			} catch (Exception e) {
				System.out.println("Error al cerrar la lectura del archivo : " + e.getMessage());
			}
		}
		return lisProd;
	}
	
	public List<Producto> separaProd(List<String> dat) {
		
		//GestionProductoImpl gdpi = new GestionProductoImpl();
				
		for (String mostProd : dat) {
			String inv[] = mostProd.split(",");

			prod.setIdProducto(Integer.parseInt(inv[0]));
			//prod.setNombre(inv[1]);
			prod.setCantidadDiponible(Integer.parseInt(inv[2]));
			prod.setPrecio(Double.parseDouble(inv[3]));
			prod.setDescuento(Boolean.valueOf(inv[4]));
			prod.setValorDescuento(Double.parseDouble(inv[5]));
			//prod.setIva(Double.parseDouble(inv[6]));
			prod.setDescripcion(inv[7]);
			prod.setImg(inv[8]);
			//prod.setMarca(gdpi.valMarca(inv[9]));
			//prod.setCategoria(gdpi.valCategoria(inv[10]));
			
			lisInv.add(prod);
			
			/*System.out.println(prod.getIdProducto() + " " + prod.getNombre() + " " + prod.getCantidadDiponible() + " "
					+ prod.getPrecio() + " " + prod.isDescuento() + " " + prod.getValorDescuento() + " " + prod.getIva() + " "
					+ prod.getDescripcion() + " " + prod.getImg() + " " + prod.getMarca() + " " + prod.getCategoria());*/
		}
		return lisInv;
	}
	
	public void agregarCarrito() {
		
		HashMap<Integer, Producto> inv = new HashMap<>();
		int w = 1;
		while (w == 1) {
			System.out.print("\nDesea agregar productos (s/n) ? : ");
			String reg = teclado.next();
			if (reg.equals("s")) {

				System.out.print("\nSeleccione Producto : ");
				//int idpr = teclado.nextInt();
				
				inv.put(prod.getIdProducto(), prod);
				
				           //cdc.getProductos().add(inv.get(idpr));
				//cdc.setProductos(lisInv);
				//System.out.print("\nProducto... " + prod.getNombre() + ", agregado al carrito con éxito\n");
								
				
			} else if (reg.equals("n")) {
				break;
			}
		}
	}
}
