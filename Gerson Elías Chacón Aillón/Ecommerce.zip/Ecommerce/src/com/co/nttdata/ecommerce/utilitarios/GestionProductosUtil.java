package com.co.nttdata.ecommerce.utilitarios;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.co.nttdata.ecommerce.entidades.Producto;
import com.co.nttdata.ecommerce.logica.GestionProductoImpl;

public class GestionProductosUtil {
	
	Scanner teclado = new Scanner(System.in);
				
	public void escribirArchivo(String nombreArchivoProd, Producto prUno, Producto prDos, Producto prTres, 
			Producto prCuatro, Producto prCinco, Producto prSeis, Producto prSiete,
			Producto prOcho, Producto prNueve, Producto prDiez) {
		
		List<Producto> lisProdAct = new ArrayList<>();
		
		lisProdAct.add(prUno);
		lisProdAct.add(prDos);
		lisProdAct.add(prTres);
		lisProdAct.add(prCuatro);
		lisProdAct.add(prCinco);
		lisProdAct.add(prSeis);
		lisProdAct.add(prSiete);
		lisProdAct.add(prOcho);
		lisProdAct.add(prNueve);
		lisProdAct.add(prDiez);
				
		FileWriter archivo = null;
		
		try {
			archivo = new FileWriter("C:\\Users\\gchacona\\Downloads\\Ecommerce\\" + nombreArchivoProd, false);
			
			for (Producto prodAct : lisProdAct) {
				archivo.write(prodAct.getIdProducto() + ", " + prodAct.getNombre() + ", " + prodAct.getCantidadDiponible() + ", "
						+ prodAct.getPrecio() + ", " + prodAct.isDescuento() + ", " + prodAct.getValorDescuento() + ", "
						+ prodAct.getIva() + ", " + prodAct.getDescripcion() + ", " + prodAct.getImg() + ", " + prodAct.getMarca() + ", "
						+ prodAct.getCategoria() + "\n");
			}
			
			
			
			System.out.println("\nEl archivo se generó correctamente\n");
			archivo.close();
			
		} catch (Exception e) {
			System.out.println("Error al escribir el archivo : " + e.getMessage() );
		}
	}
	
	
	public List<String> leerArchivo(String nombreArchivoProd) {
		
		File archivo = new File("C:\\Users\\gchacona\\Downloads\\Ecommerce\\" + nombreArchivoProd);
		Scanner s = null;
		
		List<String> lisProd = new ArrayList<>();
					
		try {
			s = new Scanner(archivo);
			while (s.hasNextLine()) {
				String linea = s.nextLine();
				System.out.println(linea);
				lisProd.add(linea);
			}
		} catch (Exception e) {
			System.out.println("Error al leer el archivo : " + e.getMessage());
		} finally {
			try {
				if (s != null) {
					s.close();
				}
			} catch (Exception e) {
				System.out.println("Error al cerrar la lectura del archivo : " + e.getMessage());
			}
		}
		return lisProd;
	}
	
	public List<Producto> separaProd(List<String> dat) {
		
		GestionProductoImpl gdpi = new GestionProductoImpl();
		List<Producto> invProd = new ArrayList<>();
		Producto prod = new Producto();
		
		for (String mostProd : dat) {
			String inv[] = mostProd.split(",");

			prod.setIdProducto(Integer.parseInt(inv[0]));
			prod.setNombre(inv[1]);
			prod.setCantidadDiponible(Integer.parseInt(inv[2]));
			prod.setPrecio(Double.parseDouble(inv[3]));
			prod.setDescuento(Boolean.valueOf(inv[4]));
			prod.setValorDescuento(Double.parseDouble(inv[5]));
			prod.setIva(Double.parseDouble(inv[6]));
			prod.setDescripcion(inv[7]);
			prod.setImg(inv[8]);
			prod.setMarca(gdpi.valMarca(inv[9]));
			prod.setCategoria(gdpi.valCategoria(inv[10]));
			
			invProd.add(prod);
			
			System.out.println(prod.getIdProducto() + " " + prod.getNombre() + " " + prod.getCantidadDiponible() + " "
					+ prod.getPrecio() + " " + prod.isDescuento() + " " + prod.getValorDescuento() + prod.getIva() + " "
					+ prod.getDescripcion() + " " + prod.getImg() + " " + prod.getMarca() + " " + prod.getCategoria());
		}
		return invProd;
	}
	
	public void agregarCarrito() {
		
		//HashMap<Integer, List<String>> inv = new HashMap<>();
		int w = 1;
		while (w == 1) {
			System.out.print("\nDesea agregar productos (s/n) ? : ");
			String reg = teclado.next();
			if (reg.equals("s")) {

				System.out.print("\nSeleccione Producto : ");
				//int idpr = teclado.nextInt();
				
				/*List<Producto> lisProd = new ArrayList<>();
				Producto prUno = new Producto(1, "nevera", 4, 450000, false, 0, 0, "nevera frost", "imgnev", Marca.LG,
						Categoria.ELECTRODOMESTICOS);
				Producto prDos = new Producto(2, "tv", 3, 300000, true, 50000, 19, "tv 32", "imgtv", Marca.SAMSUNG,
						Categoria.ELECTRODOMESTICOS);
				Producto prTres = new Producto(3, "monitor", 1, 450000, true, 30000, 19, "monitor 22", "imgmon", Marca.SAMSUNG,
						Categoria.EQUIPO_COMPUTO);
				Producto prCuatro = new Producto(4, "servidor", 1, 1500000, true, 15000, 19, "licuadora 100", "imglic",
						Marca.LENOVO, Categoria.EQUIPO_COMPUTO);
				Producto prCinco = new Producto(5, "lavadora", 1, 600000, false, 0, 19, "lavadora l12", "imglav", Marca.LG,
						Categoria.ELECTRODOMESTICOS);
				Producto prSeis = new Producto(6, "ventilador", 3, 300000, true, 10000, 5, "ventilador", "imgven",
						Marca.SAMSUNG, Categoria.ELECTRODOMESTICOS);
				Producto prSiete = new Producto(7, "aspiradora", 3, 200000, true, 50000, 19, "aspiradora", "imgasp", Marca.LG,
						Categoria.ELECTRODOMESTICOS);
				Producto prOcho = new Producto(8, "horno", 0, 700000, false, 0, 5, "horno p25", "imghor", Marca.SAMSUNG,
						Categoria.ELECTRODOMESTICOS);
				Producto prNueve = new Producto(9, "estufa", 4, 480000, true, 80000, 19, "estufa t147", "imgest", Marca.LG,
						Categoria.ELECTRODOMESTICOS);
				Producto prDiez = new Producto(10, "plancha", 6, 50000, false, 0, 19, "plancha r9", "imgplan", Marca.LENOVO,
						Categoria.ELECTRODOMESTICOS);
				
				lisProd.add(prUno);
				lisProd.add(prDos);
				lisProd.add(prTres);
				lisProd.add(prCuatro);
				lisProd.add(prCinco);
				lisProd.add(prSeis);
				lisProd.add(prSiete);
				lisProd.add(prOcho);
				lisProd.add(prNueve);
				lisProd.add(prDiez);*/
								

			} else if (reg.equals("n")) {
				break;
			}
		}
	}
}
