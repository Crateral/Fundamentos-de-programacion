package com.co.nttdata.ecommerce.entidades;

import java.io.Serializable;

public class Ciudades implements Serializable {
		
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int id_ciudad;
	private String ciudad;
	private boolean principal;
	
	public Ciudades() {
		
	}
	
	public int getId_ciudad() {
		return id_ciudad;
	}
	public void setId_ciudad(int id_ciudad) {
		this.id_ciudad = id_ciudad;
	}
	public String getCiudad() {
		return ciudad;
	}
	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}
	public boolean isPrincipal() {
		return principal;
	}
	public void setPrincipal(boolean principal) {
		this.principal = principal;
	}
	
	@Override
	public String toString() {
		return "ID = " + id_ciudad + ", Ciudad = " + ciudad + ", Principal=" + principal;
	}
	
	
}
