package com.co.nttdata.ecommerce.entidades;

public enum Ciudades {
	
	BOGOTA (true),
	MEDELLIN (true),
	OTRAS(false);
	
	private boolean principal;
	
	private Ciudades (boolean principal) {
		this.principal = principal;
	}
	
	public boolean isPrincipal() {
		return principal;
	}
	
	public void setPrincipal(boolean principal) {
		this.principal = principal;
	}

}
