package com.co.nttdata.ecommerce.daos;

import java.sql.Connection;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.co.nttdata.ecommerce.entidades.Marca;
import com.co.nttdata.ecommerce.utils.Conexion;

public class MarcaDAO {
	
	Conexion con = new Conexion();
	Scanner teclado = new Scanner(System.in);
	
	public List<Marca> buscarMarca(){
		
		Connection baseDatos = con.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		List<Marca> marcas = new ArrayList<Marca>();
		
		try {
			
			st = baseDatos.prepareStatement("SELECT * FROM \"TBL_MARCAS\" ORDER BY id_marca ASC");
			rs = st.executeQuery();
			
			while (rs.next()) {
				
				Marca marca = new Marca();
				
				marca.setId_marca(rs.getInt("id_marca"));
				marca.setMarca(rs.getString("marca"));
				marca.setDescripcion(rs.getString("descripcion"));
				
				marcas.add(marca);
			}
			
		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				rs.close();
				st.close();
				con.desconectarBD(baseDatos);
			} catch (Exception e2) {
				System.err.println(e2.getMessage());
			}
		}
				
		
		return marcas;
	}
	
	public Marca buscarMarca(int marca) {
		Marca m = new Marca();
		
		Connection baseDatos = con.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			st = baseDatos.prepareStatement("SELECT * FROM \"TBL_MARCAS\" WHERE id_marca = ? ");
			st.setInt(1, marca);
			//st.setString(1, marca);
			rs = st.executeQuery();
			
			while (rs.next()) {
				m.setId_marca(rs.getInt("id_marca"));
				m.setMarca(rs.getString("marca"));
				m.setDescripcion(rs.getString("descripcion"));
			}
			
		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				rs.close();
				st.close();
				con.desconectarBD(baseDatos);
			} catch (Exception e2) {
				System.err.println(e2.getMessage());
			}
		}
		return m;		
	}
	
	public void agregMarca(Marca m) {
		
		Connection baseDatos = con.conectarBD();
		PreparedStatement st = null;
		
		try {
			st = baseDatos.prepareStatement("INSERT INTO \"TBL_MARCAS\" (marca, descripcion) VALUES (?, ?)");
			st.setString(1, m.getMarca());
			st.setString(2, m.getDescripcion());
			int val = st.executeUpdate();
			
			if (val > 0) 
				System.out.println("\nRegistro guardado con éxito...");
			else
				System.err.println("\nError al guardar el registro... !");
			
		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				st.close();
				con.desconectarBD(baseDatos);
			} catch (Exception e2) {
				System.err.println(e2.getMessage());
			}
		}		
	}
	
	public Marca elimMarca(int marca) {
		Marca m = new Marca();
		
		Connection baseDatos = con.conectarBD();
		PreparedStatement st = null;
				
		System.out.print("\nDesea eliminar la Marca (s/n) ? : ");
		String rg = teclado.next();
		if (rg.equals("s")) {
			try {
				st = baseDatos.prepareStatement("DELETE FROM \"TBL_MARCAS\" WHERE id_marca = ? ");
				st.setInt(1, marca);
				int val = st.executeUpdate();
				
				if (val > 0) 
					System.out.println("\nRegistro eliminado con éxito...");
				else
					System.err.println("\nError al eliminar el registro... !");
				
			} catch (Exception e) {
				System.err.println(e.getMessage());
			} finally {
				try {
					st.close();
					con.desconectarBD(baseDatos);
				} catch (Exception e2) {
					System.err.println(e2.getMessage());
				}
			}
				
		} else if (rg.equals("n")) {
			System.out.println("\nSeleccionó no eliminar Marca... !");
		}
		return m;	
	}
	
	public void modMarca(int idmarca, String marca, String descripcion) {
			
		Connection baseDatos = con.conectarBD();
		PreparedStatement st = null;
				
		try {
			st = baseDatos.prepareStatement("UPDATE \"TBL_MARCAS\" SET marca = ?, descripcion = ? WHERE id_marca = ?");
			st.setInt(3, idmarca);
			st.setString(1, marca);
			st.setString(2, descripcion);
			int val = st.executeUpdate();

			if (val > 0)
				System.out.println("\nRegistro modificado con éxito...");
			else
				System.err.println("\nError al modificar el registro... !");

		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				st.close();
				con.desconectarBD(baseDatos);
			} catch (Exception e2) {
				System.err.println(e2.getMessage());
			}
		}
	}
	
}
