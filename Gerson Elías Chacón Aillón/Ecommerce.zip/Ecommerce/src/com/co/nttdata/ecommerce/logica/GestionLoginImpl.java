package com.co.nttdata.ecommerce.logica;

import java.util.Scanner;

import com.co.nttdata.ecommerce.entidades.Ciudades;
import com.co.nttdata.ecommerce.entidades.Cliente;
import com.co.nttdata.ecommerce.entidades.FormaPago;
import com.co.nttdata.ecommerce.entidades.Usuario;
import com.co.nttdata.ecommerce.interfaces.GestionLogin;

public class GestionLoginImpl implements GestionLogin {
	
	Scanner teclado = new Scanner(System.in);
	Cliente cli = new Cliente();
	int w = 1;
	
	private int iniSess;
	
	public GestionLoginImpl() {
		super();
	}
	
	public GestionLoginImpl(int iniSess) {
		super();
		this.iniSess = 0;
	}

	public int getIniSess() {
		return iniSess;
	}

	public void setIniSess(int iniSess) {
		this.iniSess = iniSess;
	}

	@Override
	public Usuario registarUsuario(int id, String nomb, String contra, String tipIdent, String numIdent, String correo,
			boolean estado, String direccion, String telefono, Ciudades ciudad, FormaPago forPago) {

		cli.setId(id);
		cli.setNombreUsuario(nomb);
		cli.setContrasenia(contra);
		cli.setTipoIdentificacion(tipIdent);
		cli.setNumeroIdentificacion(numIdent);
		cli.setCorreo(correo);
		cli.setEstado(estado);
		cli.setDireccion(direccion);
		cli.setTelefono(telefono);
		cli.setCiudad(ciudad);
		cli.setMetodoDePago(String.valueOf(forPago));
		System.out.print("\nUsuario registrado con éxito\n");
		return cli;
	}
	
	@Override
	public boolean login(String user, String contra) {
		if (cli.getNombreUsuario().equals(user) && cli.getContrasenia().equals(contra)) {
			System.out.print("\nSesión iniciada con éxito\n");
			setIniSess(1);
			return true;
		} else if (!cli.getNombreUsuario().equals(user) && !cli.getContrasenia().equals(contra)) {
			System.out.print("\nUsuario y Contraseña incorrectos\n");
		} else if (!cli.getNombreUsuario().equals(user)) {
			System.out.print("\nUsuario incorrecto\n");
		} else if (!cli.getContrasenia().equals(contra)) {
			System.out.print("\nContraseña incorrecta\n");
		}
		return false;
	}
	
	@Override
	public boolean logout(String cerSes) {
		if (cerSes.equals("s")) {
			System.out.println("\nSesión cerrada con éxito");
			setIniSess(0);
			return true;
		} else if (cerSes.equals("n")) {
			System.out.println("\nSeleccionó no cerrar sesión");
		}
		return false;
	}
	

	@Override
	public String recuperContrasenia(String user) {
		while (w == 1) {
			if (getIniSess() == 1) {
				if (cli.getNombreUsuario().equals(user)) {
					System.out.print("\nDesea recuperar la contraseña (s/n) ? : ");
					String opc = teclado.next();
					if (opc.equals("s")) {
						System.out.print("Digite la nueva contraseña : ");
						String nvcont = teclado.next();
						cli.setContrasenia(nvcont);
						System.out.println("\nContraseña cambiada con éxito\n");
						break;
					} else if (opc.equals("n")) {
						System.out.println("\nSeleccionó no recuperar la contraseña\n");
						break;
					}
				} else {
					System.out.println("\nUsuario no existe\n");
					break;
				}
			} else {
				System.out.println("\nInicie sesión\n");
				break;
			}
		}
		return user;
	}
	
}
