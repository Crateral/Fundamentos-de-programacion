package com.co.nttdata.ecommerce.entidades;

public enum Empresa {
	
	EMP_SANGER (890501, "Resolucion DIAN", "av 6", 60758345);
	
	private int nit;
	private String resolucionDian;
	private String direccion;
	private int telefono;
	
	private Empresa(int nit, String resolucionDian, String direccion, int telefono) {
		this.nit = nit;
		this.resolucionDian = resolucionDian;
		this.direccion = direccion;
		this.telefono = telefono;
	}

	public int getNit() {
		return nit;
	}

	public void setNit(int nit) {
		this.nit = nit;
	}

	public String getResolucionDian() {
		return resolucionDian;
	}

	public void setResolucionDian(String resolucionDian) {
		this.resolucionDian = resolucionDian;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public int getTelefono() {
		return telefono;
	}

	public void setTelefono(int telefono) {
		this.telefono = telefono;
	}

}
