package com.co.nttdata.ecommerce.vistas;

import java.util.ArrayList;
import java.util.List;

import com.co.nttdata.ecommerce.logica.GestionCarritoDeCompras;
import com.co.nttdata.ecommerce.logica.GestionFactura;
import com.co.nttdata.ecommerce.modelos.*;

public class Main {

	public static void main(String[] args) {
		
		//Instanciar objetos logica de negocio
		GestionCarritoDeCompras gestionCarrito = new GestionCarritoDeCompras();
		GestionFactura gestionFactura = new GestionFactura();
		
		//Instanciar objetos VO - Beans
		Factura factura = new Factura();
		CarritoDeCompras carrito = new CarritoDeCompras();
		Cliente cliente = new Cliente();
		
		//Añadir ciudad al cliente
		cliente.setCiudad("Apartado");
		
		//Crear 10 productos
		Producto televisor = new Producto();
		Producto nevera = new Producto();
		Producto lavadora = new Producto();
		Producto silla = new Producto();
		Producto arrocera = new Producto();
		Producto freidora = new Producto();
		Producto celular = new Producto();
		Producto computador = new Producto();
		Producto impresora = new Producto();
		Producto escritorio = new Producto();
		
		//Instanciar lista de productos
		List<Producto> listaProductos = new ArrayList<>();
		
		//Añadir valores a los productos
		arrocera.setIdProducto(5);
		arrocera.setNombre("Arrocera");
		arrocera.setCantidadDiponible(250);
		arrocera.setPrecio(219000);
		arrocera.setDescuento(Categoria.ELECTRODOMESTICOS.isDescuento());
		arrocera.setValorDescuento(arrocera.getPrecio()*Categoria.ELECTRODOMESTICOS.getValorDescuento());
		arrocera.setIva(arrocera.getPrecio()*0.19);
		arrocera.setDescripcion("Multiusos 10 tazas");
		arrocera.setImg("img005.jpg");
		arrocera.setMarca(Marca.OSTER);
		arrocera.setCategoria(Categoria.ELECTRODOMESTICOS);
		
		freidora.setIdProducto(6);
		freidora.setNombre("Freidora");
		freidora.setCantidadDiponible(300);
		freidora.setPrecio(259900);
		freidora.setDescuento(Categoria.ELECTRODOMESTICOS.isDescuento());
		freidora.setValorDescuento(freidora.getPrecio()*Categoria.ELECTRODOMESTICOS.getValorDescuento());
		freidora.setIva(freidora.getPrecio()*0.19);
		freidora.setDescripcion("Freidora de Aire 4 litros");
		freidora.setImg("img006.jpg");
		freidora.setMarca(Marca.OSTER);
		freidora.setCategoria(Categoria.ELECTRODOMESTICOS);
		
		celular.setIdProducto(7);
		celular.setNombre("Celular Android");
		celular.setCantidadDiponible(150);
		celular.setPrecio(919900);
		celular.setDescuento(Categoria.CELULARES.isDescuento());
		celular.setValorDescuento(celular.getPrecio()*Categoria.CELULARES.getValorDescuento());
		celular.setIva(celular.getPrecio()*0.0);
		celular.setDescripcion("Redmi Note 11S 6gb 128 gb");
		celular.setImg("img007.jpg");
		celular.setMarca(Marca.XIAOMI);
		celular.setCategoria(Categoria.CELULARES);

		computador.setIdProducto(8);
		computador.setNombre("Computador portátil");
		computador.setCantidadDiponible(50);
		computador.setPrecio(2199000);
		computador.setDescuento(Categoria.TECNOLOGIA.isDescuento());
		computador.setValorDescuento(computador.getPrecio()*Categoria.TECNOLOGIA.getValorDescuento());
		computador.setIva(computador.getPrecio()*0.19);
		computador.setDescripcion("Portátil Asus AMD Ryzen 5");
		computador.setImg("img008.jpg");
		computador.setMarca(Marca.ASUS);
		computador.setCategoria(Categoria.TECNOLOGIA);
		
		impresora.setIdProducto(9);
		impresora.setNombre("Impresora");
		impresora.setCantidadDiponible(90);
		impresora.setPrecio(799000);
		impresora.setDescuento(Categoria.TECNOLOGIA.isDescuento());
		impresora.setValorDescuento(impresora.getPrecio()*Categoria.TECNOLOGIA.getValorDescuento());
		impresora.setIva(impresora.getPrecio()*0.19);
		impresora.setDescripcion("HP Laserjet pro 107w");
		impresora.setImg("img009.jpg");
		impresora.setMarca( Marca.HP);
		impresora.setCategoria(Categoria.TECNOLOGIA);
		
		escritorio.setIdProducto(10);
		escritorio.setNombre("Escritorio");
		escritorio.setCantidadDiponible(40);
		escritorio.setPrecio(264490);
		escritorio.setDescuento(Categoria.HOGAR.isDescuento());
		escritorio.setValorDescuento(escritorio.getPrecio()*Categoria.TECNOLOGIA.getValorDescuento());
		escritorio.setIva(escritorio.getPrecio()*0.0);
		escritorio.setDescripcion("Escritorio Amaretto blanco");
		escritorio.setImg("img010.jpg");
		escritorio.setMarca(Marca.INVAL);
		escritorio.setCategoria(Categoria.HOGAR);
		
		//Añadir 6 al carrito de comprar
		listaProductos.add(arrocera);
		listaProductos.add(freidora);
		listaProductos.add(celular);
		listaProductos.add(computador);
		listaProductos.add(impresora);
		listaProductos.add(escritorio);
		
		//Añadir los productos al carro de compras
		carrito.setProductos(listaProductos);
		carrito.setValorEnvio(15000);
		carrito = gestionCarrito.calcularCostoEnvio(cliente, carrito);
			
		//Calcular el valor del subtotal del carro de compras
		carrito = gestionCarrito.calcularTotalSinIva(carrito);
		carrito = gestionCarrito.calcularTotalConIva(carrito);
		
		//Crear la factura de ese carrito de compras
		factura = gestionFactura.pagar(cliente, carrito);
		
		//Mostrar la factura
		gestionFactura.imprimirFactura(factura);

	}

}
