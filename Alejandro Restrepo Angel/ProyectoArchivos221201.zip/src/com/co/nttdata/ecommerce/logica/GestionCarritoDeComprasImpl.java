package com.co.nttdata.ecommerce.logica;

import java.util.List;

import com.co.nttdata.ecommerce.interfaces.IGestionCarritoDeCompras;
import com.co.nttdata.ecommerce.modelos.*;

public class GestionCarritoDeComprasImpl implements IGestionCarritoDeCompras{

	@Override
	public CarritoDeCompras añadirAlCarrito(CarritoDeCompras carrito, List<Producto> listaProductos) {
		carrito.setProductos(listaProductos);
		return carrito;
	}

	@Override
	public CarritoDeCompras calcularTotalSinIva(CarritoDeCompras carrito) {
		
		double subtotal = 0.0;

		for (int i = 0; i < carrito.getProductos().size(); i++) {
			subtotal += carrito.getProductos().get(i).getPrecio()
					-carrito.getProductos().get(i).getValorDescuento();
		}
		
		carrito.setSubTotalSinIva(subtotal);
		return carrito;
	}
	
	@Override
	public CarritoDeCompras calcularTotalConIva(CarritoDeCompras carrito) {

		double total = 0.0;

		for (int i = 0; i < carrito.getProductos().size(); i++) {
			total += (carrito.getProductos().get(i).getPrecio() + carrito.getProductos().get(i).getIva()
					-carrito.getProductos().get(i).getValorDescuento());
		}
		

		carrito.setSubTotalConIva(total);
		return carrito;
	}

	@Override
	public CarritoDeCompras calcularCostoEnvio(Cliente cliente, CarritoDeCompras carrito) {
		// Para el calculo del envio se debe tener en cuenta la ubicacion del cliente
		// Si se encuentra en ciudades principales se debe cobrar el 5%
		// Si se encuentra en ciudades no principales se debe cobrar el 10%

		String ciudad = cliente.getCiudad();

		if (ciudad.equalsIgnoreCase("Bogotá") || ciudad.equalsIgnoreCase("Medellin") || ciudad.equalsIgnoreCase("Cali")
				|| ciudad.equalsIgnoreCase("Barranquilla")) {
			carrito.setValorEnvio(carrito.getValorEnvio() * 1.05);
		} else {
			carrito.setValorEnvio(carrito.getValorEnvio() * 1.10);
		}
		return carrito;
	}

}
