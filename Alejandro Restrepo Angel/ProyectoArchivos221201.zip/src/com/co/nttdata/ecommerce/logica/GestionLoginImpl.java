package com.co.nttdata.ecommerce.logica;

import com.co.nttdata.ecommerce.interfaces.*;
import com.co.nttdata.ecommerce.modelos.*;

public class GestionLoginImpl implements IGestionLogin {

	private boolean token;
	private String usr = "usuario";
	private String pwd = "1234";
	
	//Registrar usuario
	public Usuario registrar(String nombreUsuario, String clave, String tipoIdentificacion, 
			String numeroIdentificacion, String correo, String direccion) {
		Cliente cliente = new Cliente();
		cliente.setNombreUsuario(nombreUsuario);
		cliente.setContrasenia(clave);
		cliente.setTipoIdentificacion(tipoIdentificacion);
		cliente.setNumeroIdentificacion(numeroIdentificacion);
		cliente.setCorreo(correo);
		cliente.setDireccion(direccion);
		return cliente;
	}
	
	//Login
	public boolean iniciarSesion(String nombreUsuario, String clave) {
		
		if(!nombreUsuario.equals(usr)) {
			return false;
		}
		if(!clave.equals(pwd)) {
			return false;
		}
		token = true;
		return true;
	}
	
	//Logout
	public boolean cerrarSesion() {
		if(token == true) {
			return false;
		}
		return token;
	}
	
	//Olvide la contraseña
	public Usuario cambiarClave(Usuario usuario, String clave){
		usuario.setContrasenia(clave);
		return usuario;
		
	}
	
	
}
