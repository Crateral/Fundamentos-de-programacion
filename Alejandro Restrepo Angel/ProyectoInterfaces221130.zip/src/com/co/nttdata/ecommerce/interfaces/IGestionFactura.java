package com.co.nttdata.ecommerce.interfaces;

import com.co.nttdata.ecommerce.modelos.*;

public interface IGestionFactura {
	
	public Factura pagar(Cliente cliente, CarritoDeCompras carrito);
	public void imprimirFactura(Factura factura);

}
