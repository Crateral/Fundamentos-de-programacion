package com.co.nttdata.ecommerce.interfaces;

import com.co.nttdata.ecommerce.modelos.*;

public interface IGestionLogin {

	public Usuario registrar(String nombreUsuario, String clave, String tipoIdentificacion, 
			String numeroIdentificacion, String correo, String direccion);
	public boolean iniciarSesion(String nombreUsuario, String clave);
	public boolean cerrarSesion();
	public Usuario cambiarClave(Usuario usuario, String clave);
	
}
