package com.co.nttdata.ecommerce.modelos;

public class Administrador extends Usuario {

	private String correo;
	private boolean estado;
	private String direccion;
	private String numeroIdentificacion;
	private String tipoIdentificacion;

	public Administrador() {
		super();
	}

	public Administrador(String correo, boolean estado,String direccion, String numeroIdentificacion, String tipoIdentificacion) {
		super();
		this.correo = correo;
		this.estado = estado;
		this.direccion = direccion;
		this.numeroIdentificacion = numeroIdentificacion;
		this.tipoIdentificacion = tipoIdentificacion;
	}

	public Administrador(int id, String nombreUsuario, String contrasenia, String correo, boolean estado,
			String direccion, String numeroIdentificacion, String tipoIdentificacion) {
		super(id, nombreUsuario, contrasenia);
		this.correo = correo;
		this.estado = estado;
		this.direccion = direccion;
		this.numeroIdentificacion = numeroIdentificacion;
		this.tipoIdentificacion = tipoIdentificacion;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public boolean isEstado() {
		return estado;
	}

	public void setEstado(boolean estado) {
		this.estado = estado;
	}
	
	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getNumeroIdentificacion() {
		return numeroIdentificacion;
	}

	public void setNumeroIdentificacion(String numeroIdentificacion) {
		this.numeroIdentificacion = numeroIdentificacion;
	}

	public String getTipoIdentificacion() {
		return tipoIdentificacion;
	}

	public void setTipoIdentificacion(String tipoIdentificacion) {
		this.tipoIdentificacion = tipoIdentificacion;
	}

	@Override
	public String toString() {
		return "Administrador [correo=" + correo + ", estado=" + estado + ", direccion=" + direccion +", numeroIdentificacion="
				+ numeroIdentificacion + ", tipoIdentificacion=" + tipoIdentificacion + "]";
	}

}
