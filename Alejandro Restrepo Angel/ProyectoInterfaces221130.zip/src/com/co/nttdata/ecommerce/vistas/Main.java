package com.co.nttdata.ecommerce.vistas;

import java.util.ArrayList;
import java.util.List;

import com.co.nttdata.ecommerce.interfaces.*;
import com.co.nttdata.ecommerce.logica.*;
import com.co.nttdata.ecommerce.modelos.*;

public class Main {

	public static void main(String[] args) {
		
		//Instanciar objetos logica de negocio
		IGestionLogin gestionLogin = new GestionLoginImpl();
		IGestionLogin gestionLoginAdm = new GestionLoginAdmImpl();
		
		//Crear usuarios
		Cliente cliente = (Cliente) gestionLogin.registrar("usuario", "1234", "CC", "1111222333", "user@mail.com",
				"Medellin");
		System.out.println(cliente.toString());
		Administrador administrador = (Administrador) gestionLoginAdm.registrar("administrador", "0000", "CC", "1000200300", 
				"admin@mail.com","");
		System.out.println(administrador.toString());
		
		//Iniciar sesión
		if(gestionLogin.iniciarSesion(cliente.getNombreUsuario(), cliente.getContrasenia())) {
			System.out.println("Ingreso correctamente");
		}
		else
		{
			System.out.println("Error al iniciar sesión");
		}
		
		//Cerrar sesión
		if(!gestionLogin.cerrarSesion()) {
			System.out.println("Saliste correctamente");
		}
		
		//Cambiar Clave
		cliente = (Cliente) gestionLogin.cambiarClave(cliente, "4321");
		System.out.println(cliente.toString());	
	}
}
