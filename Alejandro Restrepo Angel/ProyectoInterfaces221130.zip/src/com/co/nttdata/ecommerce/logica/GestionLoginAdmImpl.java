package com.co.nttdata.ecommerce.logica;

import com.co.nttdata.ecommerce.interfaces.*;
import com.co.nttdata.ecommerce.modelos.*;

public class GestionLoginAdmImpl implements IGestionLogin{

	private boolean token;
	private String usr = "administrador";
	private String pwd = "0000";
	
	@Override
	public Usuario registrar(String nombreUsuario, String clave, String tipoIdentificacion, String numeroIdentificacion,
			String correo, String direccion) {
		Administrador administrador = new Administrador();
		administrador.setNombreUsuario(nombreUsuario);
		administrador.setContrasenia(clave);
		administrador.setTipoIdentificacion(tipoIdentificacion);
		administrador.setNumeroIdentificacion(numeroIdentificacion);
		administrador.setCorreo(correo);
		administrador.setDireccion(direccion);
		return administrador;
	}

	@Override
	public boolean iniciarSesion(String nombreUsuario, String clave) {
		if(!nombreUsuario.equals(usr)) {
			return false;
		}
		if(!clave.equals(pwd)) {
			return false;
		}
		token = true;
		return true;
	}

	@Override
	public boolean cerrarSesion() {
		if(token == true) {
			return false;
		}
		return token;
	}

	@Override
	public Usuario cambiarClave(Usuario usuario, String clave) {
		usuario.setContrasenia(clave);
		return usuario;
	}

}
