package com.co.nttdata.ecommerce.modelos;

public class Empresa {

}
