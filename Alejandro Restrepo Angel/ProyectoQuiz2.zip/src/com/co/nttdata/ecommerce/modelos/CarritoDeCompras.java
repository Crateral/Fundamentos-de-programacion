package com.co.nttdata.ecommerce.modelos;

import java.util.ArrayList;
import java.util.List;

public class CarritoDeCompras {

	// Se debe cambiar los artibutos del subTotal a:
	// - subTotalConIva y subTotaSinIva

	private int idCarritoDeCompras;
	private List<Producto> productos;
	private double subTotalSinIva;
	private double subTotalConIva;
	private double ValorEnvio;

	public CarritoDeCompras() {
		this.productos = new ArrayList<>();
	}

	public CarritoDeCompras(int idCarritoDeCompras, List<Producto> productos, double subTotalSinIva,
			double subTotalConIva, double valorEnvio) {
		super();
		this.idCarritoDeCompras = idCarritoDeCompras;
		this.productos = productos;
		this.subTotalSinIva = subTotalSinIva;
		this.subTotalConIva = subTotalConIva;
		ValorEnvio = valorEnvio;
	}

	public int getIdCarritoDeCompras() {
		return idCarritoDeCompras;
	}

	public void setIdCarritoDeCompras(int idCarritoDeCompras) {
		this.idCarritoDeCompras = idCarritoDeCompras;
	}

	public List<Producto> getProductos() {
		return productos;
	}

	public void setProductos(List<Producto> productos) {
		this.productos = productos;
	}

	public double getSubTotalSinIva() {
		return subTotalSinIva;
	}

	public void setSubTotalSinIva(double subTotalSinIva) {
		this.subTotalSinIva = subTotalSinIva;
	}

	public double getSubTotalConIva() {
		return subTotalConIva;
	}

	public void setSubTotalConIva(double subTotalConIva) {
		this.subTotalConIva = subTotalConIva;
	}

	public double getValorEnvio() {
		return ValorEnvio;
	}

	public void setValorEnvio(double valorEnvio) {
		ValorEnvio = valorEnvio;
	}

	@Override
	public String toString() {
		return "CarritoDeCompras [idCarritoDeCompras=" + idCarritoDeCompras + ", productos=" + productos
				+ ", subTotalSinIva=" + subTotalSinIva + ", subTotalConIva=" + subTotalConIva + ", ValorEnvio="
				+ ValorEnvio + "]";
	}

}
