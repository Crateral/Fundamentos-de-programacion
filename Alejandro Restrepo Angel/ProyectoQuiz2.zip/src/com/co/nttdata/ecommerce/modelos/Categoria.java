package com.co.nttdata.ecommerce.modelos;

public enum Categoria {

	MERCADO(1, "Mercado, frutas y legumbres", true, 0.30),
	TECNOLOGIA(2, "Televisores, computadores, cámaras y audio", true, 0.20),
	CELULARES(3, "Celulares y accesorios", true, 0.25),
	ELECTRODOMESTICOS(4, "Refrigeracion, lavado, cocina y climatización", true, 0.15),
	DORMITORIO(5, "Colchones, dormitorio y ropa de hogar", false, 0.0),
	HOGAR(6, "Oficina en casa, baño, comedor y salas", true, 0.22), 
	MODA(7, "Hombre, mujer e infantil", true, 0.10),
	SALUD(8, "Medicinas, maquilllaje, cuidado corporal, higiene oral y capilar", false, 0.0),
	JUGUETERIA(9, "Juguetes, Vehículos, juegos de mesa y muñecos", true, 0.22),
	DEPORTES(10, "Ciclismo, fitness, camping e implementos deportivos", true, 0.12),
	FERRETERIA(11, "Herramientas, materiales y accesorios", false, 0.0);

	private int idCategoria;
	private String descripcion;
	private boolean descuento;
	private double valorDescuento;

	Categoria() {

	}

	Categoria(int idCategoria, String descripcion, boolean descuento, double valorDescuento) {
		this.idCategoria = idCategoria;
		this.descripcion = descripcion;
		this.descuento = descuento;
		this.valorDescuento = valorDescuento;
	}

	public int getIdCategoria() {
		return idCategoria;
	}

	public void setIdCategoria(int idCategoria) {
		this.idCategoria = idCategoria;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public boolean isDescuento() {
		return descuento;
	}

	public void setDescuento(boolean descuento) {
		this.descuento = descuento;
	}

	public double getValorDescuento() {
		return valorDescuento;
	}

	public void setValorDescuento(double valorDescuento) {
		this.valorDescuento = valorDescuento;
	}
}
