package com.co.nttdata.ecommerce.interfaces;

import java.util.List;

import com.co.nttdata.ecommerce.modelos.Factura;
import com.co.nttdata.ecommerce.modelos.Producto;

public interface IGestionArchivo {
	
	public void escribirCarrito(String nombreArchivo, List<Producto> productos);
	public void escribirFactura(String nombreArchivo, Factura factura);
	public void leerArchivo(String nombreArchivo);
	public List<Producto> leerProductos(String archivoCarrito);

}
