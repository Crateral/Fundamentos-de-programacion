package com.co.nttdata.ecommerce.logica;

import com.co.nttdata.ecommerce.interfaces.IGestionFactura;
import com.co.nttdata.ecommerce.modelos.*;
import java.util.Date;

public class GestionFacturaImpl implements IGestionFactura {

	public Factura pagar(Cliente cliente, CarritoDeCompras carrito) {
		Factura factura = new Factura();
		factura.setCliente(cliente);
		factura.setDescripcion("Mi primer factura");
		factura.setIdFactura(123123);
		factura.setCarritoDeCompras(carrito);
		factura.setFecha(new Date());
		factura.setEmpresa(null);
		factura.setCliente(null);
		factura.setValorTotalSinIva(carrito.getSubTotalSinIva() + carrito.getValorEnvio());
		factura.setValorTotalConIva(carrito.getSubTotalConIva() + carrito.getValorEnvio());
		return factura;
	}

	public void imprimirFactura(Factura factura) {

		System.out.println("Factura: " + factura.getIdFactura());
		System.out.println("Fecha: " + factura.getFecha());
		System.out.println("Empresa: " + factura.getEmpresa());
		System.out.println("Cliente: " + factura.getCliente());
		System.out.println("Descripción: " + factura.getDescripcion());

		// Recorrer los productos en el carro de compras
		factura.getCarritoDeCompras().getProductos().forEach((producto) -> System.out.println(producto.toString()));
		System.out.println("Subtotal sin IVA: " + factura.getCarritoDeCompras().getSubTotalSinIva());
		System.out.println("Subtotal con IVA: " + factura.getCarritoDeCompras().getSubTotalConIva());
		System.out.println("Valor envío: " + factura.getCarritoDeCompras().getValorEnvio());	
		System.out.println("Valor neto: " + factura.getValorTotalSinIva());
		System.out.println("Total pagar: " + factura.getValorTotalConIva());

	}

}
