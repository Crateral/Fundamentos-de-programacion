package com.co.nttdata.ecommerce.logica;

import com.co.nttdata.ecommerce.interfaces.IGestionProducto;
import com.co.nttdata.ecommerce.modelos.Producto;

public class GestionProductoImpl implements IGestionProducto{
	
	@Override
	public Producto descontarProducto(Producto producto) {
		
		producto.setCantidadDiponible((producto.getCantidadDiponible()-1));
		return producto;
		
	}

}
