package com.co.nttdata.ecommerce.utilitarios;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.co.nttdata.ecommerce.interfaces.IGestionArchivo;
import com.co.nttdata.ecommerce.modelos.*;

public class GestionArchivoImpl implements IGestionArchivo{
	
	public void escribirCarrito(String nombreArchivo, List<Producto> productos) {	
		FileWriter archivo = null;				
		try {
			archivo = new FileWriter("C:\\Users\\arestrep\\Downloads\\"+nombreArchivo, false);
			for (int i = 0; i < productos.size(); i++) {
				archivo.write(productos.get(i).getIdProducto() + "," +
						productos.get(i).getNombre()+ "," +
						productos.get(i).getCantidadDiponible()+ "," +
						productos.get(i).getPrecio()+ "," +
						productos.get(i).isDescuento()+ "," +
						productos.get(i).getValorDescuento()+ "," +
						productos.get(i).getIva()+ "," +
						productos.get(i).getDescripcion()+ "," +
						productos.get(i).getImg()+ "," +
						productos.get(i).getMarca()+ "," +
						productos.get(i).getCategoria() + "\n"
						);
			}	
			System.out.println("El archivo se ha escrito con exito");
			archivo.close();
		}
		catch(Exception e) {
			System.out.println("Error al escribir el archivo: " + e.getMessage());
		}
	}
	
	
	public void escribirFactura(String nombreArchivo, Factura factura) {	
		FileWriter archivo = null;				
		try {
			archivo = new FileWriter("C:\\Users\\arestrep\\Downloads\\"+nombreArchivo, false);
			archivo.write("Fecha: " + factura.getFecha() + "\n" +
					"Factura: " + factura.getIdFactura() + "\n" +
					"Empresa: " + factura.getEmpresa() + "\n" +
					"Cliente: " + factura.getCliente() + "\n" +
					"Descripción: " + factura.getDescripcion() + "\n"
					);
			for (Producto producto:factura.getCarritoDeCompras().getProductos())
			{
				archivo.write(producto + "\n");
			}
			archivo.write("Subtotal sin IVA: " + factura.getCarritoDeCompras().getSubTotalSinIva() + "\n" +
					"Subtotal con IVA: " + factura.getCarritoDeCompras().getSubTotalConIva() + "\n" +
					"Valor envío: " + factura.getCarritoDeCompras().getValorEnvio() +"\n" +
					"Valor neto: " + factura.getValorTotalSinIva() + "\n" +
					"Total pagar: " + factura.getValorTotalConIva() + "\n"
					);		
			System.out.println("El archivo se ha escrito con exito");
			archivo.close();
		}
		catch(Exception e) {
			System.out.println("Error al escribir el archivo: " + e.getMessage());
		}
	}
	
	
	public List<Producto> leerProductos(String nombreArchivo) {
		File archivo = new File("C:\\Users\\arestrep\\Downloads\\" + nombreArchivo);
		List<Producto> listaProductos = new ArrayList<>();
		Producto producto = new Producto();
		
		try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
			String linea;
			while((linea = br.readLine())!= null) {
				String[] p = linea.split(",");
				listaProductos.add(new Producto((Integer.parseInt(p[0])),
				(p[1]),
				(Integer.parseInt(p[2])),
				(Double.parseDouble(p[3])),
				(Boolean.parseBoolean(p[4])),
				(Double.parseDouble(p[5])),
				(Double.parseDouble(p[6])),
				(p[7]),
				(p[8]),
				(Marca.valueOf(p[9])),
				(Categoria.valueOf(p[10]))
				));
				
			}
			
		}catch(Exception e) {
			System.out.println("Error al leer el archivo: " + e.getMessage());
		}
		return listaProductos;
	}
	
	
	public void leerArchivo(String nombreArchivo) {
		File archivo = new File("C:\\Users\\arestrep\\Downloads\\" + nombreArchivo);
		Scanner s = null;
		
		try {
			s = new Scanner(archivo);
			while(s.hasNextLine()) {
				String linea = s.nextLine();
				System.out.println(linea);
			}
			
		}catch(Exception e) {
			System.out.println("Error al leer el archivo: " + e.getMessage());
		}finally {
			try {
				if(s != null) {
					s.close();
				}
			}catch(Exception e) {
				System.out.println("Error al cerrar la lectura del archivo: " + e.getMessage());
			}
		}
	}

}
