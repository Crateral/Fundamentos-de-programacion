package com.co.nttdata.ecommerce.interfaces;

import com.co.nttdata.ecommerce.modelos.*;

public interface IGestionLogin {

	public Usuario registrar(int id, int id_Usuario, String tipoIdentificacion, String numeroIdentificacion, String correo,
			String direccion, boolean estado);
	public boolean iniciarSesion(String nombreUsuario, String clave);
	public boolean cerrarSesion();
	public Usuario cambiarClave(Usuario usuario, String clave);
	
}
