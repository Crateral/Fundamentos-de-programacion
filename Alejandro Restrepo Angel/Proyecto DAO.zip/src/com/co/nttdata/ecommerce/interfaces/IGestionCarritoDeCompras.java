package com.co.nttdata.ecommerce.interfaces;

import java.util.List;

import com.co.nttdata.ecommerce.modelos.*;

public interface IGestionCarritoDeCompras {

	public CarritoDeCompras añadirAlCarrito(CarritoDeCompras carrito, List<Producto> listaProductos);
	public Producto agregarLista(List<Producto> listaProductos, int idProducto);
	public CarritoDeCompras calcularTotalSinIva(CarritoDeCompras carrito);
	public CarritoDeCompras calcularTotalConIva(CarritoDeCompras carrito);
	CarritoDeCompras calcularCostoEnvio(Cliente cliente, CarritoDeCompras carrito);
		
}
