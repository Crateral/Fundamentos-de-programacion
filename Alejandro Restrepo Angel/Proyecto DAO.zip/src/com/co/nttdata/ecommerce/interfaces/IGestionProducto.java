package com.co.nttdata.ecommerce.interfaces;

import com.co.nttdata.ecommerce.modelos.Producto;

public interface IGestionProducto {
	
	public Producto descontarProducto(Producto producto);

}
