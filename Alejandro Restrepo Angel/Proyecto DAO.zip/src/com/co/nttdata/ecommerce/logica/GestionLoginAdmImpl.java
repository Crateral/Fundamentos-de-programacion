package com.co.nttdata.ecommerce.logica;

import com.co.nttdata.ecommerce.interfaces.IGestionLogin;
import com.co.nttdata.ecommerce.modelos.*;

public class GestionLoginAdmImpl implements IGestionLogin{

	private boolean token;
	private String usr = "administrador";
	private String pwd = "0000";
	
	@Override
	public Usuario registrar(int id, int id_Usuario, String tipoIdentificacion, String numeroIdentificacion, String correo,
			String direccion, boolean estado) {
		Administrador administrador = new Administrador();
		administrador.setId_Usuario(id_Usuario);
		administrador.setTipoIdentificacion(tipoIdentificacion);
		administrador.setNumeroIdentificacion(numeroIdentificacion);
		administrador.setCorreo(correo);
		administrador.setDireccion(direccion);
		return administrador;
	}

	@Override
	public boolean iniciarSesion(String nombreUsuario, String clave) {
		if(!nombreUsuario.equals(usr)) {
			return false;
		}
		if(!clave.equals(pwd)) {
			return false;
		}
		token = true;
		return true;
	}

	@Override
	public boolean cerrarSesion() {
		if(token == true) {
			return false;
		}
		return token;
	}

	@Override
	public Usuario cambiarClave(Usuario usuario, String clave) {
		usuario.setContrasena(clave);
		return usuario;
	}

}
