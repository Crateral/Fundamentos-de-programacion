package com.co.nttdata.ecommerce.logica;

import com.co.nttdata.ecommerce.interfaces.IGestionFactura;
import com.co.nttdata.ecommerce.modelos.*;
import java.util.Date;

public class GestionFacturaImpl implements IGestionFactura {

	public Factura pagar(Cliente cliente, CarritoDeCompras carrito) {
		Factura factura = new Factura();
		factura.setId_Cliente(cliente.getId());
		factura.setDescripcion("Mi primer factura");
		factura.setId(123123);
		factura.setId_CarritoCompras(carrito.getId());
		factura.setFecha(new Date());
		factura.setEmpresa(null);
		factura.setValorTotalSinIva(carrito.getSubTotalSinIva() + carrito.getValorEnvio());
		factura.setValorTotalConIva(carrito.getSubTotalConIva() + carrito.getValorEnvio());
		return factura;
	}

	public void imprimirFactura(Factura factura) {

		System.out.println("Factura: " + factura.getId());
		System.out.println("Fecha: " + factura.getFecha());
		System.out.println("Empresa: " + factura.getEmpresa());
		System.out.println("Cliente: " + factura.getId_Cliente());
		System.out.println("Descripción: " + factura.getDescripcion());

		// Recorrer los productos en el carro de compras
		/*
		 * factura.getId_CarritoCompras().getProductos().forEach((producto) ->
		 * System.out.println(producto.toString()));
		 * System.out.println("Subtotal sin IVA: " +
		 * factura.getId_CarritoCompras().getSubTotalSinIva());
		 * System.out.println("Subtotal con IVA: " +
		 * factura.getId_CarritoCompras().getSubTotalConIva());
		 * System.out.println("Valor envío: " +
		 * factura.getId_CarritoCompras().getValorEnvio());
		 * System.out.println("Valor neto: " + factura.getValorTotalSinIva());
		 * System.out.println("Total pagar: " + factura.getValorTotalConIva());
		 */

	}

}
