package com.co.nttdata.ecommerce.logica;

import com.co.nttdata.ecommerce.interfaces.IGestionLogin;
import com.co.nttdata.ecommerce.modelos.*;

public class GestionLoginImpl implements IGestionLogin {

	private boolean token;
	private String usr = "usuario";
	private String pwd = "1234";
	
	//Registrar usuario
	public Usuario registrar(int id, int id_Usuario, String tipoIdentificacion, String numeroIdentificacion, String correo,
			String direccion, boolean estado) {
		Cliente cliente = new Cliente();
		cliente.setTipoIdentificacion(tipoIdentificacion);
		cliente.setNumeroIdentificacion(numeroIdentificacion);
		cliente.setCorreo(correo);
		cliente.setDireccion(direccion);
		return cliente;
	}
	
	//Login
	public boolean iniciarSesion(String nombreUsuario, String clave) {
		
		if(!nombreUsuario.equals(usr)) {
			return false;
		}
		if(!clave.equals(pwd)) {
			return false;
		}
		token = true;
		return true;
	}
	
	//Logout
	public boolean cerrarSesion() {
		if(token == true) {
			return false;
		}
		return token;
	}
	
	//Olvide la contraseña
	public Usuario cambiarClave(Usuario usuario, String clave){
		usuario.setContrasena(clave);
		return usuario;
		
	}
	
	
}
