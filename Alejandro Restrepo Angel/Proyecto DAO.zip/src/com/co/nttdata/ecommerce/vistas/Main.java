package com.co.nttdata.ecommerce.vistas;

import java.sql.Date;
import java.util.List;

import com.co.nttdata.ecommerce.Dao.*;
import com.co.nttdata.ecommerce.interfaces.*;
import com.co.nttdata.ecommerce.logica.*;
import com.co.nttdata.ecommerce.modelos.*;

public class Main {

	public static void main(String[] args) {
		
		
		  FacturaDAO fc = new FacturaDAO(); 
		  Factura factura = new Factura();
		  
		  List<Factura> facturas = fc.listarFacturas();
		  
		  facturas.forEach((f) -> System.out.println(f.toString()));
		  
		  factura = fc.buscarFactura(2); 
		  System.out.println(factura.toString());
		  		  
		  factura.setId(3); 
		  factura.setId_Cliente(1);
		  factura.setFecha(null);
		  factura.setDescripcion("Factura Prueba");
		  factura.setId_CarritoCompras(1);
		  factura.setValorTotalSinIva(250000);
		  factura.setValorTotalConIva(270000);


		  fc.agregarFactura(factura);
		  
		  fc.eliminarPorId(3); 
		  factura = fc.buscarPorId(3);
		  System.out.println(factura.toString());
		 	
		
		/********************************************************************/
		/* Error en el carrito */
		/*
		 * CarritoDeComprasDAO car = new CarritoDeComprasDAO(); CarritoDeCompras carrito
		 * = new CarritoDeCompras();
		 * 
		 * List<CarritoDeCompras> carritos = car.listarCarritos();
		 * 
		 * carritos.forEach((c) -> System.out.println(c.toString()));
		 * 
		 * carrito = car.buscarCarrito(1); System.out.println(carrito.toString());
		 * 
		 * carrito.setId(3); carrito.setProductos(null);
		 * carrito.setSubTotalSinIva(50000); carrito.setSubTotalConIva(55000);
		 * carrito.setValorEnvio(20000);
		 * 
		 * 
		 * car.agregarCliente(carrito);
		 * 
		 * car.eliminarPorId(3); carrito = car.buscarPorId(3);
		 * System.out.println(carrito.toString());
		 */
		/********************************************************************/
	}
}
