package com.co.nttdata.ecommerce.modelos;

import java.io.Serializable;
import java.util.Date;

public class Factura implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int id;
	private int id_Cliente;
	private Date fecha;
	private Empresa empresa;
	private String descripcion;
	private int id_CarritoCompras;
	private double valorTotalSinIva;
	private double valorTotalConIva;

	public Factura() {
		super();
	}

	public Factura(int id, int id_Cliente, Date fecha, Empresa empresa, String descripcion, int id_CarritoCompras,
			double valorTotalSinIva, double valorTotalConIva) {
		super();
		this.id = id;
		this.id_Cliente = id_Cliente;
		this.fecha = fecha;
		this.empresa = empresa;
		this.descripcion = descripcion;
		this.id_CarritoCompras = id_CarritoCompras;
		this.valorTotalSinIva = valorTotalSinIva;
		this.valorTotalConIva = valorTotalConIva;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getId_Cliente() {
		return this.id_Cliente;
	}

	public void setId_Cliente(int id_Cliente) {
		this.id_Cliente = id_Cliente;
	}

	public Date getFecha() {
		return this.fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public Empresa getEmpresa() {
		return this.empresa;
	}

	public void setEmpresa(Empresa empresa) {
		this.empresa = empresa;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public int getId_CarritoCompras() {
		return this.id_CarritoCompras;
	}

	public void setId_CarritoCompras(int id_CarritoCompras) {
		this.id_CarritoCompras = id_CarritoCompras;
	}

	public double getValorTotalSinIva() {
		return this.valorTotalSinIva;
	}

	public void setValorTotalSinIva(double valorTotalSinIva) {
		this.valorTotalSinIva = valorTotalSinIva;
	}

	public double getValorTotalConIva() {
		return this.valorTotalConIva;
	}

	public void setValorTotalConIva(double valorTotalConIva) {
		this.valorTotalConIva = valorTotalConIva;
	}

	@Override
	public String toString() {
		return "Factura [id=" + this.id 
				+ ", id_Cliente=" + this.id_Cliente 
				+ ", fecha=" + this.fecha 
				+ ", empresa=" + this.empresa
				+ ", descripcion=" + this.descripcion 
				+ ", id_CarritoCompras=" + this.id_CarritoCompras
				+ ", valorTotalSinIva=" + this.valorTotalSinIva 
				+ ", valorTotalConIva=" + this.valorTotalConIva + "]";
	}

}
