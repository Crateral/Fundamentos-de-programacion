package com.co.nttdata.ecommerce.modelos;

import java.io.Serializable;

public class Categoria implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int id;
	private String categoria;
	private String descripcion;
	private boolean descuento;
	private double valor_Descuento;

	public Categoria() {
		super();
	}

	public Categoria(int id, String categoria, String descripcion, boolean descuento, double valor_Descuento) {
		super();
		this.id = id;
		this.categoria = categoria;
		this.descripcion = descripcion;
		this.descuento = descuento;
		this.valor_Descuento = valor_Descuento;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCategoria() {
		return this.categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public boolean isDescuento() {
		return this.descuento;
	}

	public void setDescuento(boolean descuento) {
		this.descuento = descuento;
	}

	public double getValor_Descuento() {
		return this.valor_Descuento;
	}

	public void setValor_Descuento(double valor_Descuento) {
		this.valor_Descuento = valor_Descuento;
	}

	@Override
	public String toString() {
		return "Categoria [id=" + this.id 
				+ ", categoria=" + this.categoria 
				+ ", descripcion=" + this.descripcion
				+ ", descuento=" + this.descuento 
				+ ", valor_Descuento=" + this.valor_Descuento + "]";
	}

}
