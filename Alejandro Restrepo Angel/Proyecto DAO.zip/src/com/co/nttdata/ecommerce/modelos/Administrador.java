package com.co.nttdata.ecommerce.modelos;

import java.io.Serializable;

public class Administrador extends Usuario implements Serializable{

	/**
	 * 
	 */	
	private static final long serialVersionUID = 1L;
	private int id;
	private int id_Usuario;
	private String tipoIdentificacion;
	private String numeroIdentificacion;
	private String correo;
	private String direccion;
	private boolean estado;

	public Administrador() {
		super();
	}

	public Administrador(int id, int id_Usuario, String tipoIdentificacion, String numeroIdentificacion, String correo,
			String direccion, boolean estado) {
		super();
		this.id = id;
		this.id_Usuario = id_Usuario;
		this.tipoIdentificacion = tipoIdentificacion;
		this.numeroIdentificacion = numeroIdentificacion;
		this.correo = correo;
		this.direccion = direccion;
		this.estado = estado;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getId_Usuario() {
		return this.id_Usuario;
	}

	public void setId_Usuario(int id_Usuario) {
		this.id_Usuario = id_Usuario;
	}

	public String getTipoIdentificacion() {
		return this.tipoIdentificacion;
	}

	public void setTipoIdentificacion(String tipoIdentificacion) {
		this.tipoIdentificacion = tipoIdentificacion;
	}

	public String getNumeroIdentificacion() {
		return this.numeroIdentificacion;
	}

	public void setNumeroIdentificacion(String numeroIdentificacion) {
		this.numeroIdentificacion = numeroIdentificacion;
	}

	public String getCorreo() {
		return this.correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getDireccion() {
		return this.direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public boolean isEstado() {
		return this.estado;
	}

	public void setEstado(boolean estado) {
		this.estado = estado;
	}

	@Override
	public String toString() {
		return "Administrador [id=" + this.id 
				+ ", id_Usuario=" + this.id_Usuario 
				+ ", tipoIdentificacion=" + this.tipoIdentificacion
				+ ", numeroIdentificacion=" + this.numeroIdentificacion 
				+ ", correo=" + this.correo 
				+ ", direccion=" + this.direccion
				+ ", estado=" + this.estado + "]";
	}
	
}
