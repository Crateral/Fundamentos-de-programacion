package com.co.nttdata.ecommerce.modelos;

import java.io.Serializable;

public class Marca implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int id;
	private String marca;
	private String descripcion;

	public Marca() {

	}

	public Marca(int id, String marca, String descripcion) {
		super();
		this.id = id;
		this.marca = marca;
		this.descripcion = descripcion;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMarca() {
		return this.marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	@Override
	public String toString() {
		return "Marca [id=" + this.id 
				+ ", marca=" + this.marca 
				+ ", descripcion=" + this.descripcion + "]";
	}

}
