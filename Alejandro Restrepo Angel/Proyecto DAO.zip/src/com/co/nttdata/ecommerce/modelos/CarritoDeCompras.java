package com.co.nttdata.ecommerce.modelos;

import java.io.Serializable;
import java.sql.Array;
import java.util.ArrayList;
import java.util.List;

public class CarritoDeCompras implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int id;
	private Array productos;
	private double subTotalSinIva;
	private double subTotalConIva;
	private double ValorEnvio;

	public CarritoDeCompras() {

	}

	public CarritoDeCompras(int id, Array productos, double subTotalSinIva, double subTotalConIva,
			double valorEnvio) {
		super();
		this.id = id;
		this.productos = productos;
		this.subTotalSinIva = subTotalSinIva;
		this.subTotalConIva = subTotalConIva;
		ValorEnvio = valorEnvio;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Array getProductos() {
		return this.productos;
	}

	public void setProductos(Array array) {
		this.productos = array;
	}

	public double getSubTotalSinIva() {
		return this.subTotalSinIva;
	}

	public void setSubTotalSinIva(double subTotalSinIva) {
		this.subTotalSinIva = subTotalSinIva;
	}

	public double getSubTotalConIva() {
		return this.subTotalConIva;
	}

	public void setSubTotalConIva(double subTotalConIva) {
		this.subTotalConIva = subTotalConIva;
	}

	public double getValorEnvio() {
		return this.ValorEnvio;
	}

	public void setValorEnvio(double valorEnvio) {
		ValorEnvio = valorEnvio;
	}

	@Override
	public String toString() {
		return "CarritoDeCompras [id=" + this.id 
				+ ", productos=" + this.productos 
				+ ", subTotalSinIva=" + this.subTotalSinIva
				+ ", subTotalConIva=" + this.subTotalConIva 
				+ ", ValorEnvio=" + this.ValorEnvio + "]";
	}

	
}
