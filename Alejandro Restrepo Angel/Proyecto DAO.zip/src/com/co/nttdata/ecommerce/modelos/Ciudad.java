package com.co.nttdata.ecommerce.modelos;

import java.io.Serializable;

public class Ciudad implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int id;
	private String ciudad;
	private Boolean principal;
	
	public Ciudad() {
		super();
	}
	
	public Ciudad(int id, String ciudad, Boolean principal) {
		super();
		this.id = id;
		this.ciudad = ciudad;
		this.principal = principal;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCiudad() {
		return this.ciudad;
	}

	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}

	public Boolean getPrincipal() {
		return this.principal;
	}

	public void setPrincipal(Boolean principal) {
		this.principal = principal;
	}

	@Override
	public String toString() {
		return "Ciudad [id=" + this.id 
				+ ", ciudad=" + this.ciudad 
				+ ", principal=" + this.principal + "]";
	}
	
	

}
