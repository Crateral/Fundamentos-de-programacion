package com.co.nttdata.ecommerce.modelos;

import java.io.Serializable;

public class Producto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int id;
	private String producto;
	private int cantidadDiponible;
	private double precio;
	private boolean descuento;
	private double valorDescuento;
	private double iva;
	private String descripcion;
	private String imagen;
	private int id_Marca;
	private int id_Categoria;

	public Producto() {

	}

	public Producto(int id, String producto, int cantidadDiponible, double precio, boolean descuento,
			double valorDescuento, double iva, String descripcion, String imagen, int id_Marca, int id_Categoria) {
		super();
		this.id = id;
		this.producto = producto;
		this.cantidadDiponible = cantidadDiponible;
		this.precio = precio;
		this.descuento = descuento;
		this.valorDescuento = valorDescuento;
		this.iva = iva;
		this.descripcion = descripcion;
		this.imagen = imagen;
		this.id_Marca = id_Marca;
		this.id_Categoria = id_Categoria;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getProducto() {
		return this.producto;
	}

	public void setProducto(String producto) {
		this.producto = producto;
	}

	public int getCantidadDiponible() {
		return this.cantidadDiponible;
	}

	public void setCantidadDiponible(int cantidadDiponible) {
		this.cantidadDiponible = cantidadDiponible;
	}

	public double getPrecio() {
		return this.precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public boolean isDescuento() {
		return this.descuento;
	}

	public void setDescuento(boolean descuento) {
		this.descuento = descuento;
	}

	public double getValorDescuento() {
		return this.valorDescuento;
	}

	public void setValorDescuento(double valorDescuento) {
		this.valorDescuento = valorDescuento;
	}

	public double getIva() {
		return this.iva;
	}

	public void setIva(double iva) {
		this.iva = iva;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getImagen() {
		return this.imagen;
	}

	public void setImagen(String imagen) {
		this.imagen = imagen;
	}

	public int getId_Marca() {
		return this.id_Marca;
	}

	public void setId_Marca(int id_Marca) {
		this.id_Marca = id_Marca;
	}

	public int getId_Categoria() {
		return this.id_Categoria;
	}

	public void setId_Categoria(int id_Categoria) {
		this.id_Categoria = id_Categoria;
	}

	@Override
	public String toString() {
		return "Producto [id=" + this.id 
				+ ", producto=" + this.producto 
				+ ", cantidadDiponible=" + this.cantidadDiponible
				+ ", precio=" + this.precio 
				+ ", descuento=" + this.descuento 
				+ ", valorDescuento=" + this.valorDescuento 
				+ ", iva=" + this.iva 
				+ ", descripcion=" + this.descripcion 
				+ ", imagen=" + this.imagen 
				+ ", id_Marca=" + this.id_Marca
				+ ", id_Categoria=" + this.id_Categoria + "]";
	}

	

}
