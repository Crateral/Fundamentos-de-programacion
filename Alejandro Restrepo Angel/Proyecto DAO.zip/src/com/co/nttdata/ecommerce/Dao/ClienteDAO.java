package com.co.nttdata.ecommerce.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.co.nttdata.ecommerce.modelos.Cliente;
import com.co.nttdata.ecommerce.utilitarios.Conexion;

public class ClienteDAO {

	Conexion c = new Conexion();
	
	public List<Cliente> listarClientes() {		
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		List<Cliente> clientes = new ArrayList<Cliente>();

		try {
			st = baseDatos.prepareStatement("SELECT * FROM \"TBL_CLIENTES\"");
			rs = st.executeQuery();

			while (rs.next()) {
				Cliente cliente = new Cliente();

				cliente.setId(rs.getInt("id"));
				cliente.setId_Usuario(rs.getInt("id_Usuario"));
				cliente.setId_Ciudad(rs.getInt("id_Ciudad"));
				cliente.setTipoIdentificacion(rs.getString("tipo_Identificacion"));
				cliente.setNumeroIdentificacion(rs.getString("numero_Identificacion"));
				cliente.setMetodoDePago(rs.getString("metodo_Pago"));
				cliente.setCorreo(rs.getString("correo"));
				cliente.setTelefono(rs.getString("telefono"));
				cliente.setDireccion(rs.getString("direccion"));
				cliente.setEstado(rs.getBoolean("estado"));

				clientes.add(cliente);
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				rs.close();
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return clientes;
	}

	public Cliente buscarCliente(int id_Cliente) {
		
		Cliente cliente = new Cliente();
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			st = baseDatos.prepareStatement("SELECT * FROM \"TBL_CLIENTES\" WHERE id = ? ");
			st.setInt(1, id_Cliente);
			rs = st.executeQuery();
			while (rs.next()) {
				cliente.setId(rs.getInt("id"));
				cliente.setId_Usuario(rs.getInt("id_Usuario"));
				cliente.setId_Ciudad(rs.getInt("id_Ciudad"));
				cliente.setTipoIdentificacion(rs.getString("tipo_Identificacion"));
				cliente.setNumeroIdentificacion(rs.getString("numero_Identificacion"));
				cliente.setMetodoDePago(rs.getString("metodo_Pago"));
				cliente.setCorreo(rs.getString("correo"));
				cliente.setTelefono(rs.getString("telefono"));
				cliente.setDireccion(rs.getString("direccion"));
				cliente.setEstado(rs.getBoolean("estado"));
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				rs.close();
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}	
		return cliente;
	}

	public void agregarCliente(Cliente cliente) {
				
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;

		try {
			st = baseDatos.prepareStatement("INSERT INTO \"TBL_CLIENTES\" VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			st.setInt(1, cliente.getId());
			st.setInt(2, cliente.getId_Usuario());
			st.setInt(3, cliente.getId_Ciudad());
			st.setString(4, cliente.getTipoIdentificacion());
			st.setString(5, cliente.getNumeroIdentificacion());
			st.setString(6, cliente.getMetodoDePago());
			st.setString(7, cliente.getCorreo());
			st.setString(8, cliente.getTelefono());
			st.setString(9, cliente.getDireccion());
			st.setBoolean(10, cliente.isEstado());
			st.executeUpdate();
			
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void eliminarPorId(int id) {
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;

		try {
			st = baseDatos.prepareStatement("DELETE FROM \"TBL_CLIENTES\" WHERE id = ?");
			st.setInt(1, id);
			st.executeQuery();
			
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Cliente buscarPorId(int id) {
		
		Cliente cliente = new Cliente();
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			st = baseDatos.prepareStatement("SELECT * FROM \"TBL_CLIENTES\" WHERE id = ? ");
			st.setInt(1, id);
			rs = st.executeQuery();

			while (rs.next()) {
				cliente.setId(rs.getInt("id"));
				cliente.setId_Usuario(rs.getInt("id_Usuario"));
				cliente.setId_Ciudad(rs.getInt("id_Ciudad"));
				cliente.setTipoIdentificacion(rs.getString("tipo_Identificacion"));
				cliente.setNumeroIdentificacion(rs.getString("numero_Identificacion"));
				cliente.setMetodoDePago(rs.getString("metodo_Pago"));
				cliente.setCorreo(rs.getString("correo"));
				cliente.setTelefono(rs.getString("telefono"));
				cliente.setDireccion(rs.getString("direccion"));
				cliente.setEstado(rs.getBoolean("estado"));
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return cliente;
	}
	
}
