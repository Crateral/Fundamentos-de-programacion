package com.co.nttdata.ecommerce.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.co.nttdata.ecommerce.modelos.Categoria;
import com.co.nttdata.ecommerce.utilitarios.Conexion;

public class CategoriaDAO {
	
Conexion c = new Conexion();
	
	public List<Categoria> listarCategorias() {		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		List<Categoria> categorias = new ArrayList<Categoria>();

		try {
			st = baseDatos.prepareStatement("SELECT * FROM \"TBL_CATEGORIAS\"");
			rs = st.executeQuery();

			while (rs.next()) {
				Categoria categoria = new Categoria();

				categoria.setId(rs.getInt("id"));
				categoria.setCategoria(rs.getString("categoria"));
				categoria.setDescripcion(rs.getString("descripcion"));
				categoria.setDescuento(rs.getBoolean("descuento"));
				categoria.setValor_Descuento(rs.getDouble("valor_Descuento"));

				categorias.add(categoria);
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				rs.close();
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return categorias;
	}
	
	public Categoria buscarCategoria(String nombreCategoria) {
		
		Categoria categoria = new Categoria();
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			st = baseDatos.prepareStatement("SELECT * FROM \"TBL_CATEGORIAS\" WHERE categoria = ? ");
			st.setString(1, nombreCategoria);
			rs = st.executeQuery();
			while (rs.next()) {
				categoria.setId(rs.getInt("id"));
				categoria.setCategoria(rs.getString("categoria"));
				categoria.setDescripcion(rs.getString("descripcion"));
				categoria.setDescuento(rs.getBoolean("descuento"));
				categoria.setValor_Descuento(rs.getDouble("valor_Descuento"));
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				rs.close();
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}	
		return categoria;
	}

	public void agregarCategoria(Categoria categoria) {
				
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;

		try {
			st = baseDatos.prepareStatement("INSERT INTO \"TBL_CATEGORIAS\" VALUES (?, ?, ?, ?, ?)");
			st.setInt(1, categoria.getId());
			st.setString(2, categoria.getCategoria());
			st.setString(3, categoria.getDescripcion());
			st.setBoolean(4, categoria.isDescuento());
			st.setDouble(5, categoria.getValor_Descuento());
			st.executeUpdate();
			
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void eliminarPorId(int id) {
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;

		try {
			st = baseDatos.prepareStatement("DELETE FROM \"TBL_CATEGORIAS\" WHERE id = ?");
			st.setInt(1, id);
			st.executeQuery();
			
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Categoria buscarPorId(int id) {
		
		Categoria categoria = new Categoria();
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			st = baseDatos.prepareStatement("SELECT * FROM \"TBL_CATEGORIAS\" WHERE id = ? ");
			st.setInt(1, id);
			rs = st.executeQuery();

			while (rs.next()) {

				categoria.setId(rs.getInt("id"));
				categoria.setCategoria(rs.getString("categoria"));
				categoria.setDescripcion(rs.getString("descripcion"));
				categoria.setDescuento(rs.getBoolean("descuento"));
				categoria.setValor_Descuento(rs.getDouble("valor_Descuento"));
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return categoria;
	}
	
}
