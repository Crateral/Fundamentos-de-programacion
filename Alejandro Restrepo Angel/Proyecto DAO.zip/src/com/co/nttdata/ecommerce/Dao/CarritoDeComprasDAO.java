package com.co.nttdata.ecommerce.Dao;

import java.sql.Array;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.co.nttdata.ecommerce.modelos.CarritoDeCompras;
import com.co.nttdata.ecommerce.modelos.Producto;
import com.co.nttdata.ecommerce.utilitarios.Conexion;

public class CarritoDeComprasDAO {

	Conexion c = new Conexion();

	public List<CarritoDeCompras> listarCarritos() {		
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		List<CarritoDeCompras> carritos = new ArrayList<CarritoDeCompras>();

		try {
			st = baseDatos.prepareStatement("SELECT * FROM \"TBL_CARRITODECOMPRAS\"");
			rs = st.executeQuery();

			while (rs.next()) {
				CarritoDeCompras carritoDeCompras = new CarritoDeCompras();

				carritoDeCompras.setId(rs.getInt("id"));
				carritoDeCompras.setProductos(rs.getArray("productos"));
				carritoDeCompras.setSubTotalSinIva(rs.getDouble("subtotal_Sin_Iva"));
				carritoDeCompras.setSubTotalConIva(rs.getDouble("subtotal_Con_Iva"));
				carritoDeCompras.setValorEnvio(rs.getDouble("valor_Envio"));

				carritos.add(carritoDeCompras);
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				rs.close();
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return carritos;
	}

	public CarritoDeCompras buscarCarrito(int id_Carrito) {
		
		CarritoDeCompras carritoDeCompras = new CarritoDeCompras();
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			st = baseDatos.prepareStatement("SELECT * FROM \"TBL_CARRITODECOMPRAS\" WHERE id = ? ");
			st.setInt(1, id_Carrito);
			rs = st.executeQuery();
			while (rs.next()) {
				carritoDeCompras.setId(rs.getInt("id"));
				carritoDeCompras.setProductos(rs.getArray("productos"));
				carritoDeCompras.setSubTotalSinIva(rs.getDouble("subtotal_Sin_Iva"));
				carritoDeCompras.setSubTotalConIva(rs.getDouble("subtotal_Con_Iva"));
				carritoDeCompras.setValorEnvio(rs.getDouble("valor_Envio"));
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				rs.close();
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}	
		return carritoDeCompras;
	}

	public void agregarCliente(CarritoDeCompras carritoDeCompras) {
				
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;

		try {
			st = baseDatos.prepareStatement("INSERT INTO \"TBL_CARRITODECOMPRAS\" VALUES (?, ?, ?, ?, ?)");
			st.setInt(1, carritoDeCompras.getId());
			st.setArray(2, (Array) carritoDeCompras.getProductos());
			st.setDouble(3, carritoDeCompras.getSubTotalSinIva());
			st.setDouble(4, carritoDeCompras.getSubTotalConIva());
			st.setDouble(5, carritoDeCompras.getValorEnvio());
			st.executeUpdate();
			
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void eliminarPorId(int id) {
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;

		try {
			st = baseDatos.prepareStatement("DELETE FROM \"TBL_CARRITODECOMPRAS\" WHERE id = ?");
			st.setInt(1, id);
			st.executeQuery();
			
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public CarritoDeCompras buscarPorId(int id) {
		
		CarritoDeCompras carritoDeCompras = new CarritoDeCompras();
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			st = baseDatos.prepareStatement("SELECT * FROM \"TBL_CARRITODECOMPRAS\" WHERE id = ? ");
			st.setInt(1, id);
			rs = st.executeQuery();

			while (rs.next()) {
				carritoDeCompras.setId(rs.getInt("id"));
				carritoDeCompras.setProductos(rs.getArray("productos"));
				carritoDeCompras.setSubTotalSinIva(rs.getDouble("subtotal_Sin_Iva"));
				carritoDeCompras.setSubTotalConIva(rs.getDouble("subtotal_Con_Iva"));
				carritoDeCompras.setValorEnvio(rs.getDouble("'valor_Envio'"));
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return carritoDeCompras;
	}
	
}
