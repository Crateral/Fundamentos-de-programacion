package com.co.nttdata.ecommerce.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.co.nttdata.ecommerce.modelos.Marca;
import com.co.nttdata.ecommerce.utilitarios.Conexion;

public class MarcaDAO {

	Conexion c = new Conexion();
	
	public List<Marca> listarMarcas() {		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		List<Marca> marcas = new ArrayList<Marca>();

		try {
			st = baseDatos.prepareStatement("SELECT * FROM \"TBL_MARCAS\"");
			rs = st.executeQuery();

			while (rs.next()) {
				Marca marca = new Marca();

				marca.setId(rs.getInt("id"));
				marca.setMarca(rs.getString("marca"));
				marca.setDescripcion(rs.getString("descripcion"));

				marcas.add(marca);
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				rs.close();
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return marcas;
	}
	
	public Marca buscarMarca(String nombreMarca) {
		
		Marca marca = new Marca();
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			st = baseDatos.prepareStatement("SELECT * FROM \"TBL_MARCAS\" WHERE marca = ? ");
			st.setString(1, nombreMarca);
			rs = st.executeQuery();
			while (rs.next()) {
				marca.setId(rs.getInt("id"));
				marca.setMarca(rs.getString("marca"));
				marca.setDescripcion(rs.getString("descripcion"));
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				rs.close();
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}	
		return marca;
	}

	public void agregarMarca(Marca marca) {
				
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;

		try {
			st = baseDatos.prepareStatement("INSERT INTO \"TBL_MARCAS\" VALUES (?, ?, ?)");
			st.setInt(1, marca.getId());
			st.setString(2, marca.getMarca());
			st.setString(3, marca.getDescripcion());
			st.executeUpdate();
			
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void eliminarPorId(int id) {
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;

		try {
			st = baseDatos.prepareStatement("DELETE FROM \"TBL_MARCAS\" WHERE id = ?");
			st.setInt(1, id);
			st.executeQuery();
			
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Marca buscarPorId(int id) {
		
		Marca marca = new Marca();
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			st = baseDatos.prepareStatement("SELECT * FROM \"TBL_MARCAS\" WHERE id = ? ");
			st.setInt(1, id);
			rs = st.executeQuery();

			while (rs.next()) {

				marca.setId(rs.getInt("id"));
				marca.setMarca(rs.getString("marca"));
				marca.setDescripcion(rs.getString("descripcion"));
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return marca;
	}

}
