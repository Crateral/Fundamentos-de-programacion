package com.co.nttdata.ecommerce.Dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.co.nttdata.ecommerce.modelos.Factura;
import com.co.nttdata.ecommerce.utilitarios.Conexion;

public class FacturaDAO {
	
Conexion c = new Conexion();
	
	public List<Factura> listarFacturas() {		
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		List<Factura> facturas = new ArrayList<Factura>();

		try {
			st = baseDatos.prepareStatement("SELECT * FROM \"TBL_FACTURAS\"");
			rs = st.executeQuery();

			while (rs.next()) {
				Factura factura = new Factura();

				factura.setId(rs.getInt("id"));
				factura.setId_Cliente(rs.getInt("id_Cliente"));
				factura.setId_CarritoCompras(rs.getInt("id_Carrito_Compras"));
				factura.setFecha(rs.getDate("fecha"));
				factura.setDescripcion(rs.getString("descripcion"));
				factura.setValorTotalSinIva(rs.getDouble("total_Sin_Iva"));
				factura.setValorTotalConIva(rs.getDouble("total_Con_Iva"));
				facturas.add(factura);
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				rs.close();
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return facturas;
	}

	public Factura buscarFactura(int id_Factura) {
		
		Factura factura = new Factura();
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			st = baseDatos.prepareStatement("SELECT * FROM \"TBL_FACTURAS\" WHERE id = ? ");
			st.setInt(1, id_Factura);
			rs = st.executeQuery();
			while (rs.next()) {
				factura.setId(rs.getInt("id"));
				factura.setId_Cliente(rs.getInt("id_Cliente"));
				factura.setId_CarritoCompras(rs.getInt("id_Carrito_Compras"));
				factura.setFecha(rs.getDate("fecha"));
				factura.setDescripcion(rs.getString("descripcion"));
				factura.setValorTotalSinIva(rs.getDouble("total_Sin_Iva"));
				factura.setValorTotalConIva(rs.getDouble("total_Con_Iva"));
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				rs.close();
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}	
		return factura;
	}

	public void agregarFactura(Factura factura) {
				
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;

		try {
			st = baseDatos.prepareStatement("INSERT INTO \"TBL_FACTURAS\" VALUES (?, ?, ?, ?, ?, ?, ?)");
			st.setInt(1, factura.getId());
			st.setInt(2, factura.getId_Cliente());
			st.setDate(3, (Date) factura.getFecha());
			st.setString(4, factura.getDescripcion());
			st.setInt(5, factura.getId_CarritoCompras());
			st.setDouble(6, factura.getValorTotalSinIva());
			st.setDouble(7, factura.getValorTotalConIva());
			st.executeUpdate();
			
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void eliminarPorId(int id) {
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;

		try {
			st = baseDatos.prepareStatement("DELETE FROM \"TBL_FACTURAS\" WHERE id = ?");
			st.setInt(1, id);
			st.executeQuery();
			
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Factura buscarPorId(int id) {
		
		Factura factura = new Factura();
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			st = baseDatos.prepareStatement("SELECT * FROM \"TBL_FACTURAS\" WHERE id = ? ");
			st.setInt(1, id);
			rs = st.executeQuery();

			while (rs.next()) {
				factura.setId(rs.getInt("id"));
				factura.setId_Cliente(rs.getInt("id_Cliente"));
				factura.setId_CarritoCompras(rs.getInt("id_Carrito_Compras"));
				factura.setFecha(rs.getDate("fecha"));
				factura.setDescripcion(rs.getString("descripcion"));
				factura.setValorTotalSinIva(rs.getDouble("total_Sin_Iva"));
				factura.setValorTotalConIva(rs.getDouble("total_Con_Iva"));
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return factura;
	}

	
}
