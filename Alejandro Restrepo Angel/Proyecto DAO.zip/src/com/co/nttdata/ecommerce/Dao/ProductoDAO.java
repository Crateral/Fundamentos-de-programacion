package com.co.nttdata.ecommerce.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.co.nttdata.ecommerce.modelos.Producto;
import com.co.nttdata.ecommerce.utilitarios.Conexion;

public class ProductoDAO {

Conexion c = new Conexion();
	
	public List<Producto> listarProductos() {		
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		List<Producto> productos = new ArrayList<Producto>();

		try {
			st = baseDatos.prepareStatement("SELECT * FROM \"TBL_PRODUCTOS\"");
			rs = st.executeQuery();

			while (rs.next()) {
				Producto producto = new Producto();

				producto.setId(rs.getInt("id"));
				producto.setId_Marca(rs.getInt("id_Marca"));
				producto.setId_Categoria(rs.getInt("id_Categoria"));
				producto.setProducto(rs.getString("producto"));
				producto.setCantidadDiponible(rs.getInt("cantidad_Disponible"));
				producto.setPrecio(rs.getDouble("precio"));
				producto.setDescuento(rs.getBoolean("descuento"));
				producto.setValorDescuento(rs.getDouble("valor_Descuento"));
				producto.setImagen(rs.getString("imagen"));
				producto.setIva(rs.getDouble("iva"));
				producto.setDescripcion(rs.getString("descripcion"));

				productos.add(producto);
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				rs.close();
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return productos;
	}

	public Producto buscarProducto(String nombreProducto) {
		
		Producto producto = new Producto();
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			st = baseDatos.prepareStatement("SELECT * FROM \"TBL_PRODUCTOS\" WHERE producto = ? ");
			st.setString(1, nombreProducto);
			rs = st.executeQuery();
			while (rs.next()) {
				producto.setId(rs.getInt("id"));
				producto.setId_Marca(rs.getInt("id_Marca"));
				producto.setId_Categoria(rs.getInt("id_Categoria"));
				producto.setProducto(rs.getString("producto"));
				producto.setCantidadDiponible(rs.getInt("cantidad_Disponible"));
				producto.setPrecio(rs.getDouble("precio"));
				producto.setDescuento(rs.getBoolean("descuento"));
				producto.setValorDescuento(rs.getDouble("valor_Descuento"));
				producto.setImagen(rs.getString("imagen"));
				producto.setIva(rs.getDouble("iva"));
				producto.setDescripcion(rs.getString("descripcion"));
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				rs.close();
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}	
		return producto;
	}

	public void agregarProducto(Producto producto) {
				
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;

		try {
			st = baseDatos.prepareStatement("INSERT INTO \"TBL_PRODUCTOS\" VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			st.setInt(1, producto.getId());
			st.setInt(2, producto.getId_Marca());
			st.setInt(3, producto.getId_Categoria());
			st.setString(4, producto.getProducto());
			st.setInt(5, producto.getCantidadDiponible());
			st.setDouble(6, producto.getPrecio());
			st.setBoolean(7, producto.isDescuento());
			st.setDouble(8, producto.getValorDescuento());
			st.setString(9, producto.getImagen());
			st.setDouble(10, producto.getIva());
			st.setString(11, producto.getDescripcion());
			st.executeUpdate();
			
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void eliminarPorId(int id) {
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;

		try {
			st = baseDatos.prepareStatement("DELETE FROM \"TBL_PRODUCTOS\" WHERE id = ?");
			st.setInt(1, id);
			st.executeQuery();
			
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Producto buscarPorId(int id) {
		
		Producto producto = new Producto();
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			st = baseDatos.prepareStatement("SELECT * FROM \"TBL_PRODUCTOS\" WHERE id = ? ");
			st.setInt(1, id);
			rs = st.executeQuery();

			while (rs.next()) {
				producto.setId(rs.getInt("id"));
				producto.setId_Marca(rs.getInt("id_Marca"));
				producto.setId_Categoria(rs.getInt("id_Categoria"));
				producto.setProducto(rs.getString("producto"));
				producto.setCantidadDiponible(rs.getInt("cantidad_Disponible"));
				producto.setPrecio(rs.getDouble("precio"));
				producto.setDescuento(rs.getBoolean("descuento"));
				producto.setValorDescuento(rs.getDouble("valor_Descuento"));
				producto.setImagen(rs.getString("imagen"));
				producto.setIva(rs.getDouble("iva"));
				producto.setDescripcion(rs.getString("descripcion"));
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return producto;
	}

	
}
