package com.co.nttdata.ecommerce.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.co.nttdata.ecommerce.modelos.Administrador;
import com.co.nttdata.ecommerce.utilitarios.Conexion;

public class AdministradorDAO {

	Conexion c = new Conexion();
	
	public List<Administrador> listarAdministradores() {		
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		List<Administrador> administradores = new ArrayList<Administrador>();

		try {
			st = baseDatos.prepareStatement("SELECT * FROM \"TBL_ADMINISTRADORES\"");
			rs = st.executeQuery();

			while (rs.next()) {
				Administrador administrador = new Administrador();

				administrador.setId(rs.getInt("id"));
				administrador.setId_Usuario(rs.getInt("id_Usuario"));
				administrador.setTipoIdentificacion(rs.getString("tipo_Identificacion"));
				administrador.setNumeroIdentificacion(rs.getString("numero_Identificacion"));
				administrador.setCorreo(rs.getString("correo"));
				administrador.setDireccion(rs.getString("direccion"));
				administrador.setEstado(rs.getBoolean("estado"));

				administradores.add(administrador);
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				rs.close();
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return administradores;
	}

	public Administrador buscarAdministrador(int id_Administrador) {
		
		Administrador administrador = new Administrador();
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			st = baseDatos.prepareStatement("SELECT * FROM \"TBL_ADMINISTRADORES\" WHERE id = ? ");
			st.setInt(1, id_Administrador);
			rs = st.executeQuery();
			while (rs.next()) {
				administrador.setId(rs.getInt("id"));
				administrador.setId_Usuario(rs.getInt("id_Usuario"));
				administrador.setTipoIdentificacion(rs.getString("tipo_Identificacion"));
				administrador.setNumeroIdentificacion(rs.getString("numero_Identificacion"));
				administrador.setCorreo(rs.getString("correo"));
				administrador.setDireccion(rs.getString("direccion"));
				administrador.setEstado(rs.getBoolean("estado"));
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				rs.close();
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}	
		return administrador;
	}

	public void agregarAdministrador(Administrador administrador) {
				
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;

		try {
			st = baseDatos.prepareStatement("INSERT INTO \"TBL_ADMINISTRADORES\" VALUES (?, ?, ?, ?, ?, ?, ?)");
			st.setInt(1, administrador.getId());
			st.setInt(2, administrador.getId_Usuario());
			st.setString(3, administrador.getTipoIdentificacion());
			st.setString(4, administrador.getNumeroIdentificacion());
			st.setString(5, administrador.getCorreo());
			st.setString(6, administrador.getDireccion());
			st.setBoolean(7, administrador.isEstado());
			st.executeUpdate();
			
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void eliminarPorId(int id) {
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;

		try {
			st = baseDatos.prepareStatement("DELETE FROM \"TBL_ADMINISTRADORES\" WHERE id = ?");
			st.setInt(1, id);
			st.executeQuery();
			
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Administrador buscarPorId(int id) {
		
		Administrador administrador = new Administrador();
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			st = baseDatos.prepareStatement("SELECT * FROM \"TBL_ADMINISTRADORES\" WHERE id = ? ");
			st.setInt(1, id);
			rs = st.executeQuery();

			while (rs.next()) {
				administrador.setId(rs.getInt("id"));
				administrador.setId_Usuario(rs.getInt("id_Usuario"));
				administrador.setTipoIdentificacion(rs.getString("tipo_Identificacion"));
				administrador.setNumeroIdentificacion(rs.getString("numero_Identificacion"));
				administrador.setCorreo(rs.getString("correo"));
				administrador.setDireccion(rs.getString("direccion"));
				administrador.setEstado(rs.getBoolean("estado"));
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return administrador;
	}

}
