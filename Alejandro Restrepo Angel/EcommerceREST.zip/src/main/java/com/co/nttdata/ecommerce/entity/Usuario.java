package com.co.nttdata.ecommerce.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.util.List;

@Entity
@Table(name="tbl_usuarios", schema="sc_ecommerce")
@NamedQuery(name="Usuario.findAll", query="SELECT u FROM Usuario u")
public class Usuario implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;

	private String clave;

	private Boolean estado;

	private String usuario;

	//bi-directional many-to-one association to Administrador
	@OneToMany(mappedBy="usuario", cascade = CascadeType.ALL)
	private List<Administrador> administradores;

	//bi-directional many-to-one association to Cliente
	@OneToMany(mappedBy="usuario", cascade = CascadeType.ALL)
	private List<Cliente> clientes;

	//bi-directional many-to-one association to Registro
	@OneToMany(mappedBy="usuario", cascade = CascadeType.ALL)
	private List<Registro> registros;

	public Usuario() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getClave() {
		return this.clave;
	}

	public void setClave(String clave) {
		this.clave = clave;
	}

	public Boolean getEstado() {
		return this.estado;
	}

	public void setEstado(Boolean estado) {
		this.estado = estado;
	}

	public String getUsuario() {
		return this.usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public List<Administrador> getAdministradores() {
		return this.administradores;
	}

	public void setAdministradores(List<Administrador> administradores) {
		this.administradores = administradores;
	}

	public Administrador addAdministrador(Administrador administrador) {
		getAdministradores().add(administrador);
		administrador.setUsuario(this);

		return administrador;
	}

	public Administrador removeAdministrador(Administrador administrador) {
		getAdministradores().remove(administrador);
		administrador.setUsuario(null);

		return administrador;
	}

	public List<Cliente> getClientes() {
		return this.clientes;
	}

	public void setClientes(List<Cliente> clientes) {
		this.clientes = clientes;
	}

	public Cliente addCliente(Cliente cliente) {
		getClientes().add(cliente);
		cliente.setUsuario(this);

		return cliente;
	}

	public Cliente removeCliente(Cliente cliente) {
		getClientes().remove(cliente);
		cliente.setUsuario(null);

		return cliente;
	}

	public List<Registro> getRegistros() {
		return this.registros;
	}

	public void setRegistros(List<Registro> registros) {
		this.registros = registros;
	}

	public Registro addRegistro(Registro registro) {
		getRegistros().add(registro);
		registro.setUsuario(this);

		return registro;
	}

	public Registro removeRegistro(Registro registro) {
		getRegistros().remove(registro);
		registro.setUsuario(null);

		return registro;
	}

	@Override
	public String toString() {
		return "Usuario [id=" + this.id 
				+ ", clave=" + this.clave 
				+ ", estado=" + this.estado 
				+ ", usuario=" + this.usuario + "]";
	}

}