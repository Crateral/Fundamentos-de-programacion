package com.co.nttdata.ecommerce.dao;

import java.util.List;

import com.co.nttdata.ecommerce.entity.Cliente;

public interface IClienteDAO {

	public List<Cliente> findAll();
    public Cliente findById(int id);
    public Cliente findByCorreo(String correo);
    public void save(Cliente cliente);
    public void deleteById(int id);
    public void update(int id, Cliente cliente);
	
}
