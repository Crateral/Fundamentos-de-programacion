package com.co.nttdata.ecommerce.servicesImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.co.nttdata.ecommerce.dao.ICategoriaDAO;
import com.co.nttdata.ecommerce.entity.Categoria;
import com.co.nttdata.ecommerce.service.ICategoriaService;

@Service
public class CategoriaServicesImpl implements ICategoriaService {

	@Autowired
	private ICategoriaDAO categoriaDAO;

	@Override
	public List<Categoria> findAll() {
		List<Categoria> listaCategorias = categoriaDAO.findAll();
		return listaCategorias;
	}

	@Override
	public Categoria findById(int id) {
		Categoria categoria = categoriaDAO.findById(id);
		return categoria;
	}

	@Override
	public void save(Categoria categoria) {
		categoriaDAO.save(categoria);

	}

	@Override
	public void deleteById(int id) {
		categoriaDAO.deleteById(id);
	}

	@Override
	public Categoria findByNombre(String nombre) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(int id, Categoria categoria) {
		// TODO Auto-generated method stub
		
	}



}
