package com.co.nttdata.ecommerce.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

import java.util.Date;

@Entity
@Table(name="tbl_facturas", schema="sc_ecommerce")
@NamedQuery(name="Factura.findAll", query="SELECT f FROM Factura f")
public class Factura implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;

	private String descripcion;

	@Temporal(TemporalType.DATE)
	private Date fecha;

	@Column(name="total_con_iva")
	private double totalConIva;

	@Column(name="total_envio")
	private double totalEnvio;

	@Column(name="total_sin_iva")
	private double totalSinIva;

	//bi-directional many-to-one association to CarritoCompra
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name="id_carrito_compras")
	@JsonProperty(access = Access.WRITE_ONLY)
	private CarritoDeCompras carritoCompra;

	//bi-directional many-to-one association to Cliente
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name="id_cliente")
	@JsonProperty(access = Access.WRITE_ONLY)
	private Cliente cliente;

	//bi-directional many-to-one association to Empresa
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name="id_empresa")
	@JsonProperty(access = Access.WRITE_ONLY)
	private Empresa empresa;

	public Factura() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Date getFecha() {
		return this.fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public double getTotalConIva() {
		return this.totalConIva;
	}

	public void setTotalConIva(double totalConIva) {
		this.totalConIva = totalConIva;
	}

	public double getTotalEnvio() {
		return this.totalEnvio;
	}

	public void setTotalEnvio(double totalEnvio) {
		this.totalEnvio = totalEnvio;
	}

	public double getTotalSinIva() {
		return this.totalSinIva;
	}

	public void setTotalSinIva(double totalSinIva) {
		this.totalSinIva = totalSinIva;
	}

	public CarritoDeCompras getCarritoCompra() {
		return this.carritoCompra;
	}

	public void setCarritoCompra(CarritoDeCompras carritoCompra) {
		this.carritoCompra = carritoCompra;
	}

	public Cliente getCliente() {
		return this.cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public Empresa getEmpresa() {
		return this.empresa;
	}

	public void setEmpresa(Empresa empresa) {
		this.empresa = empresa;
	}

	@Override
	public String toString() {
		return "Factura [id=" + this.id 
				+ ", descripcion=" + this.descripcion 
				+ ", fecha=" + this.fecha 
				+ ", totalConIva=" + this.totalConIva 
				+ ", totalEnvio=" + this.totalEnvio 
				+ ", totalSinIva=" + this.totalSinIva 
				+ ", carritoCompra=" + this.carritoCompra 
				+ ", cliente=" + this.cliente 
				+ ", empresa=" + this.empresa + "]";
	}

}
