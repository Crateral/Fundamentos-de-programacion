
package com.co.nttdata.ecommerce.service;

import java.util.List;

import com.co.nttdata.ecommerce.entity.Administrador;

public interface IAdministradorService {

	public List<Administrador> findAll();

	public Administrador findById(int id);

	public Administrador findByCorreo(String correo);

	public void save(Administrador administrador);

	public void deleteById(int id);

	public void update(int id, Administrador administrador);

}
