package com.co.nttdata.ecommerce.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

import java.util.List;

@Entity
@Table(name="tbl_productos", schema="sc_ecommerce")
@NamedQuery(name="Producto.findAll", query="SELECT p FROM Producto p")
public class Producto implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;

	@Column(name="cantidad_disponible")
	private Integer cantidadDisponible;

	private String descripcion;

	private Boolean descuento;

	private String imagen;

	private double iva;

	private double precio;

	private String producto;

	@Column(name="valor_descuento")
	private double valorDescuento;

	//bi-directional many-to-one association to Compra
	@OneToMany(mappedBy="producto", cascade = CascadeType.ALL)
	private List<Compra> compras;

	//bi-directional many-to-one association to Categoria
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name="id_categoria")
	@JsonProperty(access = Access.WRITE_ONLY)
	private Categoria categoria;

	//bi-directional many-to-one association to Marca
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name="id_marca")
	@JsonProperty(access = Access.WRITE_ONLY)
	private Marca marca;

	public Producto() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCantidadDisponible() {
		return this.cantidadDisponible;
	}

	public void setCantidadDisponible(Integer cantidadDisponible) {
		this.cantidadDisponible = cantidadDisponible;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Boolean getDescuento() {
		return this.descuento;
	}

	public void setDescuento(Boolean descuento) {
		this.descuento = descuento;
	}

	public String getImagen() {
		return this.imagen;
	}

	public void setImagen(String imagen) {
		this.imagen = imagen;
	}

	public double getIva() {
		return this.iva;
	}

	public void setIva(double iva) {
		this.iva = iva;
	}

	public double getPrecio() {
		return this.precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public String getProducto() {
		return this.producto;
	}

	public void setProducto(String producto) {
		this.producto = producto;
	}

	public double getValorDescuento() {
		return this.valorDescuento;
	}

	public void setValorDescuento(double valorDescuento) {
		this.valorDescuento = valorDescuento;
	}

	public List<Compra> getCompras() {
		return this.compras;
	}

	public void setCompras(List<Compra> compras) {
		this.compras = compras;
	}

	public Compra addCompra(Compra compra) {
		getCompras().add(compra);
		compra.setProducto(this);

		return compra;
	}

	public Compra removeCompra(Compra compra) {
		getCompras().remove(compra);
		compra.setProducto(null);

		return compra;
	}

	public Categoria getCategoria() {
		return this.categoria;
	}

	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}

	public Marca getMarca() {
		return this.marca;
	}

	public void setMarca(Marca marca) {
		this.marca = marca;
	}

	@Override
	public String toString() {
		return "Producto [id=" + this.id 
				+ ", cantidadDisponible=" + this.cantidadDisponible 
				+ ", descripcion=" + this.descripcion
				+ ", descuento=" + this.descuento 
				+ ", imagen=" + this.imagen 
				+ ", iva=" + this.iva 
				+ ", precio=" + this.precio
				+ ", producto=" + this.producto 
				+ ", valorDescuento=" + this.valorDescuento 
				+ ", categoria=" + this.categoria
				+ ", marca=" + this.marca + "]";
	}

}