package com.co.nttdata.ecommerce.servicesImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.co.nttdata.ecommerce.dao.IMarcaDAO;
import com.co.nttdata.ecommerce.entity.Marca;
import com.co.nttdata.ecommerce.service.IMarcaService;

@Service
public class MarcaServicesImpl implements IMarcaService {

	@Autowired
	private IMarcaDAO marcaDAO;

	@Override
	public List<Marca> findAll() {
		List<Marca> listaMarcas = marcaDAO.findAll();
		return listaMarcas;
	}

	@Override
	public Marca findById(int id) {
		Marca marca = marcaDAO.findById(id);
		return marca;
	}

	@Override
	public void save(Marca marca) {
		marcaDAO.save(marca);

	}

	@Override
	public void deleteById(int id) {
		marcaDAO.deleteById(id);
	}

	@Override
	public Marca findByNombre(String nombre) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(int id, Marca marca) {
		// TODO Auto-generated method stub
		
	}

}
