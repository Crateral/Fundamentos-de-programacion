package com.co.nttdata.ecommerce.service;

import java.util.List;

import com.co.nttdata.ecommerce.entity.Cliente;

public interface IClienteService {

	public List<Cliente> findAll();
    public Cliente findById(int id);
    public Cliente findByCorreo(String correo);
    public void save(Cliente cliente);
    public void deleteById(int id);
    public void update(int id, Cliente cliente);
	
}
