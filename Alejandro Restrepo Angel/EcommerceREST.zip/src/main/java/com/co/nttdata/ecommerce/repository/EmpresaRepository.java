package com.co.nttdata.ecommerce.repository;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.co.nttdata.ecommerce.dao.IEmpresaDAO;
import com.co.nttdata.ecommerce.entity.Empresa;

@Repository
public class EmpresaRepository implements IEmpresaDAO {

	@Autowired
	private EntityManager entityManager;

	@Override
	public List<Empresa> findAll() {
		Session currentSession = entityManager.unwrap(Session.class);

		Query<Empresa> theQuery = currentSession.createQuery("from Empresa", Empresa.class);

		List<Empresa> empresas = theQuery.getResultList();

		return empresas;
	}

	@Override
	public Empresa findById(int id) {
		Session currentSession = entityManager.unwrap(Session.class);

		Empresa marca = currentSession.get(Empresa.class, id);

		return marca;
	}

	@Override
	public Empresa findByNit(String nit) {
		Session currentSession = entityManager.unwrap(Session.class);

		Empresa empresa = currentSession.get(Empresa.class, nit);

		return empresa;
	}

	@Override
	public void save(Empresa empresa) {
		Session currentSession = entityManager.unwrap(Session.class);

		currentSession.saveOrUpdate(empresa);
	}

	@Override
	public void deleteById(int id) {
		Session currentSession = entityManager.unwrap(Session.class);

		Query<Empresa> theQuery = currentSession.createQuery("delete from Empresa where id=:idEmpresa");

		theQuery.setParameter("idEmpresa", id);
		theQuery.executeUpdate();
	}

	@Override
	public void update(int id, Empresa empresa) {
		// TODO Auto-generated method stub

	}

}