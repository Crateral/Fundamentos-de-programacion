package com.co.nttdata.ecommerce.dao;

import java.util.List;

import com.co.nttdata.ecommerce.entity.Ciudad;

public interface ICiudadDAO {
	
	public List<Ciudad> findAll();
    public Ciudad findById(int id);
    public Ciudad findByNombre(String nombre);
    public void save(Ciudad ciudad);
    public void deleteById(int id);
    public void update(int id, Ciudad ciudad);
    
}
