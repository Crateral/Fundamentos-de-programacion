package com.co.nttdata.ecommerce.repository;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.co.nttdata.ecommerce.dao.ICompraDAO;
import com.co.nttdata.ecommerce.entity.Compra;
import com.co.nttdata.ecommerce.entity.Producto;

@Repository
public class CompraRepository implements ICompraDAO {

	@Autowired
	private EntityManager entityManager;

	@Override
	public List<Compra> findAll() {
		Session currentSession = entityManager.unwrap(Session.class);

		Query<Compra> theQuery = currentSession.createQuery("from Compra", Compra.class);

		List<Compra> compras = theQuery.getResultList();

		return compras;
	}

	@Override
	public Compra findById(int id) {
		Session currentSession = entityManager.unwrap(Session.class);

		Compra compra = currentSession.get(Compra.class, id);

		return compra;
	}

	@Override
	public Compra findByCarrito(int idCarrito) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void save(Compra marca) {
		Session currentSession = entityManager.unwrap(Session.class);

		currentSession.saveOrUpdate(marca);
	}

	@Override
	public void deleteById(int id) {
		Session currentSession = entityManager.unwrap(Session.class);

		Query<Compra> theQuery = currentSession.createQuery("delete from Compra where id=:idMarca");

		theQuery.setParameter("idMarca", id);
		theQuery.executeUpdate();
	}

	@Override
	public void update(int id, Compra marca) {
		// TODO Auto-generated method stub

	}

	@Override
	public Double calcularValor(int id, int cantidad) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Producto agregarProductoCompra(int id, int cantidad) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Producto devolverProductoCompra(int id, int cantidad) {
		// TODO Auto-generated method stub
		return null;
	}

}