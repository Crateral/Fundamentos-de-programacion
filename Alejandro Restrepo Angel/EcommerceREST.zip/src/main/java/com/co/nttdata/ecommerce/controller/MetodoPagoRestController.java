package com.co.nttdata.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.co.nttdata.ecommerce.entity.MetodoPago;
import com.co.nttdata.ecommerce.service.IMetodoPagoService;

@CrossOrigin(origins = "http://localhost:9090")

@RestController
@RequestMapping("/api")

public class MetodoPagoRestController {

    @Autowired
    private IMetodoPagoService metodoPagoService;

    @GetMapping("/metodospago")
    public List<MetodoPago> findAll(){
        return metodoPagoService.findAll();
    }

    @GetMapping("/metodospago/{metodopagoId}")
    public MetodoPago getMetodoPago(@PathVariable int metodopagoId){
    	MetodoPago metodopago = metodoPagoService.findById(metodopagoId);
        if(metodopago == null) {
            throw new RuntimeException("No se encontró ningún metodo de pago con el id - " + metodopagoId);
        }
        return metodopago;
    }

    @PostMapping("/metodospago")
    public MetodoPago addMetodoPago(@RequestBody MetodoPago metodopago) {
    	metodopago.setId(0);
    	metodoPagoService.save(metodopago);
        return metodopago;

    }

    @PutMapping("/metodospago")
    public MetodoPago updateMetodoPago(@RequestBody MetodoPago metodopago) {
    	metodoPagoService.save(metodopago);
        return metodopago;
    }

    @DeleteMapping("metodospago/{metodopagoId}")
    public String deleteMetodoPago(@PathVariable int metodopagoId) {
    	MetodoPago metodopago = metodoPagoService.findById(metodopagoId);
        if(metodopago == null) {
            throw new RuntimeException("No se encontró ningún metodo de pago con el id - " + metodopagoId);
        }
        metodoPagoService.deleteById(metodopagoId);
        return "Borrado por el id del método de pago - " + metodopagoId;
    }

}