package com.co.nttdata.ecommerce.servicesImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.co.nttdata.ecommerce.dao.IUsuarioDAO;
import com.co.nttdata.ecommerce.entity.Usuario;
import com.co.nttdata.ecommerce.service.IUsuarioService;

@Service
public class UsuarioServicesImpl implements IUsuarioService {

	@Autowired
	private IUsuarioDAO usuarioDAO;

	@Override
	public List<Usuario> findAll() {
		List<Usuario> listaUsuarios = usuarioDAO.findAll();
		return listaUsuarios;
	}

	@Override
	public Usuario findById(int id) {
		Usuario usuario = usuarioDAO.findById(id);
		return usuario;
	}

	@Override
	public void save(Usuario usuario) {
		usuarioDAO.save(usuario);

	}

	@Override
	public void deleteById(int id) {
		usuarioDAO.deleteById(id);
	}

	@Override
	public Usuario findByNombre(String nombre) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(int id, Usuario usuario) {
		// TODO Auto-generated method stub
		
	}



}
