package com.co.nttdata.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.co.nttdata.ecommerce.entity.Categoria;
import com.co.nttdata.ecommerce.service.ICategoriaService;

@CrossOrigin(origins = "http://localhost:9090")

@RestController
@RequestMapping("/api")

public class CategoriaRestController {

    @Autowired
    private ICategoriaService categoriaService;

    @GetMapping("/categorias")
    public List<Categoria> findAll(){
        return categoriaService.findAll();
    }

    @GetMapping("/categorias/{categoriaId}")
    public Categoria getCategoria(@PathVariable int categoriaId){
    	Categoria categoria = categoriaService.findById(categoriaId);
        if(categoria == null) {
            throw new RuntimeException("No se encontró ninguna categoría con el id - " + categoriaId);
        }
        return categoria;
    }

    @PostMapping("/categorias")
    public Categoria addCategoria(@RequestBody Categoria categoria) {
    	categoria.setId(0);
    	categoriaService.save(categoria);
        return categoria;

    }

    @PutMapping("/categorias")
    public Categoria updateCategoria(@RequestBody Categoria categoria) {
    	categoriaService.save(categoria);
        return categoria;
    }

    @DeleteMapping("categorias/{categoriaId}")
    public String deleteCategoria(@PathVariable int categoriaId) {
    	Categoria categoria = categoriaService.findById(categoriaId);
        if(categoria == null) {
            throw new RuntimeException("No se encontró ninguna categoría con el id - "+ categoriaId);
        }
        categoriaService.deleteById(categoriaId);
        return "Borrado por id  de categoría - " + categoriaId;
    }

}