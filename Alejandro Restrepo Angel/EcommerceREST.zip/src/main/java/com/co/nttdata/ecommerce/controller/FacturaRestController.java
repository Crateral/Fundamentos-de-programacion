package com.co.nttdata.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.co.nttdata.ecommerce.entity.Factura;
import com.co.nttdata.ecommerce.service.IFacturaService;

@CrossOrigin(origins = "http://localhost:9090")

@RestController
@RequestMapping("/api")

public class FacturaRestController {

    @Autowired
    private IFacturaService facturaService;

    @GetMapping("/facturas")
    public List<Factura> findAll(){
        return facturaService.findAll();
    }

    @GetMapping("/facturas/{facturaId}")
    public Factura getFactura(@PathVariable int facturaId){
    	Factura factura = facturaService.findById(facturaId);
        if(factura == null) {
            throw new RuntimeException("No se encontró ninguna factura con el id - " + facturaId);
        }
        return factura;
    }

    @PostMapping("/facturas")
    public Factura addFactura(@RequestBody Factura factura) {
    	factura.setId(0);
    	facturaService.save(factura);
        return factura;

    }

    @PutMapping("/facturas")
    public Factura updateFactura(@RequestBody Factura factura) {
    	facturaService.save(factura);
        return factura;
    }

    @DeleteMapping("facturas/{facturaId}")
    public String deleteFactura(@PathVariable int facturaId) {
    	Factura factura = facturaService.findById(facturaId);
        if(factura == null) {
            throw new RuntimeException("No se encontró ninguna factura con el id - " + facturaId);
        }
        facturaService.deleteById(facturaId);
        return "Borrado por el id de la factura - " + facturaId;
    }

}