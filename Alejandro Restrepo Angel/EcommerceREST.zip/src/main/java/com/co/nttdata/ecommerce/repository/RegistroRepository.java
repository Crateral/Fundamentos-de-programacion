package com.co.nttdata.ecommerce.repository;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.co.nttdata.ecommerce.dao.IRegistroDAO;
import com.co.nttdata.ecommerce.entity.Registro;

@Repository
public class RegistroRepository implements IRegistroDAO {

	@Autowired
	private EntityManager entityManager;

	@Override
	public List<Registro> findAll() {
		Session currentSession = entityManager.unwrap(Session.class);

		Query<Registro> theQuery = currentSession.createQuery("from Registro", Registro.class);

		List<Registro> registros = theQuery.getResultList();

		return registros;
	}

	@Override
	public Registro findById(int id) {
		Session currentSession = entityManager.unwrap(Session.class);

		Registro registro = currentSession.get(Registro.class, id);

		return registro;
	}

	@Override
	public Registro findByUsuario(String nombre) {
		Session currentSession = entityManager.unwrap(Session.class);

		Registro registro = currentSession.get(Registro.class, nombre);

		return registro;
	}

	@Override
	public void save(Registro registro) {
		Session currentSession = entityManager.unwrap(Session.class);

		currentSession.saveOrUpdate(registro);
	}

	@Override
	public void deleteById(int id) {
		Session currentSession = entityManager.unwrap(Session.class);

		Query<Registro> theQuery = currentSession.createQuery("delete from Registro where id=:idRegistro");

		theQuery.setParameter("idRegistro", id);
		theQuery.executeUpdate();
	}

	@Override
	public void update(int id, Registro registro) {
		// TODO Auto-generated method stub

	}

}