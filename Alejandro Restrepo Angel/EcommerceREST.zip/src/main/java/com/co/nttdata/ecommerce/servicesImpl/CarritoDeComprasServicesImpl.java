package com.co.nttdata.ecommerce.servicesImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.co.nttdata.ecommerce.dao.ICarritoDeComprasDAO;
import com.co.nttdata.ecommerce.entity.CarritoDeCompras;
import com.co.nttdata.ecommerce.service.ICarritoDeComprasService;

@Service
public class CarritoDeComprasServicesImpl implements ICarritoDeComprasService {

	@Autowired
	private ICarritoDeComprasDAO carritoDeComprasDAO;

	@Override
	public List<CarritoDeCompras> findAll() {
		List<CarritoDeCompras> listaCarritos = carritoDeComprasDAO.findAll();
		return listaCarritos;
	}

	@Override
	public CarritoDeCompras findById(int id) {
		CarritoDeCompras carritoDeCompra = carritoDeComprasDAO.findById(id);
		return carritoDeCompra;
	}

	@Override
	public void save(CarritoDeCompras carritoDeCompra) {
		carritoDeComprasDAO.save(carritoDeCompra);

	}

	@Override
	public void deleteById(int id) {
		carritoDeComprasDAO.deleteById(id);
	}

	@Override
	public void update(int id, CarritoDeCompras administrador) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Double calcularSubtotalSinIva(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Double calcularSubtotalConIva(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
