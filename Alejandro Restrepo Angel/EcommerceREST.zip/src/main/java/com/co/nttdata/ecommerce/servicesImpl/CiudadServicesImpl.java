package com.co.nttdata.ecommerce.servicesImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.co.nttdata.ecommerce.dao.ICiudadDAO;
import com.co.nttdata.ecommerce.entity.Ciudad;
import com.co.nttdata.ecommerce.service.ICiudadService;

@Service
public class CiudadServicesImpl implements ICiudadService {

	@Autowired
	private ICiudadDAO ciudadDAO;

	@Override
	public List<Ciudad> findAll() {
		List<Ciudad> listaCiudades = ciudadDAO.findAll();
		return listaCiudades;
	}

	@Override
	public Ciudad findById(int id) {
		Ciudad ciudad = ciudadDAO.findById(id);
		return ciudad;
	}

	@Override
	public void save(Ciudad ciudad) {
		ciudadDAO.save(ciudad);

	}

	@Override
	public void deleteById(int id) {
		ciudadDAO.deleteById(id);
	}

	@Override
	public Ciudad findByNombre(String nombre) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(int id, Ciudad ciudad) {
		// TODO Auto-generated method stub
		
	}
	
}
