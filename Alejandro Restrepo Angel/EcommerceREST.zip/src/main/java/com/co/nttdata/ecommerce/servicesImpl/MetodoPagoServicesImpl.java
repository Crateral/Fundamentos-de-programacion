package com.co.nttdata.ecommerce.servicesImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.co.nttdata.ecommerce.dao.IMetodoPagoDAO;
import com.co.nttdata.ecommerce.entity.MetodoPago;
import com.co.nttdata.ecommerce.service.IMetodoPagoService;

@Service
public class MetodoPagoServicesImpl implements IMetodoPagoService {

	@Autowired
	private IMetodoPagoDAO metodoPagoDAO;

	@Override
	public List<MetodoPago> findAll() {
		List<MetodoPago> listaMetodosPago = metodoPagoDAO.findAll();
		return listaMetodosPago;
	}

	@Override
	public MetodoPago findById(int id) {
		MetodoPago metodoPago = metodoPagoDAO.findById(id);
		return metodoPago;
	}

	@Override
	public void save(MetodoPago metodoPago) {
		metodoPagoDAO.save(metodoPago);

	}

	@Override
	public void deleteById(int id) {
		metodoPagoDAO.deleteById(id);
	}

	@Override
	public MetodoPago findByMetodo(String nombreMetodo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(int id, MetodoPago metodoPago) {
		// TODO Auto-generated method stub
		
	}

}
