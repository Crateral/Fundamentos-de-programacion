package com.co.nttdata.ecommerce.repository;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.co.nttdata.ecommerce.dao.ITipoIdentificacionDAO;
import com.co.nttdata.ecommerce.entity.TipoIdentificacion;

@Repository
public class TipoIdentificacionRepository implements ITipoIdentificacionDAO {

	@Autowired
	private EntityManager entityManager;

	@Override
	public List<TipoIdentificacion> findAll() {
		Session currentSession = entityManager.unwrap(Session.class);

		Query<TipoIdentificacion> theQuery = currentSession.createQuery("from TipoIdentificacion",
				TipoIdentificacion.class);

		List<TipoIdentificacion> tiposIdentificaion = theQuery.getResultList();

		return tiposIdentificaion;
	}

	@Override
	public TipoIdentificacion findById(int id) {
		Session currentSession = entityManager.unwrap(Session.class);

		TipoIdentificacion tipoIdentificacion = currentSession.get(TipoIdentificacion.class, id);

		return tipoIdentificacion;
	}

	@Override
	public TipoIdentificacion findByNombre(String tipo_identificacion) {
		Session currentSession = entityManager.unwrap(Session.class);

		TipoIdentificacion tipoIdentificacion = currentSession.get(TipoIdentificacion.class, tipo_identificacion);

		return tipoIdentificacion;
	}

	@Override
	public void save(TipoIdentificacion tipoIdentificacion) {
		Session currentSession = entityManager.unwrap(Session.class);

		currentSession.saveOrUpdate(tipoIdentificacion);
	}

	@Override
	public void deleteById(int id) {
		Session currentSession = entityManager.unwrap(Session.class);

		Query<TipoIdentificacion> theQuery = currentSession
				.createQuery("delete from TipoIdentificacion where id=:idTipoIdentificacion");

		theQuery.setParameter("idTipoIdentificacion", id);
		theQuery.executeUpdate();
	}

	@Override
	public void update(int id, TipoIdentificacion tipoIdentificacion) {
		// TODO Auto-generated method stub

	}

}