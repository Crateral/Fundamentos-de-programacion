package com.co.nttdata.ecommerce.servicesImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.co.nttdata.ecommerce.dao.ITipoIdentificacionDAO;
import com.co.nttdata.ecommerce.entity.TipoIdentificacion;
import com.co.nttdata.ecommerce.service.ITipoIdentificacionService;

@Service
public class TipoIdentificacionServicesImpl implements ITipoIdentificacionService {

	@Autowired
	private ITipoIdentificacionDAO tipoIdentificacionDAO;

	@Override
	public List<TipoIdentificacion> findAll() {
		List<TipoIdentificacion> listaTiposIdentificacion = tipoIdentificacionDAO.findAll();
		return listaTiposIdentificacion;
	}

	@Override
	public TipoIdentificacion findById(int id) {
		TipoIdentificacion tipoIdentificacion = tipoIdentificacionDAO.findById(id);
		return tipoIdentificacion;
	}

	@Override
	public void save(TipoIdentificacion tipoIdentificacion) {
		tipoIdentificacionDAO.save(tipoIdentificacion);

	}

	@Override
	public void deleteById(int id) {
		tipoIdentificacionDAO.deleteById(id);
	}

	@Override
	public TipoIdentificacion findByNombre(String nombre) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(int id, TipoIdentificacion tipoIdentificacion) {
		// TODO Auto-generated method stub
		
	}



}
