package com.co.nttdata.ecommerce.dao;

import java.util.List;

import com.co.nttdata.ecommerce.entity.TipoIdentificacion;

public interface ITipoIdentificacionDAO {

	public List<TipoIdentificacion> findAll();
    public TipoIdentificacion findById(int id);
    public TipoIdentificacion findByNombre(String nombre);
    public void save(TipoIdentificacion tipoIdentificacion);
    public void deleteById(int id);
    public void update(int id, TipoIdentificacion tipoIdentificacion);
	
}
