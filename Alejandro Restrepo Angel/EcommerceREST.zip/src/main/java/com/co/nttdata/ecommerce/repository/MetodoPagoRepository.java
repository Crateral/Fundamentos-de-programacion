package com.co.nttdata.ecommerce.repository;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.co.nttdata.ecommerce.dao.IMetodoPagoDAO;
import com.co.nttdata.ecommerce.entity.MetodoPago;

@Repository
public class MetodoPagoRepository implements IMetodoPagoDAO {

	@Autowired
	private EntityManager entityManager;

	@Override
	public List<MetodoPago> findAll() {
		Session currentSession = entityManager.unwrap(Session.class);

		Query<MetodoPago> theQuery = currentSession.createQuery("from MetodoPago", MetodoPago.class);

		List<MetodoPago> metodosPago = theQuery.getResultList();

		return metodosPago;
	}

	@Override
	public MetodoPago findById(int id) {
		Session currentSession = entityManager.unwrap(Session.class);

		MetodoPago metodoPago = currentSession.get(MetodoPago.class, id);

		return metodoPago;
	}

	@Override
	public MetodoPago findByMetodo(String metodo_pago) {
		Session currentSession = entityManager.unwrap(Session.class);

		MetodoPago metodoPago = currentSession.get(MetodoPago.class, metodo_pago);

		return metodoPago;
	}

	@Override
	public void save(MetodoPago metodoPago) {
		Session currentSession = entityManager.unwrap(Session.class);

		currentSession.saveOrUpdate(metodoPago);
	}

	@Override
	public void deleteById(int id) {
		Session currentSession = entityManager.unwrap(Session.class);

		Query<MetodoPago> theQuery = currentSession.createQuery("delete from MetodoPago where id=:idMetodoPago");

		theQuery.setParameter("idMetodoPago", id);
		theQuery.executeUpdate();
	}

	@Override
	public void update(int id, MetodoPago metodoPago) {
		// TODO Auto-generated method stub

	}

}