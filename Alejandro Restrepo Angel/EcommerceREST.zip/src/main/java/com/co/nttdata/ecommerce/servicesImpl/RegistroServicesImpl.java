package com.co.nttdata.ecommerce.servicesImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.co.nttdata.ecommerce.dao.IRegistroDAO;
import com.co.nttdata.ecommerce.entity.Registro;
import com.co.nttdata.ecommerce.service.IRegistroService;

@Service
public class RegistroServicesImpl implements IRegistroService {

	@Autowired
	private IRegistroDAO registroDAO;

	@Override
	public List<Registro> findAll() {
		List<Registro> listaRegistros = registroDAO.findAll();
		return listaRegistros;
	}

	@Override
	public Registro findById(int id) {
		Registro registro = registroDAO.findById(id);
		return registro;
	}

	@Override
	public void save(Registro registro) {
		registroDAO.save(registro);

	}

	@Override
	public void deleteById(int id) {
		registroDAO.deleteById(id);
	}

	@Override
	public Registro findByUsuario(String nombreUsuario) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(int id, Registro usuario) {
		// TODO Auto-generated method stub
		
	}



}
