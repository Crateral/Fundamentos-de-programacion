package com.co.nttdata.ecommerce.dao;

import java.util.List;

import com.co.nttdata.ecommerce.entity.Usuario;

public interface IUsuarioDAO {

	public List<Usuario> findAll();
    public Usuario findById(int id);
    public Usuario findByNombre(String nombre);
    public void save(Usuario usuario);
    public void deleteById(int id);
    public void update(int id, Usuario usuario);
	
}
