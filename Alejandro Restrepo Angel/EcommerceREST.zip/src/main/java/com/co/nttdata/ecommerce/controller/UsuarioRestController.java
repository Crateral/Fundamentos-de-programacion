package com.co.nttdata.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.co.nttdata.ecommerce.entity.Usuario;
import com.co.nttdata.ecommerce.service.IUsuarioService;

@CrossOrigin(origins = "http://localhost:9090")

@RestController
@RequestMapping("/api")

public class UsuarioRestController {

    @Autowired
    private IUsuarioService usuarioService;

    @GetMapping("/usuarios")
    public List<Usuario> findAll(){
        return usuarioService.findAll();
    }

    @GetMapping("/usuarios/{usuarioId}")
    public Usuario getUsuario(@PathVariable int usuarioId){
    	Usuario usuario = usuarioService.findById(usuarioId);
        if(usuario == null) {
            throw new RuntimeException("No se encontró ningún usuario con el id - " + usuarioId);
        }
        return usuario;
    }

    @PostMapping("/usuarios")
    public Usuario addUsuario(@RequestBody Usuario usuario) {
    	usuario.setId(0);
    	usuarioService.save(usuario);
        return usuario;

    }

    @PutMapping("/usuarios")
    public Usuario updateUsuario(@RequestBody Usuario usuario) {
    	usuarioService.save(usuario);
        return usuario;
    }

    @DeleteMapping("usuarios/{usuarioId}")
    public String deleteUsuario(@PathVariable int usuarioId) {
    	Usuario usuario = usuarioService.findById(usuarioId);
        if(usuario == null) {
            throw new RuntimeException("No se encontró ningún usuario con el id - " + usuarioId);
        }
        usuarioService.deleteById(usuarioId);
        return "Borrado por id de usuario - " + usuarioId;
    }

}