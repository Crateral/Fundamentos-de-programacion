package com.co.nttdata.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.co.nttdata.ecommerce.entity.Compra;
import com.co.nttdata.ecommerce.service.ICompraService;

@CrossOrigin(origins = "http://localhost:9090")

@RestController
@RequestMapping("/api")

public class CompraRestController {

    @Autowired
    private ICompraService compraService;

    @GetMapping("/compras")
    public List<Compra> findAll(){
        return compraService.findAll();
    }

    @GetMapping("/compras/{compraId}")
    public Compra getCompra(@PathVariable int compraId){
    	Compra compra = compraService.findById(compraId);
        if(compra == null) {
            throw new RuntimeException("No se encontró ninguns compra con el id - " + compraId);
        }
        return compra;
    }

    @PostMapping("/compras")
    public Compra addCompra(@RequestBody Compra compra) {
    	compra.setId(0);
    	compraService.save(compra);
        return compra;

    }

    @PutMapping("/compras")
    public Compra updateCompra(@RequestBody Compra compra) {
    	compraService.save(compra);
        return compra;
    }

    @DeleteMapping("compras/{compraId}")
    public String deleteCompra(@PathVariable int compraId) {
    	Compra compra = compraService.findById(compraId);
        if(compra == null) {
            throw new RuntimeException("No se encontró ninguna compra con el id - " + compraId);
        }
        compraService.deleteById(compraId);
        return "Borrado por el id de compra - " + compraId;
    }

}