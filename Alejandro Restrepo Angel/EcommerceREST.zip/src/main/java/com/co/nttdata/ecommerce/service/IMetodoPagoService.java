package com.co.nttdata.ecommerce.service;

import java.util.List;

import com.co.nttdata.ecommerce.entity.MetodoPago;

public interface IMetodoPagoService {

	public List<MetodoPago> findAll();
    public MetodoPago findById(int id);
    public MetodoPago findByMetodo(String nombreMetodo);
    public void save(MetodoPago metodoPago);
    public void deleteById(int id);
    public void update(int id, MetodoPago metodoPago);
	
}
