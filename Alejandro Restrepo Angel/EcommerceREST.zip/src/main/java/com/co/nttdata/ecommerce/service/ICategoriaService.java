package com.co.nttdata.ecommerce.service;

import java.util.List;

import com.co.nttdata.ecommerce.entity.Categoria;

public interface ICategoriaService {

	public List<Categoria> findAll();
    public Categoria findById(int id);
    public Categoria findByNombre(String nombre);
    public void save(Categoria categoria);
    public void deleteById(int id);
    public void update(int id, Categoria categoria);
	
}
