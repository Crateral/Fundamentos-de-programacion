package com.co.nttdata.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.co.nttdata.ecommerce.entity.Empresa;
import com.co.nttdata.ecommerce.service.IEmpresaService;

@CrossOrigin(origins = "http://localhost:9090")

@RestController
@RequestMapping("/api")

public class EmpresaRestController {

    @Autowired
    private IEmpresaService empresaService;

    @GetMapping("/empresas")
    public List<Empresa> findAll(){
        return empresaService.findAll();
    }

    @GetMapping("/empresas/{empresaId}")
    public Empresa getEmpresa(@PathVariable int empresaId){
    	Empresa empresa = empresaService.findById(empresaId);
        if(empresa == null) {
            throw new RuntimeException("No se encontró ninguna empresa con el id - " + empresaId);
        }
        return empresa;
    }

    @PostMapping("/empresas")
    public Empresa addEmpresa(@RequestBody Empresa empresa) {
    	empresa.setId(0);
    	empresaService.save(empresa);
        return empresa;

    }

    @PutMapping("/empresas")
    public Empresa updateEmpresa(@RequestBody Empresa empresa) {
    	empresaService.save(empresa);
        return empresa;
    }

    @DeleteMapping("empresas/{empresaId}")
    public String deleteEmpresa(@PathVariable int empresaId) {
    	Empresa empresa = empresaService.findById(empresaId);
        if(empresa == null) {
            throw new RuntimeException("No se encontró ninguna empresa con el id - " + empresaId);
        }
        empresaService.deleteById(empresaId);
        return "Borrado por el id de la empresa - " + empresaId;
    }

}