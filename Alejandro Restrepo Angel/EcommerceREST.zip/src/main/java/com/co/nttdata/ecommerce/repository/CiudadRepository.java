package com.co.nttdata.ecommerce.repository;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.co.nttdata.ecommerce.dao.ICiudadDAO;
import com.co.nttdata.ecommerce.entity.Ciudad;

@Repository
public class CiudadRepository implements ICiudadDAO {

	@Autowired
	private EntityManager entityManager;

	@Override
	public List<Ciudad> findAll() {
		Session currentSession = entityManager.unwrap(Session.class);

		Query<Ciudad> theQuery = currentSession.createQuery("from Ciudad", Ciudad.class);

		List<Ciudad> ciudades = theQuery.getResultList();

		return ciudades;
	}

	@Override
	public Ciudad findById(int id) {
		Session currentSession = entityManager.unwrap(Session.class);

		Ciudad ciudad = currentSession.get(Ciudad.class, id);

		return ciudad;
	}

	@Override
	public Ciudad findByNombre(String ciudad) {
		Session currentSession = entityManager.unwrap(Session.class);

		Ciudad c = currentSession.get(Ciudad.class, ciudad);

		return c;
	}

	@Override
	public void save(Ciudad ciudad) {
		Session currentSession = entityManager.unwrap(Session.class);

		currentSession.saveOrUpdate(ciudad);
	}

	@Override
	public void deleteById(int id) {
		Session currentSession = entityManager.unwrap(Session.class);

		Query<Ciudad> theQuery = currentSession.createQuery("delete from Ciudad where id=:idCiudad");

		theQuery.setParameter("idCiudad", id);
		theQuery.executeUpdate();
	}

	@Override
	public void update(int id, Ciudad ciudad) {
		// TODO Auto-generated method stub

	}

}