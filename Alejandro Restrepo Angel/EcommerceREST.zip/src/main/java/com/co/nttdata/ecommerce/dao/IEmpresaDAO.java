package com.co.nttdata.ecommerce.dao;

import java.util.List;

import com.co.nttdata.ecommerce.entity.Empresa;

public interface IEmpresaDAO {

	public List<Empresa> findAll();
    public Empresa findById(int id);
    public Empresa findByNit(String nit);
    public void save(Empresa empresa);
    public void deleteById(int id);
    public void update(int id, Empresa empresa);
	
}
