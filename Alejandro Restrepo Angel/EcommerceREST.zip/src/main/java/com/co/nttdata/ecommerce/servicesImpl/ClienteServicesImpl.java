package com.co.nttdata.ecommerce.servicesImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.co.nttdata.ecommerce.dao.IClienteDAO;
import com.co.nttdata.ecommerce.entity.Cliente;
import com.co.nttdata.ecommerce.service.IClienteService;

@Service
public class ClienteServicesImpl implements IClienteService {

	@Autowired
	private IClienteDAO clienteDAO;

	@Override
	public List<Cliente> findAll() {
		List<Cliente> listaClientes = clienteDAO.findAll();
		return listaClientes;
	}

	@Override
	public Cliente findById(int id) {
		Cliente cliente = clienteDAO.findById(id);
		return cliente;
	}

	@Override
	public void save(Cliente cliente) {
		clienteDAO.save(cliente);

	}

	@Override
	public void deleteById(int id) {
		clienteDAO.deleteById(id);
	}

	@Override
	public Cliente findByCorreo(String correo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(int id, Cliente cliente) {
		// TODO Auto-generated method stub
		
	}
	
}
