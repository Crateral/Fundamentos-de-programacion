package com.co.nttdata.ecommerce.repository;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.co.nttdata.ecommerce.dao.IProductoDAO;
import com.co.nttdata.ecommerce.entity.Producto;

@Repository
public class ProductoRepository implements IProductoDAO {

	@Autowired
	private EntityManager entityManager;

	@Override
	public List<Producto> findAll() {
		Session currentSession = entityManager.unwrap(Session.class);

		Query<Producto> theQuery = currentSession.createQuery("from Producto", Producto.class);

		List<Producto> productos = theQuery.getResultList();

		return productos;
	}

	@Override
	public Producto findById(int id) {
		Session currentSession = entityManager.unwrap(Session.class);

		Producto producto = currentSession.get(Producto.class, id);

		return producto;
	}

	@Override
	public Producto findByNombre(String producto) {
		Session currentSession = entityManager.unwrap(Session.class);

		Producto p = currentSession.get(Producto.class, producto);

		return p;
	}

	@Override
	public void save(Producto producto) {
		Session currentSession = entityManager.unwrap(Session.class);

		currentSession.saveOrUpdate(producto);
	}

	@Override
	public void deleteById(int id) {
		Session currentSession = entityManager.unwrap(Session.class);

		Query<Producto> theQuery = currentSession.createQuery("delete from Producto where id=:idProducto");

		theQuery.setParameter("idProducto", id);
		theQuery.executeUpdate();
	}

	@Override
	public void update(int id, Producto producto) {
		// TODO Auto-generated method stub

	}

	@Override
	public Double DefinirValorDescuento(int id_producto) {
		// TODO Auto-generated method stub
		return null;
	}

}