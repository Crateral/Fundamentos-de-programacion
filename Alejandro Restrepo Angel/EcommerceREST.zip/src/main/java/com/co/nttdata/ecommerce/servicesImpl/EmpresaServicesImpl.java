package com.co.nttdata.ecommerce.servicesImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.co.nttdata.ecommerce.dao.IEmpresaDAO;
import com.co.nttdata.ecommerce.entity.Empresa;
import com.co.nttdata.ecommerce.service.IEmpresaService;

@Service
public class EmpresaServicesImpl implements IEmpresaService {

	@Autowired
	private IEmpresaDAO empresaDAO;

	@Override
	public List<Empresa> findAll() {
		List<Empresa> listaEmpresas = empresaDAO.findAll();
		return listaEmpresas;
	}

	@Override
	public Empresa findById(int id) {
		Empresa empresa = empresaDAO.findById(id);
		return empresa;
	}

	@Override
	public void save(Empresa empresa) {
		empresaDAO.save(empresa);

	}

	@Override
	public void deleteById(int id) {
		empresaDAO.deleteById(id);
	}

	@Override
	public Empresa findByNit(String nit) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(int id, Empresa empresa) {
		// TODO Auto-generated method stub
		
	}



}
