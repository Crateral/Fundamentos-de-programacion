package com.co.nttdata.ecommerce.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

@Entity
@Table(name="tbl_compras", schema="sc_ecommerce")
@NamedQuery(name="Compra.findAll", query="SELECT c FROM Compra c")
public class Compra implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;

	private Integer cantidad;

	private double valor;

	//bi-directional many-to-one association to CarritoCompra
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name="id_carrito_compras")
	@JsonProperty(access = Access.WRITE_ONLY)
	private CarritoDeCompras carritoCompra;

	//bi-directional many-to-one association to Producto
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name="id_producto")
	@JsonProperty(access = Access.WRITE_ONLY)
	private Producto producto;

	public Compra() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCantidad() {
		return this.cantidad;
	}

	public void setCantidad(Integer cantidad) {
		this.cantidad = cantidad;
	}

	public double getValor() {
		return this.valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	public CarritoDeCompras getCarritoCompra() {
		return this.carritoCompra;
	}

	public void setCarritoCompra(CarritoDeCompras carritoCompra) {
		this.carritoCompra = carritoCompra;
	}

	public Producto getProducto() {
		return this.producto;
	}

	public void setProducto(Producto producto) {
		this.producto = producto;
	}

	@Override
	public String toString() {
		return "Compra [id=" + this.id 
				+ ", cantidad=" + this.cantidad 
				+ ", valor=" + this.valor 
				+ ", carritoCompra=" + this.carritoCompra
				+ ", producto=" + this.producto + "]";
	}
	
}