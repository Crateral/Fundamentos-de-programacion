package com.co.nttdata.ecommerce.service;

import java.util.List;

import com.co.nttdata.ecommerce.entity.Marca;

public interface IMarcaService {

	public List<Marca> findAll();
    public Marca findById(int id);
    public Marca findByNombre(String nombre);
    public void save(Marca marca);
    public void deleteById(int id);
    public void update(int id, Marca marca);
    
}
