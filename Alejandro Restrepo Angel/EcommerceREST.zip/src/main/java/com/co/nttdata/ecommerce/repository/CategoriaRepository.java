package com.co.nttdata.ecommerce.repository;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.co.nttdata.ecommerce.dao.ICategoriaDAO;
import com.co.nttdata.ecommerce.entity.Categoria;
import com.co.nttdata.ecommerce.entity.Ciudad;

@Repository
public class CategoriaRepository implements ICategoriaDAO {

	@Autowired
	private EntityManager entityManager;

	@Override
	public List<Categoria> findAll() {
		Session currentSession = entityManager.unwrap(Session.class);

		Query<Categoria> theQuery = currentSession.createQuery("from Categoria", Categoria.class);

		List<Categoria> categorias = theQuery.getResultList();

		return categorias;
	}

	@Override
	public Categoria findById(int id) {
		Session currentSession = entityManager.unwrap(Session.class);

		Categoria categoria = currentSession.get(Categoria.class, id);

		return categoria;
	}

	@Override
	public Categoria findByNombre(String categoria) {
		Session currentSession = entityManager.unwrap(Session.class);

		Categoria c = currentSession.get(Categoria.class, categoria);

		return c;
	}

	@Override
	public void save(Categoria categoria) {
		Session currentSession = entityManager.unwrap(Session.class);

		currentSession.saveOrUpdate(categoria);
	}

	@Override
	public void deleteById(int id) {
		Session currentSession = entityManager.unwrap(Session.class);

		Query<Categoria> theQuery = currentSession.createQuery("delete from Categoria where id=:idCategoria");

		theQuery.setParameter("idCategoria", id);
		theQuery.executeUpdate();
	}

	@Override
	public void update(int id, Categoria marca) {
		// TODO Auto-generated method stub

	}

}