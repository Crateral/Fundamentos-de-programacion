package com.co.nttdata.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.co.nttdata.ecommerce.entity.CarritoDeCompras;
import com.co.nttdata.ecommerce.service.ICarritoDeComprasService;

@CrossOrigin(origins = "http://localhost:9090")

@RestController
@RequestMapping("/api")

public class CarritoDeComprasRestController {

    @Autowired
    private ICarritoDeComprasService carritoDeComprasService;

    @GetMapping("/carritosdecompras")
    public List<CarritoDeCompras> findAll(){
        return carritoDeComprasService.findAll();
    }

    @GetMapping("/carritosdecompras/{carritosdecomprasId}")
    public CarritoDeCompras getCarritoDeCompras(@PathVariable int carritosdecomprasId){
    	CarritoDeCompras carritoDeCompras = carritoDeComprasService.findById(carritosdecomprasId);
        if(carritoDeCompras == null) {
            throw new RuntimeException("No se encontró ningún carrito de compras con el id - " + carritosdecomprasId);
        }
        return carritoDeCompras;
    }

    @PostMapping("/carritosdecompras")
    public CarritoDeCompras addCarritoDeCompras(@RequestBody CarritoDeCompras carritoDeCompras) {
    	carritoDeCompras.setId(0);
    	carritoDeComprasService.save(carritoDeCompras);
        return carritoDeCompras;

    }

    @PutMapping("/carritosdecompras")
    public CarritoDeCompras updateCarritoDeCompras(@RequestBody CarritoDeCompras carritoDeCompras) {
    	carritoDeComprasService.save(carritoDeCompras);
        return carritoDeCompras;
    }

    @DeleteMapping("carritosdecompras/{carritosdecomprasId}")
    public String deleteCarritoDeCompras(@PathVariable int carritosdecomprasId) {
    	CarritoDeCompras carritoDeCompras = carritoDeComprasService.findById(carritosdecomprasId);
        if(carritoDeCompras == null) {
            throw new RuntimeException("No se encontró ningún carrito de compras con el id - " + carritosdecomprasId);
        }
        carritoDeComprasService.deleteById(carritosdecomprasId);
        return "Borrado por id de carrito de compras - " + carritosdecomprasId;
    }

}