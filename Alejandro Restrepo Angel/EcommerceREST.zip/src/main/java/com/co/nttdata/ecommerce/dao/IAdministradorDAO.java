
package com.co.nttdata.ecommerce.dao;

import java.util.List;

import com.co.nttdata.ecommerce.entity.Administrador;

public interface IAdministradorDAO {

	public List<Administrador> findAll();

	public Administrador findById(int id);

	public Administrador findByCorreo(String correo);

	public void save(Administrador administrador);

	public void deleteById(int id);

	public void update(int id, Administrador administrador);

}
