package com.co.nttdata.ecommerce.entity;

import java.io.Serializable;
import javax.persistence.*;

import java.util.List;

@Entity
@Table(name="tbl_tipo_identificaciones", schema="sc_ecommerce")
@NamedQuery(name="TipoIdentificacion.findAll", query="SELECT t FROM TipoIdentificacion t")
public class TipoIdentificacion implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;

	private String descripcion;

	@Column(name="tipo_identificacion")
	private String tipoIdentificacion;

	//bi-directional many-to-one association to Administrador
	@OneToMany(mappedBy="tipoIdentificacion", cascade = CascadeType.ALL)
	private List<Administrador> administradores;

	//bi-directional many-to-one association to Cliente
	@OneToMany(mappedBy="tipoIdentificacion", cascade = CascadeType.ALL)
	private List<Cliente> clientes;

	public TipoIdentificacion() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getTipoIdentificacion() {
		return this.tipoIdentificacion;
	}

	public void setTipoIdentificacion(String tipoIdentificacion) {
		this.tipoIdentificacion = tipoIdentificacion;
	}

	public List<Administrador> getAdministradores() {
		return this.administradores;
	}

	public void setAdministradores(List<Administrador> administradores) {
		this.administradores = administradores;
	}

	public Administrador addAdministrador(Administrador administrador) {
		getAdministradores().add(administrador);
		administrador.setTipoIdentificacion(this);

		return administrador;
	}

	public Administrador removeAdministrador(Administrador administrador) {
		getAdministradores().remove(administrador);
		administrador.setTipoIdentificacion(null);

		return administrador;
	}

	public List<Cliente> getClientes() {
		return this.clientes;
	}

	public void setClientes(List<Cliente> clientes) {
		this.clientes = clientes;
	}

	public Cliente addCliente(Cliente cliente) {
		getClientes().add(cliente);
		cliente.setTipoIdentificacion(this);

		return cliente;
	}

	public Cliente removeCliente(Cliente cliente) {
		getClientes().remove(cliente);
		cliente.setTipoIdentificacion(null);

		return cliente;
	}

	@Override
	public String toString() {
		return "TipoIdentificacion [id=" + this.id 
				+ ", descripcion=" + this.descripcion 
				+ ", tipoIdentificacion=" + this.tipoIdentificacion + "]";
	}

}