package com.co.nttdata.ecommerce.repository;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.co.nttdata.ecommerce.dao.ICarritoDeComprasDAO;
import com.co.nttdata.ecommerce.entity.CarritoDeCompras;

@Repository
public class CarritoDeComprasRepository implements ICarritoDeComprasDAO {

	@Autowired
	private EntityManager entityManager;

	@Override
	public List<CarritoDeCompras> findAll() {
		Session currentSession = entityManager.unwrap(Session.class);

		Query<CarritoDeCompras> theQuery = currentSession.createQuery("from CarritoDeCompras", CarritoDeCompras.class);

		List<CarritoDeCompras> carritoDeCompras = theQuery.getResultList();

		return carritoDeCompras;
	}

	@Override
	public CarritoDeCompras findById(int id) {
		Session currentSession = entityManager.unwrap(Session.class);

		CarritoDeCompras carritoDeCompras = currentSession.get(CarritoDeCompras.class, id);

		return carritoDeCompras;
	}

	@Override
	public void save(CarritoDeCompras carritoDeCompras) {
		Session currentSession = entityManager.unwrap(Session.class);

		currentSession.saveOrUpdate(carritoDeCompras);
	}

	@Override
	public void deleteById(int id) {
		Session currentSession = entityManager.unwrap(Session.class);

		Query<CarritoDeCompras> theQuery = currentSession
				.createQuery("delete from CarritoDeCompras where id=:idCarritoDeCompras");

		theQuery.setParameter("idCarritoDeCompras", id);
		theQuery.executeUpdate();
	}

	@Override
	public void update(int id, CarritoDeCompras carritoDeCompras) {
		// TODO Auto-generated method stub

	}

	@Override
	public Double calcularSubtotalSinIva(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Double calcularSubtotalConIva(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}