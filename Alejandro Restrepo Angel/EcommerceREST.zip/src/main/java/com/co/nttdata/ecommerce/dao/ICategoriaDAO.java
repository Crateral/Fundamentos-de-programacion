package com.co.nttdata.ecommerce.dao;

import java.util.List;

import com.co.nttdata.ecommerce.entity.Categoria;

public interface ICategoriaDAO {
	
	public List<Categoria> findAll();
    public Categoria findById(int id);
    public Categoria findByNombre(String nombre);
    public void save(Categoria categoria);
    public void deleteById(int id);
    public void update(int id, Categoria categoria);
}
