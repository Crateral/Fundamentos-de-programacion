package com.co.nttdata.ecommerce.repository;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.co.nttdata.ecommerce.dao.IClienteDAO;
import com.co.nttdata.ecommerce.entity.Cliente;

@Repository
public class ClienteRepository implements IClienteDAO {

	@Autowired
	private EntityManager entityManager;

	@Override
	public List<Cliente> findAll() {
		Session currentSession = entityManager.unwrap(Session.class);

		Query<Cliente> theQuery = currentSession.createQuery("from Cliente", Cliente.class);

		List<Cliente> clientes = theQuery.getResultList();

		return clientes;
	}

	@Override
	public Cliente findById(int id) {
		Session currentSession = entityManager.unwrap(Session.class);

		Cliente cliente = currentSession.get(Cliente.class, id);

		return cliente;
	}

	@Override
	public Cliente findByCorreo(String correo) {
		Session currentSession = entityManager.unwrap(Session.class);

		Cliente cliente = currentSession.get(Cliente.class, correo);

		return cliente;
	}

	@Override
	public void save(Cliente cliente) {
		Session currentSession = entityManager.unwrap(Session.class);

		currentSession.saveOrUpdate(cliente);
	}

	@Override
	public void deleteById(int id) {
		Session currentSession = entityManager.unwrap(Session.class);

		Query<Cliente> theQuery = currentSession.createQuery("delete from Cliente where id=:idCliente");

		theQuery.setParameter("idCliente", id);
		theQuery.executeUpdate();
	}

	@Override
	public void update(int id, Cliente marca) {
		// TODO Auto-generated method stub

	}

}