package com.co.nttdata.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.co.nttdata.ecommerce.entity.Administrador;
import com.co.nttdata.ecommerce.service.IAdministradorService;

//@CrossOrigin(origins = "http://localhost:9090")

@RestController

@RequestMapping("/api")

public class AdministradorRestController {

	@Autowired
	private IAdministradorService administradorService;

	@GetMapping("/administradores")
	public List<Administrador> findAll() {
		List<Administrador> administradores = administradorService.findAll();
		administradores.size();
		return administradores;
	}

	@GetMapping("/administradores/{administradorId}")
	public Administrador getAdministrador(@PathVariable int administradorId) {
		Administrador administrador = administradorService.findById(administradorId);
		if (administrador == null) {
			throw new RuntimeException("No se encontró ningún administrador con el id - " + administradorId);
		}
		return administrador;
	}

	@PostMapping("/administradores")
	public Administrador addAdministrador(@RequestBody Administrador administrador) {
		administrador.setId(0);
		administradorService.save(administrador);
		return administrador;

	}

	@PutMapping("/administradores")
	public Administrador updateAdministrador(@RequestBody Administrador administrador) {
		administradorService.save(administrador);
		return administrador;
	}

	@DeleteMapping("administradores/{administradorId}")
	public String deleteAdministrador(@PathVariable int administradorId) {
		Administrador administrador = administradorService.findById(administradorId);
		if (administrador == null) {
			throw new RuntimeException("No se encontró ningún administrador con el id - " + administradorId);
		}
		administradorService.deleteById(administradorId);
		return "Borrado por id de administrador - " + administradorId;
	}

}
