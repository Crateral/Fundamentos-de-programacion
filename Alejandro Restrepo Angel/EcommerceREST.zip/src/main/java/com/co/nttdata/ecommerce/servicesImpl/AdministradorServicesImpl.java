
package com.co.nttdata.ecommerce.servicesImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.co.nttdata.ecommerce.dao.IAdministradorDAO;
import com.co.nttdata.ecommerce.entity.Administrador;
import com.co.nttdata.ecommerce.service.IAdministradorService;

@Service
public class AdministradorServicesImpl implements IAdministradorService {

	@Autowired
	private IAdministradorDAO administradorDAO;

	@Override
	public List<Administrador> findAll() {
		List<Administrador> listaAdmnistradores = administradorDAO.findAll();
		return listaAdmnistradores;
	}

	@Override
	public Administrador findById(int id) {
		Administrador administrador = administradorDAO.findById(id);
		return administrador;
	}

	@Override
	public void save(Administrador administrador) {
		administradorDAO.save(administrador);

	}

	@Override
	public void deleteById(int id) {
		administradorDAO.deleteById(id);
	}

	@Override public Administrador findByCorreo(String correo) { return null; }

	@Override public void update(int id, Administrador administrador) { }

}
