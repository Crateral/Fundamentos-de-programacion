package com.co.nttdata.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.co.nttdata.ecommerce.entity.Registro;
import com.co.nttdata.ecommerce.service.IRegistroService;

@CrossOrigin(origins = "http://localhost:9090")

@RestController
@RequestMapping("/api")

public class RegistroRestController {

    @Autowired
    private IRegistroService registroService;

    @GetMapping("/registros")
    public List<Registro> findAll(){
        return registroService.findAll();
    }

    @GetMapping("/registros/{registrorId}")
    public Registro getRegistro(@PathVariable int registrorId){
    	Registro registro = registroService.findById(registrorId);
        if(registro == null) {
            throw new RuntimeException("No se encontró ningún registro con el id - " + registrorId);
        }
        return registro;
    }

    @PostMapping("/registros")
    public Registro addAdministrador(@RequestBody Registro registro) {
    	registro.setId(0);
    	registroService.save(registro);
        return registro;

    }

    @PutMapping("/registros")
    public Registro updateRegistro(@RequestBody Registro registro) {
    	registroService.save(registro);
        return registro;
    }

    @DeleteMapping("registros/{registrorId}")
    public String deleteRegistro(@PathVariable int registrorId) {
    	Registro registro = registroService.findById(registrorId);
        if(registro == null) {
            throw new RuntimeException("No se encontró ningún registro con el id - " + registrorId);
        }
        registroService.deleteById(registrorId);
        return "Borrado por id de registro - " + registrorId;
    }

}