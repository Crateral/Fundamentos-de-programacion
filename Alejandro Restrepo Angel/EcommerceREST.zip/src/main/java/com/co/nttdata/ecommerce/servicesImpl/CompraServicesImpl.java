package com.co.nttdata.ecommerce.servicesImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.co.nttdata.ecommerce.dao.ICompraDAO;
import com.co.nttdata.ecommerce.entity.Compra;
import com.co.nttdata.ecommerce.entity.Producto;
import com.co.nttdata.ecommerce.service.ICompraService;

@Service
public class CompraServicesImpl implements ICompraService {

	@Autowired
	private ICompraDAO compraDAO;

	@Override
	public List<Compra> findAll() {
		List<Compra> listaCompras = compraDAO.findAll();
		return listaCompras;
	}

	@Override
	public Compra findById(int id) {
		Compra compra = compraDAO.findById(id);
		return compra;
	}

	@Override
	public void save(Compra compra) {
		compraDAO.save(compra);

	}

	@Override
	public void deleteById(int id) {
		compraDAO.deleteById(id);
	}

	@Override
	public Compra findByCarrito(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(int id, Compra compra) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Double calcularValor(int id, int cantidad) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Producto agregarProductoCompra(int id, int cantidad) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Producto devolverProductoCompra(int id, int cantidad) {
		// TODO Auto-generated method stub
		return null;
	}

}
