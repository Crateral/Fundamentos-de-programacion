package com.co.nttdata.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.co.nttdata.ecommerce.entity.TipoIdentificacion;
import com.co.nttdata.ecommerce.service.ITipoIdentificacionService;

@CrossOrigin(origins = "http://localhost:9090")

@RestController
@RequestMapping("/api")

public class TipoIdentificacionRestController {

    @Autowired
    private ITipoIdentificacionService tipoIdentificacionService;

    @GetMapping("/tiposidentificacion")
    public List<TipoIdentificacion> findAll(){
        return tipoIdentificacionService.findAll();
    }

    @GetMapping("/tiposidentificacion/{tipoIdentificacionId}")
    public TipoIdentificacion getTipoIdentificacion(@PathVariable int tipoIdentificacionId){
    	TipoIdentificacion tipoIdentificacion = tipoIdentificacionService.findById(tipoIdentificacionId);
        if(tipoIdentificacion == null) {
            throw new RuntimeException("No se encontró ningún tipo de identificación con el id - "+tipoIdentificacionId);
        }
        return tipoIdentificacion;
    }

    @PostMapping("/tiposidentificacion")
    public TipoIdentificacion addTipoIdentificacion(@RequestBody TipoIdentificacion tipoIdentificacion) {
    	tipoIdentificacion.setId(0);
    	tipoIdentificacionService.save(tipoIdentificacion);
        return tipoIdentificacion;

    }

    @PutMapping("/tiposidentificacion")
    public TipoIdentificacion updateTipoIdentificacion(@RequestBody TipoIdentificacion tipoIdentificacion) {
    	tipoIdentificacionService.save(tipoIdentificacion);
        return tipoIdentificacion;
    }

    @DeleteMapping("tiposidentificacion/{tipoIdentificacionId}")
    public String deleteTipoIdentificacion(@PathVariable int tipoIdentificacionId) {
    	TipoIdentificacion tipoIdentificacion = tipoIdentificacionService.findById(tipoIdentificacionId);
        if(tipoIdentificacion == null) {
            throw new RuntimeException("No se encontró ningún tipo de identificación  con el id - "+tipoIdentificacionId);
        }
        tipoIdentificacionService.deleteById(tipoIdentificacionId);
        return "Borrado por id de tipo de identificación  - " + tipoIdentificacionId;
    }

}