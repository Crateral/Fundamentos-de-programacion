package com.co.nttdata.ecommerce.servicesImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.co.nttdata.ecommerce.dao.IProductoDAO;
import com.co.nttdata.ecommerce.entity.Producto;
import com.co.nttdata.ecommerce.service.IProductoService;

@Service
public class ProductoServicesImpl implements IProductoService {

	@Autowired
	private IProductoDAO productoDAO;

	@Override
	public List<Producto> findAll() {
		List<Producto> listaProductos = productoDAO.findAll();
		return listaProductos;
	}

	@Override
	public Producto findById(int id) {
		Producto producto = productoDAO.findById(id);
		return producto;
	}

	@Override
	public void save(Producto producto) {
		productoDAO.save(producto);

	}

	@Override
	public void deleteById(int id) {
		productoDAO.deleteById(id);
	}

	@Override
	public Producto findByNombre(String nombre) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(int id, Producto producto) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Double DefinirValorDescuento(int id_producto) {
		// TODO Auto-generated method stub
		return null;
	}



}
