package com.co.nttdata.ecommerce.dao;

import java.util.List;

import com.co.nttdata.ecommerce.entity.Producto;

public interface IProductoDAO {

	public List<Producto> findAll();
    public Producto findById(int id);
    public Producto findByNombre(String nombre);
    public void save(Producto producto);
    public void deleteById(int id);
    public void update(int id, Producto producto);
	
    public Double DefinirValorDescuento(int id_producto);
}
