package com.co.nttdata.ecommerce.service;

import java.util.List;

import com.co.nttdata.ecommerce.entity.Compra;
import com.co.nttdata.ecommerce.entity.Producto;

public interface ICompraService {

	public List<Compra> findAll();
    public Compra findById(int id);
    public Compra findByCarrito(int id);
    public void save(Compra compra);
    public void deleteById(int id);
    public void update(int id, Compra compra);
	
	public Double calcularValor(int id, int cantidad);
	public Producto agregarProductoCompra(int id, int cantidad);
	public Producto devolverProductoCompra(int id, int cantidad);
	
}
