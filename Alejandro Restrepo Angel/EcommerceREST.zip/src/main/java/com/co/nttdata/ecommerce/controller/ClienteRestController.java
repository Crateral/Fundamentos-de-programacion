package com.co.nttdata.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.co.nttdata.ecommerce.entity.Cliente;
import com.co.nttdata.ecommerce.service.IClienteService;

@CrossOrigin(origins = "http://localhost:9090")

@RestController
@RequestMapping("/api")

public class ClienteRestController {

    @Autowired
    private IClienteService clienteService;

    @GetMapping("/clientes")
    public List<Cliente> findAll(){
        return clienteService.findAll();
    }

    @GetMapping("/clientes/{clienteId}")
    public Cliente getCliente(@PathVariable int clienteId){
    	Cliente cliente = clienteService.findById(clienteId);
        if(cliente == null) {
            throw new RuntimeException("No se encontró ningún cliente con el id - "+ clienteId);
        }
        return cliente;
    }

    @PostMapping("/clientes")
    public Cliente addCliente(@RequestBody Cliente cliente) {
    	cliente.setId(0);
    	clienteService.save(cliente);
        return cliente;

    }

    @PutMapping("/clientes")
    public Cliente updateCliente(@RequestBody Cliente cliente) {
    	clienteService.save(cliente);
        return cliente;
    }

    @DeleteMapping("clientes/{clienteId}")
    public String deleteCliente(@PathVariable int clienteId) {
    	Cliente cliente = clienteService.findById(clienteId);
        if(cliente == null) {
            throw new RuntimeException("No se encontró ningún cliente con el id - " + clienteId);
        }
        clienteService.deleteById(clienteId);
        return "Borrado por el id del cliente - "+ clienteId;
    }

}