package com.co.nttdata.ecommerce.repository;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.co.nttdata.ecommerce.dao.IFacturaDAO;
import com.co.nttdata.ecommerce.entity.Factura;

@Repository
public class FacturaRepository implements IFacturaDAO {

	@Autowired
	private EntityManager entityManager;

	@Override
	public List<Factura> findAll() {
		Session currentSession = entityManager.unwrap(Session.class);

		Query<Factura> theQuery = currentSession.createQuery("from Factura", Factura.class);

		List<Factura> facturas = theQuery.getResultList();

		return facturas;
	}

	@Override
	public Factura findById(int id) {
		Session currentSession = entityManager.unwrap(Session.class);

		Factura factura = currentSession.get(Factura.class, id);

		return factura;
	}

	@Override
	public Factura findByCliente(int id_cliente) {
		Session currentSession = entityManager.unwrap(Session.class);

		Factura factura = currentSession.get(Factura.class, id_cliente);

		return factura;
	}

	@Override
	public void save(Factura factura) {
		Session currentSession = entityManager.unwrap(Session.class);

		currentSession.saveOrUpdate(factura);
	}

	@Override
	public void deleteById(int id) {
		Session currentSession = entityManager.unwrap(Session.class);

		Query<Factura> theQuery = currentSession.createQuery("delete from Factura where id=:idFactura");

		theQuery.setParameter("idFactura", id);
		theQuery.executeUpdate();
	}

	@Override
	public void update(int id, Factura marca) {
		// TODO Auto-generated method stub

	}

	@Override
	public Double calcularCostoEnvio(int id_Cliente, int id_CarritoCompra) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Double calcularTotalSinIva(int id_Cliente, int id_CarritoCompra) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Double calcularTotalConIva(int id_Cliente, int id_CarritoCompra) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void imprimirFactura(int id_Factura) {
		// TODO Auto-generated method stub

	}

}