package com.co.nttdata.ecommerce.repository;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.co.nttdata.ecommerce.dao.IMarcaDAO;
import com.co.nttdata.ecommerce.entity.Marca;

@Repository
public class MarcaRepository implements IMarcaDAO {

	@Autowired
	private EntityManager entityManager;

	@Override
	public List<Marca> findAll() {
		Session currentSession = entityManager.unwrap(Session.class);

		Query<Marca> theQuery = currentSession.createQuery("from Marca", Marca.class);

		List<Marca> marcas = theQuery.getResultList();

		return marcas;
	}

	@Override
	public Marca findById(int id) {
		Session currentSession = entityManager.unwrap(Session.class);

		Marca marca = currentSession.get(Marca.class, id);

		return marca;
	}

	@Override
	public Marca findByNombre(String nombre) {
		Session currentSession = entityManager.unwrap(Session.class);

		Marca marca = currentSession.get(Marca.class, nombre);

		return marca;
	}

	@Override
	public void save(Marca marca) {
		Session currentSession = entityManager.unwrap(Session.class);

		currentSession.saveOrUpdate(marca);
	}

	@Override
	public void deleteById(int id) {
		Session currentSession = entityManager.unwrap(Session.class);

		Query<Marca> theQuery = currentSession.createQuery("delete from Marca where id=:idMarca");

		theQuery.setParameter("idMarca", id);
		theQuery.executeUpdate();
	}

	@Override
	public void update(int id, Marca marca) {
		// TODO Auto-generated method stub

	}

}
