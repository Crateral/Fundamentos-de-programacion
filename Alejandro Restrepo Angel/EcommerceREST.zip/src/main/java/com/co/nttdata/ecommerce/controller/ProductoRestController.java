package com.co.nttdata.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.co.nttdata.ecommerce.entity.Producto;
import com.co.nttdata.ecommerce.service.IProductoService;

@CrossOrigin(origins = "http://localhost:9090")

@RestController
@RequestMapping("/api")

public class ProductoRestController {

    @Autowired
    private IProductoService productoService;

    @GetMapping("/productos")
    public List<Producto> findAll(){
        return productoService.findAll();
    }

    @GetMapping("/productos/{productoId}")
    public Producto getProducto(@PathVariable int productoId){
    	Producto producto = productoService.findById(productoId);
        if(producto == null) {
            throw new RuntimeException("No se encontró ningún producto con el id - " + productoId);
        }
        return producto;
    }

    @PostMapping("/productos")
    public Producto addProducto(@RequestBody Producto producto) {
    	producto.setId(0);
    	productoService.save(producto);
        return producto;

    }

    @PutMapping("/productos")
    public Producto updateProducto(@RequestBody Producto producto) {
    	productoService.save(producto);
        return producto;
    }

    @DeleteMapping("productos/{productoId}")
    public String deleteProducto(@PathVariable int productoId) {
    	Producto producto = productoService.findById(productoId);
        if(producto == null) {
            throw new RuntimeException("No se encontró ningún producto con el id - " + productoId);
        }
        productoService.deleteById(productoId);
        return "Borrado por el id del producto -" + productoId;
    }

}