package com.co.nttdata.ecommerce.dao;

import java.util.List;

import com.co.nttdata.ecommerce.entity.Factura;

public interface IFacturaDAO {

	public List<Factura> findAll();
    public Factura findById(int id);
    public Factura findByCliente(int id_Cliente);
    public void save(Factura factura);
    public void deleteById(int id);
    public void update(int id, Factura factura);
	
	public Double calcularCostoEnvio(int id_Cliente, int id_CarritoCompra);
	public Double calcularTotalSinIva(int id_Cliente, int id_CarritoCompra);
	public Double calcularTotalConIva(int id_Cliente, int id_CarritoCompra);
	
	public void imprimirFactura(int id_Factura);
	
}
