package com.co.nttdata.ecommerce.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;

@Entity
@Table(name="tbl_categorias", schema="sc_ecommerce")
@NamedQuery(name="Categoria.findAll", query="SELECT c FROM Categoria c")
public class Categoria implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;

	private String categoria;

	private String descripcion;

	private Boolean descuento;

	@Column(name="valor_descuento")
	private double valorDescuento;

	//bi-directional many-to-one association to Producto
	@OneToMany(mappedBy="categoria", cascade = CascadeType.ALL)
	private List<Producto> productos;

	public Categoria() {
	}	

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCategoria() {
		return this.categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Boolean getDescuento() {
		return this.descuento;
	}

	public void setDescuento(Boolean descuento) {
		this.descuento = descuento;
	}

	public double getValorDescuento() {
		return this.valorDescuento;
	}

	public void setValorDescuento(double valorDescuento) {
		this.valorDescuento = valorDescuento;
	}

	public List<Producto> getProductos() {
		return this.productos;
	}

	public void setProductos(List<Producto> productos) {
		this.productos = productos;
	}

	public Producto addProducto(Producto producto) {
		getProductos().add(producto);
		producto.setCategoria(this);

		return producto;
	}

	public Producto removeProducto(Producto producto) {
		getProductos().remove(producto);
		producto.setCategoria(null);

		return producto;
	}

	@Override
	public String toString() {
		return "Categoria [id=" + this.id 
				+ ", categoria=" + this.categoria 
				+ ", descripcion=" + this.descripcion 
				+ ", descuento=" + this.descuento 
				+ ", valorDescuento=" + this.valorDescuento + "]";
	}

}