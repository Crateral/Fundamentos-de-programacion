package com.co.nttdata.ecommerce.servicesImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.co.nttdata.ecommerce.dao.IFacturaDAO;
import com.co.nttdata.ecommerce.entity.Factura;
import com.co.nttdata.ecommerce.service.IFacturaService;

@Service
public class FacturaServicesImpl implements IFacturaService {

	@Autowired
	private IFacturaDAO facturaDAO;

	@Override
	public List<Factura> findAll() {
		List<Factura> listaFacturas = facturaDAO.findAll();
		return listaFacturas;
	}

	@Override
	public Factura findById(int id) {
		Factura factura = facturaDAO.findById(id);
		return factura;
	}

	@Override
	public void save(Factura factura) {
		facturaDAO.save(factura);

	}

	@Override
	public void deleteById(int id) {
		facturaDAO.deleteById(id);
	}

	@Override
	public Factura findByCliente(int id_Cliente) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void update(int id, Factura factura) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Double calcularCostoEnvio(int id_Cliente, int id_CarritoCompra) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Double calcularTotalSinIva(int id_Cliente, int id_CarritoCompra) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Double calcularTotalConIva(int id_Cliente, int id_CarritoCompra) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void imprimirFactura(int id_Factura) {
		// TODO Auto-generated method stub
		
	}


}
