package com.co.nttdata.ecommerce.dao;

import java.util.List;

import com.co.nttdata.ecommerce.entity.Registro;

public interface IRegistroDAO {

	public List<Registro> findAll();
    public Registro findById(int id);
    public Registro findByUsuario(String nombreUsuario);
    public void save(Registro usuario);
    public void deleteById(int id);
    public void update(int id, Registro usuario);
	
}
