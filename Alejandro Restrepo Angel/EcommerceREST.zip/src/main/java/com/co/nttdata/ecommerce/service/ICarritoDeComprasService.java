package com.co.nttdata.ecommerce.service;

import java.util.List;

import com.co.nttdata.ecommerce.entity.CarritoDeCompras;

public interface ICarritoDeComprasService {

	public List<CarritoDeCompras> findAll();
    public CarritoDeCompras findById(int id);
    public void save(CarritoDeCompras carritoDeCompras);
    public void deleteById(int id);
    public void update(int id, CarritoDeCompras carritoDeCompras);
    
	public Double calcularSubtotalSinIva(int id);
	public Double calcularSubtotalConIva(int id);
	
}
