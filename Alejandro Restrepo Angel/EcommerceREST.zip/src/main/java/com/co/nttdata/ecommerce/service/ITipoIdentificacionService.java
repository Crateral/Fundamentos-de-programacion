package com.co.nttdata.ecommerce.service;

import java.util.List;

import com.co.nttdata.ecommerce.entity.TipoIdentificacion;

public interface ITipoIdentificacionService {

	public List<TipoIdentificacion> findAll();
    public TipoIdentificacion findById(int id);
    public TipoIdentificacion findByNombre(String nombre);
    public void save(TipoIdentificacion tipoIdentificacion);
    public void deleteById(int id);
    public void update(int id, TipoIdentificacion tipoIdentificacion);
	
}
