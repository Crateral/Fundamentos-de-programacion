package com.co.nttdata.ecommerce.repository;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.co.nttdata.ecommerce.dao.IAdministradorDAO;
import com.co.nttdata.ecommerce.entity.Administrador;

@Repository
public class AdministradorRepository implements IAdministradorDAO {

	@Autowired
	private EntityManager entityManager;

	@Override
	public List<Administrador> findAll() {
		Session currentSession = entityManager.unwrap(Session.class);

		Query<Administrador> theQuery = currentSession.createQuery("from Administrador", Administrador.class);

		List<Administrador> administradores = theQuery.getResultList();

		return administradores;
	}

	@Override
	public Administrador findById(int id) {
		Session currentSession = entityManager.unwrap(Session.class);

		Administrador administrador = currentSession.get(Administrador.class, id);

		return administrador;
	}

	@Override
	public Administrador findByCorreo(String correo) {
		Session currentSession = entityManager.unwrap(Session.class);

		Administrador administrador = currentSession.get(Administrador.class, correo);

		return administrador;
	}

	@Override
	public void save(Administrador administrador) {
		Session currentSession = entityManager.unwrap(Session.class);

		currentSession.saveOrUpdate(administrador);
	}

	@Override
	public void deleteById(int id) {
		Session currentSession = entityManager.unwrap(Session.class);

		Query<Administrador> theQuery = currentSession
				.createQuery("delete from Administrador where id=:idAdministrador");

		theQuery.setParameter("idAdministrador", id);
		theQuery.executeUpdate();
	}

	@Override
	public void update(int id, Administrador Administrador) {
	}

}
