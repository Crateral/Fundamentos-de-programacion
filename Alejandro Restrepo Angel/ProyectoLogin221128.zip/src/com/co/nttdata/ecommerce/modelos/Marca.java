package com.co.nttdata.ecommerce.modelos;

public enum Marca {

	LG(1, "Marca LG de televisores"), 
	SAMSUNG(2, "Marca SAMSUNG de televisores"), 
	KIA(3, "Marca KIA de televisores"),
	OSTER(4, "Marca Oster de electrodomésticos"), 
	XIAOMI(5, "Marca Xiaomi de celulares"),
	ASUS(6, "Marca Asus de portátiles"), 
	HP(7, "Marca HP de computación"), 
	INVAL(8, "Marca Inval de hogar");

	private int id;
	private String descripcion;

	Marca() {

	}

	Marca(int id, String descripcion) {
		this.id = id;
		this.descripcion = descripcion;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

}
