package com.co.nttdata.ecommerce.logica;

import com.co.nttdata.ecommerce.modelos.*;

public class GestionLogin {

	private boolean token;
	
	//Registrar usuario
	public boolean registrarUsuario(Usuario usuario) {
		if(usuario.getNombreUsuario().isEmpty()) {
			return false;
		}
		if(usuario.getContrasenia().isEmpty()) {
			return false;
		}
		return true;
	}
	
	//Login
	public boolean iniciarSesion(Usuario usuario, Usuario usuario2) {
		if(!usuario.getNombreUsuario().equals(usuario2.getNombreUsuario())) {
			return false;
		}
		if(!usuario.getContrasenia().equals(usuario2.getContrasenia())) {
			return false;
		}
		token = true;
		return true;
	}
	
	//Logout
	public boolean cerrarSesion() {
		if(token == true) {
			return false;
		}
		return token;
	}
	
	//Olvide la contraseña
	public Usuario cambiarClave(Usuario usuario, String clave){
		usuario.setContrasenia(clave);
		return usuario;
		
	}
	
	
}
