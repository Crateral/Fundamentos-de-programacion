package com.co.nttdata.colegio.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.co.nttdata.colegio.entity.Estudiante;
import com.co.nttdata.colegio.service.IEstudianteService;

@CrossOrigin(origins = "http://localhost:9090")
@RestController
@RequestMapping("/api")
public class EstudianteRestController {

	@Autowired
	private IEstudianteService estudianteService;
	
	@GetMapping("/estudiantes")
	public ResponseEntity<List<Estudiante>> listarProfesores() {
		try {
			List<Estudiante> listaEstudiantes = estudianteService.listarEstudiantes();
			if (listaEstudiantes == null || listaEstudiantes.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<>(listaEstudiantes, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping("/estudiantes")
	public Estudiante crearEstudiante(@RequestBody Estudiante estudiante) {
		return estudianteService.crearEstudiante(estudiante);
	}

	@PutMapping("/estudiantes/{id}")
	public Estudiante actualizarEstudiante(@PathVariable("id") int id,
			@RequestBody Estudiante estudiante) {
		return estudianteService.actualizarEstudiante(id, estudiante);
	}

	@DeleteMapping("/estudiantes/{id}")
	public Boolean eliminarEstudiante(@PathVariable("id") int id) {
		return estudianteService.eliminarEstudiante(id);
	}
	
	@GetMapping("/estudiantes/{id}")
	public Estudiante ObtenerEstudiantePorId(@PathVariable("id") int id) {
		return estudianteService.buscarPorId(id);
	}

	@GetMapping("/estudiantes/numero/{numero}")
	public Estudiante ObtenerEstudiantePorNumeroId(@PathVariable("numero") String numero) {
		return estudianteService.buscarPorNumeroIdentificacion(numero);
	}
}
