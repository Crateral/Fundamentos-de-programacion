package com.co.nttdata.colegio.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.co.nttdata.colegio.entity.Estudiante;;

public interface IEstudianteRepository extends JpaRepository<Estudiante, Integer>{

	Estudiante findByNumeroIdentificacion(String numero);
	
}
