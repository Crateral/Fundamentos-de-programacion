package com.co.nttdata.colegio.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.co.nttdata.colegio.entity.TipoIdentificacion;
import com.co.nttdata.colegio.service.ITipoIdentificacionService;

@CrossOrigin(origins = "http://localhost:9090")
@RestController
@RequestMapping("/api")
public class TipoIdentificacionRestController {

	@Autowired
	private ITipoIdentificacionService tipoIdentificacionService;

	@GetMapping("/tiposdeidentificacion")
	public ResponseEntity<List<TipoIdentificacion>> listarTiposIdentificacion() {
		try {
			List<TipoIdentificacion> listaTipos = tipoIdentificacionService.listarTipos();
			if (listaTipos == null || listaTipos.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<>(listaTipos, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping("/tiposdeidentificacion")
	public TipoIdentificacion crearTipoIdentificacion(@RequestBody TipoIdentificacion tipoIdentificacion) {
		return tipoIdentificacionService.crearTipo(tipoIdentificacion);
	}

	@PutMapping("/tiposdeidentificacion/{id}")
	public TipoIdentificacion actualizarTipoIdentificacion(@PathVariable("id") int id,
			@RequestBody TipoIdentificacion tipoIdentificacion) {
		return tipoIdentificacionService.actualizarTipo(id, tipoIdentificacion);
	}

	@DeleteMapping("/tiposdeidentificacion/{id}")
	public Boolean eliminarTipoIdentificacion(@PathVariable("id") int id) {
		return tipoIdentificacionService.eliminarTipo(id);
	}
	
	@GetMapping("/tiposdeidentificacion/{id}")
	public TipoIdentificacion ObtenerTipoIdentificacion(@PathVariable("id") int id) {
		return tipoIdentificacionService.buscarPorId(id);
	}

}
