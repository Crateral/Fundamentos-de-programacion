package com.co.nttdata.colegio.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

@Entity
@Table(name="tbl_cursos", schema="sc_colegio")
@NamedQuery(name="Curso.findAll", query="SELECT c FROM Curso c")
public class Curso implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	
	//bi-directional many-to-one association to Profesor
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name="id_profesor")
	@JsonProperty(access = Access.WRITE_ONLY)
	private Profesor profesor;
	
	@NotNull(message = "Curso no puede estar vacío")
	@Column(name = "curso")
	private String curso;
	
	@Column(name = "observacion")
	private String observacion;
	
	//bi-directional many-to-one association to Nota
	@OneToMany(mappedBy="nota", cascade = CascadeType.ALL)
	private List<Nota> notas;

	public Curso() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Profesor getProfesor() {
		return this.profesor;
	}

	public void setProfesor(Profesor profesor) {
		this.profesor = profesor;
	}
	
	public String getCurso() {
		return curso;
	}

	public void setCurso(String curso) {
		this.curso = curso;
	}

	public String getObservacion() {
		return this.observacion;
	}

	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}
	
	public List<Nota> getNotas() {
		return notas;
	}

	public void setNotas(List<Nota> notas) {
		this.notas = notas;
	}

	@Override
	public String toString() {
		return "Curso [id=" + this.id 
				+ ", profesor=" + this.profesor 
				+ ", curso=" + this.curso 
				+ ", observacion=" + this.observacion + "]";
	}
		
}
