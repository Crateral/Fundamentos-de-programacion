package com.co.nttdata.colegio.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.co.nttdata.colegio.entity.Nota;
import com.co.nttdata.colegio.service.INotaService;

@CrossOrigin(origins = "http://localhost:9090")
@RestController
@RequestMapping("/api")
public class NotaRestController {

	@Autowired
	private INotaService notaService;

	@GetMapping("/notas")
	public ResponseEntity<List<Nota>> listarNotas() {
		try {
			List<Nota> listaNotas = notaService.listarNotas();
			if (listaNotas == null || listaNotas.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<>(listaNotas, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping("/notas")
	public Nota crearNota(@RequestBody Nota nota) {
		return notaService.crearNota(nota);
	}

	@PutMapping("/notas/{id}")
	public Nota actualizarNota(@PathVariable("id") int id,
			@RequestBody Nota nota) {
		return notaService.actualizarNota(id, nota);
	}

	@DeleteMapping("/notas/{id}")
	public Boolean eliminarNota(@PathVariable("id") int id) {
		return notaService.eliminarNota(id);
	}
	
	@GetMapping("/notas/{id}")
	public Nota ObtenerNotaPorId(@PathVariable("id") int id) {
		return notaService.buscarPorId(id);
	}

	@GetMapping("/notas/{id}/estudiante")
	public List<Nota> notasPorAlumno(@PathVariable("id") int id) {
		return notaService.notasPorAlumno(id);
	}
	
	@GetMapping("/notas/{id}/curso")
	public List<Nota> notasPorCurso(@PathVariable("id") int id) {
		return notaService.notasPorCurso(id);
	}
	
	@GetMapping("/notas/{id}/notacurso")
	public Double CalcularPorCurso(@PathVariable("id") int id) {
		return notaService.calcularNotaCurso(id);
	}
}
