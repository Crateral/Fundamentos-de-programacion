package com.co.nttdata.colegio.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.co.nttdata.colegio.entity.Curso;
import com.co.nttdata.colegio.service.ICursoService;

@CrossOrigin(origins = "http://localhost:9090")
@RestController
@RequestMapping("/api")
public class CursoRestController {

	@Autowired
	private ICursoService cursoService;

	@GetMapping("/cursos")
	public ResponseEntity<List<Curso>> listarCursos() {
		try {
			List<Curso> listaCursos = cursoService.listarCursos();
			if (listaCursos == null || listaCursos.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<>(listaCursos, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping("/cursos")
	public Curso crearCursos(@RequestBody Curso curso) {
		return cursoService.crearCurso(curso);
	}

	@PutMapping("/cursos/{id}")
	public Curso actualizarCurso(@PathVariable("id") int id,
			@RequestBody Curso cursos) {
		return cursoService.actualizarCurso(id, cursos);
	}

	@DeleteMapping("/cursos/{id}")
	public Boolean eliminarCurso(@PathVariable("id") int id) {
		return cursoService.eliminarCurso(id);
	}
	
	@GetMapping("/cursos/{id}")
	public Curso ObtenerCursoPorId(@PathVariable("id") int id) {
		return cursoService.buscarPorId(id);
	}
	
}
