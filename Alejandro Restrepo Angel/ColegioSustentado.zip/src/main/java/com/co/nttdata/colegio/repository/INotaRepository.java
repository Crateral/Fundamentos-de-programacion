package com.co.nttdata.colegio.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.co.nttdata.colegio.entity.Nota;

public interface INotaRepository extends JpaRepository<Nota, Integer> {

	@Query(value = "SELECT n FROM Nota n WHERE n.estudiante.id = ?1")
	List<Nota> notasPorAlumno(Integer id);
	
	@Query(value = "SELECT n FROM Nota n WHERE n.curso.id = ?1")
	List<Nota> notasPorCurso(Integer id);

}
