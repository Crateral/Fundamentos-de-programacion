package com.co.nttdata.colegio.entity;

import java.io.Serializable;
import java.util.List;
import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="tbl_tipo_identificaciones", schema="sc_colegio")
@NamedQuery(name="TipoIdentificacion.findAll", query="SELECT t FROM TipoIdentificacion t")
public class TipoIdentificacion implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;

	@NotNull(message = "Curso no puede estar vacío")
	@Column(name="tipo_identificacion")
	private String tipoIdentificacion;

	@Column(name = "descripcion")
	private String descripcion;
	
	//bi-directional many-to-one association to Estudiante
	@OneToMany(mappedBy="tipoIdentificacion", cascade = CascadeType.ALL)
	private List<Estudiante> estudiantes;

	//bi-directional many-to-one association to Profesor
	@OneToMany(mappedBy="tipoIdentificacion", cascade = CascadeType.ALL)
	private List<Profesor> profesores;

	public TipoIdentificacion() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getTipoIdentificacion() {
		return this.tipoIdentificacion;
	}

	public void setTipoIdentificacion(String tipoIdentificacion) {
		this.tipoIdentificacion = tipoIdentificacion;
	}

	public List<Estudiante> getEstudiantes() {
		return this.estudiantes;
	}

	public void setEstudiantes(List<Estudiante> estudiantes) {
		this.estudiantes = estudiantes;
	}

	public Estudiante addEstudiante(Estudiante estudiante) {
		getEstudiantes().add(estudiante);
		estudiante.setTipoIdentificacion(this);

		return estudiante;
	}

	public Estudiante removeEstudiante(Estudiante estudiante) {
		getEstudiantes().remove(estudiante);
		estudiante.setTipoIdentificacion(null);

		return estudiante;
	}

	public List<Profesor> getProfesores() {
		return this.profesores;
	}

	public void setProfesores(List<Profesor> profesores) {
		this.profesores = profesores;
	}

	public Profesor addProfesor(Profesor profesor) {
		getProfesores().add(profesor);
		profesor.setTipoIdentificacion(this);

		return profesor;
	}

	public Profesor removeProfesor(Profesor profesor) {
		getProfesores().remove(profesor);
		profesor.setTipoIdentificacion(null);

		return profesor;
	}

	@Override
	public String toString() {
		return "TipoIdentificacion [id=" + this.id 
				+ ", descripcion=" + this.descripcion 
				+ ", tipoIdentificacion=" + this.tipoIdentificacion + "]";
	}

}