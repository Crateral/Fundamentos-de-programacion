package com.co.nttdata.colegio.servicesImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.co.nttdata.colegio.entity.Nota;
import com.co.nttdata.colegio.repository.INotaRepository;
import com.co.nttdata.colegio.service.INotaService;

@Service
public class NotaServiceImpl implements INotaService {

	@Autowired
	private INotaRepository notaRepository;
	
	@Transactional(readOnly = true)
	@Override
	public List<Nota> listarNotas() {
		return notaRepository.findAll();
	}

	@Transactional
	@Override
	public Nota crearNota(Nota nota) {
		return notaRepository.save(nota);
	}

	@Transactional
	@Override
	public Boolean eliminarNota(Integer id) {
		if(notaRepository.existsById(id)) {
			notaRepository.deleteById(id);
			return true;
		}
		return false;
	}

	@Transactional
	@Override
	public Nota actualizarNota(Integer id, Nota nota) {
		Nota notaBD = notaRepository.findById(id).orElse(null);
		if(notaBD != null) {
			notaBD.setCurso(nota.getCurso());
			notaBD.setEstudiante(nota.getEstudiante());
			notaBD.setNota(nota.getNota());
			notaBD.setObservacion(nota.getObservacion());
		}
		return notaRepository.save(notaBD);
	}

	@Transactional(readOnly = true)
	@Override
	public List<Nota> notasPorAlumno(Integer id) {
		return notaRepository.notasPorAlumno(id);
	}

	@Transactional(readOnly = true)
	@Override
	public List<Nota> notasPorCurso(Integer id) {
		return notaRepository.notasPorCurso(id);
	}

	@Transactional
	@Override
	public Nota buscarPorId(int id) {
		return notaRepository.findById(id).orElse(null);
	}

	public Double calcularNotaCurso(int id) {
		Double notaTotal = 0.0;
		List<Nota> lista = notaRepository.notasPorCurso(id);
		for(int i=0; i<lista.size(); i++) {
			notaTotal = notaTotal + lista.get(i).getNota();
		}
		return (notaTotal/lista.size());
	}
}
