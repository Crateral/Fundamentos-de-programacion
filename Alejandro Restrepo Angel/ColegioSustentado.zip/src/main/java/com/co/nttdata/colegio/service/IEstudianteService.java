package com.co.nttdata.colegio.service;

import java.util.List;

import com.co.nttdata.colegio.entity.Estudiante;

public interface IEstudianteService {

	public List<Estudiante> listarEstudiantes();
	public Estudiante crearEstudiante(Estudiante estudiante);
	public Boolean eliminarEstudiante(int id);
	public Estudiante actualizarEstudiante(int id, Estudiante estudiante);
	
	public Estudiante buscarPorId(int id);  
	public Estudiante buscarPorNumeroIdentificacion(String numero); 
	
}
