package com.co.nttdata.colegio.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.co.nttdata.colegio.entity.Profesor;

public interface IProfesorRepository extends JpaRepository<Profesor, Integer> {

	Profesor findByNumeroIdentificacion(String numero);
	
}
