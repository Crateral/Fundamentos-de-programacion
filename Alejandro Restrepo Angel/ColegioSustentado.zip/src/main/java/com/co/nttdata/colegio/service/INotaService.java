package com.co.nttdata.colegio.service;

import java.util.List;

import com.co.nttdata.colegio.entity.Nota;

public interface INotaService {

	public List<Nota> listarNotas();
	public Nota crearNota(Nota nota);
	public Boolean eliminarNota(Integer id);
	public Nota actualizarNota(Integer id, Nota nota);
	
	public List<Nota> notasPorAlumno(Integer id);
	public List<Nota> notasPorCurso(Integer id);
	
	public Nota buscarPorId(int id);
	public Double calcularNotaCurso(int id);
	
}
