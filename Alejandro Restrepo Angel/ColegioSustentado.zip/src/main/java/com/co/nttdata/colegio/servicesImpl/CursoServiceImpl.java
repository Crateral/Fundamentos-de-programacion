package com.co.nttdata.colegio.servicesImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.co.nttdata.colegio.entity.Curso;
import com.co.nttdata.colegio.repository.ICursoRepository;
import com.co.nttdata.colegio.service.ICursoService;

@Service
public class CursoServiceImpl implements ICursoService {

	@Autowired
	private ICursoRepository cursoRepository;
	
	@Transactional(readOnly = true)
	@Override
	public List<Curso> listarCursos() {
		return cursoRepository.findAll();
	}

	@Transactional
	@Override
	public Curso crearCurso(Curso curso) {
		return cursoRepository.save(curso);
	}

	@Transactional
	@Override
	public Boolean eliminarCurso(int id) {
		if(cursoRepository.existsById(id)) {
			cursoRepository.deleteById(id);
			return true;
		}
		return false;
	}

	@Transactional
	@Override
	public Curso actualizarCurso(int id, Curso curso) {
		Curso cursoBD = cursoRepository.findById(id).orElse(null);
		if(cursoBD!=null) {
			cursoBD.setProfesor(curso.getProfesor());
			cursoBD.setCurso(curso.getCurso());
			cursoBD.setObservacion(curso.getObservacion());
		}
		return cursoRepository.save(cursoBD);
	}

	@Transactional
	@Override
	public Curso buscarPorId(int id) {
		return cursoRepository.findById(id).orElse(null);
	}

}
