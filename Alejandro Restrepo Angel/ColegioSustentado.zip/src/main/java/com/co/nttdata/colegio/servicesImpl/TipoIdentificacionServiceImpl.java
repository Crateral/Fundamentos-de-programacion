package com.co.nttdata.colegio.servicesImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.co.nttdata.colegio.entity.TipoIdentificacion;
import com.co.nttdata.colegio.repository.ITipoIdentificacionRepository;
import com.co.nttdata.colegio.service.ITipoIdentificacionService;

@Service
public class TipoIdentificacionServiceImpl implements ITipoIdentificacionService{

	@Autowired
	private ITipoIdentificacionRepository tipoIdentificacionRepository;
	
	@Transactional(readOnly = true)
	@Override
	public List<TipoIdentificacion> listarTipos() {
		return tipoIdentificacionRepository.findAll();
	}

	@Transactional
	@Override
	public TipoIdentificacion crearTipo(TipoIdentificacion tipoIdentificacion) {
		return tipoIdentificacionRepository.save(tipoIdentificacion);
	}

	@Transactional
	@Override
	public Boolean eliminarTipo(Integer id) {
		if(tipoIdentificacionRepository.existsById(id)) {
			tipoIdentificacionRepository.deleteById(id);
			return true;
		}
		return false;
	}

	@Transactional
	@Override
	public TipoIdentificacion actualizarTipo(Integer id, TipoIdentificacion tipoIdentificacion) {
		TipoIdentificacion tipo = tipoIdentificacionRepository.findById(id).orElse(null);
		if(tipo != null) {
			tipo.setTipoIdentificacion(tipoIdentificacion.getTipoIdentificacion());
			tipo.setDescripcion(tipoIdentificacion.getDescripcion());
		}
		return tipoIdentificacionRepository.save(tipo);
	}
	
	@Transactional
	@Override
	public TipoIdentificacion buscarPorId(int id) {
		return tipoIdentificacionRepository.findById(id).orElse(null);
	}

}
