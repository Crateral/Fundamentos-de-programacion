package com.co.colegio.app.modelos;

import java.io.Serializable;

public class Materia implements Serializable {

	private static final long serialVersionUID = 1L;
	private int idMateria;
	private String nombreMateria;
	private Profesor profesor;
	private int grado;
	private String salon;
	
	public Materia() {
		super();
	}

	public Materia(int idMateria, String nombreMateria, Profesor profesor, int grado, String salon) {
		super();
		this.idMateria = idMateria;
		this.nombreMateria = nombreMateria;
		this.profesor = profesor;
		this.grado = grado;
		this.salon = salon;
	}

	public int getIdMateria() {
		return idMateria;
	}

	public void setIdMateria(int idMateria) {
		this.idMateria = idMateria;
	}

	public String getNombreMateria() {
		return nombreMateria;
	}

	public void setNombreMateria(String nombreMateria) {
		this.nombreMateria = nombreMateria;
	}

	public Profesor getProfesor() {
		return profesor;
	}

	public void setProfesor(Profesor profesor) {
		this.profesor = profesor;
	}

	public int getGrado() {
		return grado;
	}

	public void setGrado(int grado) {
		this.grado = grado;
	}

	public String getSalon() {
		return salon;
	}

	public void setSalon(String salon) {
		this.salon = salon;
	}

	@Override
	public String toString() {
		return "Materia [idMateria=" + idMateria + ", nombreMateria=" + nombreMateria + ", profesor=" + profesor
				+ ", grado=" + grado + ", salon=" + salon + "]";
	}

}
