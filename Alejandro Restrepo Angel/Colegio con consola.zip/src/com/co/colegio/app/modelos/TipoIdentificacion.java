package com.co.colegio.app.modelos;

public enum TipoIdentificacion {

	CC (1, "Cédula de ciudadanía"),
	CE (2, "Cédula de extranjería"),
	NIP(3, "Número de identificación personal"),
	NIT(4, "Número de identificación tributaria"),
	TI (5, "Tarjeta de identidad"),
	PAP(6, "Pasaporte");
	
	private int id;
	private String tipo;
	
	TipoIdentificacion() {

	}

	private TipoIdentificacion(int id, String tipo) {
		this.id = id;
		this.tipo = tipo;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTipo() {
		return this.tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

}
