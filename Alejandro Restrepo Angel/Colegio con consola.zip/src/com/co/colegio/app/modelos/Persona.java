package com.co.colegio.app.modelos;

import java.io.Serializable;

public class Persona implements Serializable {

	private static final long serialVersionUID = 1L;
	private Integer id;
	private TipoIdentificacion tipoIdentificacion;
	private String numeroIdentificacion;
	private String nombre;
	private String apellido;
	private String correo;
	private String telefono;
	private String direccion;
	private String ciudad;
	
	public Persona() {
		super();
	}
	
	public Persona(Integer id, TipoIdentificacion tipoIdentificacion, String numeroIdentificacion, String nombre, String apellido,
			String correo, String telefono, String direccion, String ciudad) {
		super();
		this.id = id;
		this.tipoIdentificacion = tipoIdentificacion;
		this.numeroIdentificacion = numeroIdentificacion;
		this.nombre = nombre;
		this.apellido = apellido;
		this.correo = correo;
		this.telefono = telefono;
		this.direccion = direccion;
		this.ciudad = ciudad;
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public TipoIdentificacion getTipoIdentificacion() {
		return this.tipoIdentificacion;
	}

	public void setTipoIdentificacion(TipoIdentificacion tipoIdentificacion) {
		this.tipoIdentificacion = tipoIdentificacion;
	}

	public String getNumeroIdentificacion() {
		return this.numeroIdentificacion;
	}

	public void setNumeroIdentificacion(String numeroIdentificacion) {
		this.numeroIdentificacion = numeroIdentificacion;
	}

	public String getNombre() {
		return this.nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return this.apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getCorreo() {
		return this.correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getTelefono() {
		return this.telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getDireccion() {
		return this.direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getCiudad() {
		return this.ciudad;
	}

	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}

	@Override
	public String toString() {
		return "id=" + this.id + ", tipoIdentificacion=" + this.tipoIdentificacion + ", numeroIdentificacion="
				+ this.numeroIdentificacion + ", nombre=" + this.nombre + ", apellido=" + this.apellido + ", correo=" + this.correo
				+ ", telefono=" + this.telefono + ", direccion=" + this.direccion + ", ciudad=" + this.ciudad;
	}

}
