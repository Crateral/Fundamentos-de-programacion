package com.co.colegio.app.interfaces;

import java.util.List;

import com.co.colegio.app.modelos.Profesor;

public interface IArchivoProfesor {

	public void guardarProfesores(String nombreArchivo, List<Profesor> profesores);
	public List<Profesor> leerProfesores(String nombreArchivo);
	
}
