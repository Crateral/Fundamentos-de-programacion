package com.co.colegio.app.interfaces;

import java.util.List;

import com.co.colegio.app.modelos.Nota;
import com.co.colegio.app.modelos.Alumno;
import com.co.colegio.app.modelos.Materia;


public interface IGestionNota {
	
	public void calcularNotas(List<Alumno> alumnos,List<Materia> materias, List<Nota> notas);
	public void calcularNota (Alumno alumno, Materia materia, List<Nota> notasAlumno);
	public List<Nota> notasAlumno(Alumno alumno, Materia materia, List<Nota> notas);
	public Nota buscarNota(List<Nota> notas, int idNota);

}
