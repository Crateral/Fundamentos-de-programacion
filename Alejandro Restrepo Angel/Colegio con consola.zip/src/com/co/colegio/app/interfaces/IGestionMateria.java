package com.co.colegio.app.interfaces;

import java.util.List;
import com.co.colegio.app.modelos.Materia;

public interface IGestionMateria {

	public Materia buscarMateria(List<Materia> materias, int id);
	
}
