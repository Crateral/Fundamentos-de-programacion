package com.co.colegio.app.interfaces;

import java.util.List;
import com.co.colegio.app.modelos.Alumno;

public interface IGestionAlumno {

	public Alumno buscarAlumno(List<Alumno> materias, int id);
	
}
