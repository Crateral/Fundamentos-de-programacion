package com.co.colegio.app.vistas;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Menu {
	
    private void menu(int opcion){
        switch (opcion) {
            case 1:
            	vistaAlumnos menuAlumnos = new vistaAlumnos();
            	menuAlumnos.vista();
                break;
            case 2:
            	vistaProfesores menuProfesores = new vistaProfesores();
            	menuProfesores.vista();
                break;
            case 3:
            	vistaMaterias menuMaterias = new vistaMaterias();
            	menuMaterias.vista();
                break;
            case 4:
            	vistaNotas menuNotas = new vistaNotas();
            	menuNotas.vista();
                break;
            case 5:
                System.out.println("Programa Finalizado\n");
                break;
            default:
                System.out.println("Error: " + opcion + " no es una opción válida.\n");
        }
    }

    public void vista(){
        int opcion;
        Scanner scanner = new Scanner(System.in);

        do {
            try{
                System.out.println("\n===========================================");
                System.out.println("| Colegio AR                              |");
                System.out.println("|=========================================|");
                System.out.println("| 1. Alumnos                              |");
                System.out.println("| 2. Profesores                           |");
                System.out.println("| 3. Materias                             |");
                System.out.println("| 4. Notas                                |");
                System.out.println("| 5. Salir                                |");
                System.out.println("===========================================");
                System.out.print("Ingrese la opción: ");
                opcion = scanner.nextInt();
                menu(opcion);
            }
            catch (InputMismatchException excepcion)
            {
                System.out.println("Error! No es una opción válida \n");
                scanner.next();
                opcion = 0;
            }
        }
        while(opcion!=5);
        scanner.close();
    }
	
}
