package com.co.colegio.app.vistas;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.co.colegio.app.interfaces.IArchivoProfesor;
import com.co.colegio.app.interfaces.IGestionProfesor;
import com.co.colegio.app.logica.GestionProfesorImpl;
import com.co.colegio.app.modelos.Profesor;
import com.co.colegio.app.modelos.Persona;
import com.co.colegio.app.modelos.TipoIdentificacion;
import com.co.colegio.app.utilitarios.ArchivoProfesorImpl;

public class vistaProfesores {

	Scanner scanner = new Scanner(System.in);

	private void menuProfesores(int opcion) {

		// Instanciar objetos logica de negocio
		IArchivoProfesor archivoProfesor = new ArchivoProfesorImpl();
		IGestionProfesor gestionProfesor = new GestionProfesorImpl();

		// Indicamos el nombre del archivo donde se encuentran los profesores
		String profesoresArchivo = "Profesores.txt";

		// Crear una lista para guardar los profesores recuperados del archivo
		List<Profesor> profesores = new ArrayList<>();
		profesores = archivoProfesor.leerProfesores(profesoresArchivo);

		switch (opcion) {
		case 1:
			System.out.println("\n===========================================");
			System.out.println("| Listado de Profesores                   |");
			System.out.println("===========================================");
			profesores.forEach((profesor) -> System.out.println(profesor.toString()));
			System.out.println("\n");
			break;
		case 2:
			scanner.nextLine();
			System.out.println("\n===========================================");
			System.out.println("| Agregar Profesor                        |");
			System.out.println("===========================================");
			System.out.println("Ingrese el número de identificación: ");
			String numeroIdentificacion = scanner.nextLine();
			System.out.println("Ingrese el nombre: ");
			String nombre = scanner.nextLine();
			System.out.println("Ingrese el apellido: ");
			String apellido = scanner.nextLine();
			System.out.println("Ingrese el correo: ");
			String correo = scanner.nextLine();
			System.out.println("Ingrese el teléfono: ");
			String telefono = scanner.nextLine();
			System.out.println("Ingrese la dirección: ");
			String direccion = scanner.nextLine();
			System.out.println("Ingrese la ciudad: ");
			String ciudad = scanner.nextLine();

			Persona profesor = new Profesor(profesores.size() + 1, TipoIdentificacion.CC, numeroIdentificacion, nombre,
					apellido, correo, telefono, direccion, ciudad);
			profesores.add((Profesor) profesor);

			// Crear la lista de profesores en un Archivo
			archivoProfesor.guardarProfesores(profesoresArchivo, profesores);

			break;
		case 3:
			scanner.nextLine();
			System.out.println("\n===========================================");
			System.out.println("| Modificar Profesor                      |");
			System.out.println("===========================================");
			System.out.println("Ingrese el id del profesor a modificar: ");
			Integer id = scanner.nextInt();
			profesor = gestionProfesor.buscarProfesor(profesores, id);
			if (profesor == null) {
				System.out.println("No se encontró id a modificar");
			} else {
				scanner.nextLine();
				System.out.println("Ingrese el número de identificación: ");
				numeroIdentificacion = scanner.nextLine();
				profesor.setNumeroIdentificacion(numeroIdentificacion);
				System.out.println("Ingrese el nombre: ");
				nombre = scanner.nextLine();
				profesor.setNombre(nombre);
				System.out.println("Ingrese el apellido: ");
				apellido = scanner.nextLine();
				profesor.setApellido(apellido);
				System.out.println("Ingrese el correo: ");
				correo = scanner.nextLine();
				profesor.setCorreo(correo);
				System.out.println("Ingrese el teléfono: ");
				telefono = scanner.nextLine();
				profesor.setTelefono(telefono);
				System.out.println("Ingrese la dirección: ");
				direccion = scanner.nextLine();
				profesor.setDireccion(direccion);
				System.out.println("Ingrese la ciudad: ");
				ciudad = scanner.nextLine();
				profesor.setCiudad(ciudad);
			}

			// Crear la lista de profesores en un Archivo
			archivoProfesor.guardarProfesores(profesoresArchivo, profesores);
			break;
		case 4:
			scanner.nextLine();
			System.out.println("\n===========================================");
			System.out.println("| Eliminar Profesor                       |");
			System.out.println("===========================================");
			System.out.println("Ingrese el id del profesor a eliminar: ");
			id = scanner.nextInt();
			profesor = gestionProfesor.buscarProfesor(profesores, id);
			if (profesor == null) {
				System.out.println("No se encontró id a eliminar");
			} else {
				profesores.remove(profesor);
			}

			// Crear la lista de profesores en un Archivo
			archivoProfesor.guardarProfesores(profesoresArchivo, profesores);
			break;
		case 5:
			System.out.println("Regresando al menu anterior\n");
			break;
		default:
			System.out.println("Error: " + opcion + " no es una opción válida.\n");
		}
	}

	public void vista() {
		int opcion;

		do {
			try {
				System.out.println("\n===========================================");
				System.out.println("| Profesores AR                           |");
				System.out.println("|=========================================|");
				System.out.println("| 1. Listar                               |");
				System.out.println("| 2. Agregar                              |");
				System.out.println("| 3. Modificar                            |");
				System.out.println("| 4. Eliminar                             |");
				System.out.println("| 5. Regresar                             |");
				System.out.println("===========================================");
				System.out.print("Ingrese la opción: ");
				opcion = scanner.nextInt();
				menuProfesores(opcion);
			} catch (InputMismatchException excepcion) {
				System.out.println("Error! No es una opción válida \n");
				scanner.next();
				opcion = 0;
			}
		} while (opcion != 5);
	}

}
