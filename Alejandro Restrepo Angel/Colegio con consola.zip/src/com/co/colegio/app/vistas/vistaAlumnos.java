package com.co.colegio.app.vistas;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.co.colegio.app.interfaces.IArchivoAlumno;
import com.co.colegio.app.interfaces.IGestionAlumno;
import com.co.colegio.app.logica.GestionAlumnoImpl;
import com.co.colegio.app.modelos.Alumno;
import com.co.colegio.app.modelos.Persona;
import com.co.colegio.app.modelos.TipoIdentificacion;
import com.co.colegio.app.utilitarios.ArchivoAlumnoImpl;

public class vistaAlumnos {

	 Scanner scanner = new Scanner(System.in);
	
	private void menuAlumnos(int opcion){
				
		//Instanciar objetos logica de negocio
		IArchivoAlumno archivoAlumno = new ArchivoAlumnoImpl();
		IGestionAlumno gestionAlumno = new GestionAlumnoImpl();
    	
		//Indicamos el nombre del archivo donde se encuentran los alumnos
		String alumnosArchivo = "Alumnos.txt";
    	
		//Crear una lista para guardar los alumnos recuperados del archivo
		List<Alumno> alumnos = new ArrayList<>();
		alumnos = archivoAlumno.leerAlumnos(alumnosArchivo);
		
        switch (opcion) {
            case 1: 
                System.out.println("\n===========================================");
                System.out.println("| Listado de Alumnos                      |");
                System.out.println("===========================================");
    			alumnos.forEach((alumno) -> System.out.println(alumno.toString()));
    			System.out.println("\n"); 			
                break;
            case 2:
            	scanner.nextLine();
            	System.out.println("\n===========================================");
                System.out.println("| Agregar Alumno                          |");
                System.out.println("===========================================");              
                System.out.println("Ingrese el número de identificación: ");
                String numeroIdentificacion = scanner.nextLine();
                System.out.println("Ingrese el nombre: ");
                String nombre = scanner.nextLine();
                System.out.println("Ingrese el apellido: ");
    			String apellido = scanner.nextLine();
    			System.out.println("Ingrese el correo: ");
    			String correo = scanner.nextLine();
    			System.out.println("Ingrese el teléfono: ");
    			String telefono = scanner.nextLine();
    			System.out.println("Ingrese la dirección: ");
    			String direccion = scanner.nextLine();
    			System.out.println("Ingrese la ciudad: ");
    			String ciudad = scanner.nextLine(); 
                
            	Persona estudiante = new Alumno(alumnos.size()+1, TipoIdentificacion.TI, numeroIdentificacion, nombre, apellido, correo, telefono, direccion, ciudad, true);
            	alumnos.add((Alumno) estudiante);
            	
            	//Crear la lista de alumnos en un Archivo
    			archivoAlumno.guardarAlumnos(alumnosArchivo, alumnos);
    			
                break;
            case 3:
            	scanner.nextLine();
            	System.out.println("\n===========================================");
                System.out.println("| Modificar Alumno                         |");
                System.out.println("===========================================");  
                System.out.println("Ingrese el id del alumno a modificar: ");
                Integer id = scanner.nextInt();
                Persona alumno = gestionAlumno.buscarAlumno(alumnos, id);
                if (alumno == null)
                {
                	System.out.println("No se encontró id a modificar");
                }
                else {
                	scanner.nextLine();
                	System.out.println("Ingrese el número de identificación: ");
                    numeroIdentificacion = scanner.nextLine();
                    alumno.setNumeroIdentificacion(numeroIdentificacion);
                    System.out.println("Ingrese el nombre: ");
                    nombre = scanner.nextLine();
                    alumno.setNombre(nombre);
                    System.out.println("Ingrese el apellido: ");
         			apellido = scanner.nextLine();
         			alumno.setApellido(apellido);
         			System.out.println("Ingrese el correo: ");
         			correo = scanner.nextLine();
         			alumno.setCorreo(correo);
         			System.out.println("Ingrese el teléfono: ");
         			telefono = scanner.nextLine();
         			alumno.setTelefono(telefono);
         			System.out.println("Ingrese la dirección: ");
         			direccion = scanner.nextLine();
         			alumno.setDireccion(direccion);
         			System.out.println("Ingrese la ciudad: ");
         			ciudad = scanner.nextLine(); 
         			alumno.setCiudad(ciudad);
                }
                
              //Crear la lista de alumnos en un Archivo
    			archivoAlumno.guardarAlumnos(alumnosArchivo, alumnos);
                break;
            case 4:
            	scanner.nextLine();
            	System.out.println("\n===========================================");
                System.out.println("| Eliminar Alumno                         |");
                System.out.println("===========================================");  
                System.out.println("Ingrese el id del alumno a eliminar: ");
                id = scanner.nextInt();
                alumno = gestionAlumno.buscarAlumno(alumnos, id);
                if (alumno == null)
                {
                	System.out.println("No se encontró id a eliminar");
                }
                else {
                	alumnos.remove(alumno);
                }
                
              //Crear la lista de alumnos en un Archivo
    			archivoAlumno.guardarAlumnos(alumnosArchivo, alumnos);
                break;
            case 5:
                System.out.println("Regresando al menu anterior\n");
                break;
            default:
                System.out.println("Error: " + opcion + " no es una opción válida.\n");
        }
    }
	
	public void vista() {
		int opcion;

        do {
            try{
                System.out.println("\n===========================================");
                System.out.println("| Alumnos AR                              |");
                System.out.println("|=========================================|");
                System.out.println("| 1. Listar                               |");
                System.out.println("| 2. Agregar                              |");
                System.out.println("| 3. Modificar                            |");
                System.out.println("| 4. Eliminar                             |");
                System.out.println("| 5. Regresar                             |");
                System.out.println("===========================================");
                System.out.print("Ingrese la opción: ");
                opcion = scanner.nextInt();
                menuAlumnos(opcion);
            }
            catch (InputMismatchException excepcion)
            {
                System.out.println("Error! No es una opción válida \n");
                scanner.next();
                opcion = 0;
            }
        }
        while(opcion!=5);		
	}

}
