package com.co.colegio.app.vistas;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.co.colegio.app.interfaces.IArchivoMateria;
import com.co.colegio.app.interfaces.IArchivoProfesor;
import com.co.colegio.app.interfaces.IGestionMateria;
import com.co.colegio.app.interfaces.IGestionProfesor;
import com.co.colegio.app.logica.GestionMateriaImpl;
import com.co.colegio.app.logica.GestionProfesorImpl;
import com.co.colegio.app.modelos.Materia;
import com.co.colegio.app.modelos.Profesor;
import com.co.colegio.app.utilitarios.ArchivoMateriaImpl;
import com.co.colegio.app.utilitarios.ArchivoProfesorImpl;

public class vistaMaterias {

	Scanner scanner = new Scanner(System.in);

	private void menuMaterias(int opcion) {

		// Instanciar objetos logica de negocio
		IArchivoMateria archivoMateria = new ArchivoMateriaImpl();
		IArchivoProfesor archivoProfesor = new ArchivoProfesorImpl();
		IGestionMateria gestionMateria = new GestionMateriaImpl();
		IGestionProfesor gestionProfesor = new GestionProfesorImpl();

		// Indicamos el nombre del archivo donde se encuentran los alumnos
		String materiasArchivo = "Materias.txt";

		// Crear una lista para guardar los alumnos recuperados del archivo
		List<Materia> materias = new ArrayList<>();
		materias = archivoMateria.leerMaterias(materiasArchivo);
		
		// Crear una lista para guardar los profesores recuperados del archivo
		String profesoresArchivo = "Profesores.txt";
		List<Profesor> profesores = new ArrayList<>();
		profesores = archivoProfesor.leerProfesores(profesoresArchivo);

		switch (opcion) {
		case 1:
			System.out.println("\n===========================================");
			System.out.println("| Listado de Materias                     |");
			System.out.println("===========================================");
			materias.forEach((materia) -> System.out.println(materia.toString()));
			System.out.println("\n");
			break;
		case 2:
			scanner.nextLine();
			System.out.println("\n===========================================");
			System.out.println("| Agregar Materia                         |");
			System.out.println("===========================================");
			System.out.println("Ingrese el nombre: ");
			String nombreMateria = scanner.nextLine();
			
			System.out.println("Ingrese el id del profesor: ");
			Integer idProfesor = scanner.nextInt();
			Profesor profesor = gestionProfesor.buscarProfesor(profesores, idProfesor);
			
			System.out.println("Ingrese el grado: ");
			Integer grado = scanner.nextInt();
			scanner.nextLine();
			System.out.println("Ingrese el salón: ");
			String salon = scanner.nextLine();

			Materia materia = new Materia(materias.size() + 1, nombreMateria, profesor, grado, salon);
			materias.add(materia);

			// Crear la lista de alumnos en un Archivo
			archivoMateria.guardarMaterias(materiasArchivo, materias);

			break;
		case 3:
			scanner.nextLine();
			System.out.println("\n===========================================");
			System.out.println("| Modificar Materia                       |");
			System.out.println("===========================================");
			System.out.println("Ingrese el id de la materia a modificar: ");
			Integer id = scanner.nextInt();
			materia = gestionMateria.buscarMateria(materias, id);
			if (materia == null) {
				System.out.println("No se encontró id a modificar");
			} else {
				scanner.nextLine();
				System.out.println("Ingrese el nombre: ");
				nombreMateria = scanner.nextLine();
				materia.setNombreMateria(nombreMateria);
				
				System.out.println("Ingrese el id del profesor: ");
				idProfesor = scanner.nextInt();
				profesor = gestionProfesor.buscarProfesor(profesores, idProfesor);
				materia.setProfesor(profesor);
				
				System.out.println("Ingrese el grado: ");
				grado = scanner.nextInt();
				materia.setGrado(grado);
				
				scanner.nextLine();
				System.out.println("Ingrese el salón: ");
				salon = scanner.nextLine();
				materia.setSalon(salon);
			}

			// Crear la lista de alumnos en un Archivo
			archivoMateria.guardarMaterias(materiasArchivo, materias);
			break;
		case 4:
			scanner.nextLine();
			System.out.println("\n===========================================");
			System.out.println("| Eliminar Materia                        |");
			System.out.println("===========================================");
			System.out.println("Ingrese el id de la materia a eliminar: ");
			id = scanner.nextInt();
			materia = gestionMateria.buscarMateria(materias, id);
			if (materia == null) {
				System.out.println("No se encontró id a eliminar");
			} else {
				materias.remove(materia);
			}

			// Crear la lista de alumnos en un Archivo
			archivoMateria.guardarMaterias(materiasArchivo, materias);
			break;
		case 5:
			System.out.println("Regresando al menu anterior\n");
			break;
		default:
			System.out.println("Error: " + opcion + " no es una opción válida.\n");
		}
	}

	public void vista() {
		int opcion;

		do {
			try {
				System.out.println("\n===========================================");
				System.out.println("| Materia AR                              |");
				System.out.println("|=========================================|");
				System.out.println("| 1. Listar                               |");
				System.out.println("| 2. Agregar                              |");
				System.out.println("| 3. Modificar                            |");
				System.out.println("| 4. Eliminar                             |");
				System.out.println("| 5. Regresar                             |");
				System.out.println("===========================================");
				System.out.print("Ingrese la opción: ");
				opcion = scanner.nextInt();
				menuMaterias(opcion);
			} catch (InputMismatchException excepcion) {
				System.out.println("Error! No es una opción válida \n");
				scanner.next();
				opcion = 0;
			}
		} while (opcion != 5);
	}

}
