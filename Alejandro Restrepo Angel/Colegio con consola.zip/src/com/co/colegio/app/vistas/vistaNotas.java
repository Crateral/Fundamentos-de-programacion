package com.co.colegio.app.vistas;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.co.colegio.app.interfaces.IArchivoAlumno;
import com.co.colegio.app.interfaces.IArchivoMateria;
import com.co.colegio.app.interfaces.IArchivoNota;
import com.co.colegio.app.interfaces.IGestionAlumno;
import com.co.colegio.app.interfaces.IGestionMateria;
import com.co.colegio.app.interfaces.IGestionNota;
import com.co.colegio.app.logica.GestionAlumnoImpl;
import com.co.colegio.app.logica.GestionMateriaImpl;
import com.co.colegio.app.logica.GestionNotaImpl;
import com.co.colegio.app.modelos.Alumno;
import com.co.colegio.app.modelos.Materia;
import com.co.colegio.app.modelos.Nota;
import com.co.colegio.app.utilitarios.ArchivoAlumnoImpl;
import com.co.colegio.app.utilitarios.ArchivoMateriaImpl;
import com.co.colegio.app.utilitarios.ArchivoNotaImpl;



public class vistaNotas {

	Scanner scanner = new Scanner(System.in);

	private void menuNotas(int opcion) {

		// Instanciar objetos logica de negocio
		IArchivoMateria archivoMateria = new ArchivoMateriaImpl();
		IArchivoAlumno archivoAlumno = new ArchivoAlumnoImpl();
		IArchivoNota archivoNota = new ArchivoNotaImpl();
		IGestionMateria gestionMateria = new GestionMateriaImpl();
		IGestionAlumno gestionAlumno = new GestionAlumnoImpl();
		IGestionNota gestionNota = new GestionNotaImpl();

		// Indicamos el nombre del archivo donde se encuentran las notas
		String notasArchivo = "Notas.txt";

		// Crear una lista para guardar las notas recuperadas del archivo
		List<Nota> notas = new ArrayList<>();
		notas = archivoNota.leerNotas(notasArchivo);
		
		// Crear una lista para guardar las materias recuperadas del archivo
		String materiasArchivo = "Materias.txt";
		List<Materia> materias = new ArrayList<>();
		materias = archivoMateria.leerMaterias(materiasArchivo);
		
		// Crear una lista para guardar los alumnos recuperados del archivo
		String alumnosArchivo = "Alumnos.txt";
		List<Alumno> alumnos = new ArrayList<>();
		alumnos = archivoAlumno.leerAlumnos(alumnosArchivo);

		switch (opcion) {
		case 1:
			System.out.println("\n===========================================");
			System.out.println("| Listado de Notas                        |");
			System.out.println("===========================================");
			notas.forEach((nota) -> System.out.println(nota.toString()));
			System.out.println("\n");
			break;
		case 2:
			scanner.nextLine();
			System.out.println("\n===========================================");
			System.out.println("| Agregar Nota                            |");
			System.out.println("===========================================");			
			System.out.println("Ingrese el id del alumno: ");
			Integer idAlumno = scanner.nextInt();
			Alumno alumno = gestionAlumno.buscarAlumno(alumnos, idAlumno);
			
			System.out.println("Ingrese el id de la materia: ");
			Integer idMateria = scanner.nextInt();
			Materia materia = gestionMateria.buscarMateria(materias, idMateria);
			
			System.out.println("Ingrese la nota: ");
			Double valorNota = scanner.nextDouble();
			
			scanner.nextLine();
			System.out.println("Ingrese la observación: ");
			String observacion = scanner.nextLine();

			Nota nota = new Nota(notas.size() + 1, alumno, materia, valorNota, observacion);
			notas.add(nota);

			// Crear la lista de notas en un Archivo
			archivoNota.guardarNotas(notasArchivo, notas);

			break;
			
		case 3:
			scanner.nextLine();
			System.out.println("\n===========================================");
			System.out.println("| Modificar Nota                          |");
			System.out.println("===========================================");
			System.out.println("Ingrese el id de la nota a modificar: ");
			Integer idNota = scanner.nextInt();
			nota = gestionNota.buscarNota(notas, idNota);
			if (nota == null) {
				System.out.println("No se encontró id a modificar");
			} else {
				
				System.out.println("Ingrese el id del alumno: ");
				idAlumno = scanner.nextInt();
				alumno = gestionAlumno.buscarAlumno(alumnos, idAlumno);
				nota.setAlumno(alumno);
				
				System.out.println("Ingrese el id de la materia: ");
				idMateria = scanner.nextInt();
				materia = gestionMateria.buscarMateria(materias, idMateria);
				nota.setMateria(materia);
				
				System.out.println("Ingrese la nota: ");
				valorNota = scanner.nextDouble();
				nota.setNota(valorNota);
				
				scanner.nextLine();
				System.out.println("Ingrese la observación: ");
				observacion = scanner.nextLine();
				nota.setObservacion(observacion);
				
			}

			// Crear la lista de notas en un Archivo
			archivoNota.guardarNotas(notasArchivo, notas);
			break;
		case 4:
			scanner.nextLine();
			System.out.println("\n===========================================");
			System.out.println("| Eliminar Nota                           |");
			System.out.println("===========================================");
			System.out.println("Ingrese el id de la nota a eliminar: ");
			idNota = scanner.nextInt();
			nota = gestionNota.buscarNota(notas, idNota);
			if (nota == null) {
				System.out.println("No se encontró id a eliminar");
			} else {
				notas.remove(nota);
			}

			// Crear la lista de notas en un Archivo
			archivoNota.guardarNotas(notasArchivo, notas);
			break;
		case 5:
			System.out.println("\n===========================================");
			System.out.println("| Reporte Nota                            |");
			System.out.println("===========================================");
			System.out.println("Ingrese el id del alumno: ");
			idAlumno = scanner.nextInt();
			alumno = gestionAlumno.buscarAlumno(alumnos, idAlumno);
			
			System.out.println("Ingrese el id de la materia: ");
			idMateria = scanner.nextInt();
			materia = gestionMateria.buscarMateria(materias, idMateria);
			
			List<Nota> notasAlumno = new ArrayList<>();
			notasAlumno = gestionNota.notasAlumno((Alumno) alumno, materia, notas);
			gestionNota.calcularNota((Alumno) alumno, materia, notasAlumno);
			break;
		case 6:
			System.out.println("\n===========================================");
			System.out.println("| Reporte Notas                           |");
			System.out.println("===========================================");
			gestionNota.calcularNotas(alumnos, materias, notas);		
			break;
		case 7:
			System.out.println("Regresando al menu anterior\n");
			break;
		default:
			System.out.println("Error: " + opcion + " no es una opción válida.\n");
		}
	}

	public void vista() {
		int opcion;

		do {
			try {
				System.out.println("\n===========================================");
				System.out.println("| Notas AR                                |");
				System.out.println("|=========================================|");
				System.out.println("| 1. Listar                               |");
				System.out.println("| 2. Agregar                              |");
				System.out.println("| 3. Modificar                            |");
				System.out.println("| 4. Eliminar                             |");
				System.out.println("| 5. Calcular nota alumno                 |");
				System.out.println("| 6. Calcular todas las notas             |");
				System.out.println("| 7. Regresar                             |");
				System.out.println("===========================================");
				System.out.print("Ingrese la opción: ");
				opcion = scanner.nextInt();
				menuNotas(opcion);
			} catch (InputMismatchException excepcion) {
				System.out.println("Error! No es una opción válida \n");
				scanner.next();
				opcion = 0;
			}
		} while (opcion != 7);
	}

}
