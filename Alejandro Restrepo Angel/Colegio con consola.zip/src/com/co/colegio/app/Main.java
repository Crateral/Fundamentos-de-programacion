package com.co.colegio.app;

import com.co.colegio.app.vistas.Menu;

public class Main {

	public static void main(String[] args) { 
		
		Menu menu = new Menu();
		menu.vista();
		
	}

}
