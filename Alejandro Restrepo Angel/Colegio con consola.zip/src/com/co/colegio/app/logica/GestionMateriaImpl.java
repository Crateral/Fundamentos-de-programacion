package com.co.colegio.app.logica;

import java.util.List;

import com.co.colegio.app.interfaces.IGestionMateria;
import com.co.colegio.app.modelos.Materia;

public class GestionMateriaImpl implements IGestionMateria{

	@Override
	public Materia buscarMateria(List<Materia> materias, int id) {
		for(Materia materia:materias) {
			if(materia.getIdMateria()==id) {
				return materia;
			}
		}
		return null;
	}

}
