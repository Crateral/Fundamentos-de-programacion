package com.co.nttdata.ecommerce.interfaces;

public interface IGestionLogin {

	public void iniciarSesion(String nombreUsuario, String clave);
	public void cerrarSesion();
	public void cambiarClave(int id_Usuario, String clave);
	
}
