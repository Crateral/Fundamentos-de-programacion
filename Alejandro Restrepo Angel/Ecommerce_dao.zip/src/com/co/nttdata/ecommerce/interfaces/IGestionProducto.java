package com.co.nttdata.ecommerce.interfaces;

import com.co.nttdata.ecommerce.modelos.Producto;

public interface IGestionProducto {
	
	public void listarProductos();
	public void crearProducto(Producto producto);
	public void buscarPorProducto(String nombreProducto);
	public void buscarPorId(int id);
	public void eliminarPorId(int id);

	public Double DefinirValorDescuento(int id_producto);

}
