package com.co.nttdata.ecommerce.interfaces;

import com.co.nttdata.ecommerce.modelos.Categoria;

public interface IGestionCategoria {
	
	public void listarCategorias();
	public void crearCategoria(Categoria categoria);
	public void buscarPorNombre(String nombreCategoria);
	public void buscarPorId(int id);
	public void eliminarPorId(int id);

}
