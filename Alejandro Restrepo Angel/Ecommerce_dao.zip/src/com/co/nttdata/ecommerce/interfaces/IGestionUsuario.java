package com.co.nttdata.ecommerce.interfaces;

import com.co.nttdata.ecommerce.modelos.Usuario;

public interface IGestionUsuario {
	
	public void listarUsuarios();
	public void crearUsuario(Usuario usuario);
	public void buscarPorNombre(String nombreUsuario);
	public void buscarPorId(int id);
	public void eliminarPorId(int id);

}
