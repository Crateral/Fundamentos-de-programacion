package com.co.nttdata.ecommerce.interfaces;

import com.co.nttdata.ecommerce.modelos.Registro;

public interface IGestionRegistro {
	
	public void listarRegistros();
	public void crearRegistro(Registro registro);
	public void buscarPorUsuario(int id_Usuario);
	public void buscarPorId(int id);
	public void eliminarPorId(int id);

}
