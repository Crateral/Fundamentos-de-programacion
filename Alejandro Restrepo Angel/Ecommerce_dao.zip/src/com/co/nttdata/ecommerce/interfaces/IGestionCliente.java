package com.co.nttdata.ecommerce.interfaces;

import com.co.nttdata.ecommerce.modelos.Cliente;

public interface IGestionCliente {
	
	public void listarClientes();
	public void crearCliente(Cliente cliente);
	public void buscarPorCorreo(String correo);
	public void buscarPorId(int id);
	public void eliminarPorId(int id);

}
