package com.co.nttdata.ecommerce.interfaces;

import com.co.nttdata.ecommerce.modelos.Empresa;

public interface IGestionEmpresa {
	
	public void listarEmpresas();
	public void crearEmpresa(Empresa empresa);
	public void buscarPorNit(String nitEmpresa);
	public void buscarPorId(int id);
	public void eliminarPorId(int id);

}
