package com.co.nttdata.ecommerce.interfaces;

import com.co.nttdata.ecommerce.modelos.Administrador;

public interface IGestionAdministrador {
	
	public void listarAdministradores();
	public void crearAdministrador(Administrador administrador);
	public void buscarPorCorreo(String correo);
	public void buscarPorId(int id);
	public void eliminarPorId(int id);

}
