package com.co.nttdata.ecommerce.interfaces;

import com.co.nttdata.ecommerce.modelos.Factura;

public interface IGestionFactura {
	
	public void listarFacturas();
	public void crearFactura(Factura factura);
	public void buscarPorCliente(int id_Cliente);
	public void buscarPorId(int id);
	public void eliminarPorId(int id);
	
	public Double calcularCostoEnvio(int id_Cliente, int id_CarritoCompra);
	public Double calcularTotalSinIva(int id_Cliente, int id_CarritoCompra);
	public Double calcularTotalConIva(int id_Cliente, int id_CarritoCompra);
	
	public void imprimirFactura(int id_Factura);

}
