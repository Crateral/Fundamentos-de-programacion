package com.co.nttdata.ecommerce.interfaces;

import com.co.nttdata.ecommerce.modelos.Ciudad;

public interface IGestionCiudad {
	
	public void listarCiudades();
	public void crearCiudad(Ciudad ciudad);
	public void buscarPorNombre(String nombreCiudad);
	public void buscarPorId(int id);
	public void eliminarPorId(int id);

}
