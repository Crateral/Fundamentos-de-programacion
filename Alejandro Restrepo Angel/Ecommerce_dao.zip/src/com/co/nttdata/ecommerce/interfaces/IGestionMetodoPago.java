package com.co.nttdata.ecommerce.interfaces;

import com.co.nttdata.ecommerce.modelos.MetodoPago;

public interface IGestionMetodoPago {
	
	public void listarMetodosPago();
	public void crearMetodoPago(MetodoPago metodoPago);
	public void buscarPorNombre(String nombreMetodo);
	public void buscarPorId(int id);
	public void eliminarPorId(int id);

}
