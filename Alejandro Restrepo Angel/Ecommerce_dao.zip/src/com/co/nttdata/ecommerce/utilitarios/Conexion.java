package com.co.nttdata.ecommerce.utilitarios;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {

	private static final String URL = "jdbc:postgresql://localhost:5432/db_ecommerce";
	private static final String USUARIO = "postgres";
	private static final String CONTRASENA = "12345678";
	
	public Connection conectarBD () {
		
		Connection baseDatos = null;		
		try {
			baseDatos = DriverManager.getConnection(URL, USUARIO, CONTRASENA);
		} catch (SQLException e) {
			e.printStackTrace();
		}		
		return baseDatos;
	}
	
	public void desconectarBD(Connection baseDatos) {
		try {
			baseDatos.close();
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
}
