package com.co.nttdata.ecommerce.modelos;

import java.io.Serializable;
import java.util.Date;

public class Registro implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int id;
	private int id_Usuario;
	private Date fecha_Accion;
	private String accion;
	private String resultado;
	private String hostname;
	private String ip;
	
	public Registro() {
		super();
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getId_Usuario() {
		return this.id_Usuario;
	}

	public void setId_Usuario(int id_Usuario) {
		this.id_Usuario = id_Usuario;
	}

	public Date getFecha_Accion() {
		return this.fecha_Accion;
	}

	public void setFecha_Accion(Date fecha_Accion) {
		this.fecha_Accion = fecha_Accion;
	}

	public String getAccion() {
		return this.accion;
	}

	public void setAccion(String accion) {
		this.accion = accion;
	}

	public String getResultado() {
		return this.resultado;
	}

	public void setResultado(String resultado) {
		this.resultado = resultado;
	}

	public String getHostname() {
		return this.hostname;
	}

	public void setHostname(String hostname) {
		this.hostname = hostname;
	}

	public String getIp() {
		return this.ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	@Override
	public String toString() {
		return "Registro [id=" + this.id 
				+ ", usuario=" + this.id_Usuario 
				+ ", fecha accion=" + this.fecha_Accion 
				+ ", accion=" + this.accion 
				+ ", resultado=" + this.resultado 
				+ ", hostname=" + this.hostname 
				+ ", ip=" + this.ip + "]";
	}

}
