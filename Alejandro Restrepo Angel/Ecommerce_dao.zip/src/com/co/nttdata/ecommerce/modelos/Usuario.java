package com.co.nttdata.ecommerce.modelos;

import java.io.Serializable;

public class Usuario implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int id;
	private String usuario;
	private String clave;
	private Boolean estado;

	public Usuario() {
		super();
	}

	public Usuario(int id, String usuario, String clave, Boolean estado) {
		super();
		this.id = id;
		this.usuario = usuario;
		this.clave = clave;
		this.estado = estado;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsuario() {
		return this.usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getClave() {
		return this.clave;
	}

	public void setClave(String clave) {
		this.clave = clave;
	}

	public Boolean getEstado() {
		return this.estado;
	}

	public void setEstado(Boolean estado) {
		this.estado = estado;
	}

	@Override
	public String toString() {
		return "Usuario [id=" + this.id 
				+ ", usuario=" + this.usuario 
				+ ", clave=" + this.clave 
				+ ", estado=" + this.estado + "]";
	}

}
