package com.co.nttdata.ecommerce.modelos;

import java.io.Serializable;
import java.util.Date;

public class Factura implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int id;
	private int id_Empresa;
	private int id_Cliente;
	private Date fecha;
	private int id_CarritoCompra;
	private String descripcion;
	private double TotalEnvio;
	private double valorTotalSinIva;
	private double valorTotalConIva;

	public Factura() {
		super();
	}

	public Factura(int id, int id_Empresa, int id_Cliente, Date fecha, int id_CarritoCompra, String descripcion,
			double TotalEnvio, double valorTotalSinIva, double valorTotalConIva) {
		super();
		this.id = id;
		this.id_Empresa = id_Empresa;
		this.id_Cliente = id_Cliente;
		this.fecha = fecha;
		this.id_CarritoCompra = id_CarritoCompra;
		this.descripcion = descripcion;
		this.TotalEnvio = TotalEnvio;
		this.valorTotalSinIva = valorTotalSinIva;
		this.valorTotalConIva = valorTotalConIva;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getId_Empresa() {
		return this.id_Empresa;
	}

	public void setId_Empresa(int id_Empresa) {
		this.id_Empresa = id_Empresa;
	}

	public int getId_Cliente() {
		return this.id_Cliente;
	}

	public void setId_Cliente(int id_Cliente) {
		this.id_Cliente = id_Cliente;
	}

	public Date getFecha() {
		return this.fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public int getId_CarritoCompra() {
		return this.id_CarritoCompra;
	}

	public void setId_CarritoCompra(int id_CarritoCompra) {
		this.id_CarritoCompra = id_CarritoCompra;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
	public double getTotalEnvio() {
		return this.TotalEnvio;
	}

	public void setTotalEnvio(double totalEnvio) {
		this.TotalEnvio = totalEnvio;
	}

	public double getValorTotalSinIva() {
		return this.valorTotalSinIva;
	}

	public void setValorTotalSinIva(double valorTotalSinIva) {
		this.valorTotalSinIva = valorTotalSinIva;
	}

	public double getValorTotalConIva() {
		return this.valorTotalConIva;
	}

	public void setValorTotalConIva(double valorTotalConIva) {
		this.valorTotalConIva = valorTotalConIva;
	}

	@Override
	public String toString() {
		return "Factura [id=" + this.id 
				+ ", empresa=" + this.id_Empresa 
				+ ", cliente=" + this.id_Cliente 
				+ ", fecha=" + this.fecha
				+ ", Carrito de Compra=" + this.id_CarritoCompra 
				+ ", descripcion=" + this.descripcion 
				+ ", Total envío=" + this.TotalEnvio
				+ ", Total sin iva=" + this.valorTotalSinIva
				+ ", Total con iva=" + this.valorTotalConIva + "]";
	}
	
}
