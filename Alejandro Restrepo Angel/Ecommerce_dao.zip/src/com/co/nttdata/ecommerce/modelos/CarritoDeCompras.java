package com.co.nttdata.ecommerce.modelos;

import java.io.Serializable;

public class CarritoDeCompras implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int id;
	private Double subtotalSinIva;
	private Double subtotalConIva;
	private Double valorEnvio;
	
	public CarritoDeCompras() {
		super();
	}

	public CarritoDeCompras(int id, Double subtotalSinIva, Double subtotalConIva, Double valorEnvio) {
		super();
		this.id = id;
		this.subtotalSinIva = subtotalSinIva;
		this.subtotalConIva = subtotalConIva;
		this.valorEnvio = valorEnvio;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Double getSubtotalSinIva() {
		return this.subtotalSinIva;
	}

	public void setSubtotalSinIva(Double subtotalSinIva) {
		this.subtotalSinIva = subtotalSinIva;
	}

	public Double getSubtotalConIva() {
		return this.subtotalConIva;
	}

	public void setSubtotalConIva(Double subtotalConIva) {
		this.subtotalConIva = subtotalConIva;
	}

	public Double getValorEnvio() {
		return this.valorEnvio;
	}

	public void setValorEnvio(Double valorEnvio) {
		this.valorEnvio = valorEnvio;
	}

	@Override
	public String toString() {
		return "Carrito de Compra [id=" + this.id 
				+ ", subtotal sin iva=" + this.subtotalSinIva 
				+ ", subtotal con iva=" + this.subtotalConIva
				+ ", valor envio=" + this.valorEnvio + "]";
	}

}
