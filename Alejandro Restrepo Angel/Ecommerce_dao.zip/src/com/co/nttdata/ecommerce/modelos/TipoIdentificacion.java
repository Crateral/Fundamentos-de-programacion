package com.co.nttdata.ecommerce.modelos;

import java.io.Serializable;

public class TipoIdentificacion implements Serializable {

	private static final long serialVersionUID = 1L;
	private int id;
	private String tipoIdentificacion;
	private String descripcion;
	
	public TipoIdentificacion() {
		super();
	}

	public TipoIdentificacion(int id, String tipoIdentificacion, String descripcion) {
		super();
		this.id = id;
		this.tipoIdentificacion = tipoIdentificacion;
		this.descripcion = descripcion;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTipoIdentificacion() {
		return this.tipoIdentificacion;
	}

	public void setTipoIdentificacion(String tipoIdentificacion) {
		this.tipoIdentificacion = tipoIdentificacion;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	@Override
	public String toString() {
		return "TipoIdentificacion [id=" + this.id 
				+ ", tipo identificacion=" + this.tipoIdentificacion 
				+ ", descripcion=" + this.descripcion + "]";
	}

}
