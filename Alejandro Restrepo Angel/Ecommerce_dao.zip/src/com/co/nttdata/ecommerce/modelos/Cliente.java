package com.co.nttdata.ecommerce.modelos;

import java.io.Serializable;

public class Cliente extends Usuario implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int id;
	private int id_Usuario;
	private int id_Ciudad;
	private int id_TipoIdentificacion;
	private String numeroIdentificacion;
	private String nombre;
	private String apellido;
	private int id_MetodoDePago;
	private String correo;
	private String telefono;
	private String direccion;

	public Cliente() {
		super();
	}

	public Cliente(int id, int id_Usuario, int id_Ciudad, int id_TipoIdentificacion, String numeroIdentificacion,
			String nombre, String apellido, int id_MetodoDePago, String correo, String telefono, String direccion) {
		super();
		this.id = id;
		this.id_Usuario = id_Usuario;
		this.id_Ciudad = id_Ciudad;
		this.id_TipoIdentificacion = id_TipoIdentificacion;
		this.numeroIdentificacion = numeroIdentificacion;
		this.nombre = nombre;
		this.apellido = apellido;
		this.id_MetodoDePago = id_MetodoDePago;
		this.correo = correo;
		this.telefono = telefono;
		this.direccion = direccion;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getId_Usuario() {
		return this.id_Usuario;
	}

	public void setId_Usuario(int id_Usuario) {
		this.id_Usuario = id_Usuario;
	}

	public int getId_Ciudad() {
		return this.id_Ciudad;
	}

	public void setId_Ciudad(int id_Ciudad) {
		this.id_Ciudad = id_Ciudad;
	}

	public int getId_TipoIdentificacion() {
		return this.id_TipoIdentificacion;
	}

	public void setId_TipoIdentificacion(int id_TipoIdentificacion) {
		this.id_TipoIdentificacion = id_TipoIdentificacion;
	}

	public String getNumeroIdentificacion() {
		return this.numeroIdentificacion;
	}

	public void setNumeroIdentificacion(String numeroIdentificacion) {
		this.numeroIdentificacion = numeroIdentificacion;
	}

	public String getNombre() {
		return this.nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return this.apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public int getId_MetodoDePago() {
		return this.id_MetodoDePago;
	}

	public void setId_MetodoDePago(int id_MetodoDePago) {
		this.id_MetodoDePago = id_MetodoDePago;
	}

	public String getCorreo() {
		return this.correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getTelefono() {
		return this.telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getDireccion() {
		return this.direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	@Override
	public String toString() {
		return "Cliente [id=" + this.id 
				+ ", usuario=" + this.id_Usuario 
				+ ", ciudad=" + this.id_Ciudad
				+ ", tipo identificacion=" + this.id_TipoIdentificacion 
				+ ", numero identificacion=" + this.numeroIdentificacion
				+ ", nombre=" + this.nombre 
				+ ", apellido=" + this.apellido 
				+ ", metodo de pago=" + this.id_MetodoDePago 
				+ ", correo=" + this.correo 
				+ ", telefono=" + this.telefono 
				+ ", direccion=" + this.direccion + "]";
	}
	
}
