package com.co.nttdata.ecommerce.modelos;

import java.io.Serializable;

public class Producto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int id;
	private int id_Marca;
	private int id_Categoria;
	private String producto;
	private int cantidadDiponible;
	private double precio;
	private boolean descuento;
	private double valorDescuento;
	private double iva;
	private String imagen;
	private String descripcion;

	public Producto() {
		super();
	}

	public Producto(int id, int id_Marca, int id_Categoria, String producto, int cantidadDiponible, double precio,
			boolean descuento, double valorDescuento, double iva, String imagen, String descripcion) {
		super();
		this.id = id;
		this.id_Marca = id_Marca;
		this.id_Categoria = id_Categoria;
		this.producto = producto;
		this.cantidadDiponible = cantidadDiponible;
		this.precio = precio;
		this.descuento = descuento;
		this.valorDescuento = valorDescuento;
		this.iva = iva;
		this.imagen = imagen;
		this.descripcion = descripcion;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getId_Marca() {
		return this.id_Marca;
	}

	public void setId_Marca(int id_Marca) {
		this.id_Marca = id_Marca;
	}

	public int getId_Categoria() {
		return this.id_Categoria;
	}

	public void setId_Categoria(int id_Categoria) {
		this.id_Categoria = id_Categoria;
	}

	public String getProducto() {
		return this.producto;
	}

	public void setProducto(String producto) {
		this.producto = producto;
	}

	public int getCantidadDiponible() {
		return this.cantidadDiponible;
	}

	public void setCantidadDiponible(int cantidadDiponible) {
		this.cantidadDiponible = cantidadDiponible;
	}

	public double getPrecio() {
		return this.precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public boolean isDescuento() {
		return this.descuento;
	}

	public void setDescuento(boolean descuento) {
		this.descuento = descuento;
	}

	public double getValorDescuento() {
		return this.valorDescuento;
	}

	public void setValorDescuento(double valorDescuento) {
		this.valorDescuento = valorDescuento;
	}

	public double getIva() {
		return this.iva;
	}

	public void setIva(double iva) {
		this.iva = iva;
	}

	public String getImagen() {
		return this.imagen;
	}

	public void setImagen(String imagen) {
		this.imagen = imagen;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	@Override
	public String toString() {
		return "Producto [id=" + this.id 
				+ ", marca=" + this.id_Marca 
				+ ", categoria=" + this.id_Categoria 
				+ ", producto=" + this.producto 
				+ ", cantidad diponible=" + this.cantidadDiponible 
				+ ", precio=" + this.precio 
				+ ", descuento=" + this.descuento 
				+ ", valor descuento=" + this.valorDescuento 
				+ ", iva=" + this.iva 
				+ ", imagen=" + this.imagen
				+ ", descripcion=" + this.descripcion + "]";
	}

}
