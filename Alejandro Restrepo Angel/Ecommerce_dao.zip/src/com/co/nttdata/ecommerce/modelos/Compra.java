package com.co.nttdata.ecommerce.modelos;

import java.io.Serializable;


public class Compra implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int id;
	private int id_Producto;
	private int id_CarritoCompra;
	private int cantidad;
	private double valor;

	public Compra() {
		super();
	}

	public Compra(int id, int id_Producto, int id_CarritoCompra, int cantidad, double valor) {
		super();
		this.id = id;
		this.id_Producto = id_Producto;
		this.id_CarritoCompra = id_CarritoCompra;
		this.cantidad = cantidad;
		this.valor = valor;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getId_Producto() {
		return this.id_Producto;
	}

	public void setId_Producto(int id_Producto) {
		this.id_Producto = id_Producto;
	}

	public int getId_CarritoCompra() {
		return id_CarritoCompra;
	}

	public void setId_CarritoCompra(int id_CarritoCompra) {
		this.id_CarritoCompra = id_CarritoCompra;
	}

	public int getCantidad() {
		return this.cantidad;
	}

	public void setCantidad(int cantidad) {
		this.cantidad = cantidad;
	}

	public double getValor() {
		return this.valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	@Override
	public String toString() {
		return "Compras [id=" + this.id 
				+ ", producto=" + this.id_Producto 
				+ ", Carrito de Compra=" + this.id_CarritoCompra
				+ ", cantidad=" + this.cantidad 
				+ ", valor=" + this.valor + "]";
	}

}
