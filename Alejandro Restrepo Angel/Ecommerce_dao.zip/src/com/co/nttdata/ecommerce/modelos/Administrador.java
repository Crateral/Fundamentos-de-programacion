package com.co.nttdata.ecommerce.modelos;

import java.io.Serializable;

public class Administrador extends Usuario implements Serializable{

	/**
	 * 
	 */	
	private static final long serialVersionUID = 1L;
	private int id;
	private int id_Usuario;
	private int id_TipoIdentificacion;
	private String numeroIdentificacion;
	private String nombre;
	private String apellido;
	private String correo;
	private String direccion;

	public Administrador() {
		super();
	}

	public Administrador(int id, int id_Usuario, int id_TipoIdentificacion, String numeroIdentificacion, String nombre,
			String apellido, String correo, String direccion) {
		super();
		this.id = id;
		this.id_Usuario = id_Usuario;
		this.id_TipoIdentificacion = id_TipoIdentificacion;
		this.numeroIdentificacion = numeroIdentificacion;
		this.nombre = nombre;
		this.apellido = apellido;
		this.correo = correo;
		this.direccion = direccion;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getId_Usuario() {
		return this.id_Usuario;
	}

	public void setId_Usuario(int id_Usuario) {
		this.id_Usuario = id_Usuario;
	}

	public int getId_TipoIdentificacion() {
		return this.id_TipoIdentificacion;
	}

	public void setId_TipoIdentificacion(int id_TipoIdentificacion) {
		this.id_TipoIdentificacion = id_TipoIdentificacion;
	}

	public String getNumeroIdentificacion() {
		return this.numeroIdentificacion;
	}

	public void setNumeroIdentificacion(String numeroIdentificacion) {
		this.numeroIdentificacion = numeroIdentificacion;
	}

	public String getNombre() {
		return this.nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return this.apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getCorreo() {
		return this.correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getDireccion() {
		return this.direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	@Override
	public String toString() {
		return "Administrador [id=" + this.id 
				+ ", usuario=" + this.id_Usuario 
				+ ", Tipo Identificacion=" + this.id_TipoIdentificacion 
				+ ", numero identificacion=" + this.numeroIdentificacion 
				+ ", nombre=" + this.nombre
				+ ", apellido=" + this.apellido 
				+ ", correo=" + this.correo 
				+ ", direccion=" + this.direccion + "]";
	}
	
}
