package com.co.nttdata.ecommerce.modelos;

import java.io.Serializable;

public class MetodoPago implements Serializable {

	private static final long serialVersionUID = 1L;
	private int id;
	private String metodoPago;
	private String descripcion;
	
	public MetodoPago() {
		super();
	}

	public MetodoPago(int id, String metodoPago, String descripcion) {
		super();
		this.id = id;
		this.metodoPago = metodoPago;
		this.descripcion = descripcion;
	}

	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMetodoPago() {
		return this.metodoPago;
	}

	public void setMetodoPago(String metodoPago) {
		this.metodoPago = metodoPago;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	@Override
	public String toString() {
		return "MetodoPago [id=" + this.id 
				+ ", metodo pago=" + this.metodoPago 
				+ ", descripcion=" + this.descripcion + "]";
	}
	
}
