package com.co.nttdata.ecommerce.vistas;

import java.sql.Date;
import java.util.List;

import com.co.nttdata.ecommerce.Dao.*;
import com.co.nttdata.ecommerce.interfaces.*;
import com.co.nttdata.ecommerce.logica.*;
import com.co.nttdata.ecommerce.modelos.*;

public class Main {

	public static void main(String[] args) {
		
		IGestionFactura gestion = new GestionFacturaImpl();
		
		gestion.imprimirFactura(1);
		
		System.out.println(gestion.calcularCostoEnvio(1, 1));
		System.out.println(gestion.calcularCostoEnvio(1, 2));
		
		System.out.println(gestion.calcularTotalSinIva(1, 1));
		System.out.println(gestion.calcularTotalConIva(1, 1));
		
		System.out.println(gestion.calcularTotalSinIva(1, 2));
		System.out.println(gestion.calcularTotalConIva(1, 2));
	}
}
