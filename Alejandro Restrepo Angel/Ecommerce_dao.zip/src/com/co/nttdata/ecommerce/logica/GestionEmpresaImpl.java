package com.co.nttdata.ecommerce.logica;

import java.util.List;

import com.co.nttdata.ecommerce.Dao.EmpresaDAO;
import com.co.nttdata.ecommerce.interfaces.IGestionEmpresa;
import com.co.nttdata.ecommerce.modelos.Empresa;

public class GestionEmpresaImpl implements IGestionEmpresa{
	
	private EmpresaDAO empresaDao = new EmpresaDAO();
	
	@Override
	public void crearEmpresa(Empresa empresa) {
		if(empresaDao.agregarEmpresa(empresa)) {
			System.out.println("La empresa se ha agregado correctamente");
		}
		else{
			System.out.println("Error: La empresa no se ha agregado correctamente");
		}
	}

	@Override
	public void listarEmpresas() {
		List<Empresa> listaEmpresa = empresaDao.listarEmpresas();
		System.out.println("Listado de empresas");
		if(listaEmpresa.isEmpty()) {
			System.out.println("Lista vacía");
		}
		else {
			listaEmpresa.forEach((empresa) ->System.out.println(empresa.toString()));	
		}
	}

	@Override
	public void buscarPorNit(String nitEmpresa) {
		Empresa empresa = new Empresa();
		empresa = empresaDao.buscarEmpresa(nitEmpresa); 
		if(empresa.getId()!=0) {
			System.out.println(empresa.toString());
		}
		else {
			System.out.println("No se ha encontrado ninguna empresa");
		}		
	}

	@Override
	public void buscarPorId(int id) {
		Empresa empresa = new Empresa();
		empresa = empresaDao.buscarPorId(id); 
		if(empresa.getId()!=0) {
			System.out.println(empresa.toString());
		}
		else {
			System.out.println("No se ha encontrado ninguna empresa");
		}	
	}

	@Override
	public void eliminarPorId(int id) {
		if(empresaDao.eliminarPorId(id)) {
			System.out.println("La empresa se ha eliminado correctamente");
		}
		else{
			System.out.println("Error: La empresa no se ha eliminado correctamente");
		}	
	}

}
