package com.co.nttdata.ecommerce.logica;

import java.util.List;

import com.co.nttdata.ecommerce.Dao.RegistroDAO;
import com.co.nttdata.ecommerce.interfaces.IGestionRegistro;
import com.co.nttdata.ecommerce.modelos.Registro;

public class GestionRegistroImpl implements IGestionRegistro{
	
	private RegistroDAO registroDao = new RegistroDAO();
	
	@Override
	public void crearRegistro(Registro registro) {
		if(registroDao.agregarRegistro(registro)) {
			System.out.println("El registro se ha agregado correctamente");
		}
		else{
			System.out.println("Error: El registro no se ha agregado correctamente");
		}
	}

	@Override
	public void listarRegistros() {
		List<Registro> listaregistros = registroDao.listarRegistros();
		System.out.println("Listado de registros");
		if(listaregistros.isEmpty()) {
			System.out.println("Lista vacía");
		}
		else {
			listaregistros.forEach((registro) ->System.out.println(registro.toString()));	
		}
	}

	@Override
	public void buscarPorUsuario(int id_Usuario) {
		List<Registro> listaregistros = registroDao.buscarRegistrosUsuario(id_Usuario); 
		System.out.println("Listado de registros");
		if(listaregistros.isEmpty()) {
			System.out.println("Lista vacía");
		}
		else {
			listaregistros.forEach((registro) ->System.out.println(registro.toString()));	
		}
	}

	@Override
	public void buscarPorId(int id) {
		Registro administrador = new Registro();
		administrador = registroDao.buscarPorId(id); 
		if(administrador.getId()!=0) {
			System.out.println(administrador.toString());
		}
		else {
			System.out.println("No se ha encontrado ningún administrador");
		}	
	}

	@Override
	public void eliminarPorId(int id) {
		if(registroDao.eliminarPorId(id)) {
			System.out.println("El registro se ha eliminado correctamente");
		}
		else{
			System.out.println("Error: El registro no se ha eliminado correctamente");
		}	
	}

}
