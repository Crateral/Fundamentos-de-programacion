package com.co.nttdata.ecommerce.logica;

import java.util.List;

import com.co.nttdata.ecommerce.Dao.CategoriaDAO;
import com.co.nttdata.ecommerce.interfaces.IGestionCategoria;
import com.co.nttdata.ecommerce.modelos.Categoria;

public class GestionCategoriaImpl implements IGestionCategoria{
	
	private CategoriaDAO categoriaDao = new CategoriaDAO();
	
	@Override
	public void crearCategoria(Categoria categoria) {
		if(categoriaDao.agregarCategoria(categoria)) {
			System.out.println("La categoría se ha agregado correctamente");
		}
		else{
			System.out.println("Error: la categoría no se ha agregado correctamente");
		}
	}

	@Override
	public void listarCategorias() {
		List<Categoria> listaCategorias = categoriaDao.listarCategorias();
		System.out.println("Listado de categorías");
		if(listaCategorias.isEmpty()) {
			System.out.println("Lista vacía");
		}
		else {
			listaCategorias.forEach((categoria) ->System.out.println(categoria.toString()));	
		}
	}

	@Override
	public void buscarPorNombre(String nombreCategoria) {
		Categoria categoria = new Categoria();
		categoria = categoriaDao.buscarCategoria(nombreCategoria); 
		if(categoria.getId()!=0) {
			System.out.println(categoria.toString());
		}
		else {
			System.out.println("No se ha encontrado ninguna categoría");
		}		
	}

	@Override
	public void buscarPorId(int id) {
		Categoria categoria = new Categoria();
		categoria = categoriaDao.buscarPorId(id); 
		if(categoria.getId()!=0) {
			System.out.println(categoria.toString());
		}
		else {
			System.out.println("No se ha encontrado ninguna categoría");
		}	
	}

	@Override
	public void eliminarPorId(int id) {
		if(categoriaDao.eliminarPorId(id)) {
			System.out.println("La categoría se ha eliminado correctamente");
		}
		else{
			System.out.println("Error: la categoría no se ha eliminado correctamente");
		}	
	}

}
