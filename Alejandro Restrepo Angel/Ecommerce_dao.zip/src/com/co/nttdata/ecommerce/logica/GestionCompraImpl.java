package com.co.nttdata.ecommerce.logica;

import java.util.List;

import com.co.nttdata.ecommerce.Dao.ProductoDAO;
import com.co.nttdata.ecommerce.Dao.CompraDAO;
import com.co.nttdata.ecommerce.interfaces.IGestionCompra;
import com.co.nttdata.ecommerce.interfaces.IGestionProducto;
import com.co.nttdata.ecommerce.modelos.Compra;
import com.co.nttdata.ecommerce.modelos.Producto;

public class GestionCompraImpl implements IGestionCompra {

	private CompraDAO compraDao = new CompraDAO();
	private ProductoDAO productoDao = new ProductoDAO();
	
	@Override
	public void crearCompra(Compra compra) {
		if(compraDao.agregarCompra(compra)) {
			System.out.println("La compra se ha agregado correctamente");
		}
		else{
			System.out.println("Error: la compra no se ha agregado correctamente");
		}
	}

	@Override
	public void listarCompras() {
		List<Compra> listaCompras = compraDao.listarCompras();
		System.out.println("Listado de compras");
		if(listaCompras.isEmpty()) {
			System.out.println("Lista vacía");
		}
		else {
			listaCompras.forEach((compra) ->System.out.println(compra.toString()));	
		}
	}

	@Override
	public void buscarPorCarritoCompras(int id_Carrito_compras) {
		List<Compra> listaCompras = compraDao.buscarPorCarritoDeCompras(id_Carrito_compras); 
		System.out.println("Listado de compras");
		if(listaCompras.isEmpty()) {
			System.out.println("Lista vacía");
		}
		else {
			listaCompras.forEach((compra) ->System.out.println(compra.toString()));	
		}	
	}

	@Override
	public void buscarPorId(int id) {
		Compra compra = new Compra();
		compra = compraDao.buscarPorId(id); 
		if(compra.getId()!=0) {
			System.out.println(compra.toString());
		}
		else {
			System.out.println("No se ha encontrado ninguna compra");
		}	
	}

	@Override
	public void eliminarPorId(int id) {
		if(compraDao.eliminarPorId(id)) {
			System.out.println("La compra se ha eliminado correctamente");
		}
		else{
			System.out.println("Error: La compra no se ha eliminado correctamente");
		}	
	}

	@Override
	public Double calcularValor(int id_Producto, int cantidad) {
		
		Double valor = 0.0, descuento = 0.0;
		
		IGestionProducto gestionProducto = new GestionProductoImpl();
		Producto producto = new Producto();
		
		descuento = gestionProducto.DefinirValorDescuento(id_Producto);
		producto = productoDao.buscarPorId(id_Producto); 
		
		valor = (producto.getPrecio() * cantidad) * (1 - descuento);	
		return valor; 
	}
	
	@Override
	public Producto agregarProductoCompra(int id_Producto, int cantidad) {	
		Producto producto = new Producto();
		producto = productoDao.buscarPorId(id_Producto); 
		producto.setCantidadDiponible((producto.getCantidadDiponible()-cantidad));
		return producto;	
	}
	
	@Override
	public Producto devolverProductoCompra(int id_Producto, int cantidad) {	
		Producto producto = new Producto();
		producto = productoDao.buscarPorId(id_Producto); 
		producto.setCantidadDiponible((producto.getCantidadDiponible()+cantidad));
		return producto;	
	}

}
