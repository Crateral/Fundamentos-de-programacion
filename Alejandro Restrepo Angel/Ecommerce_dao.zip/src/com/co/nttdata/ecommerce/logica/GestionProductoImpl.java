package com.co.nttdata.ecommerce.logica;

import java.util.List;

import com.co.nttdata.ecommerce.Dao.CategoriaDAO;
import com.co.nttdata.ecommerce.Dao.ProductoDAO;
import com.co.nttdata.ecommerce.interfaces.IGestionProducto;
import com.co.nttdata.ecommerce.modelos.Categoria;
import com.co.nttdata.ecommerce.modelos.Producto;

public class GestionProductoImpl implements IGestionProducto{
	
	private ProductoDAO productoDao = new ProductoDAO();
	private CategoriaDAO categoriaDao = new CategoriaDAO();
	
	@Override
	public void crearProducto(Producto producto) {
		if(productoDao.agregarProducto(producto)) {
			System.out.println("El producto se ha agregado correctamente");
		}
		else{
			System.out.println("Error: El producto no se ha agregado correctamente");
		}
	}

	@Override
	public void listarProductos() {
		List<Producto> listaProductos = productoDao.listarProductos();
		System.out.println("Listado de Productos");
		listaProductos.forEach((producto) ->System.out.println(producto.toString()));	
	}

	@Override
	public void buscarPorProducto(String nombreProducto) {
		Producto producto = new Producto();
		producto = productoDao.buscarProducto(nombreProducto); 
		if(producto.getId()!=0) {
			System.out.println(producto.toString());
		}
		else {
			System.out.println("No se ha encontrado ningún producto");
		}		
	}

	@Override
	public void buscarPorId(int id) {
		Producto producto = new Producto();
		producto = productoDao.buscarPorId(id); 
		if(producto.getId()!=0) {
			System.out.println(producto.toString());
		}
		else {
			System.out.println("No se ha encontrado ningún producto");
		}	
	}

	@Override
	public void eliminarPorId(int id) {
		if(productoDao.eliminarPorId(id)) {
			System.out.println("El producto se ha eliminado correctamente");
		}
		else{
			System.out.println("Error: El producto no se ha eliminado correctamente");
		}	
	}

	@Override
	public Double DefinirValorDescuento(int id_producto) {
		Double descuento = 0.0;
		Categoria categoria = new Categoria();
		Producto producto = new Producto();
		
		producto = productoDao.buscarPorId(id_producto);
		categoria = categoriaDao.buscarPorId(producto.getId_Categoria()); 
		
		if(categoria.isDescuento()) {
			descuento = categoria.getValor_Descuento();
			return descuento;
		}
		
		if(producto.isDescuento()) {
			descuento = producto.getValorDescuento();
			return descuento;
		}
		return descuento;
	}
	
}
