
package com.co.nttdata.ecommerce.logica;

import com.co.nttdata.ecommerce.Dao.UsuarioDAO;
import com.co.nttdata.ecommerce.interfaces.IGestionLogin;
import com.co.nttdata.ecommerce.modelos.*;

public class GestionLoginAdmImpl implements IGestionLogin {

	private Boolean token;

	private UsuarioDAO usuarioDao = new UsuarioDAO();

	@Override
	public void iniciarSesion(String nombreUsuario, String clave) {
		Usuario usuario = new Usuario();
		usuario = usuarioDao.buscarUsuario(nombreUsuario);
		if (usuario.getId() != 0) {
			if (usuario.getClave().equals(clave)) {
				System.out.println("Ha ingresado correctamente");
				System.out.println(usuario.toString());
			} else {
				System.out.println("Clave incorrecta");
			}
		} else {
			System.out.println("No se ha encontrado ningún usuario");
		}
	}

	@Override
	public void cerrarSesion() {
		if (token == true) {
			token = false;
			System.out.println("Ha salido correctamente");
		}
		System.out.println("No tienes sesión activa");
	}

	@Override
	public void cambiarClave(int id_Usuario, String clave) {
		Usuario usuario = new Usuario();
		usuario = usuarioDao.buscarPorId(id_Usuario);
		if (usuario.getId() != 0) {
			usuario.setClave(clave);
			System.out.println("Se ha cambiado la clave");
		}
		else {
			System.out.println("No se ha encontrado ningún usuario");
		}
	}

}
