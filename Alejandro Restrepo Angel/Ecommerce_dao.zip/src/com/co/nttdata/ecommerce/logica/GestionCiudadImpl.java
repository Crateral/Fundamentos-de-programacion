package com.co.nttdata.ecommerce.logica;

import java.util.List;

import com.co.nttdata.ecommerce.Dao.CiudadDAO;
import com.co.nttdata.ecommerce.interfaces.IGestionCiudad;
import com.co.nttdata.ecommerce.modelos.Ciudad;

public class GestionCiudadImpl implements IGestionCiudad{
	
	private CiudadDAO ciudadDao = new CiudadDAO();
	
	@Override
	public void crearCiudad(Ciudad ciudad) {
		if(ciudadDao.agregarCiudad(ciudad)) {
			System.out.println("La ciudad se ha agregado correctamente");
		}
		else{
			System.out.println("Error: la ciudad no se ha agregado correctamente");
		}
	}

	@Override
	public void listarCiudades() {
		List<Ciudad> listaCiudades = ciudadDao.listarCiudades();
		System.out.println("Listado de ciudades");
		if(listaCiudades.isEmpty()) {
			System.out.println("Lista vacía");
		}
		else {
			listaCiudades.forEach((ciudad) ->System.out.println(ciudad.toString()));	
		}
	}

	@Override
	public void buscarPorNombre(String nombreCiudad) {
		Ciudad ciudad = new Ciudad();
		ciudad = ciudadDao.buscarCiudad(nombreCiudad); 
		if(ciudad.getId()!=0) {
			System.out.println(ciudad.toString());
		}
		else {
			System.out.println("No se ha encontrado ninguna ciudad");
		}		
	}

	@Override
	public void buscarPorId(int id) {
		Ciudad ciudad = new Ciudad();
		ciudad = ciudadDao.buscarPorId(id); 
		if(ciudad.getId()!=0) {
			System.out.println(ciudad.toString());
		}
		else {
			System.out.println("No se ha encontrado ninguna ciudad");
		}	
	}

	@Override
	public void eliminarPorId(int id) {
		if(ciudadDao.eliminarPorId(id)) {
			System.out.println("La ciudad se ha eliminado correctamente");
		}
		else{
			System.out.println("Error: El ciudad no se ha eliminado correctamente");
		}	
	}

}
