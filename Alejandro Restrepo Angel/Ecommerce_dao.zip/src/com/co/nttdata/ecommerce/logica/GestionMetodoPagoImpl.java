package com.co.nttdata.ecommerce.logica;

import java.util.List;

import com.co.nttdata.ecommerce.Dao.MetodoPagoDAO;
import com.co.nttdata.ecommerce.interfaces.IGestionMetodoPago;
import com.co.nttdata.ecommerce.modelos.MetodoPago;

public class GestionMetodoPagoImpl implements IGestionMetodoPago{
	
	private MetodoPagoDAO metodoPagoDao = new MetodoPagoDAO();
	
	@Override
	public void crearMetodoPago(MetodoPago metodoPago) {
		if(metodoPagoDao.agregarMetodoPago(metodoPago)) {
			System.out.println("El método de pago se ha agregado correctamente");
		}
		else{
			System.out.println("Error: El método de pago no se ha agregado correctamente");
		}
	}

	@Override
	public void listarMetodosPago() {
		List<MetodoPago> listaMetodosPago = metodoPagoDao.listarMetodoPagos();
		System.out.println("Listado de Administradores");
		if(listaMetodosPago.isEmpty()) {
			System.out.println("Lista vacía");
		}
		else {
			listaMetodosPago.forEach((metodoPago) ->System.out.println(metodoPago.toString()));	
		}
	}

	@Override
	public void buscarPorNombre(String nombreMetodo) {
		MetodoPago metodoPago = new MetodoPago();
		metodoPago = metodoPagoDao.buscarMetodoPago(nombreMetodo); 
		if(metodoPago.getId()!=0) {
			System.out.println(metodoPago.toString());
		}
		else {
			System.out.println("No se ha encontrado ningún método de pago");
		}		
	}

	@Override
	public void buscarPorId(int id) {
		MetodoPago metodoPago = new MetodoPago();
		metodoPago = metodoPagoDao.buscarPorId(id); 
		if(metodoPago.getId()!=0) {
			System.out.println(metodoPago.toString());
		}
		else {
			System.out.println("No se ha encontrado ningún método de pago");
		}	
	}

	@Override
	public void eliminarPorId(int id) {
		if(metodoPagoDao.eliminarPorId(id)) {
			System.out.println("El método de pago se ha eliminado correctamente");
		}
		else{
			System.out.println("Error: El método de pago no se ha eliminado correctamente");
		}	
	}

}
