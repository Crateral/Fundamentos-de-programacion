
package com.co.nttdata.ecommerce.logica;

import java.util.List;
import java.util.ArrayList;

import com.co.nttdata.ecommerce.Dao.CarritoDeComprasDAO;
import com.co.nttdata.ecommerce.Dao.CiudadDAO;
import com.co.nttdata.ecommerce.Dao.ClienteDAO;
import com.co.nttdata.ecommerce.Dao.CompraDAO;
import com.co.nttdata.ecommerce.Dao.EmpresaDAO;
import com.co.nttdata.ecommerce.Dao.FacturaDAO;
import com.co.nttdata.ecommerce.interfaces.IGestionFactura;
import com.co.nttdata.ecommerce.modelos.CarritoDeCompras;
import com.co.nttdata.ecommerce.modelos.Ciudad;
import com.co.nttdata.ecommerce.modelos.Cliente;
import com.co.nttdata.ecommerce.modelos.Compra;
import com.co.nttdata.ecommerce.modelos.Empresa;
import com.co.nttdata.ecommerce.modelos.Factura;

public class GestionFacturaImpl implements IGestionFactura {

	private FacturaDAO facturaDao = new FacturaDAO();
	private ClienteDAO clienteDao = new ClienteDAO();
	private CiudadDAO ciudadDao = new CiudadDAO();
	private EmpresaDAO empresaDao = new EmpresaDAO();
	private CompraDAO compraDao = new CompraDAO();
	private CarritoDeComprasDAO carritoCompraDao = new CarritoDeComprasDAO();
	
	@Override
	public void crearFactura(Factura factura) {
		if(facturaDao.agregarFactura(factura)) {
			System.out.println("La factura se ha agregado correctamente");
		}
		else{
			System.out.println("Error: La factura no se ha agregado correctamente");
		}
	}

	@Override
	public void listarFacturas() {
		List<Factura> listaFacturas = facturaDao.listarFacturas();
		System.out.println("Listado de facturas");
		if(listaFacturas.isEmpty()) {
			System.out.println("Lista vacía");
		}
		else {
			listaFacturas.forEach((factura) ->System.out.println(factura.toString()));	
		}
	}

	@Override
	public void buscarPorCliente(int id_Cliente) {
		List<Factura> listaFacturas = facturaDao.buscarFacturasCliente(id_Cliente); 
		System.out.println("Listado de facturas");
		if(listaFacturas.isEmpty()) {
			System.out.println("Lista vacía");
		}
		else {
			listaFacturas.forEach((factura) ->System.out.println(factura.toString()));	
		}	
	}

	@Override
	public void buscarPorId(int id) {
		Factura factura = new Factura();
		factura = facturaDao.buscarPorId(id); 
		if(factura.getId()!=0) {
			System.out.println(factura.toString());
		}
		else {
			System.out.println("No se ha encontrado ninguna factura");
		}	
	}

	@Override
	public void eliminarPorId(int id) {
		if(facturaDao.eliminarPorId(id)) {
			System.out.println("La factura se ha eliminado correctamente");
		}
		else{
			System.out.println("Error: La factura no se ha eliminado correctamente");
		}	
	}

	public void imprimirFactura(int id_Factura) {
		Factura factura = new Factura();
		Empresa empresa = new Empresa();
		Cliente cliente = new Cliente();
		CarritoDeCompras carritoCompra = new CarritoDeCompras();
		
		List<Compra> compras = new ArrayList<Compra>();
		
		factura = facturaDao.buscarPorId(id_Factura); 
		empresa = empresaDao.buscarPorId(factura.getId_Empresa()); 
		cliente = clienteDao.buscarPorId(factura.getId_Cliente()); 
		carritoCompra = carritoCompraDao.buscarPorId(factura.getId_CarritoCompra()); 
		compras = compraDao.buscarPorCarritoDeCompras(factura.getId_CarritoCompra()); 
		
		if(factura.getId()!=0) {
			System.out.println("Factura: " + factura.getId());
			System.out.println("Fecha: " + factura.getFecha());
			System.out.println("Empresa: " + empresa.getEmpresa());
			System.out.println("Cliente: " + cliente.getNumeroIdentificacion());
			System.out.println("Descripción: " + factura.getDescripcion());

			// Recorrer los productos en el carro de compras

			compras.forEach((producto) -> System.out.println(producto.toString()));
			System.out.println("Subtotal sin IVA: " + carritoCompra.getSubtotalSinIva());
			System.out.println("Subtotal con IVA: " + carritoCompra.getSubtotalConIva());
			System.out.println("Valor envío: " + factura.getTotalEnvio());
			System.out.println("Valor neto: " + factura.getValorTotalSinIva());
			System.out.println("Total pagar: " + factura.getValorTotalConIva());
		}
		else {
			System.out.println("No se ha encontrado ninguna factura");
		}
	}
	
	@Override
	public Double calcularTotalSinIva(int id_Cliente, int id_CarritoCompra) {
		Double valorTotalSinIva = 0.0, TotalEnvio = 0.0;
		CarritoDeCompras carritoCompra = new CarritoDeCompras();
		carritoCompra = carritoCompraDao.buscarPorId(id_CarritoCompra);
		
		TotalEnvio = calcularCostoEnvio(id_Cliente, id_CarritoCompra);
		
		valorTotalSinIva = carritoCompra.getSubtotalSinIva() + TotalEnvio;
		return valorTotalSinIva;
	}

	@Override
	public Double calcularTotalConIva(int id_Cliente, int id_CarritoCompra) {
		Double valorTotalConIva = 0.0, TotalEnvio = 0.0;
		CarritoDeCompras carritoCompra = new CarritoDeCompras();		
		carritoCompra = carritoCompraDao.buscarPorId(id_CarritoCompra);
		
		TotalEnvio = calcularCostoEnvio(id_Cliente, id_CarritoCompra);
		
		valorTotalConIva = carritoCompra.getSubtotalConIva() + TotalEnvio;
		return valorTotalConIva;
	}

	@Override
	public Double calcularCostoEnvio(int id_Cliente, int id_CarritoCompra) {
		Double TotalEnvio = 0.0;
		Cliente cliente = new Cliente();
		Ciudad ciudad = new Ciudad();
		CarritoDeCompras carritoCompra = new CarritoDeCompras();
		cliente = clienteDao.buscarPorId(id_Cliente);
		ciudad = ciudadDao.buscarPorId(cliente.getId_Ciudad());
		carritoCompra = carritoCompraDao.buscarPorId(id_CarritoCompra);
		if(ciudad.getPrincipal()) {
			TotalEnvio= carritoCompra.getValorEnvio() * 1.05;
		}
		else {
			TotalEnvio = carritoCompra.getValorEnvio() * 1.10;
		}
		return TotalEnvio;
	}
	
}
