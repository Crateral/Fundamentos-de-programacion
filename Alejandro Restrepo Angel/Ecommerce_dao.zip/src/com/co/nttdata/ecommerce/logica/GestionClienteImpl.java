package com.co.nttdata.ecommerce.logica;

import java.util.List;

import com.co.nttdata.ecommerce.Dao.ClienteDAO;
import com.co.nttdata.ecommerce.interfaces.IGestionCliente;
import com.co.nttdata.ecommerce.modelos.Cliente;

public class GestionClienteImpl implements IGestionCliente{
	
	private ClienteDAO clienteDao = new ClienteDAO();
	
	@Override
	public void crearCliente(Cliente cliente) {
		if(clienteDao.agregarCliente(cliente)) {
			System.out.println("El cliente se ha agregado correctamente");
		}
		else{
			System.out.println("Error: El cliente no se ha agregado correctamente");
		}
	}

	@Override
	public void listarClientes() {
		List<Cliente> listaClientes = clienteDao.listarClientes();
		System.out.println("Listado de Clientes");
		if(listaClientes.isEmpty()) {
			System.out.println("Lista vacía");
		}
		else {
			listaClientes.forEach((cliente) ->System.out.println(cliente.toString()));	
		}
	}

	@Override
	public void buscarPorCorreo(String correo) {
		Cliente cliente = new Cliente();
		cliente = clienteDao.buscarCliente(correo); 
		if(cliente.getId()!=0) {
			System.out.println(cliente.toString());
		}
		else {
			System.out.println("No se ha encontrado ningún cliente");
		}		
	}

	@Override
	public void buscarPorId(int id) {
		Cliente cliente = new Cliente();
		cliente = clienteDao.buscarPorId(id); 
		if(cliente.getId()!=0) {
			System.out.println(cliente.toString());
		}
		else {
			System.out.println("No se ha encontrado ningún cliente");
		}	
	}

	@Override
	public void eliminarPorId(int id) {
		if(clienteDao.eliminarPorId(id)) {
			System.out.println("El cliente se ha eliminado correctamente");
		}
		else{
			System.out.println("Error: El cliente no se ha eliminado correctamente");
		}	
	}

}
