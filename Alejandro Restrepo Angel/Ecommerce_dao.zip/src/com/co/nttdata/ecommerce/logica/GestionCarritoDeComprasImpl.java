package com.co.nttdata.ecommerce.logica;

import java.util.ArrayList;
import java.util.List;

import com.co.nttdata.ecommerce.Dao.CarritoDeComprasDAO;
import com.co.nttdata.ecommerce.Dao.CompraDAO;
import com.co.nttdata.ecommerce.interfaces.IGestionCarritoDeCompras;
import com.co.nttdata.ecommerce.modelos.CarritoDeCompras;
import com.co.nttdata.ecommerce.modelos.Compra;

public class GestionCarritoDeComprasImpl implements IGestionCarritoDeCompras{
	
	private CarritoDeComprasDAO carritoDao = new CarritoDeComprasDAO();
	private CompraDAO compraDao = new CompraDAO();
	
	@Override
	public void crearCarritos(CarritoDeCompras carritoDeCompras) {
		if(carritoDao.agregarCarrito(carritoDeCompras)) {
			System.out.println("Se ha agregado correctamente al carrito");
		}
		else{
			System.out.println("Error: No se ha agregado correctamente al carrito");
		}
	}

	@Override
	public void listarCarritos() {
		List<CarritoDeCompras> listaCarritos = carritoDao.listarCarritos();
		System.out.println("Listado de Carritos");
		if(listaCarritos.isEmpty()) {
			System.out.println("Lista vacía");
		}
		else {
			listaCarritos.forEach((carrito) ->System.out.println(carrito.toString()));	
		}
	}

	@Override
	public void buscarPorId(int id) {
		CarritoDeCompras carritoDeCompras = new CarritoDeCompras();
		carritoDeCompras = carritoDao.buscarPorId(id); 
		if(carritoDeCompras.getId()!=0) {
			System.out.println(carritoDeCompras.toString());
		}
		else {
			System.out.println("No se ha encontrado ningún carrito de compras");
		}	
	}

	@Override
	public void eliminarPorId(int id) {
		if(carritoDao.eliminarPorId(id)) {
			System.out.println("El carrito de compras se ha eliminado correctamente");
		}
		else{
			System.out.println("Error: El carrito de compras no se ha eliminado correctamente");
		}	
	}

	@Override
	public Double calcularSubtotalSinIva(int id_CarritoCompra) {
		Double subtotalSinIva = 0.0;
		List<Compra> compras = new ArrayList<Compra>();
		compras = compraDao.buscarPorCarritoDeCompras(id_CarritoCompra); 
		for (int i = 0; i < compras.size(); i++) { 
			subtotalSinIva += compras.get(i).getValor(); 
		}
		return subtotalSinIva;
	}

	@Override
	public Double calcularSubtotalConIva(int id_CarritoCompra) {
		Double subtotalSinIva = 0.0, subtotalConIva=0.0;
		subtotalSinIva = calcularSubtotalSinIva(id_CarritoCompra);
		subtotalConIva = subtotalSinIva * 1.19;	 
		return subtotalConIva;
	}

}
