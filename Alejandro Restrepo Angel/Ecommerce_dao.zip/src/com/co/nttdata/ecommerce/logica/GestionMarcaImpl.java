package com.co.nttdata.ecommerce.logica;

import java.util.List;

import com.co.nttdata.ecommerce.Dao.MarcaDAO;
import com.co.nttdata.ecommerce.interfaces.IGestionMarca;
import com.co.nttdata.ecommerce.modelos.Marca;

public class GestionMarcaImpl implements IGestionMarca{
	
	private MarcaDAO marcaDao = new MarcaDAO();
	
	@Override
	public void crearMarca(Marca marca) {
		if(marcaDao.agregarMarca(marca)) {
			System.out.println("La marca se ha agregado correctamente");
		}
		else{
			System.out.println("Error: La marca no se ha agregado correctamente");
		}
	}

	@Override
	public void listarMarcas() {
		List<Marca> listaMarcas = marcaDao.listarMarcas();
		System.out.println("Listado de marcas");
		if(listaMarcas.isEmpty()) {
			System.out.println("Lista vacía");
		}
		else {
			listaMarcas.forEach((marca) ->System.out.println(marca.toString()));	
		}
	}

	@Override
	public void buscarPorNombre(String nombreMarca) {
		Marca marca = new Marca();
		marca = marcaDao.buscarMarca(nombreMarca); 
		if(marca.getId()!=0) {
			System.out.println(marca.toString());
		}
		else {
			System.out.println("No se ha encontrado ninguna marca");
		}		
	}

	@Override
	public void buscarPorId(int id) {
		Marca marca = new Marca();
		marca = marcaDao.buscarPorId(id); 
		if(marca.getId()!=0) {
			System.out.println(marca.toString());
		}
		else {
			System.out.println("No se ha encontrado ninguna marca");
		}	
	}

	@Override
	public void eliminarPorId(int id) {
		if(marcaDao.eliminarPorId(id)) {
			System.out.println("La marca se ha eliminado correctamente");
		}
		else{
			System.out.println("Error: La marca no se ha eliminado correctamente");
		}	
	}

}
