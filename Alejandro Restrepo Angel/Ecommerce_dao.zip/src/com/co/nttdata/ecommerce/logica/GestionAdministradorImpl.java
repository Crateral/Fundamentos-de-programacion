package com.co.nttdata.ecommerce.logica;

import java.util.List;

import com.co.nttdata.ecommerce.Dao.AdministradorDAO;
import com.co.nttdata.ecommerce.interfaces.IGestionAdministrador;
import com.co.nttdata.ecommerce.modelos.Administrador;

public class GestionAdministradorImpl implements IGestionAdministrador{
	
	private AdministradorDAO administradorDao = new AdministradorDAO();
	
	@Override
	public void crearAdministrador(Administrador administrador) {
		if(administradorDao.agregarAdministrador(administrador)) {
			System.out.println("El administrador se ha agregado correctamente");
		}
		else{
			System.out.println("Error: El administrador no se ha agregado correctamente");
		}
	}

	@Override
	public void listarAdministradores() {
		List<Administrador> listaAdministradores = administradorDao.listarAdministradores();
		System.out.println("Listado de Administradores");
		if(listaAdministradores.isEmpty()) {
			System.out.println("Lista vacía");
		}
		else {
			listaAdministradores.forEach((administrador) ->System.out.println(administrador.toString()));	
		}
	}

	@Override
	public void buscarPorCorreo(String correo) {
		Administrador administrador = new Administrador();
		administrador = administradorDao.buscarAdministrador(correo); 
		if(administrador.getId()!=0) {
			System.out.println(administrador.toString());
		}
		else {
			System.out.println("No se ha encontrado ningún administrador");
		}		
	}

	@Override
	public void buscarPorId(int id) {
		Administrador administrador = new Administrador();
		administrador = administradorDao.buscarPorId(id); 
		if(administrador.getId()!=0) {
			System.out.println(administrador.toString());
		}
		else {
			System.out.println("No se ha encontrado ningún administrador");
		}	
	}

	@Override
	public void eliminarPorId(int id) {
		if(administradorDao.eliminarPorId(id)) {
			System.out.println("El administrador se ha eliminado correctamente");
		}
		else{
			System.out.println("Error: El administrador no se ha eliminado correctamente");
		}	
	}

}
