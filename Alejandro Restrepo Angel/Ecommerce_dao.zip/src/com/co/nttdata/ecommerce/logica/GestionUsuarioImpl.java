package com.co.nttdata.ecommerce.logica;

import java.util.List;

import com.co.nttdata.ecommerce.Dao.UsuarioDAO;
import com.co.nttdata.ecommerce.interfaces.IGestionUsuario;
import com.co.nttdata.ecommerce.modelos.Usuario;

public class GestionUsuarioImpl implements IGestionUsuario{
	
	private UsuarioDAO usuarioDao = new UsuarioDAO();
	
	@Override
	public void crearUsuario(Usuario usuario) {
		if(usuarioDao.agregarUsuario(usuario)) {
			System.out.println("El usuario se ha agregado correctamente");
		}
		else{
			System.out.println("Error: El usuario no se ha agregado correctamente");
		}
	}

	@Override
	public void listarUsuarios() {
		List<Usuario> listaUsuarios = usuarioDao.listarUsuarios();
		System.out.println("Listado de usuarios");
		if(listaUsuarios.isEmpty()) {
			System.out.println("Lista vacía");
		}
		else {
			listaUsuarios.forEach((usuario) ->System.out.println(usuario.toString()));	
		}
	}

	@Override
	public void buscarPorNombre(String nombreUsuario) {
		Usuario usuario = new Usuario();
		usuario = usuarioDao.buscarUsuario(nombreUsuario); 
		if(usuario.getId()!=0) {
			System.out.println(usuario.toString());
		}
		else {
			System.out.println("No se ha encontrado ningún usuario");
		}		
	}

	@Override
	public void buscarPorId(int id) {
		Usuario usuario = new Usuario();
		usuario = usuarioDao.buscarPorId(id); 
		if(usuario.getId()!=0) {
			System.out.println(usuario.toString());
		}
		else {
			System.out.println("No se ha encontrado ningún usuario");
		}	
	}

	@Override
	public void eliminarPorId(int id) {
		if(usuarioDao.eliminarPorId(id)) {
			System.out.println("El usuario se ha eliminado correctamente");
		}
		else{
			System.out.println("Error: El usuario no se ha eliminado correctamente");
		}	
	}

}
