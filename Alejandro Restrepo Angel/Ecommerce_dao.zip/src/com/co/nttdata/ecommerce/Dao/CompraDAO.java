package com.co.nttdata.ecommerce.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.co.nttdata.ecommerce.modelos.Compra;
import com.co.nttdata.ecommerce.utilitarios.Conexion;

public class CompraDAO {
	
	Conexion c = new Conexion();

	public List<Compra> listarCompras() {

		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;

		List<Compra> compras = new ArrayList<Compra>();

		try {
			st = baseDatos.prepareStatement("SELECT * FROM sc_ecommerce.tbl_compras");
			rs = st.executeQuery();

			while (rs.next()) {
				Compra compra = new Compra();

				compra.setId(rs.getInt("id"));
				compra.setId_Producto(rs.getInt("id_producto"));
				compra.setId_CarritoCompra(rs.getInt("id_carrito_compras"));
				compra.setCantidad(rs.getInt("cantidad"));
				compra.setValor(rs.getDouble("valor"));

				compras.add(compra);
			}
		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				rs.close();
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return compras;
	}
	
	public List<Compra> buscarPorCarritoDeCompras(int id_carrito_compras) {

		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		List<Compra> compras = new ArrayList<Compra>();

		try {
			st = baseDatos.prepareStatement("SELECT * FROM sc_ecommerce.tbl_compras WHERE id_carrito_compras = ? ");
			st.setInt(1, id_carrito_compras);
			rs = st.executeQuery();

			while (rs.next()) {
				
				Compra compra = new Compra();
				
				compra.setId(rs.getInt("id"));
				compra.setId_Producto(rs.getInt("id_producto"));
				compra.setId_CarritoCompra(rs.getInt("id_carrito_compras"));
				compra.setCantidad(rs.getInt("cantidad"));
				compra.setValor(rs.getDouble("valor"));
				
				compras.add(compra);
			}
		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return compras;
	}

	public Boolean agregarCompra(Compra compra) {

		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;

		try {
			st = baseDatos.prepareStatement("INSERT INTO sc_ecommerce.tbl_compras"
					+ " (id_producto, id_carrito_compras, cantidad, valor)"
					+ " VALUES (?, ?, ?, ?)");
			st.setInt(1, compra.getId_Producto());
			st.setInt(2, compra.getId_CarritoCompra());
			st.setDouble(3, compra.getCantidad());
			st.setDouble(4, compra.getValor());
			st.executeUpdate();
			return true;

		} catch (Exception e) {
			System.err.println(e.getMessage());
			return false;
		} finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public Boolean eliminarPorId(int id) {
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;

		try {
			st = baseDatos.prepareStatement("DELETE FROM sc_ecommerce.tbl_compras WHERE id = ?");
			st.setInt(1, id);
			st.executeQuery();
			return true;

		} catch (Exception e) {
			System.err.println(e.getMessage());
			return false;
		} finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public Compra buscarPorId(int id) {

		Compra compra = new Compra();

		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;

		try {
			st = baseDatos.prepareStatement("SELECT * FROM sc_ecommerce.tbl_compras WHERE id = ? ");
			st.setInt(1, id);
			rs = st.executeQuery();

			while (rs.next()) {
				compra.setId(rs.getInt("id"));
				compra.setId_Producto(rs.getInt("id_producto"));
				compra.setId_CarritoCompra(rs.getInt("id_carrito_compras"));
				compra.setCantidad(rs.getInt("cantidad"));
				compra.setValor(rs.getDouble("valor"));
			}
		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return compra;
	}
}
