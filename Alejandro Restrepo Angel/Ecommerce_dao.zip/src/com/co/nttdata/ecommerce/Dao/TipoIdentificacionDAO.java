package com.co.nttdata.ecommerce.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.co.nttdata.ecommerce.modelos.TipoIdentificacion;
import com.co.nttdata.ecommerce.utilitarios.Conexion;

public class TipoIdentificacionDAO {

	Conexion c = new Conexion();
	
	public List<TipoIdentificacion> listarTipoIdentificaciones() {		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		List<TipoIdentificacion> tipos = new ArrayList<TipoIdentificacion>();

		try {
			st = baseDatos.prepareStatement("SELECT * FROM sc_ecommerce.tbl_tipo_identificaciones");
			rs = st.executeQuery();

			while (rs.next()) {
				TipoIdentificacion tipoIdentificacion = new TipoIdentificacion();

				tipoIdentificacion.setId(rs.getInt("id"));
				tipoIdentificacion.setTipoIdentificacion(rs.getString("tipo_identificacion"));
				tipoIdentificacion.setDescripcion(rs.getString("descripcion"));

				tipos.add(tipoIdentificacion);
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				rs.close();
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return tipos;
	}
	
	public TipoIdentificacion buscarTipoIdentificacion(String tipo) {
		
		TipoIdentificacion tipoIdentificacion =  new TipoIdentificacion();
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			st = baseDatos.prepareStatement("SELECT * FROM sc_ecommerce.tbl_tipo_identificaciones WHERE tipo_identificacion = ? ");
			st.setString(1, tipo);
			rs = st.executeQuery();
			while (rs.next()) {
				tipoIdentificacion.setId(rs.getInt("id"));
				tipoIdentificacion.setTipoIdentificacion(rs.getString("tipo_identificacion"));
				tipoIdentificacion.setDescripcion(rs.getString("descripcion"));
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				rs.close();
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}	
		return tipoIdentificacion;
	}

	public Boolean agregarTipoIdentificacion(TipoIdentificacion tipoIdentificacion) {
				
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;

		try {
			st = baseDatos.prepareStatement("INSERT INTO sc_ecommerce.tbl_tipo_identificaciones "
					+ " (tipo_identificacion, descripcion)"
					+ " VALUES (?, ?,)");
			st.setString(1, tipoIdentificacion.getTipoIdentificacion());
			st.setString(2, tipoIdentificacion.getDescripcion());
			st.executeUpdate();
			return true;
			
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
			return false;
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Boolean eliminarPorId(int id) {
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;

		try {
			st = baseDatos.prepareStatement("DELETE FROM sc_ecommerce.tbl_tipo_identificaciones WHERE id = ?");
			st.setInt(1, id);
			st.executeQuery();
			return true;
			
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
			return false;
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public TipoIdentificacion buscarPorId(int id) {
		
		TipoIdentificacion tipoIdentificacion = new TipoIdentificacion();
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			st = baseDatos.prepareStatement("SELECT * FROM sc_ecommerce.tbl_tipo_identificaciones WHERE id = ? ");
			st.setInt(1, id);
			rs = st.executeQuery();

			while (rs.next()) {

				tipoIdentificacion.setId(rs.getInt("id"));
				tipoIdentificacion.setTipoIdentificacion(rs.getString("tipo_identificacion"));
				tipoIdentificacion.setDescripcion(rs.getString("descripcion"));
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return tipoIdentificacion;
	}
	
}
