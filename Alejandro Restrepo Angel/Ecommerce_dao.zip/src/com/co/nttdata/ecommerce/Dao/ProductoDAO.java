package com.co.nttdata.ecommerce.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.co.nttdata.ecommerce.modelos.Producto;
import com.co.nttdata.ecommerce.utilitarios.Conexion;

public class ProductoDAO {

Conexion c = new Conexion();
	
	public List<Producto> listarProductos() {		
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		List<Producto> productos = new ArrayList<Producto>();

		try {
			st = baseDatos.prepareStatement("SELECT * FROM sc_ecommerce.tbl_productos");
			rs = st.executeQuery();

			while (rs.next()) {
				Producto producto = new Producto();

				producto.setId(rs.getInt("id"));
				producto.setId_Marca(rs.getInt("id_marca"));
				producto.setId_Categoria(rs.getInt("id_categoria"));
				producto.setProducto(rs.getString("producto"));
				producto.setCantidadDiponible(rs.getInt("cantidad_disponible"));
				producto.setPrecio(rs.getDouble("precio"));
				producto.setDescuento(rs.getBoolean("descuento"));
				producto.setValorDescuento(rs.getDouble("valor_descuento"));
				producto.setImagen(rs.getString("imagen"));
				producto.setIva(rs.getDouble("iva"));
				producto.setDescripcion(rs.getString("descripcion"));

				productos.add(producto);
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				rs.close();
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return productos;
	}

	public Producto buscarProducto(String nombreProducto) {
		
		Producto producto = new Producto();
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			st = baseDatos.prepareStatement("SELECT * FROM sc_ecommerce.tbl_productos WHERE producto = ? ");
			st.setString(1, nombreProducto);
			rs = st.executeQuery();
			while (rs.next()) {
				producto.setId(rs.getInt("id"));
				producto.setId_Marca(rs.getInt("id_marca"));
				producto.setId_Categoria(rs.getInt("id_categoria"));
				producto.setProducto(rs.getString("producto"));
				producto.setCantidadDiponible(rs.getInt("cantidad_disponible"));
				producto.setPrecio(rs.getDouble("precio"));
				producto.setDescuento(rs.getBoolean("descuento"));
				producto.setValorDescuento(rs.getDouble("valor_descuento"));
				producto.setImagen(rs.getString("imagen"));
				producto.setIva(rs.getDouble("iva"));
				producto.setDescripcion(rs.getString("descripcion"));
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				rs.close();
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}	
		return producto;
	}

	public Boolean agregarProducto(Producto producto) {
				
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;

		try {
			st = baseDatos.prepareStatement("INSERT INTO sc_ecommerce.tbl_productos "
					+ " (id_marca, id_categoria, producto, cantidad_disponible, precio, descuento, valor_descuento, iva, imagen, descripcion)"
					+ " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			st.setInt(1, producto.getId_Marca());
			st.setInt(2, producto.getId_Categoria());
			st.setString(3, producto.getProducto());
			st.setInt(4, producto.getCantidadDiponible());
			st.setDouble(5, producto.getPrecio());
			st.setBoolean(6, producto.isDescuento());
			st.setDouble(7, producto.getValorDescuento());
			st.setString(8, producto.getImagen());
			st.setDouble(9, producto.getIva());
			st.setString(10, producto.getDescripcion());
			st.executeUpdate();
			return true;
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
			return false;
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}		
	}
	
	public Boolean eliminarPorId(int id) {
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;

		try {
			st = baseDatos.prepareStatement("DELETE FROM sc_ecommerce.tbl_productos WHERE id = ?");
			st.setInt(1, id);
			st.executeQuery();
			return true;
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
			return false;
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Producto buscarPorId(int id) {
		
		Producto producto = new Producto();
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			st = baseDatos.prepareStatement("SELECT * FROM sc_ecommerce.tbl_productos WHERE id = ? ");
			st.setInt(1, id);
			rs = st.executeQuery();

			while (rs.next()) {
				producto.setId(rs.getInt("id"));
				producto.setId_Marca(rs.getInt("id_marca"));
				producto.setId_Categoria(rs.getInt("id_categoria"));
				producto.setProducto(rs.getString("producto"));
				producto.setCantidadDiponible(rs.getInt("cantidad_disponible"));
				producto.setPrecio(rs.getDouble("precio"));
				producto.setDescuento(rs.getBoolean("descuento"));
				producto.setValorDescuento(rs.getDouble("valor_descuento"));
				producto.setImagen(rs.getString("imagen"));
				producto.setIva(rs.getDouble("iva"));
				producto.setDescripcion(rs.getString("descripcion"));
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return producto;
	}

	
}
