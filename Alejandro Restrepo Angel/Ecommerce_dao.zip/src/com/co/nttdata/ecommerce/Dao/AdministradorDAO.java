
package com.co.nttdata.ecommerce.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.co.nttdata.ecommerce.modelos.Administrador;
import com.co.nttdata.ecommerce.utilitarios.Conexion;

public class AdministradorDAO {

	Conexion c = new Conexion();

	public List<Administrador> listarAdministradores() {

		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;

		List<Administrador> administradores = new ArrayList<Administrador>();

		try {
			st = baseDatos.prepareStatement("SELECT * FROM sc_ecommerce.tbl_administradores");
			rs = st.executeQuery();

			while (rs.next()) {
				Administrador administrador = new Administrador();

				administrador.setId(rs.getInt("id"));
				administrador.setId_Usuario(rs.getInt("id_usuario"));
				administrador.setId_TipoIdentificacion(rs.getInt("id_tipo_identificacion"));
				administrador.setNumeroIdentificacion(rs.getString("numero_identificacion"));
				administrador.setCorreo(rs.getString("nombre"));
				administrador.setCorreo(rs.getString("apellido"));
				administrador.setCorreo(rs.getString("correo"));
				administrador.setDireccion(rs.getString("direccion"));

				administradores.add(administrador);
			}
		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				rs.close();
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return administradores;
	}

	public Administrador buscarAdministrador(String correo) {

		Administrador administrador = new Administrador();

		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;

		try {
			st = baseDatos.prepareStatement("SELECT * FROM sc_ecommerce.tbl_administradores WHERE correo = ? ");
			st.setString(1, correo);
			rs = st.executeQuery();
			while (rs.next()) {
				administrador.setId(rs.getInt("id"));
				administrador.setId_Usuario(rs.getInt("id_usuario"));
				administrador.setId_TipoIdentificacion(rs.getInt("id_tipo_identificacion"));
				administrador.setNumeroIdentificacion(rs.getString("numero_identificacion"));
				administrador.setCorreo(rs.getString("nombre"));
				administrador.setCorreo(rs.getString("apellido"));
				administrador.setCorreo(rs.getString("correo"));
				administrador.setDireccion(rs.getString("direccion"));
			}
		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				rs.close();
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return administrador;
	}

	public Boolean agregarAdministrador(Administrador administrador) {

		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;

		try {
			st = baseDatos.prepareStatement("INSERT INTO sc_ecommerce.tbl_administradores"
					+ " (id_usuario, id_tipo_identificacion, numero_identificacion, "
					+ " nombre, apellido, correo, direccion) "
					+ " VALUES (?, ?, ?, ?, ?, ?, ?)");
			st.setInt(1, administrador.getId_Usuario());
			st.setInt(2, administrador.getId_TipoIdentificacion());
			st.setString(3, administrador.getNumeroIdentificacion());
			st.setString(4, administrador.getNombre());
			st.setString(5, administrador.getApellido());
			st.setString(6, administrador.getCorreo());
			st.setString(7, administrador.getDireccion());
			st.executeUpdate();
			return true;
		} catch (Exception e) {
			System.err.println(e.getMessage());
			return false;
		} finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public Boolean eliminarPorId(int id) {
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;

		try {
			st = baseDatos.prepareStatement("DELETE FROM sc_ecommerce.tbl_administradores WHERE id = ?");
			st.setInt(1, id);
			st.executeQuery();
			return true;

		} catch (Exception e) {
			System.err.println(e.getMessage());
			return false;
		} finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public Administrador buscarPorId(int id) {

		Administrador administrador = new Administrador();

		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;

		try {
			st = baseDatos.prepareStatement("SELECT * FROM sc_ecommerce.tbl_administradores WHERE id = ? ");
			st.setInt(1, id);
			rs = st.executeQuery();

			while (rs.next()) {
				administrador.setId(rs.getInt("id"));
				administrador.setId_Usuario(rs.getInt("id_usuario"));
				administrador.setId_TipoIdentificacion(rs.getInt("id_tipo_identificacion"));
				administrador.setNumeroIdentificacion(rs.getString("numero_identificacion"));
				administrador.setCorreo(rs.getString("nombre"));
				administrador.setCorreo(rs.getString("apellido"));
				administrador.setCorreo(rs.getString("correo"));
				administrador.setDireccion(rs.getString("direccion"));
			}
		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return administrador;
	}

}
