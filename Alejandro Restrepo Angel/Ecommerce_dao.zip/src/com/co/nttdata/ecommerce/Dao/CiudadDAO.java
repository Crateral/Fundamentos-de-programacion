package com.co.nttdata.ecommerce.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.co.nttdata.ecommerce.modelos.Ciudad;
import com.co.nttdata.ecommerce.utilitarios.Conexion;

public class CiudadDAO {
	
	Conexion c = new Conexion();
	
	public List<Ciudad> listarCiudades() {		
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		List<Ciudad> ciudades = new ArrayList<Ciudad>();

		try {
			st = baseDatos.prepareStatement("SELECT * FROM sc_ecommerce.tbl_ciudades");
			rs = st.executeQuery();

			while (rs.next()) {
				Ciudad ciudad = new Ciudad();

				ciudad.setId(rs.getInt("id"));
				ciudad.setCiudad(rs.getString("ciudad"));
				ciudad.setPrincipal(rs.getBoolean("principal"));

				ciudades.add(ciudad);
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				rs.close();
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return ciudades;
	}
	
	public Ciudad buscarCiudad(String nombreCiudad) {
		
		Ciudad ciudad = new Ciudad();
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			st = baseDatos.prepareStatement("SELECT * FROM sc_ecommerce.tbl_ciudades WHERE ciudad = ? ");
			st.setString(1, nombreCiudad);
			rs = st.executeQuery();
			while (rs.next()) {
				ciudad.setId(rs.getInt("id"));
				ciudad.setCiudad(rs.getString("ciudad"));
				ciudad.setPrincipal(rs.getBoolean("principal"));
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				rs.close();
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}	
		return ciudad;
	}

	public Boolean agregarCiudad(Ciudad ciudad) {
				
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;

		try {
			st = baseDatos.prepareStatement("INSERT INTO sc_ecommerce.tbl_ciudades "
					+ " (ciudad, principal)"
					+ " VALUES ( ?, ?)");
			st.setString(1, ciudad.getCiudad());
			st.setBoolean(2, ciudad.getPrincipal());
			st.executeUpdate();
			return true;
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
			return false;
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Boolean eliminarPorId(int id) {
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;

		try {
			st = baseDatos.prepareStatement("DELETE FROM sc_ecommerce.tbl_ciudades WHERE id = ?");
			st.setInt(1, id);
			st.executeQuery();
			return true;
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
			return false;
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Ciudad buscarPorId(int id) {
		
		Ciudad ciudad = new Ciudad();
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			st = baseDatos.prepareStatement("SELECT * FROM sc_ecommerce.tbl_ciudades WHERE id = ? ");
			st.setInt(1, id);
			rs = st.executeQuery();

			while (rs.next()) {

				ciudad.setId(rs.getInt("id"));
				ciudad.setCiudad(rs.getString("ciudad"));
				ciudad.setPrincipal(rs.getBoolean("principal"));
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return ciudad;
	}
}
