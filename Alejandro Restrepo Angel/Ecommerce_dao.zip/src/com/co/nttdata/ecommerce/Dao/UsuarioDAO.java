
package com.co.nttdata.ecommerce.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.co.nttdata.ecommerce.modelos.Usuario;
import com.co.nttdata.ecommerce.utilitarios.Conexion;

public class UsuarioDAO {

	Conexion c = new Conexion();

	public List<Usuario> listarUsuarios() {

		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;

		List<Usuario> usuarios = new ArrayList<Usuario>();

		try {
			st = baseDatos.prepareStatement("SELECT * FROM sc_ecommerce.tbl_usuarios");
			rs = st.executeQuery();

			while (rs.next()) {
				Usuario usuario = new Usuario();

				usuario.setId(rs.getInt("id"));
				usuario.setUsuario(rs.getString("usuario"));
				usuario.setClave(rs.getString("clave"));
				usuario.setEstado(rs.getBoolean("estado"));
				
				usuarios.add(usuario);
			}
		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				rs.close();
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return usuarios;
	}

	public Usuario buscarUsuario(String nombreUsuario) {

		Usuario usuario = new Usuario();

		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;

		try {
			st = baseDatos.prepareStatement("SELECT * FROM sc_ecommerce.tbl_usuarios WHERE usuario = ? ");
			st.setString(1, nombreUsuario);
			rs = st.executeQuery();
			while (rs.next()) {
				usuario.setId(rs.getInt("id"));
				usuario.setUsuario(rs.getString("usuario"));
				usuario.setClave(rs.getString("clave"));
				usuario.setEstado(rs.getBoolean("estado"));
			}
		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				rs.close();
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return usuario;
	}

	public Boolean agregarUsuario(Usuario usuario) {

		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;

		try {
			st = baseDatos.prepareStatement("INSERT INTO sc_ecommerce.tbl_usuarios "
					+ " (usuario, clave, estado)"
					+ " VALUES (?, ?, ?)");
			st.setString(1, usuario.getUsuario());
			st.setString(2, usuario.getClave());
			st.setBoolean(3, usuario.getEstado());
			st.executeUpdate();
			return true;

		} catch (Exception e) {
			System.err.println(e.getMessage());
			return false;
		} finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public Boolean eliminarPorId(int id) {
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;

		try {
			st = baseDatos.prepareStatement("DELETE FROM sc_ecommerce.tbl_usuarios WHERE id = ?");
			st.setInt(1, id);
			st.executeQuery();
			return true;

		} catch (Exception e) {
			System.err.println(e.getMessage());
			return false;
		} finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public Usuario buscarPorId(int id) {

		Usuario usuario = new Usuario();

		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;

		try {
			st = baseDatos.prepareStatement("SELECT * FROM sc_ecommerce.tbl_usuarios WHERE id = ? ");
			st.setInt(1, id);
			rs = st.executeQuery();

			while (rs.next()) {

				usuario.setId(rs.getInt("id"));
				usuario.setUsuario(rs.getString("usuario"));
				usuario.setClave(rs.getString("clave"));
				usuario.setEstado(rs.getBoolean("estado"));
			}
		} catch (Exception e) {
			System.err.println(e.getMessage());
		} finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return usuario;
	}

}
