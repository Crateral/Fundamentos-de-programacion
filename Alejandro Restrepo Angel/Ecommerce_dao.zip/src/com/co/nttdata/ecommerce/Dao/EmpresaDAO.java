package com.co.nttdata.ecommerce.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.co.nttdata.ecommerce.modelos.Empresa;
import com.co.nttdata.ecommerce.utilitarios.Conexion;

public class EmpresaDAO {

	Conexion c = new Conexion();
	
	public List<Empresa> listarEmpresas() {		
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		List<Empresa> empresas = new ArrayList<Empresa>();

		try {
			st = baseDatos.prepareStatement("SELECT * FROM sc_ecommerce.tbl_empresas");
			rs = st.executeQuery();

			while (rs.next()) {
				Empresa empresa = new Empresa();

				empresa.setId(rs.getInt("id"));
				empresa.setEmpresa(rs.getString("empresa"));
				empresa.setNit(rs.getString("nit"));
				empresa.setTelefono(rs.getString("telefono"));
				empresa.setDireccion(rs.getString("direccion"));

				empresas.add(empresa);
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				rs.close();
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return empresas;
	}
	
	public Empresa buscarEmpresa(String nit) {
		
		Empresa empresa = new Empresa();
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			st = baseDatos.prepareStatement("SELECT * FROM sc_ecommerce.tbl_empresas WHERE nit = ? ");
			st.setString(1, nit);
			rs = st.executeQuery();
			while (rs.next()) {
				empresa.setId(rs.getInt("id"));
				empresa.setEmpresa(rs.getString("empresa"));
				empresa.setNit(rs.getString("nit"));
				empresa.setTelefono(rs.getString("telefono"));
				empresa.setDireccion(rs.getString("direccion"));
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				rs.close();
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}	
		return empresa;
	}

	public Boolean agregarEmpresa(Empresa empresa) {
				
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;

		try {
			st = baseDatos.prepareStatement("INSERT INTO sc_ecommerce.tbl_empresas "
					+ " (empresa, nit, telefono, direccion)"
					+ " VALUES ( ?, ?, ?, ?)");
			st.setString(1, empresa.getEmpresa());
			st.setString(2, empresa.getNit());
			st.setString(3, empresa.getTelefono());
			st.setString(4, empresa.getDireccion());
			st.executeUpdate();
			return true;
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
			return false;
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Boolean eliminarPorId(int id) {
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;

		try {
			st = baseDatos.prepareStatement("DELETE FROM sc_ecommerce.tbl_empresas WHERE id = ?");
			st.setInt(1, id);
			st.executeQuery();
			return true;
			
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
			return false;
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Empresa buscarPorId(int id) {
		
		Empresa empresa = new Empresa();
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			st = baseDatos.prepareStatement("SELECT * FROM sc_ecommerce.tbl_empresas WHERE id = ? ");
			st.setInt(1, id);
			rs = st.executeQuery();

			while (rs.next()) {

				empresa.setId(rs.getInt("id"));
				empresa.setEmpresa(rs.getString("empresa"));
				empresa.setNit(rs.getString("nit"));
				empresa.setTelefono(rs.getString("telefono"));
				empresa.setDireccion(rs.getString("direccion"));
				
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return empresa;
	}
	
}
