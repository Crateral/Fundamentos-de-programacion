package com.co.nttdata.ecommerce.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.co.nttdata.ecommerce.modelos.MetodoPago;
import com.co.nttdata.ecommerce.utilitarios.Conexion;

public class MetodoPagoDAO {
	
	Conexion c = new Conexion();
	
	public List<MetodoPago> listarMetodoPagos() {		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		List<MetodoPago> metodosPagos = new ArrayList<MetodoPago>();

		try {
			st = baseDatos.prepareStatement("SELECT * FROM sc_ecommerce.tbl_metodo_pagos");
			rs = st.executeQuery();

			while (rs.next()) {
				MetodoPago metodoPago = new MetodoPago();

				metodoPago.setId(rs.getInt("id"));
				metodoPago.setMetodoPago(rs.getString("metodo_pago"));
				metodoPago.setDescripcion(rs.getString("descripcion"));

				metodosPagos.add(metodoPago);
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				rs.close();
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return metodosPagos;
	}
	
	public MetodoPago buscarMetodoPago(String metodo) {
		
		MetodoPago metodoPago = new MetodoPago();
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			st = baseDatos.prepareStatement("SELECT * FROM sc_ecommerce.tbl_metodo_pagos WHERE metodo_pago = ? ");
			st.setString(1, metodo);
			rs = st.executeQuery();
			while (rs.next()) {
				metodoPago.setId(rs.getInt("id"));
				metodoPago.setMetodoPago(rs.getString("metodo_pago"));
				metodoPago.setDescripcion(rs.getString("descripcion"));
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				rs.close();
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}	
		return metodoPago;
	}

	public Boolean agregarMetodoPago(MetodoPago metodoPago) {
				
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;

		try {
			st = baseDatos.prepareStatement("INSERT INTO sc_ecommerce.tbl_metodo_pagos "
					+ " (metodo_pago, descripcion)"
					+ " VALUES (?, ?,)");
			st.setString(1, metodoPago.getMetodoPago());
			st.setString(2, metodoPago.getDescripcion());
			st.executeUpdate();
			return true;
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
			return false;
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Boolean eliminarPorId(int id) {
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;

		try {
			st = baseDatos.prepareStatement("DELETE FROM sc_ecommerce.tbl_metodo_pagos WHERE id = ?");
			st.setInt(1, id);
			st.executeQuery();
			return true;
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
			return false;
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public MetodoPago buscarPorId(int id) {
		
		MetodoPago metodoPago = new MetodoPago();
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			st = baseDatos.prepareStatement("SELECT * FROM sc_ecommerce.tbl_metodo_pagos WHERE id = ? ");
			st.setInt(1, id);
			rs = st.executeQuery();

			while (rs.next()) {

				metodoPago.setId(rs.getInt("id"));
				metodoPago.setMetodoPago(rs.getString("metodo_pago"));
				metodoPago.setDescripcion(rs.getString("descripcion"));
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return metodoPago;
	}
	
}
