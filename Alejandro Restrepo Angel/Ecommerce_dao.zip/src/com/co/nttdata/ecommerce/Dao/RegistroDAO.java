package com.co.nttdata.ecommerce.Dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.co.nttdata.ecommerce.modelos.Registro;
import com.co.nttdata.ecommerce.utilitarios.Conexion;

public class RegistroDAO {

	Conexion c = new Conexion();
	
	public List<Registro> listarRegistros() {		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		List<Registro> registros = new ArrayList<Registro>();

		try {
			st = baseDatos.prepareStatement("SELECT * FROM sc_ecommerce.tbl_registros");
			rs = st.executeQuery();

			while (rs.next()) {
				Registro registro = new Registro();

				registro.setId(rs.getInt("id"));
				registro.setId_Usuario(rs.getInt("id_usuario"));
				registro.setFecha_Accion(rs.getDate("fecha_accion"));
				registro.setAccion(rs.getString("accion"));
				registro.setResultado(rs.getString("resultado"));
				registro.setHostname(rs.getString("hostname"));
				registro.setIp(rs.getString("ip"));

				registros.add(registro);
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				rs.close();
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return registros;
	}
	
	public List<Registro> buscarRegistrosUsuario(int id_usuario) {
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		List<Registro> registros = new ArrayList<Registro>();
		
		try {
			st = baseDatos.prepareStatement("SELECT * FROM sc_ecommerce.tbl_registros WHERE id_usuario = ? ");
			st.setInt(1, id_usuario);
			rs = st.executeQuery();
			while (rs.next()) {
				Registro registro = new Registro();
				
				registro.setId(rs.getInt("id"));
				registro.setId_Usuario(rs.getInt("id_usuario"));
				registro.setFecha_Accion(rs.getDate("fecha_accion"));
				registro.setAccion(rs.getString("accion"));
				registro.setResultado(rs.getString("resultado"));
				registro.setHostname(rs.getString("hostname"));
				registro.setIp(rs.getString("ip"));
				
				registros.add(registro);
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				rs.close();
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}	
		return registros;
	}

	public Boolean agregarRegistro(Registro registro) {
				
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;

		try {
			st = baseDatos.prepareStatement("INSERT INTO sc_ecommerce.tbl_registros "
					+ " (id_usuario, fecha_accion, accion, resultado, hostname, ip)"
					+ " VALUES (?, ?, ?, ?, ?, ?)");
			st.setInt(1, registro.getId_Usuario());
			st.setDate(2, (Date) registro.getFecha_Accion());
			st.setString(3, registro.getAccion());
			st.setString(4, registro.getResultado());
			st.setString(5, registro.getHostname());
			st.setString(6, registro.getIp());
			
			st.executeUpdate();
			return true;
			
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
			return false;
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Boolean eliminarPorId(int id) {
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;

		try {
			st = baseDatos.prepareStatement("DELETE FROM sc_ecommerce.tbl_registros WHERE id = ?");
			st.setInt(1, id);
			st.executeQuery();
			return true;
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
			return false;
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Registro buscarPorId(int id) {
		
		Registro registro = new Registro();
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			st = baseDatos.prepareStatement("SELECT * FROM sc_ecommerce.tbl_registros WHERE id = ? ");
			st.setInt(1, id);
			rs = st.executeQuery();

			while (rs.next()) {

				registro.setId(rs.getInt("id"));
				registro.setId_Usuario(rs.getInt("id_usuario"));
				registro.setFecha_Accion(rs.getDate("fecha_accion"));
				registro.setAccion(rs.getString("accion"));
				registro.setResultado(rs.getString("resultado"));
				registro.setHostname(rs.getString("hostname"));
				registro.setIp(rs.getString("ip"));
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return registro;
	}
	
}
