package com.co.nttdata.ecommerce.Dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.co.nttdata.ecommerce.modelos.Factura;
import com.co.nttdata.ecommerce.utilitarios.Conexion;

public class FacturaDAO {
	
Conexion c = new Conexion();
	
	public List<Factura> listarFacturas() {		
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		List<Factura> facturas = new ArrayList<Factura>();

		try {
			st = baseDatos.prepareStatement("SELECT * FROM sc_ecommerce.tbl_facturas");
			rs = st.executeQuery();

			while (rs.next()) {
				Factura factura = new Factura();

				factura.setId(rs.getInt("id"));
				factura.setId_Empresa(rs.getInt("id_empresa"));
				factura.setId_Cliente(rs.getInt("id_cliente"));
				factura.setFecha(rs.getDate("fecha"));
				factura.setId_CarritoCompra(rs.getInt("id_carrito_compras"));
				factura.setDescripcion(rs.getString("descripcion"));
				factura.setTotalEnvio(rs.getDouble("total_envio"));
				factura.setValorTotalSinIva(rs.getDouble("total_sin_iva"));
				factura.setValorTotalConIva(rs.getDouble("total_con_iva"));
				facturas.add(factura);
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				rs.close();
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return facturas;
	}

	public List<Factura> buscarFacturasCliente(int id_Cliente) {		
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		List<Factura> facturas = new ArrayList<Factura>();

		try {
			st = baseDatos.prepareStatement("SELECT * FROM sc_ecommerce.tbl_facturas WHERE id_cliente = ? ");
			st.setInt(1, id_Cliente);
			rs = st.executeQuery();

			while (rs.next()) {
				Factura factura = new Factura();

				factura.setId(rs.getInt("id"));
				factura.setId_Empresa(rs.getInt("id_empresa"));
				factura.setId_Cliente(rs.getInt("id_cliente"));
				factura.setFecha(rs.getDate("fecha"));
				factura.setId_CarritoCompra(rs.getInt("id_carrito_compras"));
				factura.setDescripcion(rs.getString("descripcion"));
				factura.setTotalEnvio(rs.getDouble("total_envio"));
				factura.setValorTotalSinIva(rs.getDouble("total_sin_iva"));
				factura.setValorTotalConIva(rs.getDouble("total_con_iva"));
				facturas.add(factura);
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				rs.close();
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return facturas;
	}

	public Boolean agregarFactura(Factura factura) {
				
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;

		try {
			st = baseDatos.prepareStatement("INSERT INTO sc_ecommerce.tbl_facturas"
					+ " (id_empresa, id_cliente, fecha, id_carrito_compras, descripcion, total_envio, total_sin_iva, total_con_iva)"
					+ " VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
			st.setInt(1, factura.getId_Empresa());
			st.setInt(2, factura.getId_Cliente());
			st.setDate(3, (Date) factura.getFecha());
			st.setInt(4, factura.getId_CarritoCompra());
			st.setString(5, factura.getDescripcion());
			st.setDouble(6, factura.getValorTotalSinIva());
			st.setDouble(7, factura.getValorTotalSinIva());
			st.setDouble(8, factura.getValorTotalConIva());
			st.executeUpdate();
			return true;
			
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
			return false;
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Boolean eliminarPorId(int id) {
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;

		try {
			st = baseDatos.prepareStatement("DELETE FROM sc_ecommerce.tbl_facturas WHERE id = ?");
			st.setInt(1, id);
			st.executeQuery();
			return true;
			
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
			return false;
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Factura buscarPorId(int id) {
		
		Factura factura = new Factura();
		
		Connection baseDatos = c.conectarBD();
		PreparedStatement st = null;
		ResultSet rs = null;
		
		try {
			st = baseDatos.prepareStatement("SELECT * FROM sc_ecommerce.tbl_facturas WHERE id = ? ");
			st.setInt(1, id);
			rs = st.executeQuery();

			while (rs.next()) {
				factura.setId(rs.getInt("id"));
				factura.setId_Empresa(rs.getInt("id_empresa"));
				factura.setId_Cliente(rs.getInt("id_cliente"));
				factura.setFecha(rs.getDate("fecha"));
				factura.setId_CarritoCompra(rs.getInt("id_carrito_compras"));
				factura.setDescripcion(rs.getString("descripcion"));
				factura.setTotalEnvio(rs.getDouble("total_envio"));
				factura.setValorTotalSinIva(rs.getDouble("total_sin_iva"));
				factura.setValorTotalConIva(rs.getDouble("total_con_iva"));
			}
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		} 
		finally {
			try {
				st.close();
				c.desconectarBD(baseDatos);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return factura;
	}
	
}
