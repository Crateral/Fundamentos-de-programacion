package com.co.nttdata.ecommerce.logicas;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.co.nttdata.ecommerce.daos.MetodoPagoDAO;
import com.co.nttdata.ecommerce.interfaces.IGestionMetodoPago;
import com.co.nttdata.ecommerce.modelos.MetodoPago;

public class GestionMetodoPagoImpl implements IGestionMetodoPago{
	
	public static final String PERSISTENCE_UNIT_NAME="EcommerceJPA";
	private static EntityManagerFactory factory;
		
	@Override
	public void crearMetodoPago(MetodoPago metodoPago) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		MetodoPagoDAO metodoPagoDao = new MetodoPagoDAO(em);
		
		if(metodoPagoDao.create(metodoPago)) {
			System.out.println("El método de pago se ha agregado correctamente");
		}
		else{
			System.out.println("Error: El método de pago no se ha agregado correctamente");
		}
	}

	@Override
	public void listarMetodosPago() {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		MetodoPagoDAO metodoPagoDao = new MetodoPagoDAO(em);
		
		List<MetodoPago> listaMetodosPago = metodoPagoDao.findAll();
		System.out.println("Listado de Administradores");
		if(listaMetodosPago.isEmpty()) {
			System.out.println("Lista vacía");
		}
		else {
			listaMetodosPago.forEach((metodoPago) ->System.out.println(metodoPago.toString()));	
		}
	}

	@Override
	public void buscarPorNombre(String nombreMetodo) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		MetodoPagoDAO metodoPagoDao = new MetodoPagoDAO(em);
		
		MetodoPago metodoPago = new MetodoPago();
		metodoPago = metodoPagoDao.findByNombre(nombreMetodo); 
		if(metodoPago.getId()!=0) {
			System.out.println(metodoPago.toString());
		}
		else {
			System.out.println("No se ha encontrado ningún método de pago");
		}		
	}

	@Override
	public void buscarPorId(int id) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		MetodoPagoDAO metodoPagoDao = new MetodoPagoDAO(em);
		
		MetodoPago metodoPago = new MetodoPago();
		metodoPago = metodoPagoDao.findById(id); 
		if(metodoPago.getId()!=0) {
			System.out.println(metodoPago.toString());
		}
		else {
			System.out.println("No se ha encontrado ningún método de pago");
		}	
	}

	@Override
	public void eliminarPorId(int id) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		MetodoPagoDAO metodoPagoDao = new MetodoPagoDAO(em);
		
		MetodoPago metodoPago = new MetodoPago();
		metodoPago = metodoPagoDao.findById(id); 
		if(metodoPagoDao.delete(metodoPago)) {
			System.out.println("El método de pago se ha eliminado correctamente");
		}
		else{
			System.out.println("Error: El método de pago no se ha eliminado correctamente");
		}	
	}

}
