package com.co.nttdata.ecommerce.logicas;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.co.nttdata.ecommerce.daos.CarritoCompraDAO;
import com.co.nttdata.ecommerce.daos.CompraDAO;
import com.co.nttdata.ecommerce.interfaces.IGestionCarritoCompra;
import com.co.nttdata.ecommerce.modelos.CarritoCompra;
import com.co.nttdata.ecommerce.modelos.Compra;

public class GestionCarritoCompraImpl implements IGestionCarritoCompra{
	
	public static final String PERSISTENCE_UNIT_NAME="EcommerceJPA";
	private static EntityManagerFactory factory;

	@Override
	public void crearCarritos(CarritoCompra carritoCompra) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		
		CarritoCompraDAO carritoDao = new CarritoCompraDAO(em);
		
		if(carritoDao.create(carritoCompra)) {
			System.out.println("Se ha agregado correctamente al carrito");
		}
		else{
			System.out.println("Error: No se ha agregado correctamente al carrito");
		}
	}

	@Override
	public void listarCarritos() {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		
		CarritoCompraDAO carritoDao = new CarritoCompraDAO(em);
		
		List<CarritoCompra> listaCarritos = carritoDao.findAll();
		System.out.println("Listado de Carritos");
		if(listaCarritos.isEmpty()) {
			System.out.println("Lista vacía");
		}
		else {
			listaCarritos.forEach((carrito) ->System.out.println(carrito.toString()));	
		}
	}

	@Override
	public void buscarPorId(int id) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		
		CarritoCompraDAO carritoDao = new CarritoCompraDAO(em);
		
		CarritoCompra carritoCompras = new CarritoCompra();
		carritoCompras = carritoDao.findById(id); 
		if(carritoCompras.getId()!=0) {
			System.out.println(carritoCompras.toString());
		}
		else {
			System.out.println("No se ha encontrado ningún carrito de compras");
		}	
	}

	@Override
	public void eliminarPorId(int id) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		
		CarritoCompraDAO carritoDao = new CarritoCompraDAO(em);

		CarritoCompra carritoCompras = new CarritoCompra();
		carritoCompras = carritoDao.findById(id); 
		
		if(carritoDao.delete(carritoCompras)) {
			System.out.println("El carrito de compras se ha eliminado correctamente");
		}
		else{
			System.out.println("Error: El carrito de compras no se ha eliminado correctamente");
		}	
	}

	/*
	 * @Override public Double calcularSubtotalSinIva(int id_CarritoCompra) {
	 * factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
	 * EntityManager em = factory.createEntityManager();
	 * 
	 * CarritoCompraDAO carritoDao = new CarritoCompraDAO(em); CompraDAO compraDao =
	 * new CompraDAO(em);
	 * 
	 * Double subtotalSinIva = 0.0; List<Compra> compras = new ArrayList<Compra>();
	 * compras = compraDao.findByCarritoCompra(id_CarritoCompra); for (int i = 0; i
	 * < compras.size(); i++) { subtotalSinIva += compras.get(i).getValor(); }
	 * return subtotalSinIva; }
	 * 
	 * @Override public Double calcularSubtotalConIva(int id_CarritoCompra) {
	 * factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
	 * EntityManager em = factory.createEntityManager();
	 * 
	 * CarritoCompraDAO carritoDao = new CarritoCompraDAO(em); CompraDAO compraDao =
	 * new CompraDAO(em);
	 * 
	 * Double subtotalSinIva = 0.0, subtotalConIva=0.0; subtotalSinIva =
	 * calcularSubtotalSinIva(id_CarritoCompra); subtotalConIva = subtotalSinIva *
	 * 1.19; return subtotalConIva; }
	 */

}
