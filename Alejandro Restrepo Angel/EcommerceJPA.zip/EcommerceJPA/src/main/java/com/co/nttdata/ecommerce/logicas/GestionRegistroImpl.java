package com.co.nttdata.ecommerce.logicas;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.co.nttdata.ecommerce.daos.RegistroDAO;
import com.co.nttdata.ecommerce.interfaces.IGestionRegistro;
import com.co.nttdata.ecommerce.modelos.Registro;

public class GestionRegistroImpl implements IGestionRegistro{
	
	public static final String PERSISTENCE_UNIT_NAME="EcommerceJPA";
	private static EntityManagerFactory factory;
	
	@Override
	public void crearRegistro(Registro registro) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		RegistroDAO registroDao = new RegistroDAO(em);
		
		if(registroDao.create(registro)) {
			System.out.println("El registro se ha agregado correctamente");
		}
		else{
			System.out.println("Error: El registro no se ha agregado correctamente");
		}
	}

	@Override
	public void listarRegistros() {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		RegistroDAO registroDao = new RegistroDAO(em);
		
		List<Registro> listaregistros = registroDao.findAll();
		System.out.println("Listado de registros");
		if(listaregistros.isEmpty()) {
			System.out.println("Lista vacía");
		}
		else {
			listaregistros.forEach((registro) ->System.out.println(registro.toString()));	
		}
	}

	/*
	 * @Override public void buscarPorUsuario(int id_Usuario) { factory =
	 * Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME); EntityManager
	 * em = factory.createEntityManager(); RegistroDAO registroDao = new
	 * RegistroDAO(em);
	 * 
	 * List<Registro> listaregistros =
	 * registroDao.buscarRegistrosUsuario(id_Usuario);
	 * System.out.println("Listado de registros"); if(listaregistros.isEmpty()) {
	 * System.out.println("Lista vacía"); } else { listaregistros.forEach((registro)
	 * ->System.out.println(registro.toString())); } }
	 */

	@Override
	public void buscarPorId(int id) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		RegistroDAO registroDao = new RegistroDAO(em);
		
		Registro registro = new Registro();
		registro = registroDao.findById(id); 
		if(registro.getId()!=0) {
			System.out.println(registro.toString());
		}
		else {
			System.out.println("No se ha encontrado ningún registro");
		}	
	}

	@Override
	public void eliminarPorId(int id) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		RegistroDAO registroDao = new RegistroDAO(em);
		
		Registro registro = new Registro();
		registro = registroDao.findById(id); 
		if(registroDao.delete(registro)) {
			System.out.println("El registro se ha eliminado correctamente");
		}
		else{
			System.out.println("Error: El registro no se ha eliminado correctamente");
		}	
	}

}
