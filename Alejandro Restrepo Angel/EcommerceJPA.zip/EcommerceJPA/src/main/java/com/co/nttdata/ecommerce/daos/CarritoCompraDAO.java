package com.co.nttdata.ecommerce.daos;

import java.util.List;

import javax.persistence.EntityManager;

import com.co.nttdata.ecommerce.modelos.CarritoCompra;

public class CarritoCompraDAO {

	private EntityManager entityManager;

	public CarritoCompraDAO(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public List<CarritoCompra> findAll() {
		entityManager.getTransaction().begin();
		javax.persistence.Query carritos = entityManager.createQuery("Select * From CarritoCompra");
		entityManager.getTransaction().commit();
		return carritos.getResultList();
	}

	public List<CarritoCompra> findByCarritoCompra(int id_CarritoCompra) {
		entityManager.getTransaction().begin();
		javax.persistence.Query carritos = entityManager.createQuery("Select * From CarritoCompra");
		entityManager.getTransaction().commit();
		return carritos.getResultList();
	}
	
	public Boolean create(CarritoCompra carritoCompra) {
		try {
			entityManager.getTransaction().begin();
			entityManager.persist(carritoCompra);
			entityManager.getTransaction().commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
			return false;
		}
	}

	public CarritoCompra findById(int id) {
		return entityManager.find(CarritoCompra.class, id);
	}

	public void update(CarritoCompra carritoCompra) {
		entityManager.getTransaction().begin();
		entityManager.merge(carritoCompra);
		entityManager.getTransaction().commit();
	}

	public Boolean delete(CarritoCompra carritoCompra) {
		try {
			entityManager.getTransaction().begin();
			entityManager.remove(carritoCompra);
			entityManager.getTransaction().commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
			return false;
		}
	}

}
