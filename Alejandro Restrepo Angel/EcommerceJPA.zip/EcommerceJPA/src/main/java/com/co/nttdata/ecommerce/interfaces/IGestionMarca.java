package com.co.nttdata.ecommerce.interfaces;

import com.co.nttdata.ecommerce.modelos.Marca;

public interface IGestionMarca {
	
	public void listarMarcas();
	public void crearMarca(Marca marca);
	public void buscarPorNombre(String nombreMarca);
	public void buscarPorId(int id);
	public void eliminarPorId(int id);

}
