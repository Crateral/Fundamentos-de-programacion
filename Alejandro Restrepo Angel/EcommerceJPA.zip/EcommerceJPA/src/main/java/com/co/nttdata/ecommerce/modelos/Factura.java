package com.co.nttdata.ecommerce.modelos;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the tbl_facturas database table.
 * 
 */
@Entity
@Table(name="tbl_facturas", schema="sc_ecommerce")
@NamedQuery(name="Factura.findAll", query="SELECT f FROM Factura f")
public class Factura implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;

	private String descripcion;

	@Temporal(TemporalType.DATE)
	private Date fecha;

	@Column(name="total_con_iva")
	private double totalConIva;

	@Column(name="total_envio")
	private double totalEnvio;

	@Column(name="total_sin_iva")
	private double totalSinIva;

	//bi-directional many-to-one association to CarritoCompra
	@ManyToOne
	@JoinColumn(name="id_carrito_compras")
	private CarritoCompra carritoCompra;

	//bi-directional many-to-one association to Cliente
	@ManyToOne
	@JoinColumn(name="id_cliente")
	private Cliente cliente;

	//bi-directional many-to-one association to Empresa
	@ManyToOne
	@JoinColumn(name="id_empresa")
	private Empresa empresa;

	public Factura() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Date getFecha() {
		return this.fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public double getTotalConIva() {
		return this.totalConIva;
	}

	public void setTotalConIva(double totalConIva) {
		this.totalConIva = totalConIva;
	}

	public double getTotalEnvio() {
		return this.totalEnvio;
	}

	public void setTotalEnvio(double totalEnvio) {
		this.totalEnvio = totalEnvio;
	}

	public double getTotalSinIva() {
		return this.totalSinIva;
	}

	public void setTotalSinIva(double totalSinIva) {
		this.totalSinIva = totalSinIva;
	}

	public CarritoCompra getCarritoCompra() {
		return this.carritoCompra;
	}

	public void setCarritoCompra(CarritoCompra carritoCompra) {
		this.carritoCompra = carritoCompra;
	}

	public Cliente getCliente() {
		return this.cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public Empresa getEmpresa() {
		return this.empresa;
	}

	public void setEmpresa(Empresa empresa) {
		this.empresa = empresa;
	}

	@Override
	public String toString() {
		return "Factura [id=" + id + ", descripcion=" + descripcion + ", fecha=" + fecha + ", totalConIva="
				+ totalConIva + ", totalEnvio=" + totalEnvio + ", totalSinIva=" + totalSinIva + ", carritoCompra="
				+ carritoCompra + ", cliente=" + cliente + ", empresa=" + empresa + "]";
	}

}