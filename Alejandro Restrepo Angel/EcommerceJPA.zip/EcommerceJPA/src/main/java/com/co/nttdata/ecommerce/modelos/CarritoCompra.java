package com.co.nttdata.ecommerce.modelos;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the tbl_carrito_compras database table.
 * 
 */
@Entity
@Table(name="tbl_carrito_compras", schema="sc_ecommerce")
@NamedQuery(name="CarritoCompra.findAll", query="SELECT c FROM CarritoCompra c")
public class CarritoCompra implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;

	@Column(name="subtotal_con_iva")
	private double subtotalConIva;

	@Column(name="subtotal_sin_iva")
	private double subtotalSinIva;

	@Column(name="valor_envio")
	private double valorEnvio;

	//bi-directional many-to-one association to Compra
	@OneToMany(mappedBy="carritoCompra")
	private List<Compra> compras;

	//bi-directional many-to-one association to Factura
	@OneToMany(mappedBy="carritoCompra")
	private List<Factura> facturas;

	public CarritoCompra() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public double getSubtotalConIva() {
		return this.subtotalConIva;
	}

	public void setSubtotalConIva(double subtotalConIva) {
		this.subtotalConIva = subtotalConIva;
	}

	public double getSubtotalSinIva() {
		return this.subtotalSinIva;
	}

	public void setSubtotalSinIva(double subtotalSinIva) {
		this.subtotalSinIva = subtotalSinIva;
	}

	public double getValorEnvio() {
		return this.valorEnvio;
	}

	public void setValorEnvio(double valorEnvio) {
		this.valorEnvio = valorEnvio;
	}

	public List<Compra> getCompras() {
		return this.compras;
	}

	public void setCompras(List<Compra> compras) {
		this.compras = compras;
	}

	public Compra addCompra(Compra compra) {
		getCompras().add(compra);
		compra.setCarritoCompra(this);

		return compra;
	}

	public Compra removeCompra(Compra compra) {
		getCompras().remove(compra);
		compra.setCarritoCompra(null);

		return compra;
	}

	public List<Factura> getFacturas() {
		return this.facturas;
	}

	public void setFacturas(List<Factura> facturas) {
		this.facturas = facturas;
	}

	public Factura addFactura(Factura factura) {
		getFacturas().add(factura);
		factura.setCarritoCompra(this);

		return factura;
	}

	public Factura removeFactura(Factura factura) {
		getFacturas().remove(factura);
		factura.setCarritoCompra(null);

		return factura;
	}

	@Override
	public String toString() {
		return "CarritoCompra [id=" + id + ", subtotalConIva=" + subtotalConIva + ", subtotalSinIva=" + subtotalSinIva
				+ ", valorEnvio=" + valorEnvio + "]";
	}

}