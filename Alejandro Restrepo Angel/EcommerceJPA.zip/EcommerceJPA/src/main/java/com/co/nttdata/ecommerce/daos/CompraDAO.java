package com.co.nttdata.ecommerce.daos;

import java.util.List;

import javax.persistence.EntityManager;

import com.co.nttdata.ecommerce.modelos.Compra;

public class CompraDAO {

	private EntityManager entityManager;

	public CompraDAO(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public List<Compra> findAll() {
		entityManager.getTransaction().begin();
		javax.persistence.Query compras = entityManager.createQuery("Select * From Compra");
		entityManager.getTransaction().commit();
		return compras.getResultList();
	}

	public Boolean create(Compra compra) {
		try {
			entityManager.getTransaction().begin();
			entityManager.persist(compra);
			entityManager.getTransaction().commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
			return false;
		}
	}

	public Compra findById(int id) {
		return entityManager.find(Compra.class, id);
	}

	public void update(Compra compra) {
		entityManager.getTransaction().begin();
		entityManager.merge(compra);
		entityManager.getTransaction().commit();
	}

	public Boolean delete(Compra compra) {
		try {
			entityManager.getTransaction().begin();
			entityManager.remove(compra);
			entityManager.getTransaction().commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
			return false;
		}
	}

}
