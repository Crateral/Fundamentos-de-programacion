package com.co.nttdata.ecommerce.interfaces;

import com.co.nttdata.ecommerce.modelos.Compra;
//import com.co.nttdata.ecommerce.modelos.Producto;
  
public interface IGestionCompra {
 
	public void listarCompras();
	public void crearCompra(Compra compra);
	//public void buscarPorCarritoCompras(int id_Carrito_compras);
	public void buscarPorId(int id);
	public void eliminarPorId(int id);
	  
	//public Double calcularValor(int id_Producto, int cantidad);
	//public Producto agregarProductoCompra(int id_Producto, int cantidad);
	//public Producto devolverProductoCompra(int id_Producto, int cantidad);
	
} 