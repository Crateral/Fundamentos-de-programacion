package com.co.nttdata.ecommerce.daos;

import java.util.List;

import javax.persistence.EntityManager;

import com.co.nttdata.ecommerce.modelos.Categoria;
import com.co.nttdata.ecommerce.modelos.TipoIdentificacion;

public class TipoIdentificacionDAO {

	private EntityManager entityManager;

	public TipoIdentificacionDAO(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	
	public List<TipoIdentificacion> findAll() {
		entityManager.getTransaction().begin();
		javax.persistence.Query tiposIdentificacion = entityManager.createQuery("Select * From TipoIdentificacion");
		entityManager.getTransaction().commit();
		return tiposIdentificacion.getResultList();
	}

	public Boolean create(TipoIdentificacion tipoIdentificacion) {
		try {
			entityManager.getTransaction().begin();
			entityManager.persist(tipoIdentificacion);
			entityManager.getTransaction().commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
			return false;
		}
	}

	public TipoIdentificacion findById(int id) {
		return entityManager.find(TipoIdentificacion.class, id);
	}
	
	public TipoIdentificacion findByNombre(String tipoIdentificacion) {
		return entityManager.find(TipoIdentificacion.class, tipoIdentificacion);
	}

	public void update(TipoIdentificacion tipoIdentificacion) {
		entityManager.getTransaction().begin();
		entityManager.merge(tipoIdentificacion);
		entityManager.getTransaction().commit();
	}

	public Boolean delete(TipoIdentificacion tipoIdentificacion) {
		try {
			entityManager.getTransaction().begin();
			entityManager.remove(tipoIdentificacion);
			entityManager.getTransaction().commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
			return false;
		}
	}

}
