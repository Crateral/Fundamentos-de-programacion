package com.co.nttdata.ecommerce.logicas;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.co.nttdata.ecommerce.daos.UsuarioDAO;
import com.co.nttdata.ecommerce.interfaces.IGestionUsuario;
import com.co.nttdata.ecommerce.modelos.Usuario;

public class GestionUsuarioImpl implements IGestionUsuario{
	
	public static final String PERSISTENCE_UNIT_NAME="EcommerceJPA";
	private static EntityManagerFactory factory;
	
	@Override
	public void crearUsuario(Usuario usuario) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		UsuarioDAO usuarioDao = new UsuarioDAO(em);
		
		if(usuarioDao.create(usuario)) {
			System.out.println("El usuario se ha agregado correctamente");
		}
		else{
			System.out.println("Error: El usuario no se ha agregado correctamente");
		}
	}

	@Override
	public void listarUsuarios() {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		UsuarioDAO usuarioDao = new UsuarioDAO(em);
		
		List<Usuario> listaUsuarios = usuarioDao.findAll();
		System.out.println("Listado de usuarios");
		if(listaUsuarios.isEmpty()) {
			System.out.println("Lista vacía");
		}
		else {
			listaUsuarios.forEach((usuario) ->System.out.println(usuario.toString()));	
		}
	}

	@Override
	public void buscarPorNombre(String nombreUsuario) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		UsuarioDAO usuarioDao = new UsuarioDAO(em);
		
		Usuario usuario = new Usuario();
		usuario = usuarioDao.findByNombre(nombreUsuario); 
		if(usuario.getId()!=0) {
			System.out.println(usuario.toString());
		}
		else {
			System.out.println("No se ha encontrado ningún usuario");
		}		
	}

	@Override
	public void buscarPorId(int id) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		UsuarioDAO usuarioDao = new UsuarioDAO(em);
		
		Usuario usuario = new Usuario();
		usuario = usuarioDao.findById(id); 
		if(usuario.getId()!=0) {
			System.out.println(usuario.toString());
		}
		else {
			System.out.println("No se ha encontrado ningún usuario");
		}	
	}

	@Override
	public void eliminarPorId(int id) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		UsuarioDAO usuarioDao = new UsuarioDAO(em);
		
		Usuario usuario = new Usuario();
		usuario = usuarioDao.findById(id);
		if(usuarioDao.delete(usuario)) {
			System.out.println("El usuario se ha eliminado correctamente");
		}
		else{
			System.out.println("Error: El usuario no se ha eliminado correctamente");
		}	
	}

}
