package com.co.nttdata.ecommerce.interfaces;

import com.co.nttdata.ecommerce.modelos.CarritoCompra;

public interface IGestionCarritoCompra {
	
	public void listarCarritos();
	public void crearCarritos(CarritoCompra carritoDeCompras);
	public void buscarPorId(int id);
	public void eliminarPorId(int id);
	
	//public Double calcularSubtotalSinIva(int id_CarritoCompra);
	//public Double calcularSubtotalConIva(int id_CarritoCompra);

}
