package com.co.nttdata.ecommerce.logicas;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.co.nttdata.ecommerce.daos.CiudadDAO;
import com.co.nttdata.ecommerce.interfaces.IGestionCiudad;
import com.co.nttdata.ecommerce.modelos.Ciudad;

public class GestionCiudadImpl implements IGestionCiudad{
	
	public static final String PERSISTENCE_UNIT_NAME="EcommerceJPA";
	private static EntityManagerFactory factory;
		
	@Override
	public void crearCiudad(Ciudad ciudad) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		
		CiudadDAO ciudadDao = new CiudadDAO(em);
		
		if(ciudadDao.create(ciudad)) {
			System.out.println("La ciudad se ha agregado correctamente");
		}
		else{
			System.out.println("Error: la ciudad no se ha agregado correctamente");
		}
	}

	@Override
	public void listarCiudades() {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		
		CiudadDAO ciudadDao = new CiudadDAO(em);
		
		List<Ciudad> listaCiudades = ciudadDao.findAll();
		System.out.println("Listado de ciudades");
		if(listaCiudades.isEmpty()) {
			System.out.println("Lista vacía");
		}
		else {
			listaCiudades.forEach((ciudad) ->System.out.println(ciudad.toString()));	
		}
	}

	@Override
	public void buscarPorNombre(String nombreCiudad) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		
		CiudadDAO ciudadDao = new CiudadDAO(em);
		
		Ciudad ciudad = new Ciudad();
		ciudad = ciudadDao.findByNombre(nombreCiudad); 
		if(ciudad.getId()!=0) {
			System.out.println(ciudad.toString());
		}
		else {
			System.out.println("No se ha encontrado ninguna ciudad");
		}		
	}

	@Override
	public void buscarPorId(int id) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		
		CiudadDAO ciudadDao = new CiudadDAO(em);
		
		Ciudad ciudad = new Ciudad();
		ciudad = ciudadDao.findById(id); 
		if(ciudad.getId()!=0) {
			System.out.println(ciudad.toString());
		}
		else {
			System.out.println("No se ha encontrado ninguna ciudad");
		}	
	}

	@Override
	public void eliminarPorId(int id) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		
		CiudadDAO ciudadDao = new CiudadDAO(em);
		Ciudad ciudad = new Ciudad();
		ciudad = ciudadDao.findById(id); 
		if(ciudadDao.delete(ciudad)) {
			System.out.println("La ciudad se ha eliminado correctamente");
		}
		else{
			System.out.println("Error: El ciudad no se ha eliminado correctamente");
		}	
	}

}
