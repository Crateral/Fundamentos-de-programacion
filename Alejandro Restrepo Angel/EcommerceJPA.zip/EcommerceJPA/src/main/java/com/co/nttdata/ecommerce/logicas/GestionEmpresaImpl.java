package com.co.nttdata.ecommerce.logicas;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.co.nttdata.ecommerce.daos.EmpresaDAO;
import com.co.nttdata.ecommerce.interfaces.IGestionEmpresa;
import com.co.nttdata.ecommerce.modelos.Empresa;

public class GestionEmpresaImpl implements IGestionEmpresa{
	
	public static final String PERSISTENCE_UNIT_NAME="EcommerceJPA";
	private static EntityManagerFactory factory;
	

	
	@Override
	public void crearEmpresa(Empresa empresa) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		EmpresaDAO empresaDao = new EmpresaDAO(em);
		if(empresaDao.create(empresa)) {
			System.out.println("La empresa se ha agregado correctamente");
		}
		else{
			System.out.println("Error: La empresa no se ha agregado correctamente");
		}
	}

	@Override
	public void listarEmpresas() {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		EmpresaDAO empresaDao = new EmpresaDAO(em);
		
		List<Empresa> listaEmpresa = empresaDao.findAll();
		System.out.println("Listado de empresas");
		if(listaEmpresa.isEmpty()) {
			System.out.println("Lista vacía");
		}
		else {
			listaEmpresa.forEach((empresa) ->System.out.println(empresa.toString()));	
		}
	}

	@Override
	public void buscarPorNit(String nitEmpresa) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		EmpresaDAO empresaDao = new EmpresaDAO(em);
		
		Empresa empresa = new Empresa();
		empresa = empresaDao.findByNit(nitEmpresa); 
		if(empresa.getId()!=0) {
			System.out.println(empresa.toString());
		}
		else {
			System.out.println("No se ha encontrado ninguna empresa");
		}		
	}

	@Override
	public void buscarPorId(int id) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		EmpresaDAO empresaDao = new EmpresaDAO(em);
		
		Empresa empresa = new Empresa();
		empresa = empresaDao.findById(id); 
		if(empresa.getId()!=0) {
			System.out.println(empresa.toString());
		}
		else {
			System.out.println("No se ha encontrado ninguna empresa");
		}	
	}

	@Override
	public void eliminarPorId(int id) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		EmpresaDAO empresaDao = new EmpresaDAO(em);
		
		Empresa empresa = new Empresa();
		empresa = empresaDao.findById(id); 
		if(empresaDao.delete(empresa)) {
			System.out.println("La empresa se ha eliminado correctamente");
		}
		else{
			System.out.println("Error: La empresa no se ha eliminado correctamente");
		}	
	}

}
