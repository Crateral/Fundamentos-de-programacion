package com.co.nttdata.ecommerce.vistas;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.co.nttdata.ecommerce.daos.TipoIdentificacionDAO;
import com.co.nttdata.ecommerce.modelos.TipoIdentificacion;

public class Main {

	public static final String PERSISTENCE_UNIT_NAME = "EcommerceJPA";
	private static EntityManagerFactory factory; 
	
	public static void main(String[] args) {
		
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		
		TipoIdentificacionDAO tid = new TipoIdentificacionDAO(em);
		TipoIdentificacion ti = new TipoIdentificacion();

		ti = tid.findById(6);
		System.out.println(ti.toString());
		em.close();
	}
}
