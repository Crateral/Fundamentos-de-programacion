package com.co.nttdata.ecommerce.logicas;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.co.nttdata.ecommerce.daos.AdministradorDAO;
import com.co.nttdata.ecommerce.interfaces.IGestionAdministrador;
import com.co.nttdata.ecommerce.modelos.Administrador;

public class GestionAdministradorImpl implements IGestionAdministrador{
	
	public static final String PERSISTENCE_UNIT_NAME="EcommerceJPA";
	private static EntityManagerFactory factory;
	
	@Override
	public void crearAdministrador(Administrador administrador) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		
		AdministradorDAO administradorDao = new AdministradorDAO(em);
		
		if(administradorDao.create(administrador)) {
			System.out.println("El administrador se ha agregado correctamente");
		}
		else{
			System.out.println("Error: El administrador no se ha agregado correctamente");
		}
	}

	@Override
	public void listarAdministradores() {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		
		AdministradorDAO administradorDao = new AdministradorDAO(em);
		
		
		List<Administrador> listaAdministradores = administradorDao.findAll();
		System.out.println("Listado de Administradores");
		if(listaAdministradores.isEmpty()) {
			System.out.println("Lista vacía");
		}
		else {
			listaAdministradores.forEach((administrador) ->System.out.println(administrador.toString()));	
		}
	}

	@Override
	public void buscarPorCorreo(String correo) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		
		AdministradorDAO administradorDao = new AdministradorDAO(em);
		
		
		Administrador administrador = new Administrador();
		administrador = administradorDao.findByCorreo(correo); 
		if(administrador.getId()!=0) {
			System.out.println(administrador.toString());
		}
		else {
			System.out.println("No se ha encontrado ningún administrador");
		}		
	}

	@Override
	public void buscarPorId(int id) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		
		AdministradorDAO administradorDao = new AdministradorDAO(em);
		
		
		Administrador administrador = new Administrador();
		administrador = administradorDao.findById(id); 
		if(administrador.getId()!=0) {
			System.out.println(administrador.toString());
		}
		else {
			System.out.println("No se ha encontrado ningún administrador");
		}	
	}

	@Override
	public void eliminarPorId(int id) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		
		AdministradorDAO administradorDao = new AdministradorDAO(em);
		
		
		Administrador administrador = new Administrador();
		administrador = administradorDao.findById(id); 
		if(administradorDao.delete(administrador)) {
			System.out.println("El administrador se ha eliminado correctamente");
		}
		else{
			System.out.println("Error: El administrador no se ha eliminado correctamente");
		}	
	}

}
