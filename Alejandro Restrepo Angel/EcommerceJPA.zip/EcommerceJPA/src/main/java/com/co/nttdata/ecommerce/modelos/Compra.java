package com.co.nttdata.ecommerce.modelos;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the tbl_compras database table.
 * 
 */
@Entity
@Table(name="tbl_compras", schema="sc_ecommerce")
@NamedQuery(name="Compra.findAll", query="SELECT c FROM Compra c")
public class Compra implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;

	private Integer cantidad;

	private double valor;

	//bi-directional many-to-one association to CarritoCompra
	@ManyToOne
	@JoinColumn(name="id_carrito_compras")
	private CarritoCompra carritoCompra;

	//bi-directional many-to-one association to Producto
	@ManyToOne
	@JoinColumn(name="id_producto")
	private Producto producto;

	public Compra() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getCantidad() {
		return this.cantidad;
	}

	public void setCantidad(Integer cantidad) {
		this.cantidad = cantidad;
	}

	public double getValor() {
		return this.valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	public CarritoCompra getCarritoCompra() {
		return this.carritoCompra;
	}

	public void setCarritoCompra(CarritoCompra carritoCompra) {
		this.carritoCompra = carritoCompra;
	}

	public Producto getProducto() {
		return this.producto;
	}

	public void setProducto(Producto producto) {
		this.producto = producto;
	}

	@Override
	public String toString() {
		return "Compra [id=" + id + ", cantidad=" + cantidad + ", valor=" + valor + ", carritoCompra=" + carritoCompra
				+ ", producto=" + producto + "]";
	}
	
}