package com.co.nttdata.ecommerce.logicas;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.co.nttdata.ecommerce.daos.CategoriaDAO;
import com.co.nttdata.ecommerce.daos.ProductoDAO;
import com.co.nttdata.ecommerce.interfaces.IGestionProducto;
import com.co.nttdata.ecommerce.modelos.Categoria;
import com.co.nttdata.ecommerce.modelos.Producto;

public class GestionProductoImpl implements IGestionProducto{
	
	public static final String PERSISTENCE_UNIT_NAME="EcommerceJPA";
	private static EntityManagerFactory factory;
	
	@Override
	public void crearProducto(Producto producto) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		
		ProductoDAO productoDao = new ProductoDAO(em);
		
		if(productoDao.create(producto)) {
			System.out.println("El producto se ha agregado correctamente");
		}
		else{
			System.out.println("Error: El producto no se ha agregado correctamente");
		}
	}

	@Override
	public void listarProductos() {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		
		ProductoDAO productoDao = new ProductoDAO(em);
		
		List<Producto> listaProductos = productoDao.findAll();
		System.out.println("Listado de Productos");
		listaProductos.forEach((producto) ->System.out.println(producto.toString()));	
	}

	@Override
	public void buscarPorProducto(String nombreProducto) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		
		ProductoDAO productoDao = new ProductoDAO(em);
		
		Producto producto = new Producto();
		producto = productoDao.findByNombre(nombreProducto); 
		if(producto.getId()!=0) {
			System.out.println(producto.toString());
		}
		else {
			System.out.println("No se ha encontrado ningún producto");
		}		
	}

	@Override
	public void buscarPorId(int id) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		
		ProductoDAO productoDao = new ProductoDAO(em);
		
		Producto producto = new Producto();
		producto = productoDao.findById(id); 
		if(producto.getId()!=0) {
			System.out.println(producto.toString());
		}
		else {
			System.out.println("No se ha encontrado ningún producto");
		}	
	}

	@Override
	public void eliminarPorId(int id) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		
		ProductoDAO productoDao = new ProductoDAO(em);
		
		Producto producto = new Producto();
		producto = productoDao.findById(id); 
		if(productoDao.delete(producto)) {
			System.out.println("El producto se ha eliminado correctamente");
		}
		else{
			System.out.println("Error: El producto no se ha eliminado correctamente");
		}	
	}

	/*
	 * @Override public Double DefinirValorDescuento(int id_producto) { Double
	 * descuento = 0.0; Categoria categoria = new Categoria(); Producto producto =
	 * new Producto();
	 * 
	 * producto = productoDao.buscarPorId(id_producto); categoria =
	 * categoriaDao.buscarPorId(producto.getId_Categoria());
	 * 
	 * if(categoria.isDescuento()) { descuento = categoria.getValor_Descuento();
	 * return descuento; }
	 * 
	 * if(producto.isDescuento()) { descuento = producto.getValorDescuento(); return
	 * descuento; } return descuento; }
	 */
	
}
