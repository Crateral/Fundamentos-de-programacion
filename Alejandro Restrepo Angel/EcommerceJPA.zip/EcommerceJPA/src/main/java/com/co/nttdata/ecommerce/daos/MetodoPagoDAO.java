package com.co.nttdata.ecommerce.daos;

import java.util.List;

import javax.persistence.EntityManager;

import com.co.nttdata.ecommerce.modelos.MetodoPago;

public class MetodoPagoDAO {

	private EntityManager entityManager;

	public MetodoPagoDAO(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public List<MetodoPago> findAll() {
		entityManager.getTransaction().begin();
		javax.persistence.Query metodosPago = entityManager.createQuery("Select * From MetodoPago");
		entityManager.getTransaction().commit();
		return metodosPago.getResultList();
	}

	public Boolean create(MetodoPago metodoPago) {
		try {
			entityManager.getTransaction().begin();
			entityManager.persist(metodoPago);
			entityManager.getTransaction().commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
			return false;
		}
	}

	public MetodoPago findById(int id) {
		return entityManager.find(MetodoPago.class, id);
	}

	public MetodoPago findByNombre(String metodoPago) {
		return entityManager.find(MetodoPago.class, metodoPago);
	}

	public void update(MetodoPago metodoPago) {
		entityManager.getTransaction().begin();
		entityManager.merge(metodoPago);
		entityManager.getTransaction().commit();
	}

	public Boolean delete(MetodoPago metodoPago) {
		try {
			entityManager.getTransaction().begin();
			entityManager.remove(metodoPago);
			entityManager.getTransaction().commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
			return false;
		}
	}

}
