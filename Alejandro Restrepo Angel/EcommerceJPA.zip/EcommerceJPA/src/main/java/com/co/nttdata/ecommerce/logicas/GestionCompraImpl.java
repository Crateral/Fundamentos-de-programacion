package com.co.nttdata.ecommerce.logicas;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.co.nttdata.ecommerce.daos.ProductoDAO;
import com.co.nttdata.ecommerce.daos.CompraDAO;
import com.co.nttdata.ecommerce.interfaces.IGestionCompra;
import com.co.nttdata.ecommerce.interfaces.IGestionProducto;
import com.co.nttdata.ecommerce.modelos.Compra;
import com.co.nttdata.ecommerce.modelos.Producto;

public class GestionCompraImpl implements IGestionCompra {

	public static final String PERSISTENCE_UNIT_NAME="EcommerceJPA";
	private static EntityManagerFactory factory;
		
	@Override
	public void crearCompra(Compra compra) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		CompraDAO compraDao = new CompraDAO(em);
		
		if(compraDao.create(compra)) {
			System.out.println("La compra se ha agregado correctamente");
		}
		else{
			System.out.println("Error: la compra no se ha agregado correctamente");
		}
	}

	@Override
	public void listarCompras() {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		CompraDAO compraDao = new CompraDAO(em);
		
		List<Compra> listaCompras = compraDao.findAll();
		System.out.println("Listado de compras");
		if(listaCompras.isEmpty()) {
			System.out.println("Lista vacía");
		}
		else {
			listaCompras.forEach((compra) ->System.out.println(compra.toString()));	
		}
	}

	/*
	 * @Override public void buscarPorCarritoCompras(int id_Carrito_compras) {
	 * factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
	 * EntityManager em = factory.createEntityManager(); private CompraDAO compraDao
	 * = new CompraDAO(em); private ProductoDAO productoDao = new ProductoDAO(em);
	 * 
	 * List<Compra> listaCompras =
	 * compraDao.buscarPorCarritoDeCompras(id_Carrito_compras);
	 * System.out.println("Listado de compras"); if(listaCompras.isEmpty()) {
	 * System.out.println("Lista vacía"); } else { listaCompras.forEach((compra)
	 * ->System.out.println(compra.toString())); } }
	 */

	@Override
	public void buscarPorId(int id) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		CompraDAO compraDao = new CompraDAO(em);
		
		Compra compra = new Compra();
		compra = compraDao.findById(id); 
		if(compra.getId()!=0) {
			System.out.println(compra.toString());
		}
		else {
			System.out.println("No se ha encontrado ninguna compra");
		}	
	}

	@Override
	public void eliminarPorId(int id) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		CompraDAO compraDao = new CompraDAO(em);
		
		Compra compra = new Compra();
		compra = compraDao.findById(id); 
		if(compraDao.delete(compra)) {
			System.out.println("La compra se ha eliminado correctamente");
		}
		else{
			System.out.println("Error: La compra no se ha eliminado correctamente");
		}	
	}

	/*
	 * @Override public Double calcularValor(int id_Producto, int cantidad) {
	 * 
	 * Double valor = 0.0, descuento = 0.0;
	 * 
	 * IGestionProducto gestionProducto = new GestionProductoImpl(); Producto
	 * producto = new Producto();
	 * 
	 * descuento = gestionProducto.DefinirValorDescuento(id_Producto); producto =
	 * productoDao.buscarPorId(id_Producto);
	 * 
	 * valor = (producto.getPrecio() * cantidad) * (1 - descuento); return valor; }
	 * 
	 * @Override public Producto agregarProductoCompra(int id_Producto, int
	 * cantidad) { Producto producto = new Producto(); producto =
	 * productoDao.buscarPorId(id_Producto);
	 * producto.setCantidadDiponible((producto.getCantidadDiponible()-cantidad));
	 * return producto; }
	 * 
	 * @Override public Producto devolverProductoCompra(int id_Producto, int
	 * cantidad) { Producto producto = new Producto(); producto =
	 * productoDao.buscarPorId(id_Producto);
	 * producto.setCantidadDiponible((producto.getCantidadDiponible()+cantidad));
	 * return producto; }
	 */

}
