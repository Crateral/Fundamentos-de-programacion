package com.co.nttdata.ecommerce.logicas;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.co.nttdata.ecommerce.daos.MarcaDAO;
import com.co.nttdata.ecommerce.interfaces.IGestionMarca;
import com.co.nttdata.ecommerce.modelos.Marca;

public class GestionMarcaImpl implements IGestionMarca {

	public static final String PERSISTENCE_UNIT_NAME = "EcommerceJPA";
	private static EntityManagerFactory factory;

	@Override
	public void crearMarca(Marca marca) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		MarcaDAO marcaDao = new MarcaDAO(em);

		if (marcaDao.create(marca)) {
			System.out.println("La marca se ha agregado correctamente");
		} else {
			System.out.println("Error: La marca no se ha agregado correctamente");
		}
	}

	@Override
	public void listarMarcas() {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		MarcaDAO marcaDao = new MarcaDAO(em);

		List<Marca> listaMarcas = marcaDao.findAll();
		System.out.println("Listado de marcas");
		if (listaMarcas.isEmpty()) {
			System.out.println("Lista vacía");
		} else {
			listaMarcas.forEach((marca) -> System.out.println(marca.toString()));
		}
	}

	@Override
	public void buscarPorNombre(String nombreMarca) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		MarcaDAO marcaDao = new MarcaDAO(em);

		Marca marca = new Marca();
		marca = marcaDao.findByNombre(nombreMarca);
		if (marca.getId() != 0) {
			System.out.println(marca.toString());
		} else {
			System.out.println("No se ha encontrado ninguna marca");
		}
	}

	@Override
	public void buscarPorId(int id) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		MarcaDAO marcaDao = new MarcaDAO(em);

		Marca marca = new Marca();
		marca = marcaDao.findById(id);
		if (marca.getId() != 0) {
			System.out.println(marca.toString());
		} else {
			System.out.println("No se ha encontrado ninguna marca");
		}
	}

	@Override
	public void eliminarPorId(int id) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		MarcaDAO marcaDao = new MarcaDAO(em);

		Marca marca = new Marca();
		marca = marcaDao.findById(id);
		if (marcaDao.delete(marca)) {
			System.out.println("La marca se ha eliminado correctamente");
		} else {
			System.out.println("Error: La marca no se ha eliminado correctamente");
		}
	}

}
