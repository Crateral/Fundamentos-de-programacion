package com.co.nttdata.ecommerce.interfaces;

import com.co.nttdata.ecommerce.modelos.TipoIdentificacion;

public interface IGestionTipoIdentificacion {
	
	public void listarTiposIdentificacion();
	public void crearTipoIdentificacion(TipoIdentificacion tipoIdentificacion);
	public void buscarPorNombre(String nombreTipo);
	public void buscarPorId(int id);
	public void eliminarPorId(int id);

}
