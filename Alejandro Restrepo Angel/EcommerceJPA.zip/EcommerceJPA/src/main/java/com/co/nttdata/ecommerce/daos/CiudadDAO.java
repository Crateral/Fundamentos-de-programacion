package com.co.nttdata.ecommerce.daos;

import java.util.List;

import javax.persistence.EntityManager;

import com.co.nttdata.ecommerce.modelos.Ciudad;

public class CiudadDAO {

	private EntityManager entityManager;

	public CiudadDAO(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public List<Ciudad> findAll() {
		entityManager.getTransaction().begin();
		javax.persistence.Query ciudades = entityManager.createQuery("Select * From Ciudad");
		entityManager.getTransaction().commit();
		return ciudades.getResultList();
	}

	public Boolean create(Ciudad ciudad) {
		try {
			entityManager.getTransaction().begin();
			entityManager.persist(ciudad);
			entityManager.getTransaction().commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
			return false;
		}
	}

	public Ciudad findById(int id) {
		return entityManager.find(Ciudad.class, id);
	}
	
	public Ciudad findByNombre(String ciudad) {
		return entityManager.find(Ciudad.class, ciudad);
	}

	public void update(Ciudad ciudad) {
		entityManager.getTransaction().begin();
		entityManager.merge(ciudad);
		entityManager.getTransaction().commit();
	}

	public Boolean delete(Ciudad ciudad) {
		try {
			entityManager.getTransaction().begin();
			entityManager.remove(ciudad);
			entityManager.getTransaction().commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
			return false;
		}
	}

}
