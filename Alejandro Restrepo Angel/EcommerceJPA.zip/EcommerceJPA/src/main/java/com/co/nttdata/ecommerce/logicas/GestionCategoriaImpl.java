package com.co.nttdata.ecommerce.logicas;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.co.nttdata.ecommerce.daos.CategoriaDAO;
import com.co.nttdata.ecommerce.interfaces.IGestionCategoria;
import com.co.nttdata.ecommerce.modelos.Categoria;

public class GestionCategoriaImpl implements IGestionCategoria{
	
	public static final String PERSISTENCE_UNIT_NAME="EcommerceJPA";
	private static EntityManagerFactory factory;
	
	@Override
	public void crearCategoria(Categoria categoria) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		
		CategoriaDAO categoriaDao = new CategoriaDAO(em);
		if(categoriaDao.create(categoria)) {
			System.out.println("La categoría se ha agregado correctamente");
		}
		else{
			System.out.println("Error: la categoría no se ha agregado correctamente");
		}
	}

	@Override
	public void listarCategorias() {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		
		CategoriaDAO categoriaDao = new CategoriaDAO(em);
		
		List<Categoria> listaCategorias = categoriaDao.findAll();
		System.out.println("Listado de categorías");
		if(listaCategorias.isEmpty()) {
			System.out.println("Lista vacía");
		}
		else {
			listaCategorias.forEach((categoria) ->System.out.println(categoria.toString()));	
		}
	}

	@Override
	public void buscarPorNombre(String nombreCategoria) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		
		CategoriaDAO categoriaDao = new CategoriaDAO(em);
		
		Categoria categoria = new Categoria();
		categoria = categoriaDao.findByNombre(nombreCategoria); 
		if(categoria.getId()!=0) {
			System.out.println(categoria.toString());
		}
		else {
			System.out.println("No se ha encontrado ninguna categoría");
		}		
	}

	@Override
	public void buscarPorId(int id) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		
		CategoriaDAO categoriaDao = new CategoriaDAO(em);
		
		Categoria categoria = new Categoria();
		categoria = categoriaDao.findById(id); 
		if(categoria.getId()!=0) {
			System.out.println(categoria.toString());
		}
		else {
			System.out.println("No se ha encontrado ninguna categoría");
		}	
	}

	@Override
	public void eliminarPorId(int id) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		
		CategoriaDAO categoriaDao = new CategoriaDAO(em);
		
		Categoria categoria = new Categoria();
		categoria = categoriaDao.findById(id); 
		if(categoriaDao.delete(categoria)) {
			System.out.println("La categoría se ha eliminado correctamente");
		}
		else{
			System.out.println("Error: la categoría no se ha eliminado correctamente");
		}	
	}

}
