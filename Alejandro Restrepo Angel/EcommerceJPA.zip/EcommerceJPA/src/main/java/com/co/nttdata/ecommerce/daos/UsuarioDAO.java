package com.co.nttdata.ecommerce.daos;

import java.util.List;

import javax.persistence.EntityManager;

import com.co.nttdata.ecommerce.modelos.Usuario;

public class UsuarioDAO {

	private EntityManager entityManager;

	public UsuarioDAO(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public List<Usuario> findAll() {
		entityManager.getTransaction().begin();
		javax.persistence.Query usuarios = entityManager.createQuery("Select * From Usuario");
		entityManager.getTransaction().commit();
		return usuarios.getResultList();
	}

	public Boolean create(Usuario usuario) {
		try {
			entityManager.getTransaction().begin();
			entityManager.persist(usuario);
			entityManager.getTransaction().commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
			return false;
		}
	}

	public Usuario findById(int id) {
		return entityManager.find(Usuario.class, id);
	}

	public Usuario findByNombre(String usuario) {
		return entityManager.find(Usuario.class, usuario);
	}

	public void update(Usuario usuario) {
		entityManager.getTransaction().begin();
		entityManager.merge(usuario);
		entityManager.getTransaction().commit();
	}

	public Boolean delete(Usuario usuario) {
		try {
			entityManager.getTransaction().begin();
			entityManager.remove(usuario);
			entityManager.getTransaction().commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
			return false;
		}
	}

}
