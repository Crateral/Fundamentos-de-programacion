package com.co.nttdata.ecommerce.logicas;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.co.nttdata.ecommerce.daos.TipoIdentificacionDAO;
import com.co.nttdata.ecommerce.interfaces.IGestionTipoIdentificacion;
import com.co.nttdata.ecommerce.modelos.TipoIdentificacion;

public class GestionTipoIdentificacionImpl implements IGestionTipoIdentificacion{
	
	public static final String PERSISTENCE_UNIT_NAME="EcommerceJPA";
	private static EntityManagerFactory factory;
	
	@Override
	public void crearTipoIdentificacion(TipoIdentificacion tipoIdentificacion) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		TipoIdentificacionDAO tipoIdentificacionDao = new TipoIdentificacionDAO(em);
		
		if(tipoIdentificacionDao.create(tipoIdentificacion)) {
			System.out.println("El tipo de identificación se ha agregado correctamente");
		}
		else{
			System.out.println("Error: El tipo de identificación no se ha agregado correctamente");
		}
	}

	@Override
	public void listarTiposIdentificacion() {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		TipoIdentificacionDAO tipoIdentificacionDao = new TipoIdentificacionDAO(em);
		
		List<TipoIdentificacion> listaTiposIdentificacion = tipoIdentificacionDao.findAll();
		System.out.println("Listado de tipos de identificación");
		if(listaTiposIdentificacion.isEmpty()) {
			System.out.println("Lista vacía");
		}
		else {
			listaTiposIdentificacion.forEach((tipoIdentificacion) ->System.out.println(tipoIdentificacion.toString()));	
		}
	}

	@Override
	public void buscarPorNombre(String nombreTipo) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		TipoIdentificacionDAO tipoIdentificacionDao = new TipoIdentificacionDAO(em);
		
		TipoIdentificacion tipoIdentificacion = new TipoIdentificacion();
		tipoIdentificacion = tipoIdentificacionDao.findByNombre(nombreTipo); 
		if(tipoIdentificacion.getId()!=0) {
			System.out.println(tipoIdentificacion.toString());
		}
		else {
			System.out.println("No se ha encontrado ningún tipo de identificación");
		}		
	}

	@Override
	public void buscarPorId(int id) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		TipoIdentificacionDAO tipoIdentificacionDao = new TipoIdentificacionDAO(em);
		
		TipoIdentificacion tipoIdentificacion = new TipoIdentificacion();
		tipoIdentificacion = tipoIdentificacionDao.findById(id); 
		if(tipoIdentificacion.getId()!=0) {
			System.out.println(tipoIdentificacion.toString());
		}
		else {
			System.out.println("No se ha encontrado ningún tipo de identificación");
		}	
	}

	@Override
	public void eliminarPorId(int id) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		TipoIdentificacionDAO tipoIdentificacionDao = new TipoIdentificacionDAO(em);
		
		TipoIdentificacion tipoIdentificacion = new TipoIdentificacion();
		tipoIdentificacion = tipoIdentificacionDao.findById(id); 
		if(tipoIdentificacionDao.delete(tipoIdentificacion)) {
			System.out.println("El tipo de identificación se ha eliminado correctamente");
		}
		else{
			System.out.println("Error: El tipo de identificación no se ha eliminado correctamente");
		}	
	}

}
