package com.co.nttdata.ecommerce.logicas;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.co.nttdata.ecommerce.daos.ClienteDAO;
import com.co.nttdata.ecommerce.interfaces.IGestionCliente;
import com.co.nttdata.ecommerce.modelos.Cliente;

public class GestionClienteImpl implements IGestionCliente{
	
	
	public static final String PERSISTENCE_UNIT_NAME="EcommerceJPA";
	private static EntityManagerFactory factory;

	@Override
	public void crearCliente(Cliente cliente) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		ClienteDAO clienteDao = new ClienteDAO(em);
		
		if(clienteDao.create(cliente)) {
			System.out.println("El cliente se ha agregado correctamente");
		}
		else{
			System.out.println("Error: El cliente no se ha agregado correctamente");
		}
	}

	@Override
	public void listarClientes() {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();	
		ClienteDAO clienteDao = new ClienteDAO(em);
		
		List<Cliente> listaClientes = clienteDao.findAll();
		System.out.println("Listado de Clientes");
		if(listaClientes.isEmpty()) {
			System.out.println("Lista vacía");
		}
		else {
			listaClientes.forEach((cliente) ->System.out.println(cliente.toString()));	
		}
	}

	@Override
	public void buscarPorCorreo(String correo) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		ClienteDAO clienteDao = new ClienteDAO(em);
		
		Cliente cliente = new Cliente();
		cliente = clienteDao.findByCorreo(correo); 
		if(cliente.getId()!=0) {
			System.out.println(cliente.toString());
		}
		else {
			System.out.println("No se ha encontrado ningún cliente");
		}		
	}

	@Override
	public void buscarPorId(int id) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		ClienteDAO clienteDao = new ClienteDAO(em);
		
		Cliente cliente = new Cliente();
		cliente = clienteDao.findById(id); 
		if(cliente.getId()!=0) {
			System.out.println(cliente.toString());
		}
		else {
			System.out.println("No se ha encontrado ningún cliente");
		}	
	}

	@Override
	public void eliminarPorId(int id) {
		factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em = factory.createEntityManager();
		ClienteDAO clienteDao = new ClienteDAO(em);
		
		Cliente cliente = new Cliente();
		cliente = clienteDao.findById(id); 
		if(clienteDao.delete(cliente)) {
			System.out.println("El cliente se ha eliminado correctamente");
		}
		else{
			System.out.println("Error: El cliente no se ha eliminado correctamente");
		}	
	}

}
