package com.co.nttdata.ecommerce.daos;

import java.util.List;

import javax.persistence.EntityManager;

import com.co.nttdata.ecommerce.modelos.Empresa;

public class EmpresaDAO {

	private EntityManager entityManager;

	public EmpresaDAO(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	
	public List<Empresa> findAll() {
		entityManager.getTransaction().begin();
		javax.persistence.Query empresas = entityManager.createQuery("Select * From Empresa");
		entityManager.getTransaction().commit();
		return empresas.getResultList();
	}

	public Boolean create(Empresa empresa) {
		try {
			entityManager.getTransaction().begin();
			entityManager.persist(empresa);
			entityManager.getTransaction().commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
			return false;
		}
	}

	public Empresa findById(int id) {
		return entityManager.find(Empresa.class, id);
	}
	
	public Empresa findByNit(String nit) {
		return entityManager.find(Empresa.class, nit);
	}

	public void update(Empresa empresa) {
		entityManager.getTransaction().begin();
		entityManager.merge(empresa);
		entityManager.getTransaction().commit();
	}

	public Boolean delete(Empresa empresa) {
		try {
			entityManager.getTransaction().begin();
			entityManager.remove(empresa);
			entityManager.getTransaction().commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
			return false;
		}
	}

}
