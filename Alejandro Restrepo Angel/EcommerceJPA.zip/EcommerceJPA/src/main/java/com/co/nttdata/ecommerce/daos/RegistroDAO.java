package com.co.nttdata.ecommerce.daos;

import java.util.List;

import javax.persistence.EntityManager;

import com.co.nttdata.ecommerce.modelos.Registro;

public class RegistroDAO {

	private EntityManager entityManager;

	public RegistroDAO(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public List<Registro> findAll() {
		entityManager.getTransaction().begin();
		javax.persistence.Query registros = entityManager.createQuery("Select * From Registro");
		entityManager.getTransaction().commit();
		return registros.getResultList();
	}

	public Boolean create(Registro registro) {
		try {
			entityManager.getTransaction().begin();
			entityManager.persist(registro);
			entityManager.getTransaction().commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
			return false;
		}
	}

	public Registro findById(int id) {
		return entityManager.find(Registro.class, id);
	}

	public void update(Registro registro) {
		entityManager.getTransaction().begin();
		entityManager.merge(registro);
		entityManager.getTransaction().commit();
	}

	public Boolean delete(Registro registro) {
		try {
			entityManager.getTransaction().begin();
			entityManager.remove(registro);
			entityManager.getTransaction().commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
			return false;
		}
	}

}
