package com.co.nttdata.ecommerce.daos;

import java.util.List;

import javax.persistence.EntityManager;

import com.co.nttdata.ecommerce.modelos.Categoria;

public class CategoriaDAO {

	private EntityManager entityManager;

	public CategoriaDAO(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public List<Categoria> findAll() {
		entityManager.getTransaction().begin();
		javax.persistence.Query categorias = entityManager.createQuery("Select * From Categoria");
		entityManager.getTransaction().commit();
		return categorias.getResultList();
	}

	public Boolean create(Categoria categoria) {
		try {
			entityManager.getTransaction().begin();
			entityManager.persist(categoria);
			entityManager.getTransaction().commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
			return false;
		}
	}

	public Categoria findById(int id) {
		return entityManager.find(Categoria.class, id);
	}
	
	public Categoria findByNombre(String categoria) {
		return entityManager.find(Categoria.class, categoria);
	}

	public void update(Categoria categoria) {
		entityManager.getTransaction().begin();
		entityManager.merge(categoria);
		entityManager.getTransaction().commit();
	}

	public Boolean delete(Categoria categoria) {
		try {
			entityManager.getTransaction().begin();
			entityManager.remove(categoria);
			entityManager.getTransaction().commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
			return false;
		}
	}

}
