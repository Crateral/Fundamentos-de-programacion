package com.co.nttdata.ecommerce.daos;

import java.util.List;

import javax.persistence.EntityManager;

import com.co.nttdata.ecommerce.modelos.Cliente;

public class ClienteDAO {

	private EntityManager entityManager;

	public ClienteDAO(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public List<Cliente> findAll() {
		entityManager.getTransaction().begin();
		javax.persistence.Query clientes = entityManager.createQuery("Select * From Cliente");
		entityManager.getTransaction().commit();
		return clientes.getResultList();
	}
	
	public Boolean create(Cliente cliente) {
		try {
			entityManager.getTransaction().begin();
			entityManager.persist(cliente);
			entityManager.getTransaction().commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
			return false;
		}
	}

	public Cliente findById(int id) {
		return entityManager.find(Cliente.class, id);
	}

	public Cliente findByCorreo(String correo) {
		return entityManager.find(Cliente.class, correo);
	}

	public void update(Cliente cliente) {
		entityManager.getTransaction().begin();
		entityManager.merge(cliente);
		entityManager.getTransaction().commit();
	}

	public Boolean delete(Cliente cliente) {
		try {
			entityManager.getTransaction().begin();
			entityManager.remove(cliente);
			entityManager.getTransaction().commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
			return false;
		}
	}

}
