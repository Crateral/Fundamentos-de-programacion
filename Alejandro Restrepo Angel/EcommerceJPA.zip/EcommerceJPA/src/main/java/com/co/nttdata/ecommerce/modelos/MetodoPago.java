package com.co.nttdata.ecommerce.modelos;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the tbl_metodo_pagos database table.
 * 
 */
@Entity
@Table(name="tbl_metodo_pagos", schema="sc_ecommerce")
@NamedQuery(name="MetodoPago.findAll", query="SELECT m FROM MetodoPago m")
public class MetodoPago implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;

	private String descripcion;

	@Column(name="metodo_pago")
	private String metodoPago;

	//bi-directional many-to-one association to Cliente
	@OneToMany(mappedBy="metodoPago")
	private List<Cliente> clientes;

	public MetodoPago() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getMetodoPago() {
		return this.metodoPago;
	}

	public void setMetodoPago(String metodoPago) {
		this.metodoPago = metodoPago;
	}

	public List<Cliente> getClientes() {
		return this.clientes;
	}

	public void setClientes(List<Cliente> clientes) {
		this.clientes = clientes;
	}

	public Cliente addCliente(Cliente cliente) {
		getClientes().add(cliente);
		cliente.setMetodoPago(this);

		return cliente;
	}

	public Cliente removeCliente(Cliente cliente) {
		getClientes().remove(cliente);
		cliente.setMetodoPago(null);

		return cliente;
	}

	@Override
	public String toString() {
		return "MetodoPago [id=" + id + ", descripcion=" + descripcion + ", metodoPago=" + metodoPago + "]";
	}
	
}