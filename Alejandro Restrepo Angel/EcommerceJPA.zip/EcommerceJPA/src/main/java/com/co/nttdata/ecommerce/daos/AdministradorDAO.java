package com.co.nttdata.ecommerce.daos;

import java.util.List;

import javax.persistence.EntityManager;

import com.co.nttdata.ecommerce.modelos.Administrador;

public class AdministradorDAO {

	private EntityManager entityManager;

	public AdministradorDAO(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public List<Administrador> findAll() {
		entityManager.getTransaction().begin();
		javax.persistence.Query administradores = entityManager.createQuery("Select * From Administrador");
		entityManager.getTransaction().commit();
		return administradores.getResultList();
	}

	public Boolean create(Administrador administrador) {
		try {
			entityManager.getTransaction().begin();
			entityManager.persist(administrador);
			entityManager.getTransaction().commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
			return false;
		}
	}

	public Administrador findById(int id) {
		return entityManager.find(Administrador.class, id);
	}

	public Administrador findByCorreo(String correo) {
		return entityManager.find(Administrador.class, correo);
	}
	
	public void update(Administrador administrador) {
		try {
			entityManager.getTransaction().begin();
			entityManager.merge(administrador);
			entityManager.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
		}
	}

	public Boolean delete(Administrador administrador) {
		try {
			entityManager.getTransaction().begin();
			entityManager.remove(administrador);
			entityManager.getTransaction().commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
			return false;
		}
	}

}
