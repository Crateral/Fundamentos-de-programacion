package com.co.nttdata.ecommerce.daos;

import java.util.List;

import javax.persistence.EntityManager;

import com.co.nttdata.ecommerce.modelos.Factura;

public class FacturaDAO {

	private EntityManager entityManager;

	public FacturaDAO(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public List<Factura> findAll() {
		entityManager.getTransaction().begin();
		javax.persistence.Query facturas = entityManager.createQuery("Select * From Factura");
		entityManager.getTransaction().commit();
		return facturas.getResultList();
	}

	public Boolean create(Factura factura) {
		try {
			entityManager.getTransaction().begin();
			entityManager.persist(factura);
			entityManager.getTransaction().commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
			return false;
		}
	}

	public Factura findById(int id) {
		return entityManager.find(Factura.class, id);
	}
	
	public void update(Factura factura) {
		entityManager.getTransaction().begin();
		entityManager.merge(factura);
		entityManager.getTransaction().commit();
	}

	public Boolean delete(Factura factura) {
		try {
			entityManager.getTransaction().begin();
			entityManager.remove(factura);
			entityManager.getTransaction().commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
			return false;
		}
	}

}
