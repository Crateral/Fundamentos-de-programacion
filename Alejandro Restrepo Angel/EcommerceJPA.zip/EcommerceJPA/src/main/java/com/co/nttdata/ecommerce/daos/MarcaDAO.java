package com.co.nttdata.ecommerce.daos;

import java.util.List;

import javax.persistence.EntityManager;

import com.co.nttdata.ecommerce.modelos.Marca;

public class MarcaDAO {

	private EntityManager entityManager;

	public MarcaDAO(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	
	public List<Marca> findAll() {
		entityManager.getTransaction().begin();
		javax.persistence.Query marcas = entityManager.createQuery("Select * From Marca");
		entityManager.getTransaction().commit();
		return marcas.getResultList();
	}

	public Boolean create(Marca marca) {
		try {
			entityManager.getTransaction().begin();
			entityManager.persist(marca);
			entityManager.getTransaction().commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
			return false;
		}
	}

	public Marca findById(int id) {
		return entityManager.find(Marca.class, id);
	}
	
	public Marca findByNombre(String marca) {
		return entityManager.find(Marca.class, marca);
	}

	public void update(Marca marca) {
		entityManager.getTransaction().begin();
		entityManager.merge(marca);
		entityManager.getTransaction().commit();
	}

	public Boolean delete(Marca marca) {
		try {
			entityManager.getTransaction().begin();
			entityManager.remove(marca);
			entityManager.getTransaction().commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
			return false;
		}
	}

}
