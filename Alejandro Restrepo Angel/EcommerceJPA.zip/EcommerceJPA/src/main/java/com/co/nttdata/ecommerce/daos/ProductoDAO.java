package com.co.nttdata.ecommerce.daos;

import java.util.List;

import javax.persistence.EntityManager;

import com.co.nttdata.ecommerce.modelos.Producto;

public class ProductoDAO {

	private EntityManager entityManager;

	public ProductoDAO(EntityManager entityManager) {
		this.entityManager = entityManager;
	}
	
	public List<Producto> findAll() {
		entityManager.getTransaction().begin();
		javax.persistence.Query productos = entityManager.createQuery("Select * From Producto");
		entityManager.getTransaction().commit();
		return productos.getResultList();
	}

	public Boolean create(Producto producto) {
		try {
			entityManager.getTransaction().begin();
			entityManager.persist(producto);
			entityManager.getTransaction().commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
			return false;
		}
	}

	public Producto findById(int id) {
		return entityManager.find(Producto.class, id);
	}
	
	public Producto findByNombre(String producto) {
		return entityManager.find(Producto.class, producto);
	}

	public void update(Producto producto) {
		entityManager.getTransaction().begin();
		entityManager.merge(producto);
		entityManager.getTransaction().commit();
	}

	public Boolean delete(Producto producto) {
		try {
			entityManager.getTransaction().begin();
			entityManager.remove(producto);
			entityManager.getTransaction().commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			entityManager.getTransaction().rollback();
			return false;
		}
	}

}
