package com.co.colegio.app;

import java.util.ArrayList;
import java.util.List;

import com.co.colegio.app.interfaces.*;
import com.co.colegio.app.logica.*;
import com.co.colegio.app.modelos.*;
import com.co.colegio.app.utilitarios.*;

public class Main {

	public static void main(String[] args) { 
		
		//Instanciar objetos logica de negocio
		IArchivoProfesor archivoProfesor = new ArchivoProfesorImpl();
		IArchivoAlumno archivoAlumno = new ArchivoAlumnoImpl();
		IArchivoNota archivoNota = new ArchivoNotaImpl();
		IArchivoMateria archivoMateria = new ArchivoMateriaImpl();
		IGestionNota gestionNota = new GestionNotaImpl();
		
		//Instanciar objetos VO - Beans
		Persona profesor1 = new Profesor(1,TipoIdentificacion.CE,"10002223001","John","Doe","john@mail.com","2223301","Parque","Sabaneta");
		Persona profesor2 = new Profesor(2,TipoIdentificacion.CC,"10002223002","Juan","Doe","juan@mail.com","2223302","Merced","Envigado");
		Persona profesor3 = new Profesor(3,TipoIdentificacion.CC,"10002223003","Jose","Doe","jose@mail.com","2223303","Laureles","Medellin");
		
		//Instanciar lista de profesores
		List<Profesor> listaProfesores = new ArrayList<>();
		
		//Crear Lista del archivo
		listaProfesores.add((Profesor) profesor1);
		listaProfesores.add((Profesor) profesor2);
		listaProfesores.add((Profesor) profesor3);

		//Crear la lista de profesores en un Archivo
		String profesoresArchivo = "Profesores.txt";
		archivoProfesor.guardarProfesores(profesoresArchivo, listaProfesores);
		
		//Crear una lista con los profesores de un archivo
		List<Profesor> profesores = new ArrayList<>();
		profesores = archivoProfesor.leerProfesores(profesoresArchivo);

		//Instanciar objetos VO - Beans
		Persona estudiante1 = new Alumno(1, TipoIdentificacion.CE,"10002223001","Nombre1","Apellido1","correo1@mail.com","2224401","SantaMaria1","Rionegro",true);
		Persona estudiante2 = new Alumno(2, TipoIdentificacion.CC,"10002223002","Nombre2","Apellido2","correo2@mail.com","2224402","SantaMaria2","Medellin",false);
		Persona estudiante3 = new Alumno(3, TipoIdentificacion.CC,"10002223003","Nombre3","Apellido3","correo3@mail.com","2224403","SantaMaria3","Bello",true);
		Persona estudiante4 = new Alumno(4, TipoIdentificacion.CC,"10002223004","Nombre4","Apellido4","correo4@mail.com","2224404","SantaMaria4","Rionegro",true);
		Persona estudiante5 = new Alumno(5, TipoIdentificacion.CC,"10002223005","Nombre5","Apellido5","correo5@mail.com","2224405","SantaMaria5","Medellin",true);
		Persona estudiante6 = new Alumno(6, TipoIdentificacion.CC,"10002223006","Nombre6","Apellido6","correo6@mail.com","2224406","SantaMaria6","Medellin",false);
		Persona estudiante7 = new Alumno(7, TipoIdentificacion.CE,"10002223007","Nombre7","Apellido7","correo7@mail.com","2224407","SantaMaria7","Rionegro",true);
		Persona estudiante8 = new Alumno(8, TipoIdentificacion.CE,"10002223008","Nombre8","Apellido8","correo8@mail.com","2224408","SantaMaria8","Bello",true);
		Persona estudiante9 = new Alumno(9, TipoIdentificacion.CC,"10002223009","Nombre9","Apellido9","correo9@mail.com","2224409","SantaMaria9","Medellin",false);
		Persona estudiante10 = new Alumno(10, TipoIdentificacion.TI,"10002223010","Nombre10","Apellido10","correo10@mail.com","2224410","SantaMaria10","Bello",true);
		Persona estudiante11 = new Alumno(11, TipoIdentificacion.TI,"10002223011","Nombre11","Apellido11","correo11@mail.com","2224411","SantaMaria11","Rionegro",true);
		Persona estudiante12 = new Alumno(12, TipoIdentificacion.CC,"10002223012","Nombre12","Apellido12","correo12@mail.com","2224412","SantaMaria12","Envigado",false);
		Persona estudiante13 = new Alumno(13, TipoIdentificacion.CC,"10002223013","Nombre13","Apellido13","correo13@mail.com","2224413","SantaMaria13","Rionegro",true);
		Persona estudiante14 = new Alumno(14, TipoIdentificacion.TI,"10002223014","Nombre14","Apellido14","correo14@mail.com","2224414","SantaMaria14","Envigado",true);
		Persona estudiante15 = new Alumno(15, TipoIdentificacion.CE,"10002223015","Nombre15","Apellido15","correo15@mail.com","2224415","SantaMaria15","Envigado",true);
		
		//Instanciar lista de Alumnos
		List<Alumno> listaAlumnos = new ArrayList<>();
		
		//Crear Lista del archivo
		listaAlumnos.add((Alumno) estudiante1);
		listaAlumnos.add((Alumno) estudiante2);
		listaAlumnos.add((Alumno) estudiante3);
		listaAlumnos.add((Alumno) estudiante4);
		listaAlumnos.add((Alumno) estudiante5);
		listaAlumnos.add((Alumno) estudiante6);
		listaAlumnos.add((Alumno) estudiante7);
		listaAlumnos.add((Alumno) estudiante8);
		listaAlumnos.add((Alumno) estudiante9);
		listaAlumnos.add((Alumno) estudiante10);
		listaAlumnos.add((Alumno) estudiante11);
		listaAlumnos.add((Alumno) estudiante12);
		listaAlumnos.add((Alumno) estudiante13);
		listaAlumnos.add((Alumno) estudiante14);
		listaAlumnos.add((Alumno) estudiante15);

		//Crear la lista de alumnos en un Archivo
		String alumnosArchivo = "Alumnos.txt";
		archivoAlumno.guardarAlumnos(alumnosArchivo, listaAlumnos);
		
		//Crear una lista con los alumnos de un archivo
		List<Alumno> alumnos = new ArrayList<>();
		alumnos = archivoAlumno.leerAlumnos(alumnosArchivo);
		
		//Instanciar objetos VO - Beans
		Materia materia1 = new Materia(1, "Matemáticas", (Profesor) profesor1, 9, "B-101");
		Materia materia2 = new Materia(2, "Historia", (Profesor) profesor2, 10, "A-201");
		Materia materia3 = new Materia(3, "Informática", (Profesor) profesor3, 8,"B-201");
		
		//Instanciar lista de materias
		List<Materia> listaMaterias = new ArrayList<>();
		
		//Crear Lista del archivo
		listaMaterias.add(materia1);
		listaMaterias.add(materia2);
		listaMaterias.add(materia3);
		
		//Crear la lista de materias en un Archivo
		String materiasArchivo = "Materias.txt";
		archivoMateria.guardarMaterias(materiasArchivo, listaMaterias);
		
		//Crear una lista con las materias de un archivo
		List<Materia> materias = new ArrayList<>();
		materias = archivoMateria.leerMaterias(materiasArchivo);
			
		//Instanciar objetos VO - Beans
		Nota nota1 = new Nota(1, (Alumno) estudiante1, materia1, 3.5, "Parcial 1 Matemáticas");
		Nota nota2 = new Nota(2, (Alumno) estudiante1, materia1, 4.2, "Parcial 2 Matemáticas");
		Nota nota3 = new Nota(3, (Alumno) estudiante1, materia1, 3.1, "Parcial 3 Matemáticas");
		Nota nota4 = new Nota(4, (Alumno) estudiante2, materia1, 3.0, "Parcial 1 Matemáticas");
		Nota nota5 = new Nota(5, (Alumno) estudiante2, materia1, 2.5, "Parcial 2 Matemáticas");
		Nota nota6 = new Nota(6, (Alumno) estudiante2, materia1, 3.8, "Parcial 3 Matemáticas");
		Nota nota7 = new Nota(7, (Alumno) estudiante3, materia1, 1.9, "Parcial 1 Matemáticas");
		Nota nota8 = new Nota(8, (Alumno) estudiante3, materia1, 4.2,  "Parcial 2 Matemáticas");
		Nota nota9 = new Nota(9, (Alumno) estudiante3, materia1, 4.1, "Parcial 3 Matemáticas");
		Nota nota10 = new Nota(10, (Alumno) estudiante4, materia1, 2.5, "Parcial 1 Matemáticas");
		Nota nota11 = new Nota(11, (Alumno) estudiante4, materia1, 3.2, "Parcial 2 Matemáticas");
		Nota nota12 = new Nota(12, (Alumno) estudiante4, materia1, 3.1, "Parcial 3 Matemáticas");
		Nota nota13 = new Nota(13, (Alumno) estudiante5, materia1, 4.5, "Parcial 1 Matemáticas");
		Nota nota14 = new Nota(14, (Alumno) estudiante5, materia1, 3.2, "Parcial 2 Matemáticas");
		Nota nota15 = new Nota(15, (Alumno) estudiante5, materia1, 4.1, "Parcial 3 Matemáticas");
		Nota nota16 = new Nota(16, (Alumno) estudiante6, materia2, 3.5, "Parcial 1 Historia");
		Nota nota17 = new Nota(17, (Alumno) estudiante6, materia2, 4.2, "Parcial 2 Historia");
		Nota nota18 = new Nota(18, (Alumno) estudiante6, materia2, 3.1, "Parcial 3 Historia");
		Nota nota19 = new Nota(19, (Alumno) estudiante7, materia2, 3.0, "Parcial 1 Historia");
		Nota nota20 = new Nota(20, (Alumno) estudiante7, materia2, 2.5, "Parcial 2 Historia");
		Nota nota21 = new Nota(21, (Alumno) estudiante7, materia2, 3.8, "Parcial 3 Historia");
		Nota nota22 = new Nota(22, (Alumno) estudiante8, materia2, 1.9, "Parcial 1 Historia");
		Nota nota23 = new Nota(23, (Alumno) estudiante8, materia2, 4.2, "Parcial 2 Historia");
		Nota nota24 = new Nota(24, (Alumno) estudiante8, materia2, 4.1, "Parcial 3 Historia");
		Nota nota25 = new Nota(25, (Alumno) estudiante9, materia2, 2.5, "Parcial 1 Historia");
		Nota nota26 = new Nota(26, (Alumno) estudiante9, materia2, 3.2, "Parcial 2 Historia");
		Nota nota27 = new Nota(27, (Alumno) estudiante9, materia2, 3.1, "Parcial 3 Historia");
		Nota nota28 = new Nota(28, (Alumno) estudiante10, materia2, 4.5, "Parcial 1 Historia");
		Nota nota29 = new Nota(29, (Alumno) estudiante10, materia2, 3.2, "Parcial 2 Historia");
		Nota nota30 = new Nota(30, (Alumno) estudiante10, materia2, 4.1, "Parcial 3 Historia");
		Nota nota31 = new Nota(31, (Alumno) estudiante11, materia3, 3.5, "Parcial 1 Informática");
		Nota nota32 = new Nota(32, (Alumno) estudiante11, materia3, 4.2, "Parcial 2 Informática");
		Nota nota33 = new Nota(33, (Alumno) estudiante11, materia3, 3.1, "Parcial 3 Informática");
		Nota nota34 = new Nota(34, (Alumno) estudiante12, materia3, 3.0, "Parcial 1 Informática");
		Nota nota35 = new Nota(35, (Alumno) estudiante12, materia3, 2.5, "Parcial 2 Informática");
		Nota nota36 = new Nota(36, (Alumno) estudiante12, materia3, 3.8, "Parcial 3 Informática");
		Nota nota37 = new Nota(37, (Alumno) estudiante13, materia3, 1.9, "Parcial 1 Informática");
		Nota nota38 = new Nota(38, (Alumno) estudiante13, materia3, 4.2, "Parcial 2 Informática");
		Nota nota39 = new Nota(39, (Alumno) estudiante13, materia3, 4.1, "Parcial 3 Informática");
		Nota nota40 = new Nota(40, (Alumno) estudiante14, materia3, 2.5, "Parcial 1 Informática");
		Nota nota41 = new Nota(41, (Alumno) estudiante14, materia3, 3.2, "Parcial 2 Informática");
		Nota nota42 = new Nota(42, (Alumno) estudiante14, materia3, 3.1, "Parcial 3 Informática");
		Nota nota43 = new Nota(43, (Alumno) estudiante15, materia3, 4.5, "Parcial 1 Informática");
		Nota nota44 = new Nota(44, (Alumno) estudiante15, materia3, 3.2, "Parcial 2 Informática");
		Nota nota45 = new Nota(45, (Alumno) estudiante15, materia3, 4.1, "Parcial 3 Informática");
		
		//Instanciar lista de notas
		List<Nota> listaNotas = new ArrayList<>();
		
		//Crear Lista del archivo
		listaNotas.add(nota1);
		listaNotas.add(nota2);
		listaNotas.add(nota3);
		listaNotas.add(nota4);
		listaNotas.add(nota5);
		listaNotas.add(nota6);
		listaNotas.add(nota7);
		listaNotas.add(nota8);
		listaNotas.add(nota9);
		listaNotas.add(nota10);
		listaNotas.add(nota11);
		listaNotas.add(nota12);
		listaNotas.add(nota13);
		listaNotas.add(nota14);
		listaNotas.add(nota15);
		listaNotas.add(nota16);
		listaNotas.add(nota17);
		listaNotas.add(nota18);
		listaNotas.add(nota19);
		listaNotas.add(nota20);
		listaNotas.add(nota21);
		listaNotas.add(nota22);
		listaNotas.add(nota23);
		listaNotas.add(nota24);
		listaNotas.add(nota25);
		listaNotas.add(nota26);
		listaNotas.add(nota27);
		listaNotas.add(nota28);
		listaNotas.add(nota29);
		listaNotas.add(nota30);
		listaNotas.add(nota31);
		listaNotas.add(nota32);
		listaNotas.add(nota33);
		listaNotas.add(nota34);
		listaNotas.add(nota35);
		listaNotas.add(nota36);
		listaNotas.add(nota37);
		listaNotas.add(nota38);
		listaNotas.add(nota39);
		listaNotas.add(nota40);
		listaNotas.add(nota41);
		listaNotas.add(nota42);
		listaNotas.add(nota43);
		listaNotas.add(nota44);
		listaNotas.add(nota45);
		
		//Crear la lista de notas en un Archivo
		String notasArchivo = "Notas.txt";
		archivoNota.guardarNotas(notasArchivo, listaNotas);
		
		//Crear una lista con las notas de un archivo
		List<Nota> notas = new ArrayList<>();
		notas = archivoNota.leerNotas(notasArchivo);
		
		System.out.println("\nPruebaNotas");
		notas.forEach((n) -> System.out.println(n.toString()));
		System.out.println("PruebaNotas");
	
		gestionNota.calcularNotas(alumnos, materias, notas);		
		gestionNota.modificarNota(notas, 44, 4.0, "Parcial 2 Informática revisión");
	
		List<Nota> notasAlumno = new ArrayList<>();
		notasAlumno = gestionNota.notasAlumno((Alumno) estudiante15, materia3, notas);
		gestionNota.calcularNota((Alumno) estudiante15, materia3, notasAlumno);
		
	}

}
