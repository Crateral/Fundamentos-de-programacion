package com.co.colegio.app.logica;

import java.util.List;

import com.co.colegio.app.interfaces.IGestionProfesor;
import com.co.colegio.app.modelos.Profesor;

public class GestionProfesorImpl implements IGestionProfesor{

	@Override
	public Profesor buscarProfesor(List<Profesor> profesores, int id) {
		for(Profesor profesor:profesores) {
			if(profesor.getId()==id) {
				return profesor;
			}
		}
		return null;
	}

}
