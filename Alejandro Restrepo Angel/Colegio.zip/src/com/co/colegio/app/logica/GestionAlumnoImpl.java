package com.co.colegio.app.logica;

import java.util.List;

import com.co.colegio.app.interfaces.IGestionAlumno;
import com.co.colegio.app.modelos.Alumno;

public class GestionAlumnoImpl implements IGestionAlumno{

	@Override
	public Alumno buscarAlumno(List<Alumno> alumnos, int id) {
		for(Alumno alumno:alumnos) {
			if(alumno.getId()==id) {
				return alumno;
			}
		}
		return null;
	}

}
