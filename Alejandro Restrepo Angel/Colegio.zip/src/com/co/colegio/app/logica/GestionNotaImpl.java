package com.co.colegio.app.logica;

import java.util.ArrayList;
import java.util.List;

import com.co.colegio.app.interfaces.IGestionNota;
import com.co.colegio.app.modelos.Nota;
import com.co.colegio.app.modelos.Alumno;
import com.co.colegio.app.modelos.Materia;

public class GestionNotaImpl implements IGestionNota{

	@Override
	public void calcularNotas(List<Alumno> alumnos,List<Materia> materias, List<Nota> notas) {
		List<Nota> notasAlumno = new ArrayList<>();
		for (Alumno alumno:alumnos) {
			for (Materia materia:materias) {
				notasAlumno = notasAlumno((Alumno) alumno, materia, notas);
				if(notasAlumno.isEmpty()) {
					continue;
				}
				calcularNota((Alumno) alumno, materia, notasAlumno);
			}
			System.out.println("----------------------------------------");
		}
	}
	
	@Override
	public void calcularNota(Alumno alumno, Materia materia, List<Nota> notasAlumno) {
		
		double suma = 0;
		int cantidad = notasAlumno.size();
		System.out.println("Reporte de Notas");		
		System.out.println(alumno.getNombre() + " " + alumno.getApellido() + " - " +  materia.getNombreMateria());
		
		for(Nota nota: notasAlumno)
		{
			System.out.println("Nota: " + nota.getNota() + " - Observacion: " + nota.getObservacion());
			suma = suma + nota.getNota();
		}
		System.out.println("Promedio: " + suma/cantidad);
		String mensaje=(suma/cantidad>=3.0) ? "El Alumno aprobó la materia" : "El Alumno no aprobó la materia";
		System.out.println(mensaje);
	}
	
	public List<Nota> notasAlumno(Alumno alumno, Materia materia, List<Nota> notas){
		List<Nota> notasAlumnoMateria = new ArrayList<>();
		for(Nota nota:notas) {
			if(alumno.getId() == nota.getAlumno().getId() && materia.getIdMateria() == nota.getMateria().getIdMateria()) {
				notasAlumnoMateria.add(nota);
			}
		}	
		return notasAlumnoMateria;
	}

	@Override
	public Nota modificarNota(List<Nota> notas, int idNota, Double nota, String observacion) {
		Nota notaModificar = buscarNota(notas, idNota);
		notaModificar.setNota(nota);
		notaModificar.setObservacion(observacion);
		return notaModificar;
	}

	@Override
	public Nota buscarNota(List<Nota> notas, int idNota) {
		for(Nota nota:notas) {
			if(nota.getIdNota()==idNota) {
				return nota;
			}
		}
		return null;
	}

}
