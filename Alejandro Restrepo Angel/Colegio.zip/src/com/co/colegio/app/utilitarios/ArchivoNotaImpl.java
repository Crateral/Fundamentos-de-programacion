package com.co.colegio.app.utilitarios;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

import com.co.colegio.app.interfaces.*;
import com.co.colegio.app.logica.*;
import com.co.colegio.app.modelos.*;


public class ArchivoNotaImpl implements IArchivoNota{
	
	public void guardarNotas(String nombreArchivo, List<Nota> notas) {	
		FileWriter archivo = null;				
		try {
			archivo = new FileWriter("./src/com/co/colegio/app/archivos/"+nombreArchivo, false);
			for (int i = 0; i < notas.size(); i++) {
				archivo.write(notas.get(i).getIdNota() + "," +
						notas.get(i).getAlumno().getId() + "," +
						notas.get(i).getMateria().getIdMateria() + "," +
						notas.get(i).getNota() + "," +
						notas.get(i).getObservacion() + "\n"
						);
			}	
			System.out.println("El archivo se ha escrito con exito");
			archivo.close();
		}
		catch(Exception e) {
			System.out.println("Error al escribir el archivo: " + e.getMessage());
		}
	}
	
	public List<Nota> leerNotas(String nombreArchivo) {
		File archivo = new File("./src/com/co/colegio/app/archivos/" + nombreArchivo);
		List<Nota> listaNotas = new ArrayList<>();		
		
		IArchivoAlumno archivoAlumno = new ArchivoAlumnoImpl();
		IGestionAlumno gestionAlumno = new GestionAlumnoImpl();
		String alumnosArchivo = "Alumnos.txt";
		List<Alumno> alumnos = new ArrayList<>();
		alumnos = archivoAlumno.leerAlumnos(alumnosArchivo);
		
		IArchivoMateria archivoMateria = new ArchivoMateriaImpl();
		IGestionMateria gestionMateria = new GestionMateriaImpl();
		String materiaArchivo = "Materias.txt";
		List<Materia> materias = new ArrayList<>();
		materias = archivoMateria.leerMaterias(materiaArchivo);
		
		try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
			String linea;
			while((linea = br.readLine())!= null) {
				String[] p = linea.split(",");
				listaNotas.add(new Nota((Integer.parseInt(p[0])),
				gestionAlumno.buscarAlumno(alumnos, Integer.parseInt(p[1])), 
				gestionMateria.buscarMateria(materias, Integer.parseInt(p[2])), 
				(Double.parseDouble(p[3])),
				(p[4])
				));
				
			}
			
		}catch(Exception e) {
			System.out.println("Error al leer el archivo: " + e.getMessage());
		}
		return listaNotas;
	}
	
}
