package com.co.colegio.app.utilitarios;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

import com.co.colegio.app.interfaces.IArchivoAlumno;
import com.co.colegio.app.modelos.*;


public class ArchivoAlumnoImpl implements IArchivoAlumno {
	
	public void guardarAlumnos(String nombreArchivo, List<Alumno> alumnos) {	
		FileWriter archivo = null;				
		try {
			archivo = new FileWriter("./src/com/co/colegio/app/archivos/"+nombreArchivo, false);
			for (int i = 0; i < alumnos.size(); i++) {
				archivo.write(alumnos.get(i).getId() + "," +
						alumnos.get(i).getTipoIdentificacion() + "," +
						alumnos.get(i).getNumeroIdentificacion() + "," +
						alumnos.get(i).getNombre() + "," +
						alumnos.get(i).getApellido() + "," +
						alumnos.get(i).getCorreo() + "," +
						alumnos.get(i).getTelefono() + "," +
						alumnos.get(i).getDireccion() + "," +
						alumnos.get(i).getCiudad() + "," +
						alumnos.get(i).getEstado() +"\n"
						);
			}	
			System.out.println("El archivo se ha escrito con exito");
			archivo.close();
		}
		catch(Exception e) {
			System.out.println("Error al escribir el archivo: " + e.getMessage());
		}
	}
	
	public List<Alumno> leerAlumnos(String nombreArchivo) {
		File archivo = new File("./src/com/co/colegio/app/archivos/" + nombreArchivo);
		List<Alumno> listaAlumnos = new ArrayList<>();		
		try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
			String linea;
			while((linea = br.readLine())!= null) {
				String[] p = linea.split(",");
				listaAlumnos.add(new Alumno((Integer.parseInt(p[0])),
				(TipoIdentificacion.valueOf(p[1])),
				(p[2]),
				(p[3]),
				(p[4]),
				(p[5]),
				(p[6]),
				(p[7]),
				(p[8]),
				(Boolean.parseBoolean(p[9]))
				));
				
			}
			
		}catch(Exception e) {
			System.out.println("Error al leer el archivo: " + e.getMessage());
		}
		return listaAlumnos;
	}
	
}
