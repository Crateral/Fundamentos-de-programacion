package com.co.colegio.app.utilitarios;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.co.colegio.app.interfaces.*;
import com.co.colegio.app.logica.GestionProfesorImpl;
import com.co.colegio.app.modelos.*;

public class ArchivoMateriaImpl implements IArchivoMateria {

	public void guardarMaterias(String nombreArchivo, List<Materia> materias) {
		FileWriter archivo = null;
		try {
			archivo = new FileWriter("./src/com/co/colegio/app/archivos/" + nombreArchivo, false);
			for (int i = 0; i < materias.size(); i++) {
				archivo.write(materias.get(i).getIdMateria() + "," 
						+ materias.get(i).getNombreMateria() + ","
						+ materias.get(i).getProfesor().getId() + "," 
						+ materias.get(i).getGrado() + ","
						+ materias.get(i).getSalon() + "\n");
			}
			System.out.println("El archivo se ha escrito con exito");
			archivo.close();
		} catch (Exception e) {
			System.out.println("Error al escribir el archivo: " + e.getMessage());
		}
	}

	public List<Materia> leerMaterias(String nombreArchivo) {
		File archivo = new File("./src/com/co/colegio/app/archivos/" + nombreArchivo);
		List<Materia> listaMaterias = new ArrayList<>();
		
		IArchivoProfesor archivoProfesor = new ArchivoProfesorImpl();
		IGestionProfesor gestionProfesor = new GestionProfesorImpl();
		String profesoresArchivo = "Profesores.txt";
		List<Profesor> profesores = new ArrayList<>();
		profesores = archivoProfesor.leerProfesores(profesoresArchivo);
		
		try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
			String linea;
			while ((linea = br.readLine()) != null) {
				String[] p = linea.split(",");
				listaMaterias
						.add(new Materia((Integer.parseInt(p[0])), 
								(p[1]), 
								gestionProfesor.buscarProfesor(profesores, Integer.parseInt(p[2])), 
								Integer.parseInt(p[3]), 
								(p[4])));
			}

		} catch (Exception e) {
			System.out.println("Error al leer el archivo: " + e.getMessage());
		}
		return listaMaterias;
	}

}
