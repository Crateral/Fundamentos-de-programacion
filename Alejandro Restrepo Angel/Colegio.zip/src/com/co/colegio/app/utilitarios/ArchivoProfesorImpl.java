package com.co.colegio.app.utilitarios;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

import com.co.colegio.app.interfaces.IArchivoProfesor;
import com.co.colegio.app.modelos.*;


public class ArchivoProfesorImpl implements IArchivoProfesor {
	
	public void guardarProfesores(String nombreArchivo, List<Profesor> profesores) {	
		FileWriter archivo = null;				
		try {
			archivo = new FileWriter("./src/com/co/colegio/app/archivos/"+nombreArchivo, false);
			for (int i = 0; i < profesores.size(); i++) {
				archivo.write(profesores.get(i).getId() + "," +
						profesores.get(i).getTipoIdentificacion() + "," +
						profesores.get(i).getNumeroIdentificacion() + "," +
						profesores.get(i).getNombre() + "," +
						profesores.get(i).getApellido() + "," +
						profesores.get(i).getCorreo() + "," +
						profesores.get(i).getTelefono() + "," +
						profesores.get(i).getDireccion() + "," +
						profesores.get(i).getCiudad() + "\n"
						);
			}	
			System.out.println("El archivo se ha escrito con exito");
			archivo.close();
		}
		catch(Exception e) {
			System.out.println("Error al escribir el archivo: " + e.getMessage());
		}
	}
	
	public List<Profesor> leerProfesores(String nombreArchivo) {
		File archivo = new File("./src/com/co/colegio/app/archivos/" + nombreArchivo);
		List<Profesor> listaProfesores = new ArrayList<>();		
		try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
			String linea;
			while((linea = br.readLine())!= null) {
				String[] p = linea.split(",");
				listaProfesores.add(new Profesor((Integer.parseInt(p[0])),
				(TipoIdentificacion.valueOf(p[1])),
				(p[2]),
				(p[3]),
				(p[4]),
				(p[5]),
				(p[6]),
				(p[7]),
				(p[8])
				));
				
			}
			
		}catch(Exception e) {
			System.out.println("Error al leer el archivo: " + e.getMessage());
		}
		return listaProfesores;
	}
	
}
