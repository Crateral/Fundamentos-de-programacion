package com.co.colegio.app.modelos;

import java.io.Serializable;
import java.util.Date;

public class Alumno extends Persona implements Serializable {
	
	private Boolean estado;
	
	public Alumno() {
		super();
	}
	
	public Alumno(Integer id, TipoIdentificacion tipoIdentificacion, String numeroIdentificacion, String nombre,
			String apellido, String correo, String telefono, String direccion, String ciudad, Boolean estado) {
		super(id, tipoIdentificacion, numeroIdentificacion, nombre, apellido, correo, telefono, direccion, ciudad);
		this.estado = estado;
	}

	public Boolean getEstado() {
		return this.estado;
	}

	public void setEstado(Boolean estado) {
		this.estado = estado;
	}

	@Override
	public String toString() {
		return "Alumno [" + super.toString() + ", estado=" + this.estado + "]";
	}

	
	
}
