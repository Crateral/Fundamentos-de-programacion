package com.co.colegio.app.modelos;

import java.io.Serializable;

public class Nota implements Serializable{
	
	private Integer idNota;
	private Alumno alumno;
	private Materia materia;
	private Double nota;
	private String observacion;
	
	public Nota() {
		super();
	}

	public Nota(Integer idNota, Alumno alumno, Materia materia, Double nota, String observacion) {
		super();
		this.idNota = idNota;
		this.alumno = alumno;
		this.materia = materia;
		this.nota = nota;
		this.observacion = observacion;
	}

	public Integer getIdNota() {
		return idNota;
	}

	public void setIdNota(Integer idNota) {
		this.idNota = idNota;
	}

	public Alumno getAlumno() {
		return alumno;
	}

	public void setAlumno(Alumno alumno) {
		this.alumno = alumno;
	}

	public Materia getMateria() {
		return materia;
	}

	public void setMateria(Materia materia) {
		this.materia = materia;
	}

	public Double getNota() {
		return nota;
	}

	public void setNota(Double nota) {
		this.nota = nota;
	}

	public String getObservacion() {
		return observacion;
	}

	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}

	@Override
	public String toString() {
		return "Nota [idNota=" + idNota + ", alumno=" + alumno + ", materia=" + materia + ", nota=" + nota
				+ ", observacion=" + observacion + "]";
	}

}
