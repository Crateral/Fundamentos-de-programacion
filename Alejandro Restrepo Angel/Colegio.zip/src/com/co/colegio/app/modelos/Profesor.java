package com.co.colegio.app.modelos;

import java.io.Serializable;
import java.util.Date;

public class Profesor extends Persona implements Serializable {

	public Profesor() {
		super();
	}

	public Profesor(Integer id, TipoIdentificacion tipoIdentificacion, String numeroIdentificacion, String nombre,
			String apellido, String correo, String telefono, String direccion, String ciudad) {
		super(id, tipoIdentificacion, numeroIdentificacion, nombre, apellido, correo, telefono, direccion, ciudad);
	}

	@Override
	public String toString() {
		return "Profesor [" + super.toString() + "]";
	}
	
}
