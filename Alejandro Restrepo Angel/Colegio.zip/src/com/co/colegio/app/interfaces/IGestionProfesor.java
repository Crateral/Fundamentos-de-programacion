package com.co.colegio.app.interfaces;

import java.util.List;
import com.co.colegio.app.modelos.Profesor;

public interface IGestionProfesor {

	public Profesor buscarProfesor(List<Profesor> profesores, int id);
	
}
