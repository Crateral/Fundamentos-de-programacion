package com.co.colegio.app.interfaces;

import java.util.List;

import com.co.colegio.app.modelos.Alumno;

public interface IArchivoAlumno {

	public void guardarAlumnos(String nombreArchivo, List<Alumno> alumnos);
	public List<Alumno> leerAlumnos(String nombreArchivo);
	
}
