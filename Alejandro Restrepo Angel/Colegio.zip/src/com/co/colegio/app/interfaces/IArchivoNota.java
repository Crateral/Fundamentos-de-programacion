package com.co.colegio.app.interfaces;

import java.util.List;

import com.co.colegio.app.modelos.Nota;

public interface IArchivoNota {

	public void guardarNotas(String nombreArchivo, List<Nota> notas);
	public List<Nota> leerNotas(String nombreArchivo);
	
}
