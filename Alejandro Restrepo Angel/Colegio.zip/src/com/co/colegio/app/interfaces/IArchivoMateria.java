package com.co.colegio.app.interfaces;

import java.util.List;

import com.co.colegio.app.modelos.Materia;

public interface IArchivoMateria {

	public void guardarMaterias(String nombreArchivo, List<Materia> materias);
	public List<Materia> leerMaterias(String nombreArchivo);
	
}
