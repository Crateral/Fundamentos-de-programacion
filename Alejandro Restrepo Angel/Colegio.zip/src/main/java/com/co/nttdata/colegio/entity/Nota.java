package com.co.nttdata.colegio.entity;

import java.io.Serializable;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

@Entity
@Table(name="tbl_notas", schema="sc_colegio")
@NamedQuery(name="Nota.findAll", query="SELECT c FROM Nota c")
public class Nota implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;
	
	//bi-directional many-to-one association to Curso
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name="id_curso")
	@JsonProperty(access = Access.WRITE_ONLY)
	private Curso curso;
	
	//bi-directional many-to-one association to Estudiante
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name="id_estudiante")
	@JsonProperty(access = Access.WRITE_ONLY)
	private Estudiante estudiante;
	
	@NotNull(message = "Nota no puede estar vacía")
	@Column(name = "nota")
	private Double nota;
	
	@Column(name = "observacion")
	private String observacion;

	public Nota() {
		
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Curso getCurso() {
		return this.curso;
	}

	public void setCurso(Curso curso) {
		this.curso = curso;
	}

	public Estudiante getEstudiante() {
		return this.estudiante;
	}

	public void setEstudiante(Estudiante estudiante) {
		this.estudiante = estudiante;
	}

	public Double getNota() {
		return this.nota;
	}

	public void setNota(Double nota) {
		this.nota = nota;
	}

	public String getObservacion() {
		return this.observacion;
	}

	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}

	@Override
	public String toString() {
		return "Nota [id=" + this.id 
				+ ", curso=" + this.curso 
				+ ", estudiante=" + this.estudiante 
				+ ", nota=" + this.nota
				+ ", observacion=" + this.observacion + "]";
	}

}
