package com.co.nttdata.colegio.servicesImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.co.nttdata.colegio.entity.Estudiante;
import com.co.nttdata.colegio.repository.IEstudianteRepository;
import com.co.nttdata.colegio.service.IEstudianteService;

@Service
public class EstudianteServiceImpl implements IEstudianteService {

	@Autowired
	private IEstudianteRepository estudianteRepository;
	
	@Transactional(readOnly = true)
	@Override
	public List<Estudiante> listarEstudiantes() {
		return estudianteRepository.findAll();
	}

	@Transactional
	@Override
	public Estudiante crearEstudiante(Estudiante estudiante) {
		return estudianteRepository.save(estudiante);
	}

	@Transactional
	@Override
	public Boolean eliminarEstudiante(int id) {
		if(estudianteRepository.existsById(id)) {
			estudianteRepository.deleteById(id);
			return true;
		}
		return false;
	}

	@Transactional
	@Override
	public Estudiante actualizarEstudiante(int id, Estudiante estudiante) {
		Estudiante estudianteBD = estudianteRepository.findById(id).orElse(null);
		if(estudianteBD!=null) {
			estudianteBD.setTipoIdentificacion(estudiante.getTipoIdentificacion());
			estudianteBD.setNumeroIdentificacion(estudiante.getNumeroIdentificacion());
			estudianteBD.setNombre(estudiante.getNombre());
			estudianteBD.setApellido(estudiante.getApellido());
			estudianteBD.setCorreo(estudiante.getCorreo());
			estudianteBD.setTelefono(estudiante.getTelefono());
			estudianteBD.setDireccion(estudiante.getDireccion());
			estudianteBD.setCiudad(estudiante.getCiudad());
			estudianteBD.setEstado(estudiante.getEstado());
		}
		return estudianteRepository.save(estudianteBD);
	}

	@Transactional
	@Override
	public Estudiante buscarPorId(int id) {
		return estudianteRepository.findById(id).orElse(null);
	}

	@Transactional
	@Override
	public Estudiante buscarPorNumeroIdentificacion(String numero) {	
		return estudianteRepository.findByNumeroIdentificacion(numero);
	}

}
