package com.co.nttdata.colegio.servicesImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.co.nttdata.colegio.entity.Profesor;
import com.co.nttdata.colegio.repository.IProfesorRepository;
import com.co.nttdata.colegio.service.IProfesorService;

@Service
public class ProfesorServiceImpl implements IProfesorService {

	@Autowired
	private IProfesorRepository profesorRepository;
	
	@Transactional(readOnly = true)
	@Override
	public List<Profesor> listarProfesores() {
		return profesorRepository.findAll();
	}

	@Override
	public Profesor crearProfesor(Profesor profesor) {
		return profesorRepository.save(profesor);
	}

	@Override
	public Boolean eliminarProfesor(Integer id) {
		if(profesorRepository.existsById(id)) {
			profesorRepository.deleteById(id);
			return true;
		}
		return false;
	}

	@Override
	public Profesor actualizarProfesor(Integer id, Profesor profesor) {
		Profesor profesorBD = profesorRepository.findById(id).orElse(null);
		if(profesorBD!=null) {
			profesorBD.setTipoIdentificacion(profesor.getTipoIdentificacion());
			profesorBD.setNumeroIdentificacion(profesor.getNumeroIdentificacion());
			profesorBD.setNombre(profesor.getNombre());
			profesorBD.setApellido(profesor.getApellido());
			profesorBD.setCorreo(profesor.getCorreo());
			profesorBD.setTelefono(profesor.getTelefono());
			profesorBD.setDireccion(profesor.getDireccion());
			profesorBD.setCiudad(profesor.getCiudad());
		}
		return profesorRepository.save(profesorBD);
	}

	@Override
	public Profesor buscarPorId(int id) {
		return profesorRepository.findById(id).orElse(null);
	}

	@Override
	public Profesor buscarPorNumeroIdentificacion(String numero) {
		return profesorRepository.findByNumeroIdentificacion(numero);
	}

}
