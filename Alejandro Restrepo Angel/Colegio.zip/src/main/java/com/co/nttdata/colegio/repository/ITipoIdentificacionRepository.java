package com.co.nttdata.colegio.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.co.nttdata.colegio.entity.TipoIdentificacion;

public interface ITipoIdentificacionRepository extends JpaRepository<TipoIdentificacion, Integer> {

}
