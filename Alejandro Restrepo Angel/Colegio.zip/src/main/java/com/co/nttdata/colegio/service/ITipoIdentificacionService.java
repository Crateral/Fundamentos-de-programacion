package com.co.nttdata.colegio.service;

import java.util.List;

import com.co.nttdata.colegio.entity.TipoIdentificacion;

public interface ITipoIdentificacionService {

	public List<TipoIdentificacion> listarTipos();
	public TipoIdentificacion crearTipo(TipoIdentificacion tipoIdentificacion);
	public Boolean eliminarTipo(Integer id);
	public TipoIdentificacion actualizarTipo(Integer id, TipoIdentificacion tipoIdentificacion);
	
	public TipoIdentificacion buscarPorId(int id); 
}
