package com.co.nttdata.colegio.service;

import java.util.List;

import com.co.nttdata.colegio.entity.Curso;

public interface ICursoService {

	public List<Curso> listarCursos();
	public Curso crearCurso(Curso curso);
	public Boolean eliminarCurso(int id);
	public Curso actualizarCurso(int id, Curso curso);
	
	public Curso buscarPorId(int id); 
	
}
