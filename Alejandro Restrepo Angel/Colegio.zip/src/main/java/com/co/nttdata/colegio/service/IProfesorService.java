package com.co.nttdata.colegio.service;

import java.util.List;

import com.co.nttdata.colegio.entity.Profesor;

public interface IProfesorService {
	
	public List<Profesor> listarProfesores();
	public Profesor crearProfesor(Profesor profesor);
	public Boolean eliminarProfesor(Integer id);
	public Profesor actualizarProfesor(Integer id, Profesor profesor);
	
	public Profesor buscarPorId(int id); 
	public Profesor buscarPorNumeroIdentificacion(String numero); 
}
