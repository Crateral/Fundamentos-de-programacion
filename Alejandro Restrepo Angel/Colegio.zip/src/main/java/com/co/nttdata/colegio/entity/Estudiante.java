package com.co.nttdata.colegio.entity;

import java.io.Serializable;
import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

@Entity
@Table(name="tbl_estudiantes", schema="sc_colegio")
@NamedQuery(name="Estudiante.findAll", query="SELECT c FROM Estudiante c")
public class Estudiante implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer id;

	//bi-directional many-to-one association to TipoIdentificacion
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
	@JoinColumn(name="id_tipo_identificacion")
	@JsonProperty(access = Access.WRITE_ONLY)
	private TipoIdentificacion tipoIdentificacion;
	
	@NotNull(message = "Número de identificación no puede estar vacío")
	@Column(name="numero_identificacion")
	private String numeroIdentificacion;
	
	@NotNull(message = "Nombre no puede estar vacío")
	@Column(name = "nombre")
	private String nombre;
	
	@NotNull(message = "Apellido no puede estar vacío")
	@Column(name = "apellido")
	private String apellido;

	@NotNull(message = "Correo no puede estar vacío")
	@Email(message = "Correo debe ser válido") 
	@Column(name = "correo")
	private String correo;

	@NotNull(message = "Teléfono no puede estar vacío")
	@Column(name = "telefono")
	private String telefono;
	
	@NotNull(message = "Dirección no puede estar vacío")
	@Column(name = "direccion")
	private String direccion;

	@NotNull(message = "Ciudad no puede estar vacío")
	@Column(name = "ciudad")
	private String ciudad;
	
	@NotNull(message = "Define el estado")
	@Column(name = "estado")
	private Boolean estado;

	public Estudiante() {
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getApellido() {
		return this.apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getCorreo() {
		return this.correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getDireccion() {
		return this.direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getNombre() {
		return this.nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getNumeroIdentificacion() {
		return this.numeroIdentificacion;
	}

	public void setNumeroIdentificacion(String numeroIdentificacion) {
		this.numeroIdentificacion = numeroIdentificacion;
	}

	public String getTelefono() {
		return this.telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getCiudad() {
		return this.ciudad;
	}

	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}

	public TipoIdentificacion getTipoIdentificacion() {
		return this.tipoIdentificacion;
	}

	public void setTipoIdentificacion(TipoIdentificacion tipoIdentificacion) {
		this.tipoIdentificacion = tipoIdentificacion;
	}
	
	public Boolean getEstado() {
		return estado;
	}

	public void setEstado(Boolean estado) {
		this.estado = estado;
	}

	@Override
	public String toString() {
		return "Estudiante [id=" + this.id 
				+ ", tipoIdentificacion=" + this.tipoIdentificacion
				+ ", numeroIdentificacion=" +this. numeroIdentificacion 
				+ ", nombre=" + this.nombre 
				+ ", apellido=" + this.apellido 
				+ ", correo=" + this.correo 
				+ ", direccion=" + this.direccion
				+ ", telefono=" + this.telefono
				+ ", ciudad=" + this.ciudad
				+ ", estado=" + this.estado + "]";
	}
	
}