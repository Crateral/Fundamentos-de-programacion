package com.co.nttdata.colegio.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.co.nttdata.colegio.entity.Curso;

public interface ICursoRepository extends JpaRepository<Curso, Integer>{

}
