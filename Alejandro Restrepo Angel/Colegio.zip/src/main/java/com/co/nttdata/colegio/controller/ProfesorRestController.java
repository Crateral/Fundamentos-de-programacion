package com.co.nttdata.colegio.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.co.nttdata.colegio.entity.Profesor;
import com.co.nttdata.colegio.service.IProfesorService;

@CrossOrigin(origins = "http://localhost:9090")
@RestController
@RequestMapping("/api")
public class ProfesorRestController {

	@Autowired
	private IProfesorService profesorService;
	@GetMapping("/profesores")
	public ResponseEntity<List<Profesor>> listarProfesores() {
		try {
			List<Profesor> listaProfesores = profesorService.listarProfesores();
			if (listaProfesores == null || listaProfesores.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			return new ResponseEntity<>(listaProfesores, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@PostMapping("/profesores")
	public Profesor crearProfesor(@RequestBody Profesor profesor) {
		return profesorService.crearProfesor(profesor);
	}

	@PutMapping("/profesores/{id}")
	public Profesor actualizarProfesor(@PathVariable("id") int id,
			@RequestBody Profesor profesor) {
		return profesorService.actualizarProfesor(id, profesor);
	}

	@DeleteMapping("/profesores/{id}")
	public Boolean eliminarProfesor(@PathVariable("id") int id) {
		return profesorService.eliminarProfesor(id);
	}
	
	@GetMapping("/profesores/{id}")
	public Profesor ObtenerProfesorPorId(@PathVariable("id") int id) {
		return profesorService.buscarPorId(id);
	}
	
	@GetMapping("/profesores/numero/{numero}")
	public Profesor ObtenerProfesorPorNumeroId(@PathVariable("numero") String numero) {
		return profesorService.buscarPorNumeroIdentificacion(numero);
	}

}
