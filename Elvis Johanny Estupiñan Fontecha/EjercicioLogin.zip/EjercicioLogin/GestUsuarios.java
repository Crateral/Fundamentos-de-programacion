/*package EjercicioLogin;

import java.util.ArrayList;
import java.util.List;

public class GestUsuarios extends Usuario {

    List<Usuario> registroUsuarios = new ArrayList<>();


    public void AgregarUsusario(String nombre, String correo, String contrasena) {

        Usuario nuevUsuario = new Usuario();
        nuevUsuario.setNombre(nombre);
        nuevUsuario.setCorreo(correo);
        nuevUsuario.setContrasena(contrasena);
        registroUsuarios.add(nuevUsuario);
        System.out.println("Usuario Registrado Exitosamente");
    }


    public void ConsultarUsuarios() {
        if (registroUsuarios.size() != 0) {
            for (Usuario regisPerson : registroUsuarios) {
                System.out.println(regisPerson.toString());// buscar con ToString
            }
        } else {

            System.out.println("No existen usuarios registrados");
        }
    }

    public void inicioSesion(String correo, String contrasena) {
        for (Usuario regisPerson : registroUsuarios) {
            if (regisPerson.getCorreo().equals(correo) && regisPerson.getContrasena().equals(contrasena)) {
                System.out.println("Inicio de sesion Exitoso");
            } else {
                System.out.println("Los datos ingresados no son validos");
            }
        }
    }

}*/




