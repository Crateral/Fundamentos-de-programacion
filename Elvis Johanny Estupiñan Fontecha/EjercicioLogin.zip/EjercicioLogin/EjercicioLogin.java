package EjercicioLogin;


import java.util.ArrayList;

import java.util.List;
import java.util.Scanner;

public class EjercicioLogin {
    static List<Categorias2> listaCategorias2 = new ArrayList<>();
    static List<Usuario> listusuarios = new ArrayList<>();


    // Metodo main o principal
    public static void main(String[] args) {
        //Quemado de datos a las categorias con constructor con parametros
        Categorias2 categorias2 = new Categorias2("Frutas");
        Categorias2 categorias3 = new Categorias2("Lacteos");
        Categorias2 categorias4 = new Categorias2("Carnes");
        Categorias2 categorias5 = new Categorias2("Verduras");
        //Se agregan a la lista
        listaCategorias2.add(categorias2);
        listaCategorias2.add(categorias3);
        listaCategorias2.add(categorias4);
        listaCategorias2.add(categorias5);

        // Se invoca metodo de primer menu
        menuLogin();
    }

    // Primer menu
    public static void menuLogin() {

        Scanner entrada = new Scanner(System.in);

        String nombre, contraseña, correo;
        int opcion = 0;

        System.out.println("------------------------------------");
        System.out.println("    🤴🏻 Registro de usuarios 👸🏻      ");
        System.out.println("------------------------------------|");
        System.out.println("|  1. Crear usuarios                |");
        System.out.println("|  2. Consultar usuarios            |");
        System.out.println("|  3. Iniciar Sesion                |");
        System.out.println("|  4. Cambiar Contraseña            |");
        System.out.println("|  5. Recuperar Contraseña          |");
        System.out.println("|  6. Agregar Productos al Carrito  |");
        System.out.println("|  7. Salir                         |");
        System.out.println("|-------Digite una Opcion-----------|");
        System.out.println("|-----------------------------------|");
        opcion = entrada.nextInt();

        try {

            switch (opcion) {
                case 1:
                    Usuario numReg = new Usuario(); //crear objeto
                    System.out.println("Digite datos del usuario");
                    System.out.print("Nombre: ");
                    nombre = entrada.next();
                    numReg.setNombre(nombre);

                    System.out.print("Ingrese el correo: ");
                    correo = entrada.next();
                    numReg.setCorreo(correo);

                    System.out.print("Ingrese contraseña: ");
                    contraseña = entrada.next();
                    numReg.setContraseña(contraseña);

                    for (int i = 0; i < listusuarios.size(); i++) {
                        if (numReg.getCorreo() == correo) {
                            System.out.println("Correo ya registrado");
                        } else {
                            listusuarios.add(numReg);
                        }
                    }
                    listusuarios.add(numReg);
                    menuLogin();
                    break;

                case 2:
                    if (listusuarios.size() != 0) {
                        for (Usuario personaReg : listusuarios) {
                            System.out.println(personaReg.toString());
                        }
                    } else {
                        System.out.println("No hay usuarios");
                    }
                    menuLogin();
                    break;


                case 3:
                    System.out.println("DIGITE SUS CREDENCIALES");
                    System.out.print("Usuario: ");
                    correo = entrada.next();
                    System.out.print("Contraseña");
                    contraseña = entrada.next();
                    for (Usuario usuario : listusuarios) {
                        if (usuario.getCorreo().equals(correo) && usuario.getContraseña().equals(contraseña)) {
                            System.out.println("----SESION INICIADA----");
                        } else {
                            System.out.println("Los datos no son validos ");
                        }
                    }
                    menuLogin();
                    break;

                case 4:

                    System.out.println("¿Desea cambiar su contraseña?(1.SI) (2.NO) ");
                    int cambiContra = entrada.nextInt();
                    if (cambiContra == 1) {
                        System.out.print(" Digite su correo");
                        correo = entrada.next();

                        for (Usuario cambiContra1 : listusuarios) {
                            if (cambiContra1.getCorreo().equals(correo)) {
                                int indice = listusuarios.indexOf(cambiContra1.getCorreo());//busque la posicion

                                if (indice != 0) {
                                    System.out.print("Ingrese su nueva contraseña");
                                    contraseña = entrada.next();
                                    cambiContra1.setContraseña(contraseña);
                                }
                            }
                        }
                    } else {
                        System.out.println("Ingrese otra opcion");
                    }
                    menuLogin();
                    break;

                case 5:
                    System.out.println("Quiere recuperar su contraseña: 1 (si); 2 (no)  ");
                    int olvidoCon = entrada.nextInt();
                    if (olvidoCon == 1) {
                        System.out.print("digite su correo");
                        correo = entrada.next();

                        for (Usuario olvidoCon1 : listusuarios) {
                            if (olvidoCon1.getCorreo().equals(correo)) {
                                int Recuperarcon = listusuarios.indexOf(olvidoCon1.getCorreo());

                                if (Recuperarcon != 0) {
                                    System.out.print("ingresa tu nueva contraseña");
                                    contraseña = entrada.next();
                                    olvidoCon1.setContraseña(contraseña);
                                }
                            }
                        }
                    }
                    menuLogin();
                    break;

                case 6:
                    menu();
                    break;

                case 7:
                    System.out.println("Sesion Finalizada");
                    System.exit(0);
                    break;

                default:
                    System.out.println("Opcion no valida");
                    menuLogin();
                    break;
            }
        }catch(Exception e){
            System.out.println("Error al digitar"+e);
            }
    }

    // Segundo menu de compras
    public static void menu() {
        Scanner sc2 = new Scanner(System.in);
        int condicion = 0;
        String nombre;

        System.out.println("\nProductos");
        System.out.println("1. Agregar Productos");
        System.out.println("2. Consultar Productos");
        System.out.println("3. Eliminar productos");
        System.out.println("4. Total factura");
        System.out.println("5. salir");
        System.out.println(" Ingresar una opcion: ");
        condicion = sc2.nextInt();

        Categorias2 categorias2 = new Categorias2();

        switch (condicion) {

            case 1:
                System.out.print("Ingrese el nombre del producto: ");
                sc2.nextLine();
                String[] nombreArreglo = sc2.nextLine().split(" ");

                System.out.print("Ingrese precio del producto: ");
                int precio = sc2.nextInt();

                Productos2 productos2 = new Productos2(nombreArreglo[0], precio);

                int numeroCategoria = 0;
                String nombreCategoria = "";
                if (listaCategorias2.isEmpty()) {
                    System.out.println("Digite la nueva categoria");
                    nombreCategoria = sc2.next();
                    categorias2.setNombreCategoria(nombreCategoria);
                    listaCategorias2.add(categorias2);
                } else {
                    for (int i = 0; i < listaCategorias2.size(); i++) {
                        System.out.println(i + " --->" + listaCategorias2.get(i).getNombreCategoria());
                    }
                    System.out.println("\n--> Existen " + listaCategorias2.size() + " Categorias Disponibles");
                    System.out.println("Seleccione el numero del categoria");
                    numeroCategoria = sc2.nextInt();
                    nombreCategoria = listaCategorias2.get(numeroCategoria).getNombreCategoria();

                }
                crearProducto(numeroCategoria, nombreCategoria, productos2);
                break;


            case 2:
                for (int i = 0; i < listaCategorias2.size(); i++) {
                    listaCategorias2.get(i).mostrarProductos2();
                }
                menu();
                break;

            case 3:



                menu();
                break;

            case 4:
                facturas();
                break;

            case 5:
                menuLogin();
                break;

            default:
                System.out.println("Opcion no valida");
                break;

        }
    }

    //Metodo que guarda los productos en las categorias y listas
    public static void crearProducto(int numeroCategoria, String nombreCategoria, Productos2 producto2) {
        if (numeroCategoria < listaCategorias2.size()) {
            listaCategorias2.get(numeroCategoria).añadirProd(producto2);
        } else {
            Categorias2 categorias2 = new Categorias2(nombreCategoria);
            categorias2.añadirProd(producto2);
            listaCategorias2.add(categorias2);
        }
        for (int i = 0; i < listaCategorias2.size(); i++) {
            listaCategorias2.get(i).mostrarProductos2();
        }
        menu();
    }

    //Metodo de facturas
    public static void facturas(){  //metodo
        int valor=0;
        double valor2=valor*0.19;
        System.out.println("------------- Total factura -------------");
        for (int i=0; i<listaCategorias2.size();i++){
            valor = listaCategorias2.get(i).guardarPrecioProductos()+valor;
        }

        System.out.println("Compra: "+valor);
        System.out.println("iva: "+valor2);
        System.out.println("Total: "+(valor+valor2));

        menu();
    }



}