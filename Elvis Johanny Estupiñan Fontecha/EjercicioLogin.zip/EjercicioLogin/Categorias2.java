package EjercicioLogin;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.Scanner;

public class Categorias2 implements Serializable {

    private String nombreCategoria;

    ArrayList<Productos2> listaProductos=new ArrayList<>();

    public Categorias2() {
    }

    public void añadirProd(Productos2 producto2) {
        listaProductos.add(producto2);
    }


    public void mostrarProductos2(){
        for (int i = 0; i<listaProductos.size() ; i++) {
            System.out.println("Categoria: "+nombreCategoria+" --- Producto: "+listaProductos.get(i).getNombreProducto()
                    +" --- Precio: "+listaProductos.get(i).getPrecioProducto());
        }
    }



   /* public boolean eliminarProducto() {
        Scanner entrada=new Scanner(System.in);
        String eliminar;
        System.out.println("Escriba el nombre del producto a eliminar");
        eliminar=entrada.next();
        boolean encontrado=false;
        for (int i=0; i<listaProductos.size(); i++) {
            if (listaProductos.get(i).getNombreProducto().equals(eliminar)){
                encontrado=true;
                listaProductos.get(i).;
                EjercicioLogin.listaCategorias2.remove(eliminar);
            }
        }
        return encontrado;
    }*/









    //Metodo que guarda el valor de los productos comprados
    public int guardarPrecioProductos(){
        int valor = 0;
        int resultado=0;
        for (int i = 0; i<listaProductos.size() ; i++) {
            valor=listaProductos.get(i).getPrecioProducto();
            resultado=valor+resultado;
            System.out.println("- Producto: "+listaProductos.get(i).getNombreProducto()+" -- Precio: "+valor+" ");
        }
        return resultado;
    }



    public Categorias2(String nombreCategoria) {
        this.nombreCategoria = nombreCategoria;
    }

    public String getNombreCategoria() {
        return nombreCategoria;
    }

    public void setNombreCategoria(String nombreCategoria) {
        this.nombreCategoria = nombreCategoria;
    }

    @Override
    public String toString() {
        return "Categorias2{" +
                "nombreCategoria='" + nombreCategoria + '\'' +
                '}';
    }
}
