package EjercicioLogin;

import Evaluacion2.Producto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Categorias2 implements Serializable {

    private String nombreCategoria;

    ArrayList<Productos2> listaProductos=new ArrayList<>();

    public void añadirProd(Productos2 producto2){
        listaProductos.add(producto2);
    }
    public void mostrarProductos2(){
        for (int i = 0; i<listaProductos.size() ; i++) {

            System.out.println("Categoria: "+nombreCategoria+"---Producto: "+listaProductos.get(i).getNombreProducto()
            +" ---Precio: "+listaProductos.get(i).getPrecioProducto());
        }
    }

    public Categorias2(String nombreCategoria) {
        this.nombreCategoria = nombreCategoria;
    }

    public String getNombreCategoria() {
        return nombreCategoria;
    }

    public void setNombreCategoria(String nombreCategoria) {
        this.nombreCategoria = nombreCategoria;
    }

    @Override
    public String toString() {
        return "Categorias2{" +
                "nombreCategoria='" + nombreCategoria + '\'' +
                '}';
    }
}
