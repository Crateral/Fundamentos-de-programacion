package Evaluacion2;

import java.util.ArrayList;
import java.util.List;

public class Categoria {

    private String nombreCategoria;
    ArrayList<Producto> listaProductos = new ArrayList<>();

    public Categoria(String nombreCategoria) {
        this.nombreCategoria = nombreCategoria;
    }

    public void agregarProductoCarr(Producto producto1){
        listaProductos.add(producto1);
    }

    public void mostrarProductos(){
        for (int i = 0; i<listaProductos.size() ; i++) {
            System.out.println(listaProductos.get(i));
        }
    }


    public String getNombreCategoria() {
        return nombreCategoria;
    }

    public void setNombreCategoria(String nombreCategoria) {
        this.nombreCategoria = nombreCategoria;
    }

    @Override
    public String toString() {
        return "Categoria{" +
                "categoria='" + nombreCategoria + '\'' +
                '}';
    }
}

