package Evaluacion2;

import Ejercicio5.Informe;

import java.util.ArrayList;
import java.util.Scanner;

public class CarritoCompras {
    static ArrayList<Categoria> categorias = new ArrayList<>();
    static Scanner sc = new Scanner(System.in);
    static Scanner sc1 = new Scanner(System.in);

    public static void main(String[] args) {
        int opcion = 0;

        do {
            System.out.println("1. Agregar Productos");
            System.out.println("2. Consultar Productos");
            System.out.println("3. salir");
            System.out.println(" Ingresar una opcion: ");
            opcion = sc.nextInt();

            switch (opcion) {

                case 1:

                    System.out.println("Ingrese datos del producto: nombre del producto y precio ");
                    sc.nextLine();
                    String[] datos = sc.nextLine().split(" ");

                    System.out.println("ingrese precio ");
                    int datos1 = sc1.nextInt();

                    Producto producto = new Producto(datos[0], datos1);

                    int numeroCategoria = 0;
                    String nombreCategoria = "";

                    if (categorias.isEmpty()) {
                        nombreCategoria = "";
                        System.out.println("ingrese nombre de categoria");
                        nombreCategoria = sc.nextLine();

                    } else {
                        for (int i = 0; i < categorias.size(); i++) {
                            System.out.println(i + " --->" + categorias.get(i).getNombreCategoria());
                        }
                        System.out.println(categorias.size() + "--> Categoria Disponible");
                        System.out.println("Seleccione el numero del categoria");
                        numeroCategoria = sc.nextInt();

                        if (numeroCategoria <= categorias.size()) {
                            System.out.println("Ingrese el nombre de la catergoria: ");
                            sc.nextLine();
                            nombreCategoria = sc.nextLine();
                        }
                    }

                    crearProducto(numeroCategoria, nombreCategoria, producto);
                    break;


                case 2:

                    int contador = 0;
                    for (Categoria categoria : categorias) {
                        for (int i = 0; i < categorias.size(); i++) {
                            System.out.println("Las productos son: " + categoria.listaProductos);

                            contador = contador;
                        }
                    }

                    break;
                case 3:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Producto no existente");
                    break;
            }


        }
        while (opcion != 3);
    }

    public static void crearProducto(int numeroCategoria, String nombreCategoria, Producto producto1) {
        if (numeroCategoria < categorias.size()) {
            categorias.get(numeroCategoria).agregarProductoCarr(producto1);
        } else {
            Categoria categoria1 = new Categoria(nombreCategoria);
            categoria1.agregarProductoCarr(producto1);
            categorias.add(categoria1);
        }
        System.out.println(categorias);
        for (int i = 0; i < categorias.size(); i++) {
            categorias.get(i).mostrarProductos();
        }
    }

}


