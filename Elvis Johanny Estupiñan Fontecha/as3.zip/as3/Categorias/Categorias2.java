package com.co.nttdata.as3.Categorias;


import com.co.nttdata.as3.Productos.Productos2;

import java.io.Serializable;
import java.util.ArrayList;

public class Categorias2 implements Serializable {
    private String nombreCategoria;

    ArrayList<Productos2> listaProductos = new ArrayList<>();

    public Categorias2() {
    }

    //Agregar la lista de productos a cada categoria
    public void añadirProd(Productos2 producto2) {
        listaProductos.add(producto2);
    }
    public void mostrarProductos2() {
        for (int i = 0; i < listaProductos.size(); i++) {
            System.out.println("Categoria: " + nombreCategoria + " --- Producto: " + listaProductos.get(i).getNombreProducto()
                    + " --- Precio: " + listaProductos.get(i).getPrecioProducto());
        }
    }

    //Metodo que guarda el valor de los productos comprados
    public int guardarPrecioProductos() {
        int valor = 0;
        int resultado = 0;
        for (int i = 0; i < listaProductos.size(); i++) {
            valor = listaProductos.get(i).getPrecioProducto();
            resultado = valor + resultado;
            System.out.println("| Producto:     " + listaProductos.get(i).getNombreProducto() + "| Precio: " + valor + "|");
        }
        return resultado;
    }

    public Categorias2(String nombreCategoria) {
        this.nombreCategoria = nombreCategoria;
    }

    public String getNombreCategoria() {
        return nombreCategoria;
    }

    public void setNombreCategoria(String nombreCategoria) {
        this.nombreCategoria = nombreCategoria;
    }

    @Override
    public String toString() {
        return "Categorias2{" +
                "nombreCategoria='" + nombreCategoria + '\'' +
                '}';
    }
}
