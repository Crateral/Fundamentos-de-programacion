package com.notas.colegioRest.dao;

import java.util.List;

import com.notas.colegioRest.models.Curso;

public interface CursoDao {
	
	public List<Curso> findAll();

	public Curso findByld(int id_curso);

	public void save(Curso curso);

	public void deleteByld(int id_curso);

}
