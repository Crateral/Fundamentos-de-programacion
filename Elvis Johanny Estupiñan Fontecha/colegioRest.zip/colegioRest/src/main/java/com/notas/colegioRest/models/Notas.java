package com.notas.colegioRest.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "\"tbl_notas\"")
public class Notas {

	@Id
	@Column(name = "\"id_notas\"")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id_notas;
	private Double nota1;
	private Double nota2;
	private Double nota3;
	private Double nota_final;
	
	
	public Notas() {
		super();
	}
	

	public int getId_notas() {
		return id_notas;
	}


	public void setId_notas(int id_notas) {
		this.id_notas = id_notas;
	}



	public Double getNota1() {
		return nota1;
	}


	public void setNota1(Double nota1) {
		this.nota1 = nota1;
	}


	public Double getNota2() {
		return nota2;
	}


	public void setNota2(Double nota2) {
		this.nota2 = nota2;
	}


	public Double getNota3() {
		return nota3;
	}


	public void setNota3(Double nota3) {
		this.nota3 = nota3;
	}


	public Double getNota_final() {
		return nota_final;
	}


	public void setNota_final(Double nota_final) {
		this.nota_final = nota_final;
	}


	@Override
	public String toString() {
		return "Notas [id_notas=" + id_notas + ", nota1=" + nota1 + ", nota2=" + nota2 + ", nota3=" + nota3
				+ ", nota_final=" + nota_final + "]";
	}	

}
