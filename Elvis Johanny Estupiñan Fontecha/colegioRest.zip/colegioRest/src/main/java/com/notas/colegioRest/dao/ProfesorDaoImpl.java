package com.notas.colegioRest.dao;

import java.util.List;
import javax.persistence.EntityManager;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.notas.colegioRest.models.Profesor;

@Repository
public class ProfesorDaoImpl implements ProfesorDao {

	@Autowired
	private EntityManager entityManager;

	@Override
	public List<Profesor> findAll() {

		Session currentSession = entityManager.unwrap(Session.class);
//Session currentSession = entityManager.unwrap(Session.class);
		Query<Profesor> theQuery = currentSession.createQuery("from Profesor", Profesor.class);
		List<Profesor> profesor = theQuery.getResultList();
		return profesor;
	}

	@Override
	public Profesor findByld(int id_profesor) {
		Session currentSession = entityManager.unwrap(Session.class);
		Profesor profesor = currentSession.get(Profesor.class, id_profesor);
		return profesor;
	}

	@Override
	public void save(Profesor profesor) {

		Session currentSession = entityManager.unwrap(Session.class);
		currentSession.saveOrUpdate(profesor);
	}

	@Override
	public void deleteByld(int id_profesor) {
		Session currentSession = entityManager.unwrap(Session.class);
		Query<Profesor> theQuery = currentSession.createQuery("delete from Profesor where id=:id_profesor");
		theQuery.setParameter("id_profesor", id_profesor);
		theQuery.executeUpdate();
	}
}
