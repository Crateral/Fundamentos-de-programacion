package com.notas.colegioRest.dao;

import java.util.List;
import javax.persistence.EntityManager;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.notas.colegioRest.models.Curso;

@Repository
public class CursoDaoImpl implements CursoDao {
	
	@Autowired
	private EntityManager entityManager;

	@Override
	public List<Curso> findAll() {

		Session currentSession = entityManager.unwrap(Session.class);
		// Session currentSession = entityManager.unwrap(Session.class);
		Query<Curso> theQuery = currentSession.createQuery("from Curso", Curso.class);
		List<Curso> curso = theQuery.getResultList();
		return curso;
	}

	@Override
	public Curso findByld(int id_curso) {
		Session currentSession = entityManager.unwrap(Session.class);
		Curso curso = currentSession.get(Curso.class, id_curso);
		return curso;
	}

	@Override
	public void save(Curso curso) {

		Session currentSession = entityManager.unwrap(Session.class);
		currentSession.saveOrUpdate(curso);
	}

	@Override
	public void deleteByld(int id_curso) {
		Session currentSession = entityManager.unwrap(Session.class);
		Query<Curso> theQuery = currentSession.createQuery("delete from Curso where id=:id_curso");
		theQuery.setParameter("id_curso", id_curso);
		theQuery.executeUpdate();
	}



}
