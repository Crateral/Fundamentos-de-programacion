package com.notas.colegioRest.dao;

import java.util.List;

import com.notas.colegioRest.models.Profesor;

public interface ProfesorDao {
	
	public List<Profesor> findAll();
	
	public Profesor findByld(int id_profesor);

	public void save(Profesor profesor);

	public void deleteByld(int id_profesor);
}
