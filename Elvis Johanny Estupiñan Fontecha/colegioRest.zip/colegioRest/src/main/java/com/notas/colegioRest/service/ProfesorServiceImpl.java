package com.notas.colegioRest.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.notas.colegioRest.dao.ProfesorDao;
import com.notas.colegioRest.models.Profesor;

@Repository
public class ProfesorServiceImpl implements ProfesorService {
	@Autowired
	private ProfesorDao profesorDao;

	@Override
	@Transactional(readOnly = true)
	public List<Profesor> findAll() {
		List<Profesor> listaProfesor = profesorDao.findAll();
		return listaProfesor;
	}

	@Override
	@Transactional(readOnly = true)
	public Profesor findByld(int id_profesor) {
		Profesor profesor = profesorDao.findByld(id_profesor);
		return profesor;
	}

	@Override
	@Transactional
	public void save(Profesor profesor) {
		profesorDao.save(profesor);
	}

	@Override
	@Transactional
	public void deleteByld(int id_profesor) {
		profesorDao.deleteByld(id_profesor);
	}
}
