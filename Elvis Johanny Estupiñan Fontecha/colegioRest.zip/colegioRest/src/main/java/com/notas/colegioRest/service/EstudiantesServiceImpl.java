package com.notas.colegioRest.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.notas.colegioRest.dao.EstudiantesDao;
import com.notas.colegioRest.models.Estudiantes;


@Repository
public class EstudiantesServiceImpl implements EstudiantesService {
	
	@Autowired
	private EstudiantesDao estudiantesDao;

	@Override
	@Transactional(readOnly = true)
	public List<Estudiantes> findAll() {
		List<Estudiantes> listaEstudiantes = estudiantesDao.findAll();
		return listaEstudiantes;
	}

	@Override
	@Transactional(readOnly = true)
	public Estudiantes findByld(int id_estudiante) {
		Estudiantes estudiantes = estudiantesDao.findByld(id_estudiante);
		return estudiantes;
	}

	@Override
	@Transactional
	public void save(Estudiantes estudiantes) {
		estudiantesDao.save(estudiantes);
	}

	@Override
	@Transactional
	public void deleteByld(int id_estudiante) {
		estudiantesDao.deleteByld(id_estudiante);
	}

}
