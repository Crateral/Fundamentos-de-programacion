package com.notas.colegioRest.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "\"tbl_estudiantes\"")
public class Estudiantes {
	
	@Id
	@Column(name = "\"id_estudiante\"")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id_estudiante;
	private String nom_estudiante;
	private String materia;
	private int id_notas;
	private int id_curso;
	private int id_profesor;
	
	
	public Estudiantes(){
		super();		
	}


	public int getId_estudiante() {
		return id_estudiante;
	}


	public void setId_estudiante(int id_estudiante) {
		this.id_estudiante = id_estudiante;
	}


	public String getNom_estudiante() {
		return nom_estudiante;
	}


	public void setNom_estudiante(String nom_estudiante) {
		this.nom_estudiante = nom_estudiante;
	}


	public String getMateria() {
		return materia;
	}


	public void setMateria(String materia) {
		this.materia = materia;
	}


	public int getId_notas() {
		return id_notas;
	}


	public void setId_notas(int id_notas) {
		this.id_notas = id_notas;
	}


	public int getId_curso() {
		return id_curso;
	}


	public void setId_curso(int id_curso) {
		this.id_curso = id_curso;
	}


	public int getId_profesor() {
		return id_profesor;
	}


	public void setId_profesor(int id_profesor) {
		this.id_profesor = id_profesor;
	}


	@Override
	public String toString() {
		return "Estudiantes [id_estudiante=" + id_estudiante + ", nom_estudiante=" + nom_estudiante + ", materia="
				+ materia + ", id_notas=" + id_notas + ", id_curso=" + id_curso + ", id_profesor=" + id_profesor + "]";
	}	
}
