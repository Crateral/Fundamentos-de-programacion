package com.notas.colegioRest.service;

import java.util.List;

import com.notas.colegioRest.models.Estudiantes;


public interface EstudiantesService {
	
	public List<Estudiantes> findAll();

	public Estudiantes findByld(int id_estudiante);

	public void save(Estudiantes estudiantes);

	public void deleteByld(int id_estudiante);

}
