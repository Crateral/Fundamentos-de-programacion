package com.notas.colegioRest.dao;

import java.util.List;

import com.notas.colegioRest.models.Notas;

public interface NotasDao {
	
	public List<Notas> findAll();

	public Notas findByld(int id_notas);

	public void save(Notas notas);

	public void deleteByld(int id_notas);
}
