package com.notas.colegioRest.service;

import java.util.List;

import com.notas.colegioRest.models.Profesor;

public interface ProfesorService {
	
	public List<Profesor> findAll();

	public Profesor findByld(int id_profesor);

	public void save(Profesor profesor);

	public void deleteByld(int id_profesor);
}
