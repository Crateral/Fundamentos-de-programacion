package com.notas.colegioRest.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.notas.colegioRest.models.Estudiantes;


@Repository
public class EstudiantesDaoImpl implements EstudiantesDao {
	
	@Autowired
	private EntityManager entityManager;

	@Override
	public List<Estudiantes> findAll() {

		Session currentSession = entityManager.unwrap(Session.class);
		// Session currentSession = entityManager.unwrap(Session.class);
		Query<Estudiantes> theQuery = currentSession.createQuery("from Estudiantes", Estudiantes.class);
		List<Estudiantes> estudiantes = theQuery.getResultList();
		return estudiantes;
	}

	@Override
	public Estudiantes findByld(int id_estudiante) {
		Session currentSession = entityManager.unwrap(Session.class);
		Estudiantes estudiantes = currentSession.get(Estudiantes.class, id_estudiante);
		return estudiantes;
	}

	@Override
	public void save(Estudiantes estudiantes) {

		Session currentSession = entityManager.unwrap(Session.class);
		currentSession.saveOrUpdate(estudiantes);
	}

	@Override
	public void deleteByld(int id_estudiante) {
		Session currentSession = entityManager.unwrap(Session.class);
		Query<Estudiantes> theQuery = currentSession.createQuery("delete from Estudiantes where id=:id_estudiante");
		theQuery.setParameter("id_estudiante", id_estudiante);
		theQuery.executeUpdate();
	}
}
