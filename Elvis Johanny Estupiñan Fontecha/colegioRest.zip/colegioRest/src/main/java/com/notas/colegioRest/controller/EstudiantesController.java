package com.notas.colegioRest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.notas.colegioRest.models.Estudiantes;
import com.notas.colegioRest.service.EstudiantesService;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/colegioRest")
public class EstudiantesController {
	
	// localhost:8081/colegioRest/estudiantes

		@Autowired
		private EstudiantesService estudiantesService;

		@GetMapping("/estudiantes")
		public List<Estudiantes> findAll() {
			return estudiantesService.findAll();
		}

		@GetMapping("/estudiantes/{estudianteId}")
		public Estudiantes getEstudiantes(@PathVariable int estudianteId) {
			Estudiantes estudiantes = estudiantesService.findByld(estudianteId);
			if (estudiantes == null) {
				throw new RuntimeException("Estudiantes not found-" + estudianteId);
			}
			return estudiantes;
		}

		@PostMapping("/estudiantes")
		public Estudiantes addEstudiantes(@RequestBody Estudiantes estudiantes) {
			estudiantes.setId_estudiante(0);
			estudiantesService.save(estudiantes);
			return estudiantes;
		}

		@PutMapping("/estudiantes")
		public Estudiantes updateEstudiantes(@RequestBody Estudiantes estudiantes) {
			estudiantesService.save(estudiantes);
			// este metodo actualizará al usuario enviado
			return estudiantes;
		}

		@DeleteMapping("estudiantes/{estudianteId}")
		public String deleteEstudiantes(@PathVariable int estudianteId) {
			Estudiantes estudiantes = estudiantesService.findByld(estudianteId);
			if (estudiantes == null) {
				throw new RuntimeException("Estudiantes not found -" + estudianteId);
			}
			estudiantesService.deleteByld(estudianteId);
			return "Deleted Estudiante id - " + estudianteId;
		}

}
