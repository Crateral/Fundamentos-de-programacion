package com.notas.colegioRest.dao;

import java.util.List;
import javax.persistence.EntityManager;
import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.notas.colegioRest.models.Notas;



@Repository
public class NotasDaoImpl implements NotasDao {

	@Autowired
	private EntityManager entityManager;

	@Override
	public List<Notas> findAll() {

		Session currentSession = entityManager.unwrap(Session.class);
		// Session currentSession = entityManager.unwrap(Session.class);
		Query<Notas> theQuery = currentSession.createQuery("from Notas", Notas.class);
		List<Notas> notas = theQuery.getResultList();
		return notas;
	}

	@Override
	public Notas findByld(int id_notas) {
		Session currentSession = entityManager.unwrap(Session.class);
		Notas notas = currentSession.get(Notas.class, id_notas);
		return notas;
	}

	@Override
	public void save(Notas notas) {

		Session currentSession = entityManager.unwrap(Session.class);
		currentSession.saveOrUpdate(notas);
	}

	@Override
	public void deleteByld(int id_notas) {
		Session currentSession = entityManager.unwrap(Session.class);
		Query<Notas> theQuery = currentSession.createQuery("delete from Notas where id=:id_notas");
		theQuery.setParameter("id_notas", id_notas);
		theQuery.executeUpdate();
	}

}
