package com.notas.colegioRest.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.notas.colegioRest.models.Notas;
import com.notas.colegioRest.service.NotasService;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/colegioRest")
public class NotasController {

	// localhost:8081/colegioRest/notas

	@Autowired
	private NotasService notasService;

	@GetMapping("/notas")
	public List<Notas> findAll() {
		return notasService.findAll();
	}

	@GetMapping("/notas/{notasId}")
	public Notas getNotas(@PathVariable int notasId) {
		Notas notas = notasService.findByld(notasId);
		if (notas == null) {
			throw new RuntimeException("Notas not found-" + notasId);
		}
		return notas;
	}

	@PostMapping("/notas")
	public Notas addNotas(@RequestBody Notas notas) {
		notas.setId_notas(0);
		notasService.save(notas);
		return notas;
	}

	@PutMapping("/notas")
	public Notas updateNotas(@RequestBody Notas notas) {
		notasService.save(notas);
		// este metodo actualizará al usuario enviado
		return notas;
	}

	@DeleteMapping("notas/{notasId}")
	public String deleteNotas(@PathVariable int notasId) {
		Notas notas = notasService.findByld(notasId);
		if (notas == null) {
			throw new RuntimeException("Notas not found -" + notasId);
		}
		notasService.deleteByld(notasId);
		return "Deleted Notas id - " + notasId;
	}

}
