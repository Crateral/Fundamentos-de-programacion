package com.notas.colegioRest.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.notas.colegioRest.dao.NotasDao;
import com.notas.colegioRest.models.Notas;



@Repository
public class NotasServiceImpl implements NotasService {
	@Autowired
	private NotasDao notasDao;

	@Override
	@Transactional(readOnly = true)
	public List<Notas> findAll() {
		List<Notas> listaNotas = notasDao.findAll();
		return listaNotas;
	}

	@Override
	@Transactional(readOnly = true)
	public Notas findByld(int id_notas) {
		Notas notas = notasDao.findByld(id_notas);
		return notas;
	}

	@Override
	@Transactional
	public void save(Notas notas) {
		notasDao.save(notas);
	}

	@Override
	@Transactional
	public void deleteByld(int id_notas) {
		notasDao.deleteByld(id_notas);
	}
}
