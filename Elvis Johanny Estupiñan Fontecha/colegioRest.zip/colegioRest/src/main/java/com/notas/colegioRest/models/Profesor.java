package com.notas.colegioRest.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "\"tbl_profesor\"")
public class Profesor {
	
	@Id
	@Column(name = "\"id_profesor\"")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id_profesor;		
	private String nom_profesor;	
	private String cedula;
	private String correo;
	
	public Profesor() {
		super();
	}

	
	public int getId_profesor() {
		return id_profesor;
	}

	public void setId_profesor(int id_profesor) {
		this.id_profesor = id_profesor;
	}

	public String getNom_profesor() {
		return nom_profesor;
	}

	public void setNom_profesor(String nom_profesor) {
		this.nom_profesor = nom_profesor;
	}

	public String getCedula() {
		return cedula;
	}

	public void setCedula(String cedula) {
		this.cedula = cedula;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	@Override
	public String toString() {
		return "Profesor [id_profesor=" + id_profesor + ", nom_profesor=" + nom_profesor + ", cedula=" + cedula
				+ ", correo=" + correo + "]";
	}
}
