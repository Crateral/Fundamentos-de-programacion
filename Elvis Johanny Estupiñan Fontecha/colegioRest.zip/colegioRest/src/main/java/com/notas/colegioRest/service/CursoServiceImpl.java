package com.notas.colegioRest.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.notas.colegioRest.dao.CursoDao;
import com.notas.colegioRest.models.Curso;

@Repository
public class CursoServiceImpl implements CursoService {
	@Autowired
	private CursoDao cursoDao;

	@Override
	@Transactional(readOnly = true)
	public List<Curso> findAll() {
		List<Curso> listaCursos = cursoDao.findAll();
		return listaCursos;
	}

	@Override
	@Transactional(readOnly = true)
	public Curso findByld(int id_curso) {
		Curso curso = cursoDao.findByld(id_curso);
		return curso;
	}

	@Override
	@Transactional
	public void save(Curso curso) {
		cursoDao.save(curso);
	}

	@Override
	@Transactional
	public void deleteByld(int id_curso) {
		cursoDao.deleteByld(id_curso);
	}
}
