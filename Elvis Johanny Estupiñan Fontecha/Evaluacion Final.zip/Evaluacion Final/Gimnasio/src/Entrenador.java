public class Entrenador extends Persona{

    private String id_entrenador;

    public Entrenador() {
    }

    public String getId_entrenador() {
        return id_entrenador;
    }

    public void setId_entrenador(String id_entrenador) {
        this.id_entrenador = id_entrenador;
    }

    @Override
    public String toString() {
        return "Entrenador{" +
                "id_entrenador='" + id_entrenador + '\'' +
                '}';
    }
}
