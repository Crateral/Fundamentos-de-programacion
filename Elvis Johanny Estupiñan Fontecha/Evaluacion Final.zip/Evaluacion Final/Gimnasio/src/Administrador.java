public class Administrador extends Persona{

    private String id_administrador;

    public Administrador() {
    }

    public String getId_administrador() {
        return id_administrador;
    }

    public void setId_administrador(String id_administrador) {
        this.id_administrador = id_administrador;
    }

    @Override
    public String toString() {
        return "Administrador{" +
                "id_administrador='" + id_administrador + '\'' +
                '}';
    }
}
