import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Gimnasio {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int opcion = 0;

        opcion = menu();
        Gimnasio(); //llamar metodo
        Usuario usuario = new Usuario(); //instanciar clase
        List<Usuario>listaUsuarios = new ArrayList<>();
        List<Administrador>listaAdmin = new ArrayList<>();
        List<Entrenador>listaEntren = new ArrayList<>();

        listaUsuarios.add(usuario);

        while (opcion != 3) {
            switch (opcion) {
                case 1:
                    System.out.println("Digite su numero de documento");
                    usuario.setCedula(sc.nextInt());
                    System.out.println("Digite su nombre completo");
                    usuario.setNombre(sc.next());
                    System.out.println("Digite su correo");
                    usuario.setCorreo(sc.next());
                    System.out.println("Digite número de teléfono");
                    usuario.setTelefono(sc.nextInt());
                    System.out.println("Digite su nombre de usuario");
                    usuario.setUsuario(sc.next());
                    System.out.println("Digite nueva contraseña");
                    usuario.setContraseña(sc.next());

                    System.out.println("Usuario registrado Exitosamente");
                    opcion=menu();

                    listaUsuarios.add(usuario);

                    break;
                case 2:
                    System.out.println("Digite su usuario");
                    String usuario1 = sc.next();
                    System.out.println("Digiete su contraseña");
                    String contra1 =sc.next();
                   for (int i=0; i<listaUsuarios.size();i++){
                       if(usuario1.equals(listaUsuarios.get(i).getUsuario()) && contra1.equals(listaUsuarios.get(i).getContraseña())){
                           System.out.println("Ingreso Exitoso");
                       }else {
                           System.out.println("Usuario no registrado");

                       }
                   }



                    break;

                case 3:
                    break;

                default:
                    break;
            }
        }

    }

    public static void Gimnasio() {
        Administrador administrador = new Administrador();
        administrador.setId_administrador("1001");
        administrador.setCedula(10691245);
        administrador.setNombre("Johanny Estupiñan");
        administrador.setCorreo("Johanny07@gmail.com");
        administrador.setTelefono(3124574);
        administrador.setUsuario("Johanny07@gmail.com");
        administrador.setContraseña("12345");
    }

    public static int menu() {
        int entrada;
        Scanner sc = new Scanner(System.in);
        do {
            System.out.print("|----------------------|\n");
            System.out.print("|       Bienvenido     |\n");
            System.out.print("|----------------------|\n");
            System.out.print("|     1. Registrarse   |\n");
            System.out.print("|     2. Ingresar      |\n");
            System.out.print("|     3. Salir         |\n");
            System.out.print("|----------------------|\n");
            entrada = sc.nextInt();
        } while (entrada == 3);
        return entrada;
    }
}