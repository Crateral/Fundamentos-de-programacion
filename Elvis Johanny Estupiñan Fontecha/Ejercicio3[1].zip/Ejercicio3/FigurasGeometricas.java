package Ejercicio3;

public class FigurasGeometricas {

    private String cuadrado;
    private String rectangulo;
    private String triangulo;
    private String circulo;
    private String pentagono;

    public FigurasGeometricas() {
    }

    public String getCuadrado() {
        return cuadrado;
    }

    public void setCuadrado(String cuadrado) {
        this.cuadrado = cuadrado;
    }

    public String getRectangulo() {
        return rectangulo;
    }

    public void setRectangulo(String rectangulo) {
        this.rectangulo = rectangulo;
    }

    public String getTriangulo() {
        return triangulo;
    }

    public void setTriangulo(String triangulo) {
        this.triangulo = triangulo;
    }

    public String getCirculo() {
        return circulo;
    }

    public void setCirculo(String circulo) {
        this.circulo = circulo;
    }

    public String getPentagono() {
        return pentagono;
    }

    public void setPentagono(String pentagono) {
        this.pentagono = pentagono;
    }

    @Override
    public String toString() {
        return "FigurasGeometricas{" +
                "cuadrado='" + cuadrado + '\'' +
                ", rectangulo='" + rectangulo + '\'' +
                ", triangulo='" + triangulo + '\'' +
                ", circulo='" + circulo + '\'' +
                ", pentagono='" + pentagono + '\'' +
                '}';
    }
}
