package EjercicioCamioneta;

public class Camioneta extends Vehiculo implements Funciones{


    @Override
    public void encender() {
        System.out.println("El vehiculo encendio");
    }
    @Override
    public void apagar() {
        System.out.println("El vehiculo se apago");

    }
    @Override
    public void mover(int distancia) {
        System.out.println("El vehiculo se movio "+distancia+" metros");

    }

}
