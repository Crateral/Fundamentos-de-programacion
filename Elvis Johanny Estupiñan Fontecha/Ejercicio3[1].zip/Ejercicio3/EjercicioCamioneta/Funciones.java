package EjercicioCamioneta;

import javax.sound.midi.Soundbank;

public interface Funciones {

    public void encender();
    public void apagar();
    public void mover(int distancia);
}
