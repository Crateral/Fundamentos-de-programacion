package EjercicioCamioneta;

public class Total {
    public static void main(String[] args) {

        System.out.println("los datos del vehiculo son: "+datos() );
    }
    public static Camioneta datos(){

    Camioneta camioneta=new Camioneta();
    camioneta.setMarca("Toyota");
    camioneta.setModelo("Prado");
    camioneta.setAño("2023");
    camioneta.setColor("Negro");
    camioneta.setPuertas(4);
    camioneta.setKilometros(1);
    camioneta.setPrecio(200000000);
    camioneta.encender();
    camioneta.mover(1000);
    camioneta.apagar();

    return camioneta;
    }
}
