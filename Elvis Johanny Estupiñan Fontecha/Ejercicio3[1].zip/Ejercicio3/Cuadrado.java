package Ejercicio3;
//herencia
public class Cuadrado extends Geometricas{

}




