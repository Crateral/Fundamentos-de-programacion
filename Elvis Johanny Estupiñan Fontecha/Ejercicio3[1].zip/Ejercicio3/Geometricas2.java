package Ejercicio3;

public class Geometricas2 {
    public static void main(String[] args) {

        System.out.println("los datos son: " +datos());
    }
        public static Cuadrado datos(){

        Cuadrado cuadrado=new Cuadrado();//instanciar clases
        cuadrado.setNombre("cuadrado");
        cuadrado.setNumeroVertices(4);

        return cuadrado;
    }

}