package EjercicioEmpleados;

public class Empleados extends GestionHumana {
}
