package EjercicioEmpleados;

public class Empresa {
    public static void main(String[] args) {

        System.out.println("los datos son: "+datos()+"\n"+datos2());
    }

    public static Empleados datos() {

        Empleados empleados = new Empleados();
        empleados.setAsistenteAdmin("Laura Camila Perez");
        empleados.setRecepcionista("Manuela Gomez");
        empleados.setMensajero("Carlos Rodriguez");
        return empleados;
    }


    public static Empleados2 datos2(){

        Empleados2 empleados2=new Empleados2();
        empleados2.setTransportePasajeros("El Sol S.A");
        empleados2.setNumeroConductores(3);
        return empleados2;

    }

}
