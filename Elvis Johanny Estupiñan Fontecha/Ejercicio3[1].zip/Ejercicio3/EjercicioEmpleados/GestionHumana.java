package EjercicioEmpleados;

public class GestionHumana {

    private String asistenteAdmin;
    private String recepcionista;
    private String mensajero;

    public GestionHumana() {
    }

    public String getAsistenteAdmin() {
        return asistenteAdmin;
    }

    public void setAsistenteAdmin(String asistenteAdmin) {
        this.asistenteAdmin = asistenteAdmin;
    }

    public String getRecepcionista() {
        return recepcionista;
    }

    public void setRecepcionista(String recepcionista) {
        this.recepcionista = recepcionista;
    }

    public String getMensajero() {
        return mensajero;
    }

    public void setMensajero(String mensajero) {
        this.mensajero = mensajero;
    }

    @Override
    public String toString() {
        return "GestionHumana{" +
                "asistenteAdmin='" + asistenteAdmin + '\'' +
                ", recepcionista='" + recepcionista + '\'' +
                ", mensajero='" + mensajero + '\'' +
                '}';
    }
}
