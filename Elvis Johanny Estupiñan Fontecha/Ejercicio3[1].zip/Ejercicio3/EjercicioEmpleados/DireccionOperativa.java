package EjercicioEmpleados;

public class DireccionOperativa {

    private String transportePasajeros;
    private Integer numeroConductores;

    public DireccionOperativa() {
    }

    public String getTransportePasajeros() {
        return transportePasajeros;
    }

    public void setTransportePasajeros(String transportePasajeros) {
        this.transportePasajeros = transportePasajeros;
    }

    public Integer getNumeroConductores() {
        return numeroConductores;
    }

    public void setNumeroConductores(Integer numeroConductores) {
        this.numeroConductores = numeroConductores;
    }

    @Override
    public String toString() {
        return "DireccionOperativa{" +
                "transportePasajeros='" + transportePasajeros + '\'' +
                ", numeroConductores=" + numeroConductores +
                '}';
    }
}
