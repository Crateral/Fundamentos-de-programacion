package EjercicioEmpleados;

public class Empleados2 extends DireccionOperativa{
}
