package Ejercicio3;

public class Geometricas {

    private String nombre;
    private Integer numeroVertices;


    public Geometricas() {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Integer getNumeroVertices() {
        return numeroVertices;
    }

    public void setNumeroVertices(Integer numeroVertices) {
        this.numeroVertices = numeroVertices;
    }

    @Override
    public String toString() {
        return "Geometricas{" +
                "nombre='" + nombre + '\'' +
                ", numeroVertices=" + numeroVertices +
                '}';
    }
}
