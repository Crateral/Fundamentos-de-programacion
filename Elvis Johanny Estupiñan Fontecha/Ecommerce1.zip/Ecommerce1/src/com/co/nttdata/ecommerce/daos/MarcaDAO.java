package com.co.nttdata.ecommerce.daos;

import com.co.nttdata.ecommerce.entidades.Marca;
import com.co.nttdata.ecommerce.utils.Conexion;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MarcaDAO {
    Scanner entrada = new Scanner(System.in);
    Conexion conexion = new Conexion();
    public List<Marca> consultarMarca () {

        Connection baseDatos = conexion.conectarBD();
        Statement st = null;
        ResultSet rs = null;

        List<Marca> listaMarcas = new ArrayList<Marca>();

        try {
            st = baseDatos.createStatement();
            rs = st.executeQuery("select * from tbl_marca");

            while (rs.next()) {
                Marca marca = new Marca();
                marca.setId_marca(rs.getInt("id_marca"));
                marca.setMarca(rs.getString("Marca"));
                marca.setDescripcion(rs.getString("Descripcion"));

                listaMarcas.add(marca);

            }
        }catch (Exception e){
            System.err.println(e.getMessage());
        }finally{
            try{
                rs.close();
                st.close();
                conexion.desconectarBD(baseDatos);
            }catch (SQLException e){
                e.printStackTrace();
            }
        }
        return listaMarcas;
    }

    public void agregar(Marca marca) {

        Connection baseDatos = conexion.conectarBD();
        PreparedStatement st = null;

        try {

            st = baseDatos.prepareStatement("INSERT INTO public.tbl_marcas(" +" marca, descripcion)"
                    + "VALUES (?, ?);");

            st.setString(1, marca.getMarca());
            st.setString(2, marca.getDescripcion());
            st.executeUpdate();

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {

                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }

    }


    public void buscar(String Marca) {
        Connection baseDatos = conexion.conectarBD();
        PreparedStatement st = null;
        ResultSet rs = null;

        try {

            st = baseDatos.prepareStatement("select * from tbl_marca where Marca =?");

            st.setString(1, Marca);
            rs = st.executeQuery();

            while (rs.next()) {
                Marca marca = new Marca();
                marca.setId_marca((rs.getInt("id_marca")));
                marca.setMarca(rs.getString("marca"));
                marca.setDescripcion(rs.getString("descripcion"));
                System.out.println("id_marca: " + marca.getId_marca());
                System.out.println("Marca: " + marca.getMarca());
                System.out.println("Descripcion: " + marca.getDescripcion());

            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                rs.close();
                st.close();
                baseDatos.close();

            } catch (SQLException e) {
                System.out.println();
            }
        }

    }

    public Marca eliminar(int marca) {
        Marca m = new Marca();

        Connection baseDatos = conexion.conectarBD();
        PreparedStatement st = null;

        System.out.print("\nDesea eliminar la Marca (si/no) ? : ");
        String rg = entrada.next();
        if (rg.equals("si")) {
            try {
                st = baseDatos.prepareStatement("delete from tbl_marca where id_marca = ? ");
                st.setInt(1, marca);
                int val = st.executeUpdate();

                if (val > 0)
                    System.out.println("\nSe eliminado con éxito...");
                else
                    System.err.println("\nError al eliminar");

            } catch (Exception e) {
                System.err.println(e.getMessage());
            } finally {
                try {
                    st.close();
                    baseDatos.close();
                } catch (Exception e2) {
                    System.err.println();
                }
            }

        } else if (rg.equals("no")) {
            System.out.println("\nSeleccionó no eliminar Marca... !");
        }
        return m;
    }
}
