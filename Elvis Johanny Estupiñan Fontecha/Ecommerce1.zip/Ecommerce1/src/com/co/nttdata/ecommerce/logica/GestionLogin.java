package com.co.nttdata.ecommerce.logica;

import com.co.nttdata.ecommerce.entidades.Cliente;
import com.co.nttdata.ecommerce.entidades.Usuario;

import java.util.Scanner;

public class GestionLogin {
    Scanner entrada = new Scanner(System.in);
    String usuarioEscanner;
    String contraseniaEscaner;
    //System.out.println(usuario.getNombreUsuario() + " " + usuario.getContrasenia());// prueba

    int registroId;

    public void registrUsuario(Usuario usuario, Cliente usuario1) {
        int opcion1 = 0;

        System.out.println("Registrarse como: [1] Administrador  [2] Cliente");
        opcion1 = entrada.nextInt();
        String registroAdministrador;
        String registroUsuario;


        switch (opcion1) {
            case 1:
                System.out.println("Digite su número de Cédula");
                registroId = entrada.nextInt();
                usuario.setIdAdministrador(registroId);
                System.out.print("Digite nombre de Administrador: ");
                registroAdministrador = entrada.next();
                usuario.setNombreAdministrador(registroAdministrador);
                System.out.print("Digite contraseña de Administrador: ");
                registroAdministrador = entrada.next();
                usuario.setContraseniaAdministrador(registroAdministrador);
                System.out.println("Registro EXitoso");
                break;

            case 2:
                System.out.println("Digite su número de Cédula");
                registroId = entrada.nextInt();
                usuario1.setId(registroId);
                System.out.print("Digite su nombre de Usuario: ");
                registroUsuario = entrada.next();
                usuario1.setNombreUsuario(registroUsuario);
                System.out.print("Digite su Contraseña: ");
                registroUsuario = entrada.next();
                usuario1.setContrasenia(registroUsuario);
                System.out.println("Registro EXitoso");
                break;

            default:
                break;
        }
    }

    public void inicioDeSesion(Usuario usuario, Cliente usuario1) {
        int opcion = 0;
        System.out.println("INICIAR SESION como: [1] Administrador [2] Cliente");
        opcion = entrada.nextInt();
        switch (opcion) {
            case 1:
                System.out.println("|👨🏻|   Ingrese usuario Administrador");
                usuarioEscanner = entrada.next();
                System.out.println("|🗝|Ingrese contraseña");
                contraseniaEscaner = entrada.next();

                if (usuario.getNombreAdministrador().equals(usuarioEscanner) && usuario.getContraseniaAdministrador().
                        equals(contraseniaEscaner)) {
                    System.out.println("👨🏻‍💻 Bienvenido Administrador " + usuario.getNombreAdministrador());
                } else {
                    System.out.println("usuario o contraseña incorrectos");
                }
                break;

            case 2:
                System.out.print("|🧑🏻| Ingrese usuario Cliente: ");
                usuarioEscanner = entrada.next();
                System.out.print("|🗝| Ingrese contraseña: ");
                contraseniaEscaner = entrada.next();

                if (usuario1.getNombreUsuario().equals(usuarioEscanner) && usuario1.getContrasenia().equals
                        (contraseniaEscaner)) {
                    System.out.println("\n🎇 Sesion iniciada 🎇");
                } else {
                    System.out.println("\n❌ Usuario o contraseña incorrectos ❌");
                }
                break;

            default:
                break;
        }
    }

    public void recuperarContraseña(Usuario usuario, Cliente usuario1) {
        int opcion2 = 0;
        //usuario.settDatos();
        System.out.println("Seleccione para recuperar contraseña: [1] Administrador [2] Cliente");
        opcion2 = entrada.nextInt();
        String nuevaContraseña;

        switch (opcion2) {
            case 1:
                System.out.println("Digite número de Cédula");
                registroId = entrada.nextInt();

                if (usuario.getIdAdministrador() == registroId) {
                    System.out.println("Digite la nueva contraseña");
                    nuevaContraseña = entrada.next();
                    usuario.setContraseniaAdministrador(nuevaContraseña);
                    System.out.println("La contraseña se ha actualizado");
                } else {
                    System.out.println("Usuario no encontrado");
                }
                break;

            case 2:
                System.out.println("Digite número de Cedula");
                registroId = entrada.nextInt();

                if (usuario1.getId() == registroId) {
                    System.out.println("Digite la nueva Contraseña");
                    nuevaContraseña = entrada.next();
                    usuario1.setContrasenia(nuevaContraseña);
                    System.out.println("La contraseña se ha actualizado");
                } else {
                    System.out.println("Usuario no encontrado");
                }
                break;
            default:
                break;
        }
    }

    public void cerrarCesion(){
        System.out.println("Proceso finalizado");
        System.exit(0);
    }

}
