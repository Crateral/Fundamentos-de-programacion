package com.co.nttdata.ecommerce.entidades;

public class Administrador {

    private int idAdministrador;
    private String nombreAdministrador;
    private String contraseniaAdministrador;
    private String correo;
    private boolean estado;
    private String numeroIdentificacion;
    private String tipoIdentificacion;

    public Administrador() {
        super();
    }

    public Administrador(int id, String nombreUsuario, String contrasenia, int idAdministrador,
                         String nombreAdministrador, String contraseniaAdministrador, String correo,
                         boolean estado, String numeroIdentificacion, String tipoIdentificacion) {
        super();
        this.idAdministrador = idAdministrador;
        this.nombreAdministrador = nombreAdministrador;
        this.contraseniaAdministrador = contraseniaAdministrador;
        this.correo = correo;
        this.estado = estado;
        this.numeroIdentificacion = numeroIdentificacion;
        this.tipoIdentificacion = tipoIdentificacion;
    }

    public Administrador(int id, String nombreUsuario, String contrasenia) {
        super();
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public String getNumeroIdentificacion() {
        return numeroIdentificacion;
    }

    public void setNumeroIdentificacion(String numeroIdentificacion) {
        this.numeroIdentificacion = numeroIdentificacion;
    }

    public String getTipoIdentificacion() {
        return tipoIdentificacion;
    }

    public void setTipoIdentificacion(String tipoIdentificacion) {
        this.tipoIdentificacion = tipoIdentificacion;
    }

    public int getIdAdministrador() {
        return idAdministrador;
    }

    public void setIdAdministrador(int idAdministrador) {
        this.idAdministrador = idAdministrador;
    }

    public String getNombreAdministrador() {
        return nombreAdministrador;
    }

    public void setNombreAdministrador(String nombreAdministrador) {
        this.nombreAdministrador = nombreAdministrador;
    }

    public String getContraseniaAdministrador() {
        return contraseniaAdministrador;
    }

    public void setContraseniaAdministrador(String contraseniaAdministrador) {
        this.contraseniaAdministrador = contraseniaAdministrador;
    }
}
