package com.co.nttdata.ecommerce.logica;

import com.co.nttdata.ecommerce.entidades.CarritoDeCompras;
import com.co.nttdata.ecommerce.entidades.Cliente;
import com.co.nttdata.ecommerce.entidades.Empresa;
import com.co.nttdata.ecommerce.entidades.Factura;


public class GestionFactura {
    Factura f = new Factura();

    public Factura pagar(Cliente usuario1, CarritoDeCompras cdc,GestionCarritoDeCompras gcdc) {

        f.setCliente(usuario1);
        f.setDescripcion("Mi primera factura");
        f.setIdFactura(123123);
        f.setProductos(cdc);
        f.setCliente(usuario1);
        f.setValorTotalConIva(cdc.getSubTotalConIva() + cdc.getValorEnvio());
        f.setValorDeEnvio(gcdc.calcularCostoEnvio(cdc,usuario1,gcdc));
        return f;
    }

    public void imprimirFactura(CarritoDeCompras cdc, GestionCarritoDeCompras gcdc, Empresa ecommerce, Cliente cliente){

        System.out.println("\n");
        System.out.println("------------------------------------------------------------------");
        System.out.format("%50s","NUMERO FACTURA: "+ f.getIdFactura());
        System.out.println("\n------------------------------------------------------------------");
        System.out.format("DATOS DEL CLIENTE: ");
        System.out.println();
        System.out.format("\nNombre:"+"%15s"," " + f.getCliente().getNombreUsuario()+"\n");
        System.out.format("Correo: "+"%22s"," " +f.getCliente().getCorreo() +"\n");
        System.out.format("Ciudad: "+"%12s"," " +f.getCliente().getCiudad()+"\n");
        System.out.format("Direccion: "+"%18s"," " +f.getCliente().getDireccion()+"\n");
        System.out.format("Telefono: "+"%14s"," " +f.getCliente().getTelefono()+"\n");
        System.out.println("\n");

        System.out.println("PRODUCTOS:\n");
        System.out.println(f.getProductos(cdc));
        System.out.println("\n");
        System.out.format("Valor total con IVA: " +"%14s"," " + f.getValorTotalConIva()+"\n");
        System.out.format("Valor Envio: " +"%20s"," " + f.getValorDeEnvio()+"\n");
        System.out.format("Total a Pagar: " +"%20s"," " +(f.getValorTotalConIva()+f.getValorDeEnvio())+"\n");
        System.out.println("--------------------------------");

    }
}
