package com.co.nttdata.ecommerce.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {

    private static final String url = "jdbc:mysql://localhost:3306/ecommerce";
    private static final String usuario = "root";
    private static final String contrasena = "12345";


    public Connection conectarBD() {
        Connection baseDatos = null;

        try {
            baseDatos = DriverManager.getConnection(url, usuario, contrasena);
        } catch (Exception e) {
            System.out.println("Error : " + e.getMessage());
        }
        return baseDatos;
    }


    public void desconectarBD(Connection baseDatos) {

        try {
            baseDatos.close();
        } catch (Exception e) {
            System.out.println("Error : " + e.getMessage());
        }

    }
}
