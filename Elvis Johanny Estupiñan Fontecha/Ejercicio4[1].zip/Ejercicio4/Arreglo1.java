package Ejercicio4;

import java.lang.reflect.Array;
import java.util.Arrays;

public class Arreglo1 {

    public static void main(String[] args) {

        int[] arreglo = {7, 4, 2, 1, 10, 5, 6};
        Arrays.sort(arreglo);
        System.out.println("\nOrden de menor a mayor: \n");
        for (int i = 0; i < arreglo.length; i++) {
            System.out.println("" + arreglo[i]);
        }

            System.out.println("\n Orden de mayor a menor: \n");
            int[] numeros = {7, 4, 2, 1, 10, 5, 6};
            Arrays.sort(numeros);
            for (int j = numeros.length - 1; j >= 0; j--) {
                System.out.println("" + numeros[j]);
            }
        }

}