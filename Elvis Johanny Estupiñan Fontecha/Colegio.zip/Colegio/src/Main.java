import com.co.nttdata.colegio.entidades.Profesor;
import com.co.nttdata.colegio.util.NotasUtil;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);
        int opcion;

        Profesor profesor = new Profesor();
        profesor.setIdProfesor(1000695487);
        profesor.setNombreProfesor("Johanny Estupiñan");
        profesor.setMateriaDictada("Sistemas");
        NotasUtil notasUtil = new NotasUtil();


        NotasUtil notas = new NotasUtil();

        do {
            System.out.println("-------------------------------");
            System.out.println("1. Datos profesor ");
            System.out.println("2. Promedio cursos ");
            System.out.println("3. Imprimir informe");
            System.out.println("4. Salir");
            System.out.println("-------------------------------");
            System.out.println("-  Ingresa la opcion");
            System.out.println("-------------------------------");
            opcion = entrada.nextInt();

            switch (opcion) {

                case 1:
                    System.out.println(profesor.getIdProfesor() + "\n" + profesor.getNombreProfesor() + "\n" +
                            profesor.getMateriaDictada()
                    );
                    break;

                case 2:
                    notas.promedioNotas();
                    notasUtil.promedioNotas();
                    break;

                case 3:
                    notas.imprimirInformes();
                    break;

                case 4:
                    System.out.println("Proceso finalizado");
                    System.exit(0);
                    break;
            }


        } while (opcion < 6);
        System.out.println("Opcion no valida");

    }

}



