import com.co.nttdata.colegio.entidades.Curso;
import com.co.nttdata.colegio.entidades.Estudiante;
import com.co.nttdata.colegio.entidades.Notas;
import com.co.nttdata.colegio.entidades.Profesor;
import com.co.nttdata.colegio.logica.GestionDatos;
import com.co.nttdata.colegio.util.NotasUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);
        int opcion;
        List<Curso> cursoList = new ArrayList<>();
        GestionDatos gestionDatos = new GestionDatos();
        NotasUtil notasUtil = new NotasUtil();
        Profesor profesor = new Profesor();
        profesor.setIdProfesor(1000695487);
        profesor.setNombreProfesor("Johanny Estupiñan");
        profesor.setMateriaDictada("Sistemas");

        do {
            System.out.println("-------------------------------");
            System.out.println("1. Datos profesor ");
            System.out.println("2. Cargar notas ");
            System.out.println("3. Editar notas");
            System.out.println("4. Calcular promedio");
            System.out.println("5. Imprimir informe");
            System.out.println("6. Salir");
            System.out.println("-------------------------------");
            System.out.println("-  Ingresa la opcion");
            System.out.println("-------------------------------");
            opcion = entrada.nextInt();

            switch (opcion) {

                case 1:
                    System.out.println(profesor.getIdProfesor() + "\n" + profesor.getNombreProfesor() + "\n" +
                            profesor.getMateriaDictada());
                    break;

                case 2:
                    List<String> ls = new ArrayList<>();
                    ls = notasUtil.leerArchivo();
                    cursoList = gestionDatos.agregarCurso(ls);
                    break;

                case 3:
                    System.out.println("Digite el numero de documento");
                    int numDocumento = entrada.nextInt();
                    gestionDatos.cambiarNotas(cursoList, numDocumento);
                    break;

                case 4:
                    gestionDatos.calcularPromedio(cursoList);
                    break;
                case 5:
                    System.out.println("Proceso finalizado");
                    System.exit(0);
                    break;
            }


        } while (opcion < 6);
        System.out.println("Opcion no valida");

    }

}



