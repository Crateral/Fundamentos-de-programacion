package com.co.nttdata.colegio.logica;

import com.co.nttdata.colegio.entidades.*;
import com.co.nttdata.colegio.interfaces.IGestionDatos;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class GestionDatos implements IGestionDatos {

    @Override
    public List<Curso> agregarCurso(List<String> listaCursos) {
        List<Curso> cursoList = new ArrayList<>();

        for (String curso : listaCursos) {
            Notas nota1 = new Notas();
            Notas nota2 = new Notas();
            Notas nota3 = new Notas();
            Estudiante estudiante = new Estudiante();
            Curso curso1 = new Curso();

            List<Notas> listaNotas = new ArrayList<>();
            List<Estudiante> listaEstudiantes = new ArrayList<>();

            String notas[] = curso.split(",");

            nota1.setNota(Double.parseDouble(notas[4]));
            nota1.setObservaciones(notas[5]);
            nota2.setNota(Double.parseDouble(notas[6]));
            nota2.setObservaciones(notas[7]);
            nota3.setNota(Double.parseDouble(notas[8]));
            nota3.setObservaciones(notas[9]);

            Profesor profesor = new Profesor();
            profesor.setIdProfesor(1000695487);
            profesor.setNombreProfesor("Johanny Estupiñan");
            profesor.setMateriaDictada("Sistemas");

            Data data = new Data();
            data.setProfesor(profesor);

            listaNotas.add(nota1);
            listaNotas.add(nota2);
            listaNotas.add(nota3);

            estudiante.setCodigoEstudiante(Integer.parseInt(notas[3]));
            estudiante.setNombreEstudiante(notas[2]);
            estudiante.setListaNotas(listaNotas);

            listaEstudiantes.add(estudiante);

            curso1.setIdCurso(Integer.parseInt(notas[0]));
            curso1.setListaEstudiantes(listaEstudiantes);

            cursoList.add(curso1);
        }
        System.out.println(cursoList.toString());
        return cursoList;
    }

    @Override
    public void cambiarNotas(List<Curso> listaCurso, Integer codigoEstudiante) {
        Scanner input = new Scanner(System.in);
        int p=0;

        for (int i = 0; i < listaCurso.size(); i++) {
            for (int j = 0; j < listaCurso.get(i).getListaEstudiantes().size(); j++) {
                if (listaCurso.get(i).getListaEstudiantes().get(j).getCodigoEstudiante() == codigoEstudiante) {
                    System.out.println("Lista de notas " + listaCurso.get(i).getListaEstudiantes().get(j).getListaNotas());

                    List<Notas> notasList = listaCurso.get(i).getListaEstudiantes().get(j).getListaNotas();
                    System.out.println("Digite la nota que desea modificar: ");
                    int posicion = input.nextInt();

                    for (int k = 0; k < notasList.size(); k++) {
                        if (posicion == (p + 1)) {
                            System.out.println("La nota a cambiar esta en la posicion: " + (p) + " : "
                                    + notasList.get(k).getNota() + " Observacion: "
                                    + notasList.get(k).getObservaciones());

                            System.out.println("ingresa la nueva nota");
                            notasList.get(p).setNota(input.nextDouble());
                        }
                        p++;
                    }
                }
            }

        }
    }

    @Override
    public void calcularPromedio(List<Curso> listaCurso) {
        Estudiante estudiante = new Estudiante();
        Profesor profesor = new Profesor();
        Data data = new Data();

        for (int l = 0; l < listaCurso.size(); l++) {
            List<Estudiante> listaEstudiante = listaCurso.get(l).getListaEstudiantes();

            for (int i=0;i<listaEstudiante.size();i++){
                double notas = 0,promedio=0;
                List<Notas> notasList = listaEstudiante.get(i).getListaNotas();

                for (int j=0;j<notasList.size();j++){
                    notas=notas+ notasList.get(j).getNota() ;
                }
                promedio=notas/3;
                estudiante.setPromedio(promedio);
                if(promedio<3){
                    estudiante.setAprobado(false);
                }else {
                    estudiante.setAprobado(true);
                }
                //Imprime los datos
                System.out.println(listaEstudiante.get(i).getNombreEstudiante() + " ");
                for (int k=0; k<notasList.size();k++){
                    System.out.println(notasList.get(k) + " " + notasList.get(k).getObservaciones() + ", ");
                }
                System.out.println(+ estudiante.getPromedio() + " "
                            + "Esta aprobado?: "+ estudiante.isAprobado() + " ");
            }
        }


    }
}
