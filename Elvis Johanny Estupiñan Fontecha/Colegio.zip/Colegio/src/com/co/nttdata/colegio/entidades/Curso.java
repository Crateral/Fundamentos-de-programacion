package com.co.nttdata.colegio.entidades;

import java.util.List;
public class Curso {
    private List<Estudiante> listaEstudiantes;
    private int idCurso;

    public Curso() {
    }

    public Curso(List<Estudiante> listaEstudiantes) {
        this.listaEstudiantes = listaEstudiantes;
    }

    public List<Estudiante> getListaEstudiantes() {
        return listaEstudiantes;
    }

    public void setListaEstudiantes(List<Estudiante> listaEstudiantes) {
        this.listaEstudiantes = listaEstudiantes;
    }

    public int getIdCurso() {
        return idCurso;
    }

    public void setIdCurso(int idCurso) {
        this.idCurso = idCurso;
    }

    @Override
    public String toString() {
        return "Curso{" +
                "listaEstudiantes=" + listaEstudiantes +
                ", idCurso=" + idCurso +
                '}';
    }
}
