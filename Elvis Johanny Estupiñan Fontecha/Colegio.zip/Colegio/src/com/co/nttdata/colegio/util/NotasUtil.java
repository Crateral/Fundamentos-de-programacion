package com.co.nttdata.colegio.util;

import com.co.nttdata.colegio.entidades.Curso;
import com.co.nttdata.colegio.entidades.Estudiante;
import com.co.nttdata.colegio.entidades.Notas;
import com.co.nttdata.colegio.entidades.Profesor;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class NotasUtil {


    public List<String> leerArchivo() {
        List<String> listaDatos = new ArrayList<>();
        String cursos;
        Scanner sc = new Scanner(System.in);
        System.out.println("digite el curso que desea consultar ");
        cursos = sc.nextLine();

        File archivo = new File("C:\\Users\\eestupin\\Documents\\COLEGIO\\" + cursos + ".txt");
        Scanner input = null;

        try {
            input = new Scanner(archivo);

            while (input.hasNextLine()) {
                String linea = input.nextLine();
                listaDatos.add(linea);
            }
        } catch (Exception e) {
            System.out.println("Error al leer archivo " + e.getMessage());
        } finally {
            try {
                if (input != null)
                    input.close();
            } catch (Exception e2) {
                System.out.println("Error al cerrar la lectura del archivo " + e2.getMessage());
            }
        }

        return listaDatos;
    }
}
