package com.co.nttdata.colegio.util;

import com.co.nttdata.colegio.entidades.Curso;
import com.co.nttdata.colegio.entidades.Estudiante;
import com.co.nttdata.colegio.entidades.Notas;
import com.co.nttdata.colegio.entidades.Profesor;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class NotasUtil {
    List<Estudiante> estudianteList = new ArrayList<>();

    public List<Curso> promedioNotas() {
        String cursos;
        Scanner sc = new Scanner(System.in);
        System.out.println("\ndigite el curso que desea consultar agregando .txt al final: ");
        cursos = sc.nextLine();

        File archivo = new File("C:\\Users\\eestupin\\Documents\\COLEGIO\\" + cursos);
        Scanner input = null;
        Curso curso = new Curso();
        Notas notas = new Notas();
        Notas notas2 = new Notas();
        Notas notas3 = new Notas();
        Estudiante estudiante = new Estudiante();
        Profesor profesor = new Profesor();
        List<Curso> cursoList = new ArrayList<>();

        List<Notas> notaList = new ArrayList<>();

        try {
            input = new Scanner(archivo);

            while (input.hasNextLine()) {
                String linea = input.nextLine();
                //arreglo
                String[] parts = linea.split(",");

                profesor.setMateriaDictada(parts[1]);
                notas.setNota(Double.parseDouble(parts[4]));
                notas.setObservaciones(parts[5]);
                notas2.setNota(Double.parseDouble(parts[6]));
                notas2.setObservaciones(parts[7]);
                notas3.setNota(Double.parseDouble(parts[8]));
                notas3.setObservaciones(parts[9]);
                //Agregar notas a lista
                notaList.add(notas);
                notaList.add(notas2);
                notaList.add(notas3);

                estudiante.setCodigoEstudiante(Integer.parseInt(parts[3]));
                estudiante.setNombreEstudiante(parts[2]);
                estudiante.setListaNotas(notaList);
                estudianteList.add(estudiante);

                curso.setListaEstudiantes(estudianteList);
                curso.setIdCurso(Integer.parseInt(parts[0]));


                //Añade todos los datos al curso
                cursoList.add(curso);

                double promedio = 0.0;
                promedio = (notas.getNota() + notas2.getNota() + notas3.getNota()) / 3;
                promedio = (double) Math.round(promedio * 10d) / 10d;
                estudiante.setPromedio(promedio);
                //System.out.printf("%.1f ", promedio);

                if (promedio < 3.0) {
                    estudiante.setAprobado(false);
                } else {
                    estudiante.setAprobado(true);
                }

                System.out.println(estudiante.getNombreEstudiante() + " " + profesor.getMateriaDictada() + " "
                        + notas.getNota() + " " + notas.getObservaciones() + ", "
                        + notas2.getNota() + " " + notas2.getObservaciones() + ", "
                        + notas3.getNota() + " " + notas3.getObservaciones() + ", " + estudiante.getPromedio() + " "
                        + estudiante.isAprobado()
                        + " ");
            }
        } catch (Exception e) {
            System.out.println("Error al leer archivo " + e.getMessage());
        } finally {
            try {
                if (input != null)
                    input.close();
            } catch (Exception e2) {
                System.out.println("Error al cerrar la lectura del archivo " + e2.getMessage());
            }
        }
        return cursoList;
    }

}
