package com.co.nttdata.colegio.entidades;

import java.util.List;

public class Data {
    private List<Curso> listaCursos;
    private Profesor profesor;

    public Data() {
    }

    public Data(List<Curso> listaCursos, Profesor profesor) {
        this.listaCursos = listaCursos;
        this.profesor = profesor;
    }

    public List<Curso> getListaCursos() {
        return listaCursos;
    }

    public void setListaCursos(List<Curso> listaCursos) {
        this.listaCursos = listaCursos;
    }

    public Profesor getProfesor() {
        return profesor;
    }

    public void setProfesor(Profesor profesor) {
        this.profesor = profesor;
    }

    @Override
    public String toString() {
        return "Data{" +
                "listaCursos=" + listaCursos +
                ", profesor=" + profesor +
                '}';
    }
}
