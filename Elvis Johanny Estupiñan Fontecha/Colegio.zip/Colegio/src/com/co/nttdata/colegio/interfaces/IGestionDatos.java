package com.co.nttdata.colegio.interfaces;

import com.co.nttdata.colegio.entidades.Curso;
import com.co.nttdata.colegio.entidades.Estudiante;

import java.util.List;

public interface IGestionDatos {

    List<Curso> agregarCurso(List<String> listaCursos);
    void cambiarNotas(List<Curso> listaCurso, Integer codigoEstudiante);
    void calcularPromedio(List<Curso> listaCursos);

}
