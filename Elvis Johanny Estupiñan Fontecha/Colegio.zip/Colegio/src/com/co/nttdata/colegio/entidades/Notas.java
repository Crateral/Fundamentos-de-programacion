package com.co.nttdata.colegio.entidades;

public class Notas {

    private double nota;
    private String observaciones;

    public Notas() {
    }

    public Notas(double nota, String observaciones) {
        this.nota = nota;
        this.observaciones = observaciones;
    }

    public double getNota() {
        return nota;
    }

    public void setNota(double nota) {
        this.nota = nota;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    @Override
    public String toString() {
        return "Notas{" +
                "nota=" + nota +
                ", observaciones='" + observaciones + '\'' +
                '}';
    }
}
