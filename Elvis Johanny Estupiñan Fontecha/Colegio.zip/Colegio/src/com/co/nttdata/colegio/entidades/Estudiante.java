package com.co.nttdata.colegio.entidades;

import java.util.List;

public class Estudiante {

    private int codigoEstudiante;
    private String nombreEstudiante;
    private List<Notas> listaNotas;
    private double promedio;
    private boolean aprobado;

    public Estudiante() {
    }

    public Estudiante(int codigoEstudiante, String nombreEstudiante, List<Notas> listaNotas, double promedio,
                      boolean aprobado) {
        this.codigoEstudiante = codigoEstudiante;
        this.nombreEstudiante = nombreEstudiante;
        this.listaNotas = listaNotas;
        this.promedio = promedio;
        this.aprobado = aprobado;
    }

    public int getCodigoEstudiante() {
        return codigoEstudiante;
    }

    public void setCodigoEstudiante(int codigoEstudiante) {
        this.codigoEstudiante = codigoEstudiante;
    }

    public String getNombreEstudiante() {
        return nombreEstudiante;
    }

    public void setNombreEstudiante(String nombreEstudiante) {
        this.nombreEstudiante = nombreEstudiante;
    }

    public List<Notas> getListaNotas() {
        return listaNotas;
    }

    public void setListaNotas(List<Notas> listaNotas) {
        this.listaNotas = listaNotas;
    }

    public double getPromedio() {
        return promedio;
    }

    public void setPromedio(double promedio) {
        this.promedio = promedio;
    }

    public boolean isAprobado() {
        return aprobado;
    }

    public void setAprobado(boolean aprobado) {
        this.aprobado = aprobado;
    }

    @Override
    public String toString() {
        return "Estudiante{" +
                "codigoEstudiante=" + codigoEstudiante +
                ", nombreEstudiante='" + nombreEstudiante + '\'' +
                ", listaNotas=" + listaNotas +
                ", promedio=" + promedio +
                ", aprobado=" + aprobado +
                '}';
    }
}
