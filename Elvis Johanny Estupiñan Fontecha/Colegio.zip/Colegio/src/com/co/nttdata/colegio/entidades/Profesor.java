package com.co.nttdata.colegio.entidades;

public class Profesor {
    private int idProfesor;
    private String nombreProfesor;
    private String materiaDictada;

    public Profesor() {
    }

    public Profesor(int idProfesor, String nombreProfesor, String materiaDictada) {
        this.idProfesor = idProfesor;
        this.nombreProfesor = nombreProfesor;
        this.materiaDictada = materiaDictada;
    }

    public int getIdProfesor() {
        return idProfesor;
    }

    public void setIdProfesor(int idProfesor) {
        this.idProfesor = idProfesor;
    }

    public String getNombreProfesor() {
        return nombreProfesor;
    }

    public void setNombreProfesor(String nombreProfesor) {
        this.nombreProfesor = nombreProfesor;
    }

    public String getMateriaDictada() {
        return materiaDictada;
    }

    public void setMateriaDictada(String materiaDictada) {
        this.materiaDictada = materiaDictada;
    }

    @Override
    public String toString() {
        return "Profesor{" +
                "idProfesor=" + idProfesor +
                ", nombreProfesor='" + nombreProfesor + '\'' +
                ", materiaDictada='" + materiaDictada + '\'' +
                '}';
    }
}
