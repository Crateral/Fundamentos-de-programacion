package com.co.nttdata.ecommerce.logica;

import com.co.nttdata.ecommerce.entidades.Producto;

import java.util.ArrayList;
import java.util.List;

public class GestionProducto {
    public List<Producto> productos;


    public GestionProducto() {
       productos = new ArrayList<>();

    }

    public void insertar(Producto producto) {

        productos.add(producto);
    }

    public String imprime() {
        for (Producto x : productos) {
            System.out.println(x.toString());
        }
        return null;
    }

    public Producto buscar (int id){

        return productos.get(id);
    }

}
