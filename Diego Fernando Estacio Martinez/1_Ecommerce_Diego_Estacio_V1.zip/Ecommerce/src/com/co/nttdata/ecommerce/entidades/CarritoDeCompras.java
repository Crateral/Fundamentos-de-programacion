package com.co.nttdata.ecommerce.entidades;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CarritoDeCompras {

	private int idCarritoDeCompras;
	private String fecha;
	private List<Producto> productos;
	private double subTotal;
	private double valorEnvio;


	//Se debe cambiar los artibutos del subTotal a:
	// - subTotalConIva y subTotaSinIva
	
	public CarritoDeCompras() {
		this.productos = new ArrayList<>();	
	}
	/*
	public CarritoDeCompras(int idCarritoDeCompras, Date fecha, List<Producto> productos, double subTotal, double valorEnvio) {
		super();
		this.idCarritoDeCompras = idCarritoDeCompras;
		this.fecha = fecha;
		this.productos = productos;
		this.subTotal = subTotal;
		this.valorEnvio = valorEnvio;
	}
	*/

	public CarritoDeCompras(int idCarritoDeCompras,String fecha, List<Producto> productos,double subTotal, double valorEnvio) {
		this.idCarritoDeCompras = idCarritoDeCompras;
		this.fecha = fecha;
		this.productos = productos;
		this.subTotal = subTotal;
		this.valorEnvio = valorEnvio;

	}


	public int getIdCarritoDeCompras() {
		return idCarritoDeCompras;
	}

	public void setIdCarritoDeCompras(int idCarritoDeCompras) {
		this.idCarritoDeCompras = idCarritoDeCompras;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public List<Producto> getProductos() {
		return productos;
	}

	public void setProductos(List<Producto> productos) {
		this.productos = productos;
	}

	public double getSubTotal() {
		return subTotal;
	}

	public void setSubTotal(double subTotal) {
		this.subTotal = subTotal;
	}

	public double getValorEnvio() {
		return valorEnvio;
	}

	public void setValorEnvio(double valorEnvio) {
		this.valorEnvio = valorEnvio;
	}

	@Override
	public String toString() {
		return "CarritoDeCompras{" +
				"idCarritoDeCompras=" + idCarritoDeCompras +
				", fecha='" + fecha + '\'' +
				", productos=" + productos +
				", subTotal=" + subTotal +
				", valorEnvio=" + valorEnvio +
				'}';
	}
}
