package com.co.nttdata.ecommerce.entidades;

public enum Marca {
	
	LG(1, "Marca LG de TVs - Lavadoras"),
	SAMSUNG(2, "Marca Celulares - Computadores"),
	KIA(3, "Marca Vehiculos"),
	REDRAGON(4, "Marca de Sillas - de Teclados"),

	COMPUMAX(5, "Marca de Computadoras");
	
	private int id;
	private String descripcion;
	
	private Marca(int id, String descripcion) {
		this.id = id;
		this.descripcion = descripcion;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}	
	
}
