INSERT INTO GYMV2.Rol (idRol, nombreRol) VALUES (0, "Administrador");
INSERT INTO GYMV2.Rol (idRol, nombreRol) VALUES (1, "Coach");
INSERT INTO GYMV2.Rol (idRol, nombreRol) VALUES (2, "Operador");
INSERT INTO GYMV2.Rol (idRol, nombreRol) VALUES (3, "Cliente");


INSERT INTO GYMV2.NombrePeso (idNombrePeso, NombrePeso) VALUES (0, "Mancuernas");
INSERT INTO GYMV2.NombrePeso (idNombrePeso, NombrePeso) VALUES (1, "Pecho");
INSERT INTO GYMV2.NombrePeso (idNombrePeso, NombrePeso) VALUES (2, "Piernas");


INSERT INTO GYMV2.Usuario (idUsuario, Usuario, contraseniaUsu, nombresUsu, apellidosUsu, celularUsu, correoUsu, acudienteUsu, celAcudienteUsu, EstadoUsu, Rol_idRol) 
VALUES (0, "DIEGO", "DIEGO", "DIEGO", "ESTACIO", "3123456789", "DIEGO@ESTACIO.COM", "JUAN PEREZ", "3987654321", 1, 0);


INSERT INTO GYMV2.Peso (idPeso, peso, NombrePeso_idNombrePeso) VALUES (0, 20, 0);
INSERT INTO GYMV2.Peso (idPeso, peso, NombrePeso_idNombrePeso) VALUES (1, 20, 0);


INSERT INTO GYMV2.RegistroPeso (Usuario_idUsuario, RegistroPeso_idRegistroPeso, fechaRegistroPeso) VALUES (0, 0, 2022-11-08 10:00);
INSERT INTO GYMV2.RegistroPeso (Usuario_idUsuario, RegistroPeso_idRegistroPeso, fechaRegistroPeso) VALUES (0, 1, 2022-11-09 11:00);


INSERT INTO GYMV2.Clase (idClase, nombreClas, fechaInicioClas, fechaFinClas, totalClientesClas) VALUES (0, box, 2022-11-08 10:00, 2022-11-08 12:00, 10);


INSERT INTO GYMV2.Membrecia (idMembrecia, fechaInicioMem, fechaFinMem, estadoMem, Usuario_idUsuario) VALUES (0, 2022-11-08, 2022-12-08, 1, 0);


INSERT INTO GYMV2.Reserva (Clase_idClase, Membrecia_idMembrecia) VALUES (0, 0);
