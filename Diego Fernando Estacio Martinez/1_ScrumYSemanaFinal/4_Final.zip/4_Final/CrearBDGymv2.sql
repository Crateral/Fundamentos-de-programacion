
CREATE SCHEMA GYMV2  ;
USE GYMV2 ;

 
CREATE TABLE IF NOT EXISTS GYMV2.Clase (
  idClase INT NOT NULL,
  nombreClas VARCHAR(45) NOT NULL,
  fechaInicioClas DATETIME NOT NULL,
  fechaFinClas DATETIME NOT NULL,
  totalClientesClas INT NOT NULL,
  PRIMARY KEY (idClase));


CREATE TABLE IF NOT EXISTS GYMV2.Rol (
  idRol INT NOT NULL,
  nombreRol VARCHAR(45) NOT NULL,
  PRIMARY KEY (idRol));


CREATE TABLE IF NOT EXISTS GYMV2.Usuario (
  idUsuario INT NOT NULL,
  Usuario VARCHAR(45) NOT NULL,
  contraseniaUsu VARCHAR(45) NOT NULL,
  nombresUsu VARCHAR(100) NOT NULL,
  apellidosUsu VARCHAR(100) NOT NULL,
  celularUsu VARCHAR(45) NOT NULL,
  correoUsu VARCHAR(45) NOT NULL,
  acudienteUsu VARCHAR(45) NOT NULL,
  celAcudienteUsu VARCHAR(45) NOT NULL,
  EstadoUsu TINYINT NOT NULL,
  Rol_idRol INT NOT NULL,
  PRIMARY KEY (idUsuario, Rol_idRol),
  INDEX fk_Usuario_Rol_idx (Rol_idRol ASC) VISIBLE,
  CONSTRAINT fk_Usuario_Rol
    FOREIGN KEY (Rol_idRol)
    REFERENCES GYMV2.Rol (idRol)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);


CREATE TABLE IF NOT EXISTS GYMV2.Membrecia (
  idMembrecia INT NOT NULL,
  fechaInicioMem DATETIME NOT NULL,
  fechaFinMem DATETIME NOT NULL,
  estadoMem TINYINT NOT NULL,
  Usuario_idUsuario INT NOT NULL,
  PRIMARY KEY (idMembrecia, Usuario_idUsuario),
  INDEX fk_Membrecia_Usuario1_idx (Usuario_idUsuario ASC) VISIBLE,
  CONSTRAINT fk_Membrecia_Usuario1
    FOREIGN KEY (Usuario_idUsuario)
    REFERENCES GYMV2.Usuario (idUsuario)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);


CREATE TABLE IF NOT EXISTS GYMV2.Reserva (
  Clase_idClase INT NOT NULL,
  Membrecia_idMembrecia INT NOT NULL,
  PRIMARY KEY (Clase_idClase, Membrecia_idMembrecia),
  INDEX fk_Usuario_has_Clase_Clase1_idx (Clase_idClase ASC) VISIBLE,
  INDEX fk_Reserva_Membrecia1_idx (Membrecia_idMembrecia ASC) VISIBLE,
  CONSTRAINT fk_Usuario_has_Clase_Clase1
    FOREIGN KEY (Clase_idClase)
    REFERENCES GYMV2.Clase (idClase)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT fk_Reserva_Membrecia1
    FOREIGN KEY (Membrecia_idMembrecia)
    REFERENCES GYMV2.Membrecia (idMembrecia)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);


CREATE TABLE IF NOT EXISTS GYMV2.NombrePeso (
  idNombrePeso INT NOT NULL,
  NombrePeso VARCHAR(45) NOT NULL,
  PRIMARY KEY (idNombrePeso));



CREATE TABLE IF NOT EXISTS GYMV2.Peso (
  idPeso INT NOT NULL,
  peso DOUBLE NOT NULL,
  NombrePeso_idNombrePeso INT NOT NULL,
  PRIMARY KEY (idPeso, NombrePeso_idNombrePeso),
  INDEX fk_Peso_NombrePeso1_idx (NombrePeso_idNombrePeso ASC) VISIBLE,
  CONSTRAINT fk_Peso_NombrePeso1
    FOREIGN KEY (NombrePeso_idNombrePeso)
    REFERENCES GYMV2.NombrePeso (idNombrePeso)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);


CREATE TABLE IF NOT EXISTS GYMV2.Usuario_has_RegistroPeso (
  Usuario_idUsuario INT NOT NULL,
  RegistroPeso_idRegistroPeso INT NOT NULL,
  fechaRegistroPeso DATETIME NOT NULL,
  PRIMARY KEY (Usuario_idUsuario, RegistroPeso_idRegistroPeso),
  INDEX fk_Usuario_has_RegistroPeso_RegistroPeso1_idx (RegistroPeso_idRegistroPeso ASC) VISIBLE,
  INDEX fk_Usuario_has_RegistroPeso_Usuario1_idx (Usuario_idUsuario ASC) VISIBLE,
  CONSTRAINT fk_Usuario_has_RegistroPeso_Usuario1
    FOREIGN KEY (Usuario_idUsuario)
    REFERENCES GYMV2.Usuario (idUsuario)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT fk_Usuario_has_RegistroPeso_RegistroPeso1
    FOREIGN KEY (RegistroPeso_idRegistroPeso)
    REFERENCES GYMV2.Peso (idPeso)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);


