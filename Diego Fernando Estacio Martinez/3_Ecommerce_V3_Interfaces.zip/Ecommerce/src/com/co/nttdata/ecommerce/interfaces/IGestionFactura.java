package com.co.nttdata.ecommerce.interfaces;

import com.co.nttdata.ecommerce.entidades.CarritoDeCompras;
import com.co.nttdata.ecommerce.entidades.Cliente;
import com.co.nttdata.ecommerce.entidades.Factura;

public interface IGestionFactura {
    public Factura pagar(Cliente cliente, CarritoDeCompras cdc, double iva, double valDescuento, double costoEnvio);
    public void imprimir			(Factura fac);
}
