package com.co.nttdata.ecommerce.logica;

import com.co.nttdata.ecommerce.entidades.Cliente;
import com.co.nttdata.ecommerce.entidades.Usuario;
import com.co.nttdata.ecommerce.interfaces.IGestionLogin;
import com.sun.nio.file.ExtendedWatchEventModifier;

public class GestionLogin implements IGestionLogin {
    @Override
    public Usuario registrar(String nombre, String contrasenia, String tipoDocumento, String documento,String correo,
                             String direccion) {
        boolean registro =false;

            Cliente usr=new Cliente();
            usr.setNombreUsuario(nombre);
            usr.setContrasenia(contrasenia);
            usr.setTipoIdentificacion(tipoDocumento);
            usr.setNumeroIdentificacion(documento);
            usr.setCorreo(correo);

        return usr;
    }

    @Override
    public boolean login(String usr, String password) {
        return false;
    }

    @Override
    public String recuperarContrasenia(String usr) {
        return null;
    }

    @Override
    public boolean logout() {
        return false;
    }
}



/*
public Cliente(String correo, String telefono, String direccion, boolean estado, String numeroIdentificacion,
			String tipoIdentificacion, String metodoDePago,String ciudad) {
 */