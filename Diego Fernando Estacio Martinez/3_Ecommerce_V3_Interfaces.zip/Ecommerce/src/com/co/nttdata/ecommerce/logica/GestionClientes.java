package com.co.nttdata.ecommerce.logica;

import com.co.nttdata.ecommerce.entidades.Cliente;
import com.co.nttdata.ecommerce.entidades.Producto;
import com.co.nttdata.ecommerce.interfaces.IGestionClientes;


import java.util.ArrayList;
import java.util.List;

public class GestionClientes implements IGestionClientes {
    int ban=0;
    int ban2=0;

    public List<Cliente> clientes;


    public GestionClientes() {

        clientes = new ArrayList<>();
    }

    public boolean insertar(Cliente cliente) {
        if(buscar(cliente.getNumeroIdentificacion())==0){
            clientes.add(cliente);
            return true;
        }else{
            return false;
        }



    }

    public String imprime() {
        for (Cliente x : clientes) {
            System.out.println(x.toString());
        }
        return null;
    }


    public int buscar (String identificacion){
        for (Cliente x : clientes) {
            if (x.getNumeroIdentificacion().equals(identificacion)){
               ban=1;
               break;
            }
        }
        return ban;

    }

    public int validacionUsuContra(String usuario, String contrasenia){
        for (Cliente x : clientes) {
            if (x.getNombreUsuario().equals(usuario)&&x.getContrasenia().equals(contrasenia)){
                ban2=1;
            }else{
                ban2=0;
            }

        }
        return ban2;

    }



}
