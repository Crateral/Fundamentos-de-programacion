package com.co.nttdata.ecommerce.entidades;

public enum Categoria {

	TELEVISORES(1,"TELEVISORES PISO 3",0d),
	CELULARES(2,"CELULARES PISO2",0.5d),
	VEHICULOS(3,"VEHICULOS PISO 1",0.30d),
	COMPUTADORES(4,"COMPUTADORES PISO 5",0.10d),
	LAVADORAS(5,"LAVADORAS PISO 2",0d),
	SILLASGAMER(6,"SILLA GAMER PISO 5",0d);

	public int getIdCategoria() {
		return idCategoria;
	}

	public void setIdCategoria(int idCategoria) {
		this.idCategoria = idCategoria;
	}

	public String getDescipcionCategoria() {
		return descipcionCategoria;
	}

	public void setDescipcionCategoria(String descipcionCategoria) {
		this.descipcionCategoria = descipcionCategoria;
	}

	public double getDescuento() {
		return descuento;
	}

	public void setDescuento(double descuento) {
		this.descuento = descuento;
	}

	private int idCategoria;
	private String descipcionCategoria;
	double descuento;

	private Categoria(int idCategoria,String descipcionCategoria, double descuento){
		this.idCategoria=idCategoria;
		this.descipcionCategoria=descipcionCategoria;
		this.descuento=descuento;
	}


}