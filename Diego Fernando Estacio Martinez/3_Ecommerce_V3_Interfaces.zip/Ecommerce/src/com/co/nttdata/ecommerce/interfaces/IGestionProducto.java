package com.co.nttdata.ecommerce.interfaces;

import com.co.nttdata.ecommerce.entidades.Producto;

public interface IGestionProducto {


    public void insertar(Producto producto);
    public String imprime();
    public Producto buscar (int id);
}
