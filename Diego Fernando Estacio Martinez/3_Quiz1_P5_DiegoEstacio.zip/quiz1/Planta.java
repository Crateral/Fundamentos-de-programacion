/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package quiz1;

import java.time.*;

/**
 *
 * @author DIEGO ESTACIO
 */
public class Planta {

    private double altura;
    private boolean daFruto;
    private boolean tieneFlores;
    private String fechaNacimiento;

    
    public Planta(double altura, boolean daFruto, boolean tieneFlores, String fechaNacimiento) {
        this.altura = altura;
        this.daFruto = daFruto;
        this.tieneFlores = tieneFlores;
        this.fechaNacimiento = fechaNacimiento;
    }


  
    public void setAltura(Integer altura){
        this.altura =altura;
    }
    public double getAltura(){
        return altura;
    }
 
    public void setDaFruto(boolean daFruto) {
        this.daFruto = daFruto;
    }
    
    public boolean getDaFruto() {
        return daFruto;
    }

    
    public void setTieneFlores(boolean tieneFlores) {
        this.tieneFlores = tieneFlores;
    }


    public boolean getTieneFlores() {
        return tieneFlores;
    }
    
    
    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }
    
    public void fechaFallecimiento(String fechaFallecimiento){
        /*
        Pasar fecha en string aa/mm/dd a tipo date y compara con 
        la fecha de hoy
        */
    }
 

    public String imprimir(){
        return " Altura: "+altura+" da Fruto: "+daFruto+" tiene Flores"+tieneFlores;
    }
    
}
