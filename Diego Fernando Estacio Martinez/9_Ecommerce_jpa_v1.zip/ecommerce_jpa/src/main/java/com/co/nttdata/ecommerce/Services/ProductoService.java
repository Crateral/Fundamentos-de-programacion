package com.co.nttdata.ecommerce.Services;

import javax.jws.WebMethod;
import javax.jws.WebService;

import com.co.nttdata.ecommerce.entidades.TblProducto;
@WebService
public interface ProductoService {
	@WebMethod
	 public TblProducto findById(int idProductos);
	

}
