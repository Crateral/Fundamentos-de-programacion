package com.co.ntttdata.ecommerce.ServiceImpl;

import java.util.List;

import javax.jws.WebService;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.co.nttdata.ecommerce.Daos.MarcaDao;
import com.co.nttdata.ecommerce.Services.MarcaService;
import com.co.nttdata.ecommerce.entidades.TblMarca;

@WebService(endpointInterface = "com.co.nttdata.ecommerce.Services.MarcaService")
public class MarcaServiceImpl  implements MarcaService{

	public  final String PERSISTENCE_UNIT_NAME="ecommercev1";
	private  EntityManagerFactory factory;
	
	@Override
	public TblMarca findById(int idMarca) {
		factory=Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em=factory.createEntityManager();
		
		MarcaDao mDao=new MarcaDao(em);
		
		TblMarca m= new TblMarca(); 
	m= mDao.findById(idMarca);
	em.close();
	factory.close();
	return m;
	}

	
	
	
}
