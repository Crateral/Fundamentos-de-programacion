package com.co.nttdata.ecommerce.Services;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

import com.co.nttdata.ecommerce.entidades.TblMarca;
@WebService
public interface MarcaService {

	@WebMethod
	public TblMarca findById(int idMarca);
	
	
}
