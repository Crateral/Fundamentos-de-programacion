package com.co.nttdata.ecommerce.entidades;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the tbl_tipo_identicacion database table.
 * 
 */
@Entity
@Table(name="tbl_tipo_identicacion")
@NamedQuery(name="TblTipoIdenticacion.findAll", query="SELECT t FROM TblTipoIdenticacion t")
public class TblTipoIdenticacion implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="id_tipo_identicacion")
	private int idTipoIdenticacion;

	@Column(name="`nombre_tipo de identificacion`")
	private String nombreTipo_de_identificacion;

	public TblTipoIdenticacion() {
	}

	public int getIdTipoIdenticacion() {
		return this.idTipoIdenticacion;
	}

	public void setIdTipoIdenticacion(int idTipoIdenticacion) {
		this.idTipoIdenticacion = idTipoIdenticacion;
	}

	public String getNombreTipo_de_identificacion() {
		return this.nombreTipo_de_identificacion;
	}

	public void setNombreTipo_de_identificacion(String nombreTipo_de_identificacion) {
		this.nombreTipo_de_identificacion = nombreTipo_de_identificacion;
	}

}