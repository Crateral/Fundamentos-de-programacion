package com.co.ntttdata.ecommerce.ServiceImpl;

import javax.jws.WebService;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


import com.co.nttdata.ecommerce.Daos.ProductoDao;
import com.co.nttdata.ecommerce.Services.ProductoService;

import com.co.nttdata.ecommerce.entidades.TblProducto;
@WebService(endpointInterface = "com.co.nttdata.ecommerce.Services.ProductoService")
public class ProductoServiceImpl implements ProductoService {
	
	
	public  final String PERSISTENCE_UNIT_NAME="ecommercev1";
	private  EntityManagerFactory factory;
	
	@Override
	public TblProducto findById(int idProductos) {
		factory=Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em=factory.createEntityManager();
		
		ProductoDao mDao=new ProductoDao(em);
		
		TblProducto m= new TblProducto(); 
	m= mDao.findById(idProductos);
	em.close();
	factory.close();
	return m;
	}
	

}
