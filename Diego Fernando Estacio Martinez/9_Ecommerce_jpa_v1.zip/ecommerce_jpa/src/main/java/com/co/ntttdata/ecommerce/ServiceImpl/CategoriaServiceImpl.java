package com.co.ntttdata.ecommerce.ServiceImpl;

import javax.jws.WebService;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.co.nttdata.ecommerce.Daos.CategoriaDao;

import com.co.nttdata.ecommerce.Services.CategoriaService;
import com.co.nttdata.ecommerce.entidades.TblCategoria;

@WebService(endpointInterface = "com.co.nttdata.ecommerce.Services.CategoriaService")
public class CategoriaServiceImpl implements CategoriaService {
	
	public  final String PERSISTENCE_UNIT_NAME="ecommercev1";
	private  EntityManagerFactory factory;
	
	@Override
	public TblCategoria findById(int idlCategorias) {
		factory=Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em=factory.createEntityManager();
		
		CategoriaDao mDao=new CategoriaDao(em);
		
		TblCategoria m= new TblCategoria(); 
	m= mDao.findById(idlCategorias);
	em.close();
	factory.close();
	return m;
	}
	
	
	
	
}
