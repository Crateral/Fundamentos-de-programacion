package com.co.nttdata.ecommerce.entidades;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the tbl_categorias database table.
 * 
 */
@Entity
@Table(name="tbl_categorias")
@NamedQuery(name="TblCategoria.findAll", query="SELECT t FROM TblCategoria t")
public class TblCategoria implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="idl_categorias")
	private int idlCategorias;

	private String categoria;

	private String descripcion;

	private byte descuento;

	private double iva;

	private double valorDescuento;

	public TblCategoria() {
	}

	public int getIdlCategorias() {
		return this.idlCategorias;
	}

	public void setIdlCategorias(int idlCategorias) {
		this.idlCategorias = idlCategorias;
	}

	public String getCategoria() {
		return this.categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public byte getDescuento() {
		return this.descuento;
	}

	public void setDescuento(byte descuento) {
		this.descuento = descuento;
	}

	public double getIva() {
		return this.iva;
	}

	public void setIva(double iva) {
		this.iva = iva;
	}

	public double getValorDescuento() {
		return this.valorDescuento;
	}

	public void setValorDescuento(double valorDescuento) {
		this.valorDescuento = valorDescuento;
	}

}