package com.co.nttdata.ecommerce.entidades;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the tbl_marca database table.
 * 
 */
@Entity
@Table(name="tbl_marca")
@NamedQuery(name="TblMarca.findAll", query="SELECT t FROM TblMarca t")
public class TblMarca implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="id_marca")
	private int idMarca;

	private String descripcion;

	private String marca;

	public TblMarca() {
	}

	public int getIdMarca() {
		return this.idMarca;
	}

	public void setIdMarca(int idMarca) {
		this.idMarca = idMarca;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getMarca() {
		return this.marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

}