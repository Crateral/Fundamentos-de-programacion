package com.co.nttdata.ecommerce.Daos;

import javax.persistence.EntityManager;


import com.co.nttdata.ecommerce.entidades.TblCiudade;

public class CiudadesDao {


	
	private EntityManager entityManager;
	 //private Object object;
	 
	 
	 public CiudadesDao(EntityManager entityManager) {
		this.entityManager=entityManager; 
	 }
		

	 public void create(TblCiudade ciudade) {
		 entityManager.getTransaction().begin();
		 entityManager.persist(ciudade);
		 entityManager.getTransaction().commit();
		 
		
	}
	//encontrar por id
	 public TblCiudade findById(int idCiudades) {
		return entityManager.find(TblCiudade.class,idCiudades);
	}
	 
	 //actualizar
	 
	 public void update(TblCiudade ciudade ) {
		entityManager.getTransaction().begin();
		entityManager.merge(ciudade);
		entityManager.getTransaction().commit();
	}
	 
	 
	 //eliminar
	 
	 public void delete(TblCiudade ciudade ) {
		entityManager.getTransaction().begin();
		entityManager.remove(ciudade);
		entityManager.getTransaction().commit();
	}
	
	
	
}
