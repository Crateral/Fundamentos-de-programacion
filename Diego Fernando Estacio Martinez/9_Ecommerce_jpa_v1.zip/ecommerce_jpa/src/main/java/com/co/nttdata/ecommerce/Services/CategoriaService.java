package com.co.nttdata.ecommerce.Services;

import javax.jws.WebMethod;
import javax.jws.WebService;

import com.co.nttdata.ecommerce.entidades.TblCategoria;
@WebService
public interface CategoriaService {
	@WebMethod
	public TblCategoria findById(int idlCategorias);

}
