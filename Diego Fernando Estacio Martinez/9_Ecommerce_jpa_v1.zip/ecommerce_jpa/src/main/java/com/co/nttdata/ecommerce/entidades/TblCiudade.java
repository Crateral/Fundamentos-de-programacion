package com.co.nttdata.ecommerce.entidades;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the tbl_ciudades database table.
 * 
 */
@Entity
@Table(name="tbl_ciudades")
@NamedQuery(name="TblCiudade.findAll", query="SELECT t FROM TblCiudade t")
public class TblCiudade implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="id_ciudades")
	private int idCiudades;

	private String ciudad;

	private boolean principal;

	public TblCiudade() {
	}

	public int getIdCiudades() {
		return this.idCiudades;
	}

	public void setIdCiudades(int idCiudades) {
		this.idCiudades = idCiudades;
	}

	public String getCiudad() {
		return this.ciudad;
	}

	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}

	public boolean getPrincipal() {
		return this.principal;
	}

	public void setPrincipal(Boolean principal) {
		this.principal = principal;
	}

}