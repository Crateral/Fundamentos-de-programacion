package com.co.nttdata.ecommerce.Services;

import javax.jws.WebMethod;
import javax.jws.WebService;

import com.co.nttdata.ecommerce.entidades.TblCiudade;
@WebService
public interface CiudadesService {
	@WebMethod
	 public TblCiudade findById(int idCiudades);

}
