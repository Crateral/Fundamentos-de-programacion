package com.co.nttdata.ecommerce.Daos;

import javax.persistence.EntityManager;

import com.co.nttdata.ecommerce.entidades.TblCategoria;
import com.co.nttdata.ecommerce.entidades.TblMarca;

public class CategoriaDao {
	
	

	
	private EntityManager entityManager;
	 //private Object object;
	 
	 
	 public CategoriaDao(EntityManager entityManager) {
		this.entityManager=entityManager; 
	 }
		

	 public void create(TblCategoria categoria) {
		 entityManager.getTransaction().begin();
		 entityManager.persist(categoria);
		 entityManager.getTransaction().commit();
		 
		
	}
	//encontrar por id
	 public TblCategoria findById(int idlCategorias) {
		return entityManager.find(TblCategoria.class,idlCategorias);
	}
	 
	 //actualizar
	 
	 public void update(TblCategoria categoria ) {
		entityManager.getTransaction().begin();
		entityManager.merge(categoria);
		entityManager.getTransaction().commit();
	}
	 
	 
	 //eliminar
	 
	 public void delete(TblCategoria categoria ) {
		entityManager.getTransaction().begin();
		entityManager.remove(categoria);
		entityManager.getTransaction().commit();
	}
	
	
	

}
