package com.co.nttdata.ecommerce.Daos;

import javax.persistence.EntityManager;

import com.co.nttdata.ecommerce.entidades.TblMarca;
import com.co.nttdata.ecommerce.entidades.TblProducto;

public class ProductoDao {
	


	
	private EntityManager entityManager;
	 //private Object object;
	 
	 
	 public ProductoDao(EntityManager entityManager) {
		this.entityManager=entityManager; 
	 }
		

	 public void create(TblProducto producto) {
		 entityManager.getTransaction().begin();
		 entityManager.persist(producto);
		 entityManager.getTransaction().commit();
		 
		
	}
	//encontrar por id
	 public TblProducto findById(int idProductos) {
		return entityManager.find(TblProducto.class,idProductos);
	}
	 
	 //actualizar
	 
	 public void update(TblProducto producto ) {
		entityManager.getTransaction().begin();
		entityManager.merge(producto);
		entityManager.getTransaction().commit();
	}
	 
	 
	 //eliminar
	 
	 public void delete(TblProducto producto ) {
		entityManager.getTransaction().begin();
		entityManager.remove(producto);
		entityManager.getTransaction().commit();
	}
	 
}

