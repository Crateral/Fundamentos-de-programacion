package com.co.nttdata.ecommerce.entidades;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the tbl_productos database table.
 * 
 */
@Entity
@Table(name="tbl_productos")
@NamedQuery(name="TblProducto.findAll", query="SELECT t FROM TblProducto t")
public class TblProducto implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="id_productos")
	private int idProductos;

	private int cantidadDisponible;

	private byte descuento;

	@Column(name="id_categoria")
	private int idCategoria;

	@Column(name="id_marca")
	private int idMarca;

	private String imagen;

	private double precio;

	private String producto;

	private double valorDescuento;

	public TblProducto() {
	}

	public int getIdProductos() {
		return this.idProductos;
	}

	public void setIdProductos(int idProductos) {
		this.idProductos = idProductos;
	}

	public int getCantidadDisponible() {
		return this.cantidadDisponible;
	}

	public void setCantidadDisponible(int cantidadDisponible) {
		this.cantidadDisponible = cantidadDisponible;
	}

	public byte getDescuento() {
		return this.descuento;
	}

	public void setDescuento(byte descuento) {
		this.descuento = descuento;
	}

	public int getIdCategoria() {
		return this.idCategoria;
	}

	public void setIdCategoria(int idCategoria) {
		this.idCategoria = idCategoria;
	}

	public int getIdMarca() {
		return this.idMarca;
	}

	public void setIdMarca(int idMarca) {
		this.idMarca = idMarca;
	}

	public String getImagen() {
		return this.imagen;
	}

	public void setImagen(String imagen) {
		this.imagen = imagen;
	}

	public double getPrecio() {
		return this.precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public String getProducto() {
		return this.producto;
	}

	public void setProducto(String producto) {
		this.producto = producto;
	}

	public double getValorDescuento() {
		return this.valorDescuento;
	}

	public void setValorDescuento(double valorDescuento) {
		this.valorDescuento = valorDescuento;
	}

}