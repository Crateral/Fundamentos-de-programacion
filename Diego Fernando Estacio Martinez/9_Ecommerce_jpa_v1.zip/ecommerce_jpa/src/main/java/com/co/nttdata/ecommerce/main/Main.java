package com.co.nttdata.ecommerce.main;

import javax.xml.ws.Endpoint;

import com.co.ntttdata.ecommerce.ServiceImpl.MarcaServiceImpl;




public class Main {

	public static void main(String[] args) {
// TODO Auto-generated method stub

		
		Endpoint.publish("http://localhost:3019/ecommerce/getTblMarca", new MarcaServiceImpl());
	//	Endpoint.publish("http://localhost:3018/ecommerce/getTblCategoria", new CategoriaServiceImpl());
	//	Endpoint.publish("http://localhost:3017/ecommerce/getTblCiudade", new CiudadesImpl());
		//Endpoint.publish("http://localhost:3016/ecommerce/getTblProducto", new ProductoServiceImpl());
	//	Endpoint.publish("http://localhost:3005/ecommerce/getTblTipoIdentificacion", new TipoIdentificacionImpl());
	}

}
