package com.co.nttdata.ecommerce.Daos;

import javax.persistence.EntityManager;

import com.co.nttdata.ecommerce.entidades.TblTipoIdenticacion;



public class TipoIdentificacionDao {
	
	

	
	private EntityManager entityManager;
	 //private Object object;
	 
	 
	 public TipoIdentificacionDao(EntityManager entityManager) {
		this.entityManager=entityManager; 
	 }
		

	 public void create(TblTipoIdenticacion tipoIdenticacion) {
		 entityManager.getTransaction().begin();
		 entityManager.persist(tipoIdenticacion);
		 entityManager.getTransaction().commit();
		 
		
	}
	//encontrar por id
	 public TblTipoIdenticacion findById( int idTipoIdenticacion) {
		return entityManager.find(TblTipoIdenticacion.class,idTipoIdenticacion);
	}
	 
	 //actualizar
	 
	 public void update(TblTipoIdenticacion tipoIdenticacion ) {
		entityManager.getTransaction().begin();
		entityManager.merge(tipoIdenticacion);
		entityManager.getTransaction().commit();
	}
	 
	 
	 //eliminar
	 
	 public void delete(TblTipoIdenticacion tipoIdenticacion ) {
		entityManager.getTransaction().begin();
		entityManager.remove(tipoIdenticacion);
		entityManager.getTransaction().commit();
	}
	
	

	
	
	
	

}
