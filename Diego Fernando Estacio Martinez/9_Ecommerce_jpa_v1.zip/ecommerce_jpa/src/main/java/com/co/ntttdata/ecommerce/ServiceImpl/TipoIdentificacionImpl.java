package com.co.ntttdata.ecommerce.ServiceImpl;

import javax.jws.WebService;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.co.nttdata.ecommerce.Daos.ProductoDao;
import com.co.nttdata.ecommerce.Daos.TipoIdentificacionDao;
import com.co.nttdata.ecommerce.Services.TipoIdentificacionService;
import com.co.nttdata.ecommerce.entidades.TblProducto;
import com.co.nttdata.ecommerce.entidades.TblTipoIdenticacion;
@WebService(endpointInterface = "com.co.nttdata.ecommerce.Services.TipoIdentificacionService")
public class TipoIdentificacionImpl implements TipoIdentificacionService {
	

	public  final String PERSISTENCE_UNIT_NAME="ecommercev1";
	private  EntityManagerFactory factory;
	
	@Override
	public TblTipoIdenticacion findById(int idTipoIdenticacion) {
		factory=Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
		EntityManager em=factory.createEntityManager();
		
		TipoIdentificacionDao mDao=new TipoIdentificacionDao(em);
		
		TblTipoIdenticacion m= new TblTipoIdenticacion(); 
	m= mDao.findById(idTipoIdenticacion);
	em.close();
	factory.close();
	return m;
	
	}
	

}
