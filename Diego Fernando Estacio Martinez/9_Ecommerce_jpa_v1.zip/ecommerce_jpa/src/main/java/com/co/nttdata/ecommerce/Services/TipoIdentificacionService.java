package com.co.nttdata.ecommerce.Services;

import javax.jws.WebMethod;
import javax.jws.WebService;

import com.co.nttdata.ecommerce.entidades.TblTipoIdenticacion;
@WebService
public interface TipoIdentificacionService {
	
	
	@WebMethod
	public TblTipoIdenticacion findById( int idTipoIdenticacion);

}
