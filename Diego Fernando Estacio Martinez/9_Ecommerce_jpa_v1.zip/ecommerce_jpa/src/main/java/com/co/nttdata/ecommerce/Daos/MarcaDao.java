package com.co.nttdata.ecommerce.Daos;

import java.util.List;

import javax.persistence.EntityManager;


import com.co.nttdata.ecommerce.entidades.TblMarca;

public class MarcaDao {
	


	
	private EntityManager entityManager;
	 //private Object object;
	 
	 
	 public MarcaDao(EntityManager entityManager) {
		this.entityManager=entityManager; 
	 }
		

	 public void create(TblMarca marca) {
		 entityManager.getTransaction().begin();
		 entityManager.persist(marca);
		 entityManager.getTransaction().commit();
		 
		
	}
	//encontrar por id
	 public TblMarca findById(int idMarca) {
		return entityManager.find(TblMarca.class,idMarca);
	}
	 
	 public TblMarca findByString(String marca) {
			return entityManager.find(TblMarca.class,marca);
		}
	 
	 //actualizar
	 
	 public void update(TblMarca marca ) {
		entityManager.getTransaction().begin();
		entityManager.merge(marca);
		entityManager.getTransaction().commit();
	}
	 
	 
	 //eliminar
	 
	 public void delete(TblMarca marca ) {
		entityManager.getTransaction().begin();
		entityManager.remove(marca);
		entityManager.getTransaction().commit();
	}
	 public List<TblMarca>findAll(){
			entityManager.getTransaction().begin();
			javax.persistence.Query q = entityManager.createQuery("SELECT t FROM TblMarca t");
			entityManager.getTransaction().commit();
			return q.getResultList();
			
		}
	 
	 
}

