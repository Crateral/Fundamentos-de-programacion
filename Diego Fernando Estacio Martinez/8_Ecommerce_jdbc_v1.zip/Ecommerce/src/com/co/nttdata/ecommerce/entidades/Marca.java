package com.co.nttdata.ecommerce.entidades;

public class Marca {
	
	private int id;
	private String marca;
	private String descripcion;
	
	public Marca(int id, String marca, String descripcion) {
		super();
		this.id = id;
		this.marca = marca;
		this.descripcion = descripcion;
	}
	
	

	public Marca() {
		//super();
	}



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}



	public String getMarca() {
		return marca;
	}



	public void setMarca(String marca) {
		this.marca = marca;
	}



	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	@Override
	public String toString() {
		return "Marca [id=" + id + ", marca=" + marca + ", descripcion=" + descripcion + "]";
	}
	

	
}
