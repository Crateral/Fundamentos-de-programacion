package com.co.nttdata.ecommerce.logica;

import com.co.nttdata.ecommerce.entidades.Categoria;
import com.co.nttdata.ecommerce.entidades.Marca;
import com.co.nttdata.ecommerce.entidades.Producto;
import com.co.nttdata.ecommerce.entidades.ProductoPrueba;
import com.co.nttdata.ecommerce.interfaces.IGestionProducto;
import com.csvreader.CsvReader;
//import com.csvreader.CsvReader;
//import com.csvreader.CsvReader;
//import com.csvreader.CsvReader;
//import com.csvreader.CsvReader;
//import com.csvreader.CsvWriter;
//import com.opencsv.CSVReader;
import com.csvreader.CsvWriter;
//import com.csvreader.CsvWriter;
import com.csvreader.CsvWriter;

import java.io.*;
//import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

//import com.opencsv.CSVReader;
//import com.opencsv.exceptions.*;

//import java.io.FileReader;
import java.io.IOException;
//import java.nio.charset.StandardCharsets;



public class GestionProducto implements IGestionProducto {
    public List<Producto> productos;
    public List<Producto> productos2;
    public List<ProductoPrueba> productosPrueba;


    public int ban=0;


    public GestionProducto() {
        productos = new ArrayList<>();
        productos2 = new ArrayList<>();
        productosPrueba = new ArrayList<>();

    }

    public void insertar(Producto producto) {

        productos.add(producto);
    }
    public void insertar2(ProductoPrueba productoPrueba) {

        productosPrueba.add(productoPrueba);
    }

    public String imprime() {
        for (Producto x : productos) {
            System.out.println(x.toString());
        }
        return null;
    }

    public Producto buscar(int id) {
        if(ban==0){
            ImportarCSVProducto();
            ban=1;
        }


        if(productos2.get(id).getCantidadDiponible()>=1){
            productos2.get(id).setCantidadDiponible((productos2.get(id).getCantidadDiponible())-1);
            return productos2.get(id);
        }else{
            System.out.println("Cantidad de mercancia insuficiente");
            return null;
        }


    }

    public List<Producto> actualizaInventario(){
        return productos2;
    }


    public void ExportarCSVProducto() {

        String salidaArchivo = "Productos.csv";
        boolean existe = new File(salidaArchivo).exists();

        if (existe) {
            File archivoProductos = new File(salidaArchivo);
            archivoProductos.delete();
        }

        /*	public Producto(int idProducto, String nombre, int cantidadDiponible, double precio, boolean descuento, double valorDescuento, double iva,
        String descripcion, String img, Marca marca, Categoria categoria)*/
        try {
            //crea archivo
            CsvWriter salidaCSV = new CsvWriter(new FileWriter(salidaArchivo, true), ',');
            salidaCSV.write("idProducto");
            salidaCSV.write("nombre");
            salidaCSV.write("cantidadDisponible");
            salidaCSV.write("precio");
            salidaCSV.write("descuento");
            salidaCSV.write("valorDescuento");
            salidaCSV.write("iva");
            salidaCSV.write("descripcion");
            salidaCSV.write("img");
            salidaCSV.write("marca");
            salidaCSV.write("categoria");

            salidaCSV.endRecord();
            DecimalFormat formato1= new DecimalFormat("");

            for (Producto prod : productos) {
                salidaCSV.write(prod.getIdProducto() + "");
                salidaCSV.write(prod.getNombre());
                salidaCSV.write(prod.getCantidadDiponible() + "");
                salidaCSV.write(prod.getPrecio() + "");
                salidaCSV.write(prod.getValorDescuento() + "");
                salidaCSV.write(prod.getValorDescuento() + "");
                salidaCSV.write(prod.getIva() + "");
                salidaCSV.write(prod.getDescripcion());
                salidaCSV.write(prod.getImg());
                salidaCSV.write(prod.getMarca()+"");
                salidaCSV.write(prod.getCategoria() + "");

                salidaCSV.endRecord();

            }

            salidaCSV.close();


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void ImportarCSVProducto() {
        try {


            CsvReader leerProductos = new CsvReader("Productos.csv");
            leerProductos.readHeaders();

         //   while (leerProductos.readRecord()) {
            while (leerProductos.readRecord()) {
                int idProducto = Integer.parseInt(leerProductos.get(0));
                String nombre = leerProductos.get(1);
                int cantidadDisponible = Integer.parseInt(leerProductos.get(2));
                double precio = Double.parseDouble(leerProductos.get(3));
                boolean descuento = Boolean.parseBoolean(leerProductos.get(4));
                double valorDescuento = Double.parseDouble(leerProductos.get(5));
                double iva = Double.parseDouble(leerProductos.get(6));
                String descripcion = leerProductos.get(7);
                String img = leerProductos.get(8);
                String marca = leerProductos.get(9);
                Categoria categoria = Categoria.valueOf(leerProductos.get(10));

                productos2.add(new Producto(idProducto, nombre, cantidadDisponible, precio, descuento,
                        valorDescuento, iva, descripcion, img, marca, categoria));
            }
               leerProductos.close();
/*
                for (Producto prod2 : productos2) {
                    System.out.println(prod2.getIdProducto() + " , "
                            + prod2.getNombre() + " , "
                            + prod2.getCantidadDiponible() + " , "
                            + prod2.getPrecio() + " , "
                            + prod2.isDescuento() + " , "
                            + prod2.getIva() + " , "
                            + prod2.getDescripcion() + " , "
                            + prod2.getImg() + " , "
                            + prod2.getMarca() + " , "
                            + prod2.getCategoria());
                }
*/


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }//return productos2;
    }

/*
    public void ExportarCSVProducto2() {
        String salidaArchivo = "Productos.csv";
        boolean existe = new File(salidaArchivo).exists();

        if (existe) {
            File archivoProductos = new File(salidaArchivo);
            archivoProductos.delete();
        }

        try {
            //crea archivo
            CsvWriter salidaCSV = new CsvWriter(new FileWriter(salidaArchivo, true), ',');
            // salidaCSV.write("idProducto");
            salidaCSV.write("nombre");
            //  salidaCSV.write("cantidadDisponible");
            //  salidaCSV.write("precio");
            //  salidaCSV.write("descuento");
            //  salidaCSV.write("valorDescuento");
            //  salidaCSV.write("iva");
            salidaCSV.write("descripcion");
            salidaCSV.write("img");
            // salidaCSV.write("categoria");

            salidaCSV.endRecord();

            for (ProductoPrueba prodP : productosPrueba) {
                //    salidaCSV.write(prod.getIdProducto() + "");
                salidaCSV.write(prodP.getNombre());
                // salidaCSV.write(prod.getCantidadDiponible() + "");
                //  salidaCSV.write(prod.getPrecio() + "");
                // salidaCSV.write(prod.getValorDescuento() + "");
                // salidaCSV.write(prod.getValorDescuento() + "");
                // salidaCSV.write(prod.getIva() + "");
                salidaCSV.write(prodP.getDescripcion());
                salidaCSV.write(prodP.getImg());
                //  salidaCSV.write(prod.getCategoria() + "");

                salidaCSV.endRecord();

            }

            salidaCSV.close();


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void ImportarCSVProducto2() {
        try {
            List<ProductoPrueba> productosP = new ArrayList<ProductoPrueba>();

            CsvReader leerProductos = new CsvReader("Productos.csv");
            leerProductos.readHeaders();

            while (leerProductos.readRecord()) {
                //     int idProducto = Integer.parseInt(leerProductos.get(0));
                String nombre = leerProductos.get(1);
                //  int cantidadDisponible = Integer.parseInt(leerProductos.get(2));
                //    double precio = Double.parseDouble(leerProductos.get(3));
                //   boolean descuento = Boolean.parseBoolean(leerProductos.get(4));
                //     double valorDescuento = Double.parseDouble(leerProductos.get(5));
                //     double iva = Double.parseDouble(leerProductos.get(6));
                String descripcion = leerProductos.get(7);
                String img = leerProductos.get(8);
                //    Marca marca = Marca.valueOf(leerProductos.get(9));
                //     Categoria categoria = Categoria.valueOf(leerProductos.get(10));

                productosP.add(new ProductoPrueba(nombre, descripcion, img));

                for (ProductoPrueba prodP : productosPrueba) {
                    System.out.println(//prod.getIdProducto() + " ; "
                            prodP.getNombre() //+ " ; "
                                    //    + prod.getCantidadDiponible() + " ; "
                                    //    + prod.getPrecio() + " ; "
                                    //    + prod.isDescuento() + " ; "
                                    //     + prod.getIva() + " ; "
                                    + prodP.getDescripcion() //+ " ; "
                                    + prodP.getImg() //+ " ; "
                            //      + prod.getMarca() + " ; "
                            //     + prod.getCategoria() + " ; "
                    );
                }
            }


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
*/


    public void ExportarCSVProducto(List<Producto> productosCarrito) {


        File fichero2 = new File("Productos.csv");
        if (fichero2.delete())
            System.out.println("El fichero ha sido borrado satisfactoriamente");
        else
            System.out.println("El fichero no puede ser borrado");




        String salidaArchivo = "Productos.csv";
        boolean existe = new File(salidaArchivo).exists();

        if (existe) {
            File archivoProductos = new File(salidaArchivo);
            archivoProductos.delete();
        }

        /*	public Producto(int idProducto, String nombre, int cantidadDiponible, double precio, boolean descuento, double valorDescuento, double iva,
        String descripcion, String img, Marca marca, Categoria categoria)*/
        try {
            //crea archivo
            CsvWriter salidaCSV = new CsvWriter(new FileWriter(salidaArchivo, true), ',');
            salidaCSV.write("idProducto");
            salidaCSV.write("nombre");
            salidaCSV.write("cantidadDisponible");
            salidaCSV.write("precio");
            salidaCSV.write("descuento");
            salidaCSV.write("valorDescuento");
            salidaCSV.write("iva");
            salidaCSV.write("descripcion");
            salidaCSV.write("img");
            salidaCSV.write("marca");
            salidaCSV.write("categoria");

            salidaCSV.endRecord();
            DecimalFormat formato1= new DecimalFormat("");

            for (Producto prod : productosCarrito) {
                salidaCSV.write(prod.getIdProducto() + "");
                salidaCSV.write(prod.getNombre());
                salidaCSV.write(prod.getCantidadDiponible() + "");
                salidaCSV.write(prod.getPrecio() + "");
                salidaCSV.write(prod.getValorDescuento() + "");
                salidaCSV.write(prod.getValorDescuento() + "");
                salidaCSV.write(prod.getIva() + "");
                salidaCSV.write(prod.getDescripcion());
                salidaCSV.write(prod.getImg());
                salidaCSV.write(prod.getMarca()+"");
                salidaCSV.write(prod.getCategoria() + "");

                salidaCSV.endRecord();

            }

            salidaCSV.close();


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String imprime2() {
        for (Producto x : productos2) {
            System.out.println(x.toString());
        }
        return null;
    }



}
