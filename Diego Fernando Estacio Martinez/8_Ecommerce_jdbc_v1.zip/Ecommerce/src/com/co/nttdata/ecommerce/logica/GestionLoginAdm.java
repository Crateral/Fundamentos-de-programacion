package com.co.nttdata.ecommerce.logica;

import com.co.nttdata.ecommerce.entidades.Administrador;
import com.co.nttdata.ecommerce.entidades.Cliente;
import com.co.nttdata.ecommerce.entidades.Usuario;
import com.co.nttdata.ecommerce.interfaces.IGestionLogin;

public class GestionLoginAdm implements IGestionLogin{
    @Override
    public Usuario registrar(String nombre, String contrasenia, String tipoDocumento, String documento, String correo,
                             String direccion) {



        Administrador adm =new Administrador();
        adm.setNombreUsuario(nombre);
        adm.setContrasenia(contrasenia);
        adm.setTipoIdentificacion(tipoDocumento);
        adm.setNumeroIdentificacion(documento);
       // adm.setCorreo(correo);

        return adm;
    }

    @Override
    public boolean login(String usr, String password) {
        return false;
    }

    @Override
    public String recuperarContrasenia(String usr) {
        return null;
    }

    @Override
    public boolean logout() {
        return false;
    }
}
