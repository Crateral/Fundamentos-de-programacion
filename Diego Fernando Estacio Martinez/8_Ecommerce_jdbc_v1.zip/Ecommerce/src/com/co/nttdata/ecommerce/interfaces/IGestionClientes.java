package com.co.nttdata.ecommerce.interfaces;

import com.co.nttdata.ecommerce.entidades.Cliente;

import java.util.List;

public interface IGestionClientes {

    public boolean insertar(Cliente cliente) ;
    public String imprime();
    public int buscar (String identificacion);
    public int validacionUsuContra(String usuario, String contrasenia);


}
