package com.co.nttdata.DAO;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.co.conexion.Conexion;
import com.co.nttdata.ecommerce.entidades.Marca;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

public class MarcaDao {

    Conexion con = new Conexion();
    Scanner teclado = new Scanner(System.in);

    
    public List<Marca> buscarMarca(){

        Connection baseDatos = con.conectar();
        PreparedStatement st = null;
        ResultSet rs = null;

        List<Marca> marcas = new ArrayList<Marca>();

        try {
        	//st = baseDatos.prepareStatement("SELECT * FROM \"tbl_marca\" ORDER BY id_marca ASC");
            st = (PreparedStatement) baseDatos.prepareStatement("SELECT * FROM TBL_MARCA ORDER BY IDTBL_MARCA ASC");
            rs = st.executeQuery();

            while (rs.next()) {

                Marca marca = new Marca();

                
                marca.setId(rs.getInt("IDTBL_MARCA"));
                marca.setMarca(rs.getString("NOMBRE_MARCA"));

                marca.setDescripcion(rs.getString("DESCRIPCION_MARCA"));
                

                marcas.add(marca);
            }

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                rs.close();
                st.close();
              //  con.desconectarBD(baseDatos);
            } catch (Exception e2) {
                System.err.println(e2.getMessage());
            }
        }


        return marcas;


}
    
    public void agregarmarca(Marca m) {
    	
    	Connection baseDatos = con.conectar();
        PreparedStatement st = null;
        
        try {st = (PreparedStatement) baseDatos.prepareStatement("INSERT INTO TBL_MARCA (marca, descripcion) VALUES (?,?)");
            //st = baseDatos.prepareStatement("INSERT INTO \"tbl__marca\" (marca, descripcion) VALUES (?, ?)");
            st.setString(1, m.getMarca());
            st.setString(2, m.getDescripcion());
            int val = st.executeUpdate();
            
            if (val > 0)
                System.out.println("\nRegistro guardado con éxito...");
            else
                System.err.println("\nError al guardar el registro... !");
            
        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                st.close(); 
              //  con.desconectarBD(baseDatos);
            } catch (Exception e2) {
                System.err.println(e2.getMessage());
            }
        }        
    }
    
    
    
    public Marca eliminarMarca(int marca) {
        Marca m = new Marca();
        
        Connection baseDatos = con.conectar();
        PreparedStatement st = null;
                
        System.out.print("\nDesea eliminar la Marca (s/n) ? : ");
        String rg = teclado.next();
        if (rg.equals("s")) {
            try {
                st = (PreparedStatement) baseDatos.prepareStatement("DELETE FROM TBL_MARCA WHERE IDTBL_MARCA = ? ");
                st.setInt(1, marca);
                int val = st.executeUpdate();
                
                if (val > 0)
                    System.out.println("\nRegistro eliminado con éxito...");
                else
                    System.err.println("\nError al eliminar el registro... !");
                
            } catch (Exception e) {
                System.err.println(e.getMessage());
            } finally {
                try {
                    st.close();
                 //   con.desconectarBD(baseDatos);
                } catch (Exception e2) {
                    System.err.println(e2.getMessage());
                }
            }
                
        } else if (rg.equals("n")) {
            System.out.println("\nSeleccionó no eliminar Marca... !");
        }
        return m;    
    }
    
    
    
    public void modificarMarca(int id_marca, String nombre, String descripcion) {
        
        Connection baseDatos = con.conectar();
        PreparedStatement st = null;
                
        try {
            st = (PreparedStatement) baseDatos.prepareStatement("UPDATE tbl_marca SET nombre = ?, descripcion = ? WHERE id_marca = ?");
       //     st.setInt(3, id_marca);
            st.setString(1, nombre);
            st.setString(2, descripcion);
            int val = st.executeUpdate();



           if (val > 0)
                System.out.println("\nRegistro modificado con éxito...");
            else
                System.err.println("\nError al modificar el registro... !");



       } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                st.close();
              //  con.desconectarBD(baseDatos);
            } catch (Exception e2) {
                System.err.println(e2.getMessage());
            }
        }
    }
    
    


}