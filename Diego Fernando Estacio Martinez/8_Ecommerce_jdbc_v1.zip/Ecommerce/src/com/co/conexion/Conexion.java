package com.co.conexion;

import java.lang.System.Logger;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import com.mysql.jdbc.Connection;

public class Conexion {

	private static final String CONTROLADOR = "com.mysql.jdbc.Driver";
	private static final String URL = "jdbc:mysql://localhost:3306/ECOMMERCE?useSSL=false";
	private static final String USUARIO = "ecommerce";
	private static final String CLAVE = "Ecommerce2022";

	public Connection conectar() {
		Connection conexion = null;
		
		try {
			Class.forName(CONTROLADOR);
			conexion =  (Connection) DriverManager.getConnection(URL, USUARIO, CLAVE);
					
			System.out.println("Conexión OK");

		} catch (ClassNotFoundException e) {
			System.out.println("Error al cargar el controlador");
			e.printStackTrace();

		} catch (SQLException e) {
			System.out.println("Error en la conexión");
			e.printStackTrace();
		}
		
		return conexion;
	}
	
	/*public void cierraConexion() {
		
	    try {
	    	conexion.close();
	    } catch (SQLException sqle) {
	        JOptionPane.showMessageDialog(null, "Error al cerrar conexion", "Error", JOptionPane.ERROR_MESSAGE);
	      
	    }
	}*/
	
	//public Connection desconectarBD()
	//con.desconectarBD(baseDatos);
	
}
