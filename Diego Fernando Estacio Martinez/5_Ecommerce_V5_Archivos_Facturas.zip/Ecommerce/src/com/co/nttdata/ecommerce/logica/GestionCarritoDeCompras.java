package com.co.nttdata.ecommerce.logica;

import java.util.ArrayList;
import java.util.List;

import com.co.nttdata.ecommerce.entidades.CarritoDeCompras;
import com.co.nttdata.ecommerce.entidades.Producto;
import com.co.nttdata.ecommerce.interfaces.IGestionCarritoDeCompras;


public class GestionCarritoDeCompras implements IGestionCarritoDeCompras {
	double iva=0;
	double calculaIva=0;

	double acum1=0,acum2=0;
	double valorEnvio=0;
	double valDescuento=0;
	private List<Producto>  carrito;

	@Override
	public CarritoDeCompras añadirAlCarrito(CarritoDeCompras cdc, List<Producto> p) {
		
		cdc.setProductos(p);
		return cdc;
		
	}

	public GestionCarritoDeCompras() {

		carrito = new ArrayList<>();
	}


/*
	public CarritoDeCompras calcularTotalConIva(CarritoDeCompras cdc) {
		
		double total = 0.0;
		
		for (int i = 0; i < cdc.getProductos().size(); i++) {
			       //1100           2000
			total = total + cdc.getProductos().get(i).getPrecio() + 
					(cdc.getProductos().get(i).getPrecio() * 
							cdc.getProductos().get(i).getIva());
			
		}
		cdc.setSubTotal(total);
		return cdc;
	
	}*/

@Override
	public double calcularCostoEnvio(String ciudadprincipal) {

		if(ciudadprincipal.equals("BOGOTA")||ciudadprincipal.equals("bogota")){
			valorEnvio=15000+(15000*0.05);
		}else {
			valorEnvio=15000+(15000*0.10);
		}

		return valorEnvio;

	}

@Override
	public void insertar(Producto producto) {

		carrito.add(producto);


	}
	@Override
	public String imprime() {
		for (Producto x : carrito) {
			System.out.println(x.toString());
		}
		return null;
	}
	@Override
	public List<Producto> listaproductosCarrito(){

		return carrito;
	}

	@Override
	public double calcularIva(){

		for (Producto x : carrito) {
			 calculaIva=x.getPrecio()-(x.getPrecio()/x.getIva());
			 iva+=calculaIva;
		}
		//iva=acum1;
		return iva;
	}
	@Override
	public double subtotal(){

		for (Producto x : carrito) {
			acum2+=x.getPrecio();
		}

		return acum2;
	}
	@Override
	public double calculadescuento(){
		for (Producto x : carrito) {
			if(x.getCategoria().getDescuento()>x.getValorDescuento()){

				valDescuento+=x.getPrecio()*x.getCategoria().getDescuento();
				//System.out.println("descuento categoria"+x.getCategoria().getDescuento()+" descuento producto" +x.getValorDescuento()+" valor descuento "+valDescuento);
			}else{
				valDescuento+=x.getPrecio()*x.getValorDescuento();
			}

		}

		return valDescuento;

	}
	@Override
	public void limpiar(){
		carrito.clear();
		acum1=0;
		acum2=0;
		iva=0;
		valorEnvio=0;
		calculaIva=0;
	}



}
