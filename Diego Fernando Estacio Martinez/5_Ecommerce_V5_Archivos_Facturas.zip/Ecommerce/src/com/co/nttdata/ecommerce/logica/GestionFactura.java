package com.co.nttdata.ecommerce.logica;

import com.co.nttdata.ecommerce.entidades.CarritoDeCompras;
import com.co.nttdata.ecommerce.entidades.Cliente;
import com.co.nttdata.ecommerce.entidades.Empresa;
import com.co.nttdata.ecommerce.entidades.Factura;
import com.co.nttdata.ecommerce.interfaces.IGestionCarritoDeCompras;
import com.co.nttdata.ecommerce.interfaces.IGestionFactura;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;


import java.text.DecimalFormat;

public class GestionFactura implements IGestionFactura {


    //	Factura fac= gf.pagar(cli1,cdc,gcc.calculariva(),gcc.subtotal(),gcc.calculadescuento(),gcc.calcularCostoEnvio());
    public Factura pagar(Cliente cliente, CarritoDeCompras cdc, double iva, double valDescuento, double costoEnvio) {
        Factura f = new Factura();
        f.setCliente(cliente);
        f.setDescripcion("Mi primera factura");
        f.setIdFactura(123123);
        f.setProductos(cdc);
        f.setDescuentos(valDescuento);
        f.setCostoEnvio(costoEnvio);
        f.setValorTotalConIva(cdc.getSubTotal());
        f.setValorTotalSinIva(cdc.getSubTotal() - iva);
        return f;
    }

    public void imprimir(Factura fac) {

        DecimalFormat formato1 = new DecimalFormat("###,###.00");

        System.out.println("-----------------------------------------------------------------------------------------------------");
        System.out.printf(""+Empresa.POLLOSHERMANOS+"\n");
        System.out.println(""+Empresa.POLLOSHERMANOS.getNit());
        System.out.println(""+Empresa.POLLOSHERMANOS.getDireccion());
        System.out.println("-----------------------------------------------------------------------------------------------------");
        System.out.println(fac.getCliente().getNombreUsuario());
        System.out.println(fac.getCliente().getTipoIdentificacion());
        System.out.println(fac.getCliente().getNumeroIdentificacion());

        System.out.println("-----------------------------------------------------------------------------------------------------");
        System.out.printf("%10s %30s %20s %30s", "ID PRODUCTO", "NOMBRE", "IVA", "PRECIO");
        System.out.println();
        System.out.println("-----------------------------------------------------------------------------------------------------");
        for(int i=0;i<fac.getCarritoDeCompras().getProductos().size();i++){
            System.out.format("%10s %30s %20s %30s",
                    fac.getCarritoDeCompras().getProductos().get(i).getIdProducto(),fac.getCarritoDeCompras().getProductos().get(i).getNombre(),
                    fac.getCarritoDeCompras().getProductos().get(i).getIva(),formato1.format(fac.getCarritoDeCompras().getProductos().get(i).getPrecio()));
            System.out.println();
        }
        System.out.println("-----------------------------------------------------------------------------------------------------");
        System.out.println();
        System.out.println("Valor Sin IVA: "+formato1.format(fac.getValorTotalSinIva())+"    \t Valor total Con IVA:   "+formato1.format(fac.getValorTotalConIva()));
        System.out.println("COSTO ENVIO: "+ formato1.format(fac.getCostoEnvio())+ " \t \t \t \t DESCUENTOS: "+formato1.format(fac.getDescuentos()));
        System.out.println("-----------------------------------------------------------------------------------------------------");
        System.out.println("Total a pagar: "+(formato1.format(fac.getCostoEnvio()-fac.getDescuentos()+fac.getValorTotalConIva()))+"\n\n");
        System.out.println(".....Gracias por su compra....."+"\n\n");





        try {


            String ruta = "Factura.txt";
            File file = new File(ruta);


            if (!file.exists()) {
                file.createNewFile();
            }

            FileWriter fw = new FileWriter(file);
            BufferedWriter bw = new BufferedWriter(fw);

            FileWriter fw2 = new FileWriter(file);
            BufferedWriter bw2 = new BufferedWriter(fw);


            bw.write("-----------------------------------------------------------------------------------------------------\n" +
                    "" + Empresa.POLLOSHERMANOS + "\n" +
                    "" + Empresa.POLLOSHERMANOS.getNit() + "\n" +
                    "" + Empresa.POLLOSHERMANOS.getDireccion() + "\n" +
                    "-----------------------------------------------------------------------------------------------------\n" +
                    "" + fac.getCliente().getNombreUsuario() + "\n" +
                    "" + fac.getCliente().getTipoIdentificacion() + "\n" +
                    "" + fac.getCliente().getNumeroIdentificacion() + "\n" +
                    "-----------------------------------------------------------------------------------------------------\n \n");



            for(int i=0;i<fac.getCarritoDeCompras().getProductos().size();i++){
                bw.write(

                        fac.getCarritoDeCompras().getProductos().get(i).getIdProducto()+"\t"+
                                fac.getCarritoDeCompras().getProductos().get(i).getNombre()+"\t \t"+
                        fac.getCarritoDeCompras().getProductos().get(i).getIva()+"\t \t"+
                                formato1.format(fac.getCarritoDeCompras().getProductos().get(i).getPrecio())+"\n");
            }




            bw.write(

                    "-----------------------------------------------------------------------------------------------------\n"+
                    "Valor Sin IVA: " + formato1.format(fac.getValorTotalSinIva()) + "    \t Valor total Con IVA:   " + formato1.format(fac.getValorTotalConIva())+ "\n" +
                    "COSTO ENVIO: " + formato1.format(fac.getCostoEnvio()) + " \t \t \t \t DESCUENTOS: " + formato1.format(fac.getDescuentos())+ "\n" +
                    "-----------------------------------------------------------------------------------------------------\n"+
                    "Total a pagar: " + (formato1.format(fac.getCostoEnvio() - fac.getDescuentos() + fac.getValorTotalConIva())) + "\n\n"+
                    ".....Gracias por su compra....." + "\n\n"
            );

            bw.close();

        } catch (Exception e) {
            e.printStackTrace();
        }


    }


}
