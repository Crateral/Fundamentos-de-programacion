import java.util.*;

import com.co.nttdata.ecommerce.entidades.*;
import com.co.nttdata.ecommerce.interfaces.*;
import com.co.nttdata.ecommerce.logica.*;


public class Main {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
	//	System.out.println("hola mundo");
		//Crear 10 prodcutos
		//Añadir 6 al carrito de comprar
		//Crear la factura de ese carrito de compras

		IGestionClientes gc=new GestionClientes();
		IGestionLogin gl=new GestionLogin();
		IGestionLogin glAdm=new GestionLoginAdm();

		Scanner teclado = new Scanner(System.in);
		int op = 200;
		System.out.println("Digita Opcion deseada");
		do {
			try {
				//inicia do
				System.out.println("1 - Registra Usuario");
				System.out.println("2 - Login");
				System.out.println("3 - Salir");


				op = teclado.nextInt();

				switch (op) {
					case 1:

						Cliente c = (Cliente) gl.registrar("pedro","123456","CC","108522",
								"correo1@hotmail.com","direccion");

						Administrador adm=(Administrador) glAdm.registrar("pedro","123456","CC","108522",
								"correo1@hotmail.com","");



						Cliente clienteIngreso=new Cliente("correocliente@correo.com","311222111",
								"calle 15",true,"1085222","cc",
								"contado","BOGOTA");
						clienteIngreso.setId(1);
						clienteIngreso.setNombreUsuario("cliente1");
						clienteIngreso.setContrasenia("123456");

						if(gc.insertar(clienteIngreso))
						{
							System.out.println("Cliente ingreso sin inconvenientes");
						}else{
							System.out.println("Error");
						}
				}

				switch (op) {
					case 2:
						if (gc.validacionUsuContra("cliente1","123456")==1){
							System.out.println("Bienvenido");
							registrarP();
						}else {
							System.out.println("Error credenciales");
						}
				}

				switch (op) {
					case 3:
						System.exit(0);
				}
			} catch (InputMismatchException e) {
				System.out.println(" Debe digitar numeros 1 a 3 no letras ni otros caracteres ");
			} finally {
				// break;
			}
		} while (op != 3);//termina do





 	}

	private static void registrarP() {
		IGestionProducto productoGes = new GestionProducto();
		IGestionCarritoDeCompras gcc = new GestionCarritoDeCompras();
		CarritoDeCompras cdc = new CarritoDeCompras();
		Cliente cli1=new Cliente("juan@correo.com","7221122","calle32 esquina", true,"1085222444","CC","Efectivo","BOGOTA");




		cli1.setNombreUsuario("Messi");
		IGestionFactura gf=new GestionFactura();

		Producto producto0 = new Producto(0, "televisor h21          ", 4, 300000, false,
				0.05,1.19, "televisor 23 pulgadas antirreflejo", "rutaimagen",Marca.LG,Categoria.TELEVISORES);
		Producto producto1 = new Producto(1, "celular x22            ", 3, 800000, false,
				0.10,1.19, "celular dual sim doble camara", "rutaimagen2",Marca.SAMSUNG,Categoria.CELULARES);
		Producto producto2 = new Producto(2, "camioneta k3434       ", 2, 30500000, false,
				0d,1.19, "camioneta kia 0 kilimetros", "rutaimagen3",Marca.KIA,Categoria.VEHICULOS);
		Producto producto3 = new Producto(3, "computador compumax 555 ", 10, 1000000, false,
				0.20,1.19, "cpu compumax 500gb disco 4gb ram", "rutaimagen4",Marca.COMPUMAX,Categoria.COMPUTADORES);
		Producto producto4= new Producto(4, "SILLA GAMER 3345       ", 2, 900000, false,
				0d,1.19, "Silla Gamer Redragon roja tapete exclusivo", "rutaimagen5",Marca.REDRAGON,Categoria.SILLASGAMER);
		Producto producto5 = new Producto(5, "Lavadora 32x3         ", 4, 2000000, false,
				0.05,1.19, "Lavadora de lujo 32 3x", "rutaimagen5",Marca.SAMSUNG,Categoria.LAVADORAS);
		Producto producto6 = new Producto(6, "Televisor 12 xdj       ", 2, 800000, false,
				0d,1.19, "televisor 12 mini", "rutaimagen6",Marca.SAMSUNG,Categoria.TELEVISORES);

		Producto producto7 = new Producto(7, "Celular motorola g200 ", 2, 4000000, false,
				0.10,1.19, "celular 6g 7g memoria 500 almacenamiento", "rutaimagen7",Marca.LG,Categoria.CELULARES);
		Producto producto8 = new Producto(8, "Celular Sam 300       ", 2, 1000000, false,
				0.05,1.19, "celular gama baja samsung", "rutaimagen8",Marca.SAMSUNG,Categoria.CELULARES);
		Producto producto9 = new Producto(9, "todo terreno 4440z     ", 2, 50500000, false,
				0.20,1.19, "camioneta 4x4 estable", "rutaimagen9",Marca.KIA,Categoria.VEHICULOS);
		Producto producto10 = new Producto(10, "Silla gamer 800525      ", 2, 2500000, false,
				0d,1.19, "Silla gamer verde con leds", "rutaimagen10",Marca.REDRAGON,Categoria.SILLASGAMER);


		productoGes.insertar(producto0);
		productoGes.insertar(producto1);
		productoGes.insertar(producto2);
		productoGes.insertar(producto3);
		productoGes.insertar(producto4);
		productoGes.insertar(producto5);
		productoGes.insertar(producto6);
		productoGes.insertar(producto7);
		productoGes.insertar(producto8);
		productoGes.insertar(producto9);
		productoGes.insertar(producto10);

		ProductoPrueba prodP1 = new ProductoPrueba("nom1","descrip1","img1");
		ProductoPrueba prodP2 = new ProductoPrueba("nom2","descrip2","img2");
		ProductoPrueba prodP3 = new ProductoPrueba("nom3","descrip3","img3");

		productoGes.insertar2(prodP1);
		productoGes.insertar2(prodP2);
		productoGes.insertar2(prodP3);



		Scanner teclado = new Scanner(System.in);
		int op = 200;
		System.out.println("Digita Opcion deseada");
		do {
			try {
				//inicia do

				System.out.println("1 - Lista productos ");
				System.out.println("2 - Escoge id productos");
				System.out.println("3 - Factura");
				System.out.println("4 - Guarda Productos Archivo Inventario");
				System.out.println("5 - Trae Lista Archivo");
				System.out.println("6 - - - - - - - - - - -");
				System.out.println("7 - Salir");

				op = teclado.nextInt();

				switch (op) {
					case 1:
						System.out.println("__________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________\n");
						productoGes.imprime();
						System.out.println("__________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________\n");

				}

				switch (op) {
					case 2:
						System.out.println("Digite Id productos a comprar");
						int idOp = teclado.nextInt();



						//System.out.println(productoGes.buscar(idOp));
						gcc.insertar(productoGes.buscar(idOp));
						gcc.imprime();

				}

				switch (op) {
					case 3:

						for(int i=0;i<cdc.getProductos().size();i++){
							System.out.println(cdc.getProductos().get(i));
						}
						//double costoEnvio=gcc.calcularCostoEnvio(cli1.getCiudad());
					//	System.out.println(" Iva "+gcc.subtotal()+" Subtotal "+gcc.subtotal()+" Descuento "+gcc.calculadescuento()+"costo envio "+costoEnvio+"\n");





						cdc=new CarritoDeCompras(0,"20221126",gcc.listaproductosCarrito(),gcc.subtotal(),gcc.calcularCostoEnvio(cli1.getCiudad()));
						//Factura fac=new Factura(1,"20221125", Empresa.POLLOSHERMANOS,cli1,"contado",cdc,gcc.subtotal(), gcc.calculariva()+gcc.subtotal());
						Factura fac= gf.pagar(cli1,cdc,gcc.calcularIva(),gcc.calculadescuento(),gcc.calcularCostoEnvio(cli1.getCiudad()));
						gf.imprimir(fac);

						productoGes.ExportarCSVProducto(productoGes.actualizaInventario());
						//ciudad principal BOGOTA 0.5
						//otras ciudades + 0.10
						//fac.toString();


						//System.out.println(gf+"\n");

						gcc.limpiar();


				}

				switch (op) {

					case 4:
						productoGes.ExportarCSVProducto();

				}
				switch (op) {
					case 5:

						productoGes.ImportarCSVProducto();


				}	switch (op) {
					case 6:

						//productoGes.ImportarCSVProducto();


				}
			} catch (InputMismatchException e) {
				System.out.println(" Debe digitar numeros 1 a 5 no letras ni otros caracteres ");
			} finally {
				// break;
			}
		} while (op != 7);//termina do



	}

}
