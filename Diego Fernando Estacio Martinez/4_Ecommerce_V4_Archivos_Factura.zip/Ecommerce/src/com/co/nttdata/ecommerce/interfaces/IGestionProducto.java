package com.co.nttdata.ecommerce.interfaces;

import com.co.nttdata.ecommerce.entidades.Producto;
import com.co.nttdata.ecommerce.entidades.ProductoPrueba;

import java.util.List;

public interface IGestionProducto {


    public void insertar(Producto producto);
    public void insertar2(ProductoPrueba productoPrueba);
    public String imprime();
    public Producto buscar (int id);
    public void ExportarCSVProducto();
    public void ImportarCSVProducto();

   // public void ExportarCSVProducto2();
    //public void ImportarCSVProducto2();

    public void ExportarCSVProducto(List<Producto> productosCarrito);

    public List<Producto> actualizaInventario();
}
