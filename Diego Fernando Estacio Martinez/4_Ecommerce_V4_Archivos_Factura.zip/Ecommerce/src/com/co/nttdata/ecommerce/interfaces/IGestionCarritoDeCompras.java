package com.co.nttdata.ecommerce.interfaces;

import com.co.nttdata.ecommerce.entidades.CarritoDeCompras;
import com.co.nttdata.ecommerce.entidades.Producto;

import java.util.ArrayList;
import java.util.List;

public interface IGestionCarritoDeCompras {

    public void insertar(Producto producto);

    public double calcularIva();

    public double calcularCostoEnvio(String ciudadprincipal);

    public CarritoDeCompras añadirAlCarrito(CarritoDeCompras cdc, List<Producto> p);

    public String imprime();

    public List<Producto> listaproductosCarrito();

    public double subtotal();

    public double calculadescuento();

    public void limpiar();



}