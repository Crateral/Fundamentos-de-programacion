package com.co.nttdata.ecommerce.interfaces;

import com.co.nttdata.ecommerce.entidades.Cliente;
import com.co.nttdata.ecommerce.entidades.Usuario;

public interface IGestionLogin {

    public Usuario registrar(String nombre, String contrasenia, String tipoDocumento,
                             String documento,String correo,String direccion);

    public boolean login(String usr, String password);

    public String  recuperarContrasenia(String usr);

    public boolean logout();
}
/*
public Cliente(String correo, String telefono, String direccion, boolean estado, String numeroIdentificacion,
			String tipoIdentificacion, String metodoDePago,String ciudad) {
 */