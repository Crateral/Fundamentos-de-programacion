/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package carritocompras;

import java.util.Scanner;
import modelo.beans.Usuario;
import modelo.dao.UsuarioDAO;
import modelo.logic.UsuarioLogic;

/**
 *
 * @author F3R_OM
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int op = 200;
        System.out.println("Digita Opcion deseada");
        do {
            System.out.println("1 - Login");
            System.out.println("2 - Registra");
            System.out.println("3 - Elimina");
            System.out.println("4 - Consulta Todos los Usuarios");
            System.out.println("5 - Salir");

            op = teclado.nextInt();

            switch (op) {
                case 1:
                    login();
            }

            switch (op) {
                case 2:
                    registra();
            }

            switch (op) {
                case 3:
                    elimina();
            }

            switch (op) {
                case 4:
                    UsuarioLogic.imprime();
            }

        } while (op != 5);

        //llamar usuario - contraseña
    }

    public static void login() {
        Scanner teclado = new Scanner(System.in);
        System.out.println("Digita Usuario");
        String tusu = teclado.nextLine();
        System.out.println("Digita Contraseña");
        String tcon = teclado.nextLine();

        if (UsuarioLogic.autenticar(tusu, tcon)) {
            System.out.println("Welcome");
        } else {
            System.out.println("usuario y contraseña incorrectos");
        }

    }

    public static void registra() {
        Scanner teclado = new Scanner(System.in);
        System.out.println("Digita Usuario");
        String tusu = teclado.nextLine();
        System.out.println("Digita contraseña");
        String tcon = teclado.nextLine();
        System.out.println("Digita Nombres");
        String tnom = teclado.nextLine();
        System.out.println("Digita Apellidos");
        String tape = teclado.nextLine();
        System.out.println("Digita Correo");
        String tcorr = teclado.nextLine();

        Usuario usuario = new Usuario(tusu, tcon, tnom, tape, tcorr);
        if (UsuarioLogic.modificar(usuario)) {
            System.out.println("Usuario Registrado \n");
        } else {
            System.out.println("Usuario Existente \n");
        }

    }

    public static void elimina() {
        Scanner teclado = new Scanner(System.in);
        System.out.println("Digita Usuario");
        String tusu = teclado.nextLine();

        if (UsuarioLogic.eliminar(tusu)) {
            System.out.println("Usuario Eliminado");
        } else {
            System.out.println("Usuario No Encontrado");
        }
    }

    public static void buscar() {

    }

}
