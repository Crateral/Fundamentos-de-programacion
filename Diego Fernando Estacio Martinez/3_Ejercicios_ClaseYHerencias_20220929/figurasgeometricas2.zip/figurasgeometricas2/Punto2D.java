/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package figurasgeometricas2;

/**
 *
 * @author F3R_OM
 */


public class Punto2D {
    private Double mX;
    private Double mY;

    public Punto2D(Double mX, Double mY) {
        this.mX = mX;
        this.mY = mY;
    }
    
       
   public Double getmX() {
        return mX;
    }

    public void setmX(Double mX) {
        this.mX = mX;
    }

    public Double getmY() {
        return mY;
    }

    public void setmY(Double mY) {
        this.mY = mY;
    }
    
    public void imprimir(){
        System.out.println("Coordenadad X"+mX);
        System.out.println("Coordenadad Y"+mY);
    }
    
    
}
