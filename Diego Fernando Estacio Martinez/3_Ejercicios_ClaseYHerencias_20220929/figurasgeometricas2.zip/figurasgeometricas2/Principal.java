/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package figurasgeometricas2;

/**
 *
 * @author F3R_OM
 */

public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Scanner sc = new Scanner(System.in);
        Rectangulo R1=new Rectangulo(3.0,4.0,5.0,5.0);
        Cuadrado C1=new Cuadrado(3.0,5.0,5.0);
        Circulo Cir1=new Circulo(5.0,5.0,5.0);
        
        System.out.println("Rectangulo");
        R1.imprimir();
        R1.Area();
        R1.Perimetro();
        
        System.out.println("");
     
        System.out.println("Cuadrado");
        C1.imprimir();
        C1.Area();
        C1.Perimetro();
        
        System.out.println("");
        
        System.out.println("Circulo");
        Cir1.imprimir();
        Cir1.Area();
        Cir1.Perimetro();
    }
    
}
