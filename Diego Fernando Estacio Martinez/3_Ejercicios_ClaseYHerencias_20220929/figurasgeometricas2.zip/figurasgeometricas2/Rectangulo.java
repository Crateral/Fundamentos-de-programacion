/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package figurasgeometricas2;

/**
 *
 * @author F3R_OM
 */



public class Rectangulo extends Punto2D {
    
    public Double mAncho;
    public Double mLargo;
    

    public Rectangulo(Double mAncho, Double mLargo, Double mX, Double mY) {
        super(mX, mY);
        this.mAncho = mAncho;
        this.mLargo = mLargo;
    }

    public Double getmAncho() {
        return mAncho;
    }

    public void setmAncho(Double mAncho) {
        this.mAncho = mAncho;
    }

    public Double getmLargo() {
        return mLargo;
    }

    public void setmLargo(Double mLargo) {
        this.mLargo = mLargo;
    }

    @Override
    public void imprimir(){
        super.imprimir();
        System.out.println("Ancho:"+(mAncho));
        System.out.println("Largo"+(mLargo));
    }
    
    public void Area(){
        System.out.println("El area es:"+(mAncho*mLargo));
    }
    
        public void Perimetro(){
        System.out.println("El area es:"+(2*mAncho+2*mLargo));
    }
    
}
