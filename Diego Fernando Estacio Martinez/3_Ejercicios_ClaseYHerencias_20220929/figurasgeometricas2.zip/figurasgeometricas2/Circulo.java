/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package figurasgeometricas2;

/**
 *
 * @author F3R_OM
 */
public class Circulo extends Punto2D {
        public Double radio;

    public Circulo(Double radio, Double mX, Double mY) {
        super(mX, mY);
        this.radio = radio;
    }

    public Double getRadio() {
        return radio;
    }

    public void setRadio(Double radio) {
        this.radio = radio;
    }
        
     @Override
    public void imprimir(){
        super.imprimir();
        System.out.println("Radio Circulo:"+(radio));
    }
    
    public void Area(){
        System.out.println("El area es:"+(radio*3.1416));
    }
    
        public void Perimetro(){
        System.out.println("El area es:"+(2*3.1416*radio));
    }       
        
}
