/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package vehiculo;

/**
 *
 * @author F3R_OM
 */
public class Vehiculo {

    /**
     * @param args the command line arguments
     */
    private String nMotor;
    private String nSerie;
    private String nChasis;
    private String placa;
    private String modelo;
    private String marca;
    private String linea;
    private String color;
    private boolean transmisionAutomatica;

    public Vehiculo(String nMotor, String nSerie, String nChasis, String placa, String modelo, String marca, String linea, String color, boolean transmisionAutomatica) {
        this.nMotor = nMotor;
        this.nSerie = nSerie;
        this.nChasis = nChasis;
        this.placa = placa;
        this.modelo = modelo;
        this.marca = marca;
        this.linea = linea;
        this.color = color;
        this.transmisionAutomatica = transmisionAutomatica;
    }

    
    
    public String getnMotor() {
        return nMotor;
    }

    public void setnMotor(String nMotor) {
        this.nMotor = nMotor;
    }

    public String getnSerie() {
        return nSerie;
    }

    public void setnSerie(String nSerie) {
        this.nSerie = nSerie;
    }

    public String getnChasis() {
        return nChasis;
    }

    public void setnChasis(String nChasis) {
        this.nChasis = nChasis;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getLinea() {
        return linea;
    }

    public void setLinea(String linea) {
        this.linea = linea;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public boolean isTransmisionAutomatica() {
        return transmisionAutomatica;
    }

    public void setTransmisionAutomatica(boolean transmisionAutomatica) {
        this.transmisionAutomatica = transmisionAutomatica;
    }


    
    
    
}
