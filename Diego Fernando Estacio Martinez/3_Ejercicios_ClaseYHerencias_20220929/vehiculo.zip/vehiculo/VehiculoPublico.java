/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vehiculo;

/**
 *
 * @author F3R_OM
 */
public class VehiculoPublico extends Vehiculo {
    private String licencia;
    private Double capacidadToneladas;
    private String tipoUso;

    public VehiculoPublico(String licencia, Double capacidadToneladas, String tipoUso, String nMotor, String nSerie, String nChasis, String placa, String modelo, String marca, String linea, String color, boolean transmisionAutomatica) {
        super(nMotor, nSerie, nChasis, placa, modelo, marca, linea, color, transmisionAutomatica);
        this.licencia = licencia;
        this.capacidadToneladas = capacidadToneladas;
        this.tipoUso = tipoUso;
    }

    public String getLicencia() {
        return licencia;
    }

    public void setLicencia(String licencia) {
        this.licencia = licencia;
    }

    public Double getCapacidadToneladas() {
        return capacidadToneladas;
    }

    public void setCapacidadToneladas(Double capacidadToneladas) {
        this.capacidadToneladas = capacidadToneladas;
    }

    public String getTipoUso() {
        return tipoUso;
    }

    public void setTipoUso(String tipoUso) {
        this.tipoUso = tipoUso;
    }

}
