/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vehiculo;

/**
 *
 * @author F3R_OM
 */
public class VehiculoParticular extends Vehiculo{
    private String propietario;
    private int nPuestos;

    public VehiculoParticular(String propietario, int nPuestos, String nMotor, String nSerie, String nChasis, String placa, String modelo, String marca, String linea, String color, boolean transmisionAutomatica) {
        super(nMotor, nSerie, nChasis, placa, modelo, marca, linea, color, transmisionAutomatica);
        this.propietario = propietario;
        this.nPuestos = nPuestos;
    }

    public String getPropietario() {
        return propietario;
    }

    public void setPropietario(String propietario) {
        this.propietario = propietario;
    }

    public int getnPuestos() {
        return nPuestos;
    }

    public void setnPuestos(int nPuestos) {
        this.nPuestos = nPuestos;
    }
    
    
}
