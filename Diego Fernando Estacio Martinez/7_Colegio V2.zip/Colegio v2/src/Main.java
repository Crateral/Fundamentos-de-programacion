import entidades.*;
import interfaces.IGestionClase;
import interfaces.IGestionEstudiante;
import interfaces.IGestionNotaFinal;
import interfaces.IGestionRegistroNotas;
import logica.GestionClase;
import logica.GestionEstudiante;
import logica.GestionNotaFinal;
import logica.GestionRegistroNotas;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {


        IGestionEstudiante ge=new GestionEstudiante();
        IGestionClase gc=new GestionClase();
        IGestionRegistroNotas grn= new GestionRegistroNotas();
        IGestionNotaFinal gnF = new GestionNotaFinal();


        Estudiante e1=new Estudiante(1,"pedro","calle 1", "711","pedro@correo.com");
        Estudiante e2=new Estudiante(2,"maria","calle 2", "722","maria@correo.com");
        Estudiante e3=new Estudiante(3,"juan","calle 3", "733","juan@correo.com");
        Estudiante e4=new Estudiante(4,"carlos","calle 4", "744","carlos@correo.com");
        Estudiante e5=new Estudiante(5,"jorge","calle 5", "755","estiven@correo.com");
        Estudiante e6=new Estudiante(6,"gerson","calle 6", "766","gerson@correo.com");
        Estudiante e7=new Estudiante(7,"elvis","calle 7", "777","elvis@correo.com");
        Estudiante e8=new Estudiante(8,"daniel","calle 8", "788","daniel@correo.com");
        Estudiante e9=new Estudiante(9,"fabio","calle 9", "799","fabio@correo.com");
        Estudiante e10=new Estudiante(10,"alejandro","calle 10", "7100","alejandro@correo.com");

        Profesor p1=new Profesor(1,"profe1","601","profe1@correo.com");
        Profesor p2=new Profesor(2,"profe2","602","profe2@correo.com");
        Profesor p3=new Profesor(3,"profe3","603","profe3@correo.com");

        ge.insertar(e1);
        ge.insertar(e2);
        ge.insertar(e3);
        List<Estudiante> lista1 =new ArrayList<>();
        lista1.addAll(ge.getEstudiantes());
        Clase c1 = new Clase(1,"202202", Materia.MATEMATICASB1,20,"Jornada pm blooque 5",p1,lista1);
        ge.limpiar();
  //      System.out.println(c1.toString());

        ge.insertar(e4);
        ge.insertar(e5);
        ge.insertar(e6);
        List<Estudiante> lista2 =new ArrayList<>();
        lista2.addAll(ge.getEstudiantes());



        Clase c2 = new Clase(2,"202202", Materia.LENGUAJEB1,10,"Jornada pm blooque 9",p2,lista2);
        ge.limpiar();
   //     System.out.println(c2.toString());

        ge.insertar(e7);
        ge.insertar(e8);
        ge.insertar(e9);
        List<Estudiante> lista3 =new ArrayList<>();
        lista3.addAll(ge.getEstudiantes());

        Clase c3 = new Clase(3,"202202", Materia.PROGRAMACIONF1,30,"Jornada pm blooque 1",p3,lista3);
        ge.limpiar();
   //     System.out.println(c3.toString());

        gc.insertar(c1);
        gc.insertar(c2);
        gc.insertar(c3);

  //      System.out.println(gc.getClases().toString());



       /* RegistroNota rn1= new RegistroNota(1,1,1,5.0,"Excelente");
        RegistroNota rn2= new RegistroNota(2,1,1,3.0,"Aceptable");
        RegistroNota rn3= new RegistroNota(3,1,1,1.0,"Insuficiente");

        grn.insertar(rn1);
        grn.insertar(rn2);
        grn.insertar(rn3);
       // RegistroNota rn4=grn.registroNota(gc.getClases(),3,1,1,1,5,"Excelente");
*/
        grn.insertar(grn.registroNota(gc.getClases(),1,1,1,1,5,"NOTA 1 GEOMETRIA 1"));
        grn.insertar(grn.registroNota(gc.getClases(),2,1,1,1,3,"NOTA 2 ALGEBRA"));
        grn.insertar(grn.registroNota(gc.getClases(),3,1,1,1,1,"NOTA 3 TRIGONOMETRIA"));
        grn.insertar(grn.registroNota(gc.getClases(),4,1,1,1,0,"NOTA 4 CALCULO"));



        grn.ExportarCSVRegistroNotasCabeceras();
        grn.ExportarCSVRegistroNotas();

        grn.ImportarCSVRegistroNotas();

        //LISTAR NOTAS PROFESOR ESTUDIANTE
        grn.imprime2();

        grn.actualizaNota(gc.getClases(),1,1,1,1,2);

        System.out.println("\n");
        grn.imprime2();
        grn.ExportarCSVRegistroNotasCabeceras();
        grn.ExportarCSVRegistroNotas2();

        System.out.println("\n");
        System.out.println(gnF.calculaNotaF(grn.getRegistroNotas2(),1,1,1));

        gnF.ExportarCSVNotasFinalesCabeceras();
        gnF.ExportarCSVNotasFinales();
















    }
}