package logica;

import com.csvreader.CsvWriter;
import entidades.NotaFinal;
import entidades.RegistroNota;
import interfaces.IGestionNotaFinal;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class GestionNotaFinal implements IGestionNotaFinal {
    double acum=0;
    int z=0;

    public List<NotaFinal> notasF;

    public GestionNotaFinal() {
        notasF = new ArrayList<>();
    }

    public List<NotaFinal> getNotasF() {
        return notasF;
    }

    public void setNotasF(List<NotaFinal> notasF) {
        this.notasF = notasF;
    }

    public List<NotaFinal> calculaNotaF(List<RegistroNota> registroNotas,int idNotas,int idClase,int idEstudiante){
        for (RegistroNota x : registroNotas) {
            if(x.getIdEstudiante()==idEstudiante && x.getIdClase()==idClase){
                acum+= x.getNota();
                z++;
            }


        }
        NotaFinal nf=new NotaFinal(idNotas,idClase,idEstudiante,acum/z);
        notasF.add(nf);
        return notasF;
    }

    public void limpiar(){
       notasF.clear();
    }

    @Override
    public String toString() {
        return "GestionNotas{" +
                "notas=" + notasF +
                '}';
    }





    public void ExportarCSVNotasFinales() {

        String salidaArchivo = "RegistroNotasFinales.csv";
        boolean existe = new File(salidaArchivo).exists();

        if (existe) {
            File archivoProductos = new File(salidaArchivo);
            //archivoProductos.delete();
        }

        /*	     // public RegistroNota(int idRegistroNotas, int idClase, int idEstudiante, double nota, String observacionNota) { */
        try {
            //crea archivo
            CsvWriter salidaCSV = new CsvWriter(new FileWriter(salidaArchivo, true), ',');


            for (NotaFinal nf : notasF) {
                salidaCSV.write(nf.getIdNota() + "");
                salidaCSV.write(nf.getIdClase() + "");
                salidaCSV.write(nf.getIdEstudiante() + "");
                salidaCSV.write(nf.getNotaFinal() + "");

                salidaCSV.endRecord();

            }

            salidaCSV.close();


        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    public void ExportarCSVNotasFinalesCabeceras() {

        String salidaArchivo = "RegistroNotasFinales.csv";
        boolean existe = new File(salidaArchivo).exists();

        if (existe) {
            File archivoProductos = new File(salidaArchivo);
            archivoProductos.delete();
        }

        /*	     // public RegistroNota(int idRegistroNotas, int idClase, int idEstudiante, double nota, String observacionNota) { */
        try {
            //crea archivo
            CsvWriter salidaCSV = new CsvWriter(new FileWriter(salidaArchivo, true), ',');


            salidaCSV.write("idNota");
            salidaCSV.write("idClase");
            salidaCSV.write("idEstudiante");
            salidaCSV.write("NotaFinal");




            salidaCSV.endRecord();


            salidaCSV.close();


        } catch (IOException e) {
            e.printStackTrace();
        }
    }










}
