package logica;

import entidades.Clase;
import entidades.Estudiante;
import interfaces.IGestionClase;

import java.util.ArrayList;
import java.util.List;

public class GestionClase implements IGestionClase {
    public List<Clase> clases;

    public GestionClase(){
        clases = new ArrayList<>();
    }

    public void insertar(Clase clase){
        clases.add(clase);
    }

    public List<Clase> getClases() {
        return clases;
    }

    public void setClases(List<Clase> clases) {
        this.clases = clases;
    }

    @Override
    public String toString() {
        return "GestionClase{" +
                "clases=" + clases +
                '}';
    }
}
