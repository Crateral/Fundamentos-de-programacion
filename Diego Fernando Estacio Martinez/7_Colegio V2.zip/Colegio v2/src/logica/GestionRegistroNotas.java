package logica;

import com.csvreader.CsvReader;
import com.csvreader.CsvWriter;
import entidades.Clase;
import entidades.RegistroNota;
import interfaces.IGestionRegistroNotas;

import javax.imageio.spi.RegisterableService;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class GestionRegistroNotas implements IGestionRegistroNotas {

   // int ban=0;
    public List<RegistroNota> registroNotas;
    public List<RegistroNota> registroNotas2;
    RegistroNota rN = new RegistroNota();
    int ban=0;

    public GestionRegistroNotas(){

        registroNotas =new ArrayList<>();
        registroNotas2 =new ArrayList<>();
    }

    public void insertar(RegistroNota registroNota){
        registroNotas.add(registroNota);

    }

    public RegistroNota registroNota(){
        RegistroNota rn= new RegistroNota();

                return rn;
    }



    public RegistroNota registroNota (List<Clase> lc, int idRegistroNota, int idClase, int idProfesor ,int idEstudiante, double nota, String observacion){

        if(buscar(lc,idClase,idProfesor,idEstudiante)==1){
            RegistroNota rn2 = new RegistroNota(idRegistroNota,idClase,idEstudiante,nota,observacion);
            return rn2;
        }

        RegistroNota rn3=new RegistroNota();
        return rn3;
    }

    public void actualizaNota (List<Clase> lc,  int idClase, int idProfesor ,int idEstudiante, int idRegistroNota, double nota){

        if(buscar(lc,idClase,idProfesor,idEstudiante)==1){
            registroNotas2.get(idRegistroNota).setNota(nota);
           // registroNotas2.get(idRegistroNota).setObservacionNota(observacion);
        }else{
            System.out.println("Profesor no pertenece clase - estudiante no pertenece clase");
        }




    }





    public int buscar(List<Clase> lc, int idClase, int idProfesor, int idEstudiante){


    for(int i=0;i<lc.size();i++)
    {
        for(int j=0;j<lc.get(i).getEstudiantes().size();j++)
        {
            if(lc.get(i).getProfesor().getIdProfesor()==idProfesor && lc.get(i).getEstudiantes().get(j).getIdEstudiante()==idEstudiante){
                ban=1;
            }

            int x=lc.get(i).getProfesor().getIdProfesor();
            int y=lc.get(i).getEstudiantes().get(j).getIdEstudiante();
        }
    }

     return ban;
    }







    public void ExportarCSVRegistroNotas() {

        String salidaArchivo = "RegistroNotas.csv";
        boolean existe = new File(salidaArchivo).exists();

        if (existe) {
            File archivoProductos = new File(salidaArchivo);
            //archivoProductos.delete();
        }

        /*	     // public RegistroNota(int idRegistroNotas, int idClase, int idEstudiante, double nota, String observacionNota) { */
        try {
            //crea archivo
            CsvWriter salidaCSV = new CsvWriter(new FileWriter(salidaArchivo, true), ',');
/*
            if(ban==0)
            salidaCSV.write("idRegistroNotas");
            salidaCSV.write("idClase");
            salidaCSV.write("idEstudiante");
            salidaCSV.write("ListaNotas");
            ban=1;


            salidaCSV.endRecord();*/
           // DecimalFormat formato1= new DecimalFormat("");

            for (RegistroNota rn : registroNotas) {
                salidaCSV.write(rn.getIdRegistroNotas() + "");
                salidaCSV.write(rn.getIdClase() + "");
                salidaCSV.write(rn.getIdEstudiante() + "");
                salidaCSV.write(rn.getNota() + "");
                salidaCSV.write(rn.getObservacionNota() + "");
                salidaCSV.write(rn.getEstado()+"");
               // salidaCSV.write(rn.getNotas()+"");

                salidaCSV.endRecord();

            }

            salidaCSV.close();


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void ExportarCSVRegistroNotas2() {

        String salidaArchivo = "RegistroNotas.csv";
        boolean existe = new File(salidaArchivo).exists();

        if (existe) {
            File archivoProductos = new File(salidaArchivo);
            //archivoProductos.delete();
        }

        /*	     // public RegistroNota(int idRegistroNotas, int idClase, int idEstudiante, double nota, String observacionNota) { */
        try {
            //crea archivo
            CsvWriter salidaCSV = new CsvWriter(new FileWriter(salidaArchivo, true), ',');
/*
            if(ban==0)
            salidaCSV.write("idRegistroNotas");
            salidaCSV.write("idClase");
            salidaCSV.write("idEstudiante");
            salidaCSV.write("ListaNotas");
            ban=1;


            salidaCSV.endRecord();*/
            // DecimalFormat formato1= new DecimalFormat("");

            for (RegistroNota rn : registroNotas2) {
                salidaCSV.write(rn.getIdRegistroNotas() + "");
                salidaCSV.write(rn.getIdClase() + "");
                salidaCSV.write(rn.getIdEstudiante() + "");
                salidaCSV.write(rn.getNota() + "");
                salidaCSV.write(rn.getObservacionNota() + "");
                salidaCSV.write(rn.getEstado()+"");
                // salidaCSV.write(rn.getNotas()+"");

                salidaCSV.endRecord();

            }

            salidaCSV.close();


        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void ExportarCSVRegistroNotasCabeceras() {

        String salidaArchivo = "RegistroNotas.csv";
        boolean existe = new File(salidaArchivo).exists();

        if (existe) {
            File archivoProductos = new File(salidaArchivo);
            archivoProductos.delete();
        }

        /*	    public RegistroNotas(int idRegistroNotas, int idClase, int idEstudiante, List<Nota> notas, double notaFinal) */
        try {
            //crea archivo
            CsvWriter salidaCSV = new CsvWriter(new FileWriter(salidaArchivo, true), ',');


            salidaCSV.write("idRegistroNotas");
            salidaCSV.write("idClase");
            salidaCSV.write("idEstudiante");
            salidaCSV.write("Nota");
            salidaCSV.write("Observacion");
            salidaCSV.write("Estado");



            salidaCSV.endRecord();


            salidaCSV.close();


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void ImportarCSVRegistroNotas() {
        try {


            CsvReader leerRegistroNotas = new CsvReader("RegistroNotas.csv");
            leerRegistroNotas.readHeaders();


            /*	    public RegistroNotas(int idRegistroNotas, int idClase, int idEstudiante, List<Nota> notas, double notaFinal) */
            //   while (leerProductos.readRecord()) {
            while (leerRegistroNotas.readRecord()) {
                int idRegistroNotas = Integer.parseInt(leerRegistroNotas.get(0));
                int idClase = Integer.parseInt(leerRegistroNotas.get(1));
                int idEstudiante = Integer.parseInt(leerRegistroNotas.get(2));
                double nota =  Double.parseDouble(leerRegistroNotas.get(3)) ;
                String observacion =leerRegistroNotas.get(4);
                int estado = Integer.parseInt(leerRegistroNotas.get(5));

                registroNotas2.add(new RegistroNota(idRegistroNotas,idClase,idEstudiante,nota,observacion,estado));

            }
            leerRegistroNotas.close();

       /*     for (RegistroNota rn2 : registroNotas2) {
                System.out.println(//prod.getIdProducto() + " ; "
                        registroNota().getIdRegistroNotas()+ " ; "
                                   + registroNota().getIdClase() + " ; "
                                    + registroNota().getIdEstudiante() + " ; "
                                   + registroNota().getNota() + " ; "
                                    + registroNota().getEstado() + " ; "
                               // + prodP.getDescripcion() //+ " ; "
                                //+ prodP.getImg() //+ " ; "
                        //      + prod.getMarca() + " ; "
                        //     + prod.getCategoria() + " ; "
                );
            }*/



        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String imprime2() {
        for (RegistroNota x : registroNotas2) {
            System.out.println(x.toString());
        }
        return null;
    }

    public List<RegistroNota> getRegistroNotas2() {
        return registroNotas2;
    }
}
