package entidades;

public class Estudiante {
    private int idEstudiante;
    private String nombreEstudiante;
    private String direccionEstudiante;
    private String telefonoEstudiante;
    private String correoEstudiante;

    public Estudiante(int idEstudiante, String nombreEstudiante, String direccionEstudiante, String telefonoEstudiante, String correoEstudiante) {
        this.idEstudiante = idEstudiante;
        this.nombreEstudiante = nombreEstudiante;
        this.direccionEstudiante = direccionEstudiante;
        this.telefonoEstudiante = telefonoEstudiante;
        this.correoEstudiante = correoEstudiante;
    }

    public int getIdEstudiante() {
        return idEstudiante;
    }

    public void setIdEstudiante(int idEstudiante) {
        this.idEstudiante = idEstudiante;
    }

    public String getNombreEstudiante() {
        return nombreEstudiante;
    }

    public void setNombreEstudiante(String nombreEstudiante) {
        this.nombreEstudiante = nombreEstudiante;
    }

    public String getDireccionEstudiante() {
        return direccionEstudiante;
    }

    public void setDireccionEstudiante(String direccionEstudiante) {
        this.direccionEstudiante = direccionEstudiante;
    }

    public String getTelefonoEstudiante() {
        return telefonoEstudiante;
    }

    public void setTelefonoEstudiante(String telefonoEstudiante) {
        this.telefonoEstudiante = telefonoEstudiante;
    }

    public String getCorreoEstudiante() {
        return correoEstudiante;
    }

    public void setCorreoEstudiante(String correoEstudiante) {
        this.correoEstudiante = correoEstudiante;
    }

    @Override
    public String toString() {
        return "Estudiante{" +
                "idEstudiante=" + idEstudiante +
                ", nombreEstudiante='" + nombreEstudiante + '\'' +
                ", direccionEstudiante='" + direccionEstudiante + '\'' +
                ", telefonoEstudiante='" + telefonoEstudiante + '\'' +
                ", correoEstudiante='" + correoEstudiante + '\'' +
                '}';
    }
}
