package entidades;

public class Profesor {
    private int idProfesor;
    private String nombreProfesor;
    private String telefonoProfesor;
    private String correoElectronicoProfesor;

    public Profesor(int idProfesor, String nombreProfesor, String telefonoProfesor, String correoElectronicoProfesor) {
        this.idProfesor = idProfesor;
        this.nombreProfesor = nombreProfesor;
        this.telefonoProfesor = telefonoProfesor;
        this.correoElectronicoProfesor = correoElectronicoProfesor;
    }

    public int getIdProfesor() {
        return idProfesor;
    }

    public void setIdProfesor(int idProfesor) {
        this.idProfesor = idProfesor;
    }

    public String getNombreProfesor() {
        return nombreProfesor;
    }

    public void setNombreProfesor(String nombreProfesor) {
        this.nombreProfesor = nombreProfesor;
    }

    public String getTelefonoProfesor() {
        return telefonoProfesor;
    }

    public void setTelefonoProfesor(String telefonoProfesor) {
        this.telefonoProfesor = telefonoProfesor;
    }

    public String getCorreoElectronicoProfesor() {
        return correoElectronicoProfesor;
    }

    public void setCorreoElectronicoProfesor(String correoElectronicoProfesor) {
        this.correoElectronicoProfesor = correoElectronicoProfesor;
    }

    @Override
    public String toString() {
        return "Profesor{" +
                "idProfesor=" + idProfesor +
                ", nombreProfesor='" + nombreProfesor + '\'' +
                ", telefonoProfesor='" + telefonoProfesor + '\'' +
                ", correoElectronicoProfesor='" + correoElectronicoProfesor + '\'' +
                '}';
    }
}
