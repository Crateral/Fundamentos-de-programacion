package entidades;

public enum Colegio {
    COLEGIOHOGWARTS(1,"CALLE FALSA 123");

    Colegio(int idColegio, String direccionColegio) {
        this.idColegio = idColegio;
        this.direccionColegio = direccionColegio;
    }

    private int idColegio;
    private String direccionColegio;

    public int getIdColegio() {
        return idColegio;
    }

    public void setIdColegio(int idColegio) {
        this.idColegio = idColegio;
    }

    public String getDireccionColegio() {
        return direccionColegio;
    }

    public void setDireccionColegio(String direccionColegio) {
        this.direccionColegio = direccionColegio;
    }



    @Override
    public String toString() {
        return "Colegio{" +
                "idColegio=" + idColegio +
                ", direccionColegio='" + direccionColegio + '\'' +
                '}';
    }
}
