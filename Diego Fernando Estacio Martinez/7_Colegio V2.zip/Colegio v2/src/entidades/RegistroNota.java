package entidades;

import java.util.List;

public class RegistroNota {
    private int idRegistroNotas;
    private int idClase;
    private int idEstudiante;
    private double nota;
    private String observacionNota;

    private int estado=0;



    public RegistroNota(int idRegistroNotas, int idClase, int idEstudiante, double nota, String observacionNota) {
        this.idRegistroNotas = idRegistroNotas;
        this.idClase = idClase;
        this.idEstudiante = idEstudiante;
        this.nota = nota;
        this.observacionNota = observacionNota;
    }

    public RegistroNota(int idRegistroNotas, int idClase, int idEstudiante, double nota, String observacionNota, int estado) {
        this.idRegistroNotas = idRegistroNotas;
        this.idClase = idClase;
        this.idEstudiante = idEstudiante;
        this.nota = nota;
        this.observacionNota = observacionNota;
        this.estado = estado;
    }

    public RegistroNota() {
    }



    public int getIdRegistroNotas() {
        return idRegistroNotas;
    }

    public void setIdRegistroNotas(int idRegistroNotas) {
        this.idRegistroNotas = idRegistroNotas;
    }

    public int getIdClase() {
        return idClase;
    }

    public void setIdClase(int idClase) {
        this.idClase = idClase;
    }

    public int getIdEstudiante() {
        return idEstudiante;
    }

    public void setIdEstudiante(int idEstudiante) {
        this.idEstudiante = idEstudiante;
    }

    public double getNota() {
        return nota;
    }

    public void setNota(double nota) {
        this.nota = nota;
    }

    public String getObservacionNota() {
        return observacionNota;
    }

    public void setObservacionNota(String observacionNota) {
        this.observacionNota = observacionNota;
    }

    public int getEstado() {
        return estado;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "RegistroNota{" +
                "idRegistroNotas=" + idRegistroNotas +
                ", idClase=" + idClase +
                ", idEstudiante=" + idEstudiante +
                ", nota=" + nota +
                ", observacionNota='" + observacionNota + '\'' +
                ", estado=" + estado +
                '}';
    }
}
