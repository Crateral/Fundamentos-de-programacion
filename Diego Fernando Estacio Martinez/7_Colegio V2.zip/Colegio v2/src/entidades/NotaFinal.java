package entidades;

public class NotaFinal {
private int idNota;
    private int idClase;
    private int idEstudiante;
    private double notaFinal;

    public NotaFinal(int idNota, int idClase, int idEstudiante, double notaFinal) {
        this.idNota = idNota;
        this.idClase = idClase;
        this.idEstudiante=idEstudiante;
        this.notaFinal = notaFinal;

    }

    public int getIdNota() {
        return idNota;
    }

    public void setIdNota(int idNota) {
        this.idNota = idNota;
    }

    public int getIdClase() {
        return idClase;
    }

    public void setIdClase(int idClase) {
        this.idClase = idClase;
    }

    public double getNotaFinal() {
        return notaFinal;
    }

    public void setNotaFinal(double notaFinal) {
        this.notaFinal = notaFinal;
    }

    public int getIdEstudiante() {
        return idEstudiante;
    }

    public void setIdEstudiante(int idEstudiante) {
        this.idEstudiante = idEstudiante;
    }

    @Override
    public String toString() {
        return "NotaFinal{" +
                "idNota=" + idNota +
                ", idClase=" + idClase +
                ", idEstudiante=" + idEstudiante +
                ", notaFinal=" + notaFinal +
                '}';
    }
}

