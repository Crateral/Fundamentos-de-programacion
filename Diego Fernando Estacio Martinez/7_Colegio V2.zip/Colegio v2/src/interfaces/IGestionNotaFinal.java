package interfaces;

import entidades.NotaFinal;
import entidades.RegistroNota;

import java.util.List;

public interface IGestionNotaFinal {
    public List<NotaFinal> getNotasF();
    //  public void ingresaNota(int valorNota, String observacionNota);

    public void limpiar();

    public List<NotaFinal> calculaNotaF(List<RegistroNota> registroNotas,int idNotas,int idClase,int idEstudiante);

    public void ExportarCSVNotasFinalesCabeceras();
    public void ExportarCSVNotasFinales();



}
