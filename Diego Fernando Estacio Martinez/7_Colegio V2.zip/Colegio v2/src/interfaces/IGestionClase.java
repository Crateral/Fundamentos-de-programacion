package interfaces;

import entidades.Clase;

import java.util.List;

public interface IGestionClase {
    public void insertar(Clase clase);
    public List<Clase> getClases();
    public String toString();
}
