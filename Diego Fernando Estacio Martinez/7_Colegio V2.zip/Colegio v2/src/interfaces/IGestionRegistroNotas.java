package interfaces;

import entidades.Clase;
import entidades.RegistroNota;

import java.util.List;

public interface IGestionRegistroNotas {
    public void ExportarCSVRegistroNotas();
    public void insertar(RegistroNota registroNota);
    public void ExportarCSVRegistroNotasCabeceras();
    public RegistroNota registroNota (List<Clase> lc, int idRegistroNota, int idClase, int idProfesor , int idEstudiante, double nota, String observacion);

    public void ImportarCSVRegistroNotas();
    public void ExportarCSVRegistroNotas2();

    public void actualizaNota (List<Clase> lc,  int idClase, int idProfesor ,int idEstudiante, int idRegistroNota, double nota);


    public String imprime2();

    public List<RegistroNota> getRegistroNotas2();
}
