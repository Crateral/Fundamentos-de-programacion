package com.examen.examen.servicios;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examen.examen.modelos.Clase;
import com.examen.examen.repositorio.ClaseRepositorio;


@Service
public class ClaseServicioImpl implements IClaseServicio{

	
	@Autowired
	ClaseRepositorio claseRepositorio;
	
	@Override
	public List<Clase> obtenerTodo() {
		return claseRepositorio.findAll();
	}

	@Override
	public Clase guardar(Clase clase) {
		return claseRepositorio.save(clase);
		
	}

	@Override
	public Clase obtenerPorId(int id) {
		return claseRepositorio.findById(id).orElse(null);
		
	}

	@Override
	public void eliminar(int id) {
		claseRepositorio.deleteById(id);
		
	}

}
