package com.examen.examen.servicios;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.examen.examen.modelos.Profesor;
import com.examen.examen.repositorio.ProfesorRepositorio;


@Service
public class ProfesorServicioImpl implements IProfesorServicio{

	
	@Autowired
	ProfesorRepositorio profesorRepositorio;
	
	@Override
	public List<Profesor> obtenerTodo() {
		return profesorRepositorio.findAll();
	}

	@Override
	public Profesor guardar(Profesor profesor) {
		return profesorRepositorio.save(profesor);
		
	}

	@Override
	public Profesor obtenerPorId(int id) {
		return profesorRepositorio.findById(id).orElse(null);
		
	}

	@Override
	public void eliminar(int id) {
		profesorRepositorio.deleteById(id);
		
	}

	

}
