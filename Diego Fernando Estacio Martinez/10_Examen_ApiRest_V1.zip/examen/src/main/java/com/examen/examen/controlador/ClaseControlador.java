package com.examen.examen.controlador;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examen.examen.modelos.Clase;
import com.examen.examen.servicios.ClaseServicioImpl;

@RestController
@RequestMapping("/api/v1")
public class ClaseControlador {
	
	@Autowired
	ClaseServicioImpl claseServicio;
	
	
	@GetMapping("/clase")
	public List<Clase> obtenerClases(){
		return claseServicio.obtenerTodo();
	}
	
	
	@PostMapping("/guardarcl")
	public ResponseEntity<Clase> guardarClase(@RequestBody Clase clase){
		Clase nuevoClase = claseServicio.guardar(clase);
		return new ResponseEntity<>(nuevoClase,HttpStatus.CREATED);
	}
	
	@GetMapping("/clase/{id}")
	public ResponseEntity<Clase> obtenerClaseId(@PathVariable int id){
		Clase claseporId = claseServicio.obtenerPorId(id);
		
		return ResponseEntity.ok(claseporId);
	}
	

	
	@PutMapping("/clase/{id}")
	public ResponseEntity<Clase> actualizar(@PathVariable int id, @RequestBody Clase clase){
		Clase clasePorId = claseServicio.obtenerPorId(id);
		clasePorId.setNombreClase(clase.getNombreClase());
		clasePorId.setCantidadEstudiantes(clase.getCantidadEstudiantes());
		clasePorId.setIdProfesor(clase.getIdProfesor());
		
		Clase clase_actualizado = claseServicio.guardar(clasePorId);
		return new ResponseEntity<>(clase_actualizado,HttpStatus.CREATED);
		
	}
	
	
	@DeleteMapping("/clase/{id}")
	public ResponseEntity<HashMap<String, Boolean>> eliminarClase(@PathVariable int id) {
		this.claseServicio.eliminar(id);
		
		HashMap<String, Boolean> estadoClaseEliminado = new HashMap<>();
		estadoClaseEliminado.put("clase eliminado", true);
		return ResponseEntity.ok(estadoClaseEliminado);
		
	}
	
	
	

}
