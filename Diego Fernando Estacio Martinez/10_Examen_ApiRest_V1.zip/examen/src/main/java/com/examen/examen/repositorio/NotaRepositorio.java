package com.examen.examen.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import com.examen.examen.modelos.Nota;

public interface NotaRepositorio extends JpaRepository<Nota,Integer> {

}
