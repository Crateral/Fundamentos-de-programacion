package com.examen.examen.controlador;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examen.examen.modelos.Nota;
import com.examen.examen.servicios.NotaServicioImpl;

@RestController
@RequestMapping("/api/v1")
public class NotaControlador {
	
	@Autowired
	NotaServicioImpl notaServicio;
	
	
	@GetMapping("/notas")
	public List<Nota> obtenerNotas(){
		return notaServicio.obtenerTodo();
	}
	
	
	@PostMapping("/guardarno")
	public ResponseEntity<Nota> guardarNota(@RequestBody Nota nota){
		Nota nuevoNota = notaServicio.guardar(nota);
		return new ResponseEntity<>(nuevoNota,HttpStatus.CREATED);
	}
	
	@GetMapping("/nota/{id}")
	public ResponseEntity<Nota> obtenerNotaId(@PathVariable int id){
		Nota notaporId = notaServicio.obtenerPorId(id);
		
		return ResponseEntity.ok(notaporId);
	}
	

	
	@PutMapping("/nota/{id}")
	public ResponseEntity<Nota> actualizar(@PathVariable int id, @RequestBody Nota nota){
		Nota notaPorId = notaServicio.obtenerPorId(id);
		notaPorId.setIdClase(nota.getIdClase());
		notaPorId.setIdEstudiante(nota.getIdEstudiante());
		notaPorId.setNotaFinal(nota.getIdNota());

		Nota nota_actualizado = notaServicio.guardar(notaPorId);
		return new ResponseEntity<>(nota_actualizado,HttpStatus.CREATED);
		
	}
	
	
	@DeleteMapping("/nota/{id}")
	public ResponseEntity<HashMap<String, Boolean>> eliminarNota(@PathVariable int id) {
		this.notaServicio.eliminar(id);
		
		HashMap<String, Boolean> estadoNotaEliminado = new HashMap<>();
		estadoNotaEliminado.put("nota eliminado", true);
		return ResponseEntity.ok(estadoNotaEliminado);
		
	}
	
	
	

}
