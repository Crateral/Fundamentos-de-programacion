package com.examen.examen.servicios;

import java.util.List;

import com.examen.examen.modelos.Estudiante;

public interface IEstudianteServicio {

	public List<Estudiante> obtenerTodo();
	public Estudiante guardar(Estudiante estudiante);
	public Estudiante obtenerPorId(int id);
	public void eliminar(int id);
}
