package com.examen.examen.controlador;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examen.examen.modelos.Profesor;
import com.examen.examen.servicios.ProfesorServicioImpl;

@RestController
@RequestMapping("/api/v1")
public class ProfesorControlador {
	
	@Autowired
	ProfesorServicioImpl profesorServicio;
	
	
	@GetMapping("/profesores")
	public List<Profesor> obtenerProfesors(){
		return profesorServicio.obtenerTodo();
	}
	
	
	@PostMapping("/guardarpr")
	public ResponseEntity<Profesor> guardarProfesor(@RequestBody Profesor profesor){
		Profesor nuevoProfesor = profesorServicio.guardar(profesor);
		return new ResponseEntity<>(nuevoProfesor,HttpStatus.CREATED);
	}
	
	@GetMapping("/profesor/{id}")
	public ResponseEntity<Profesor> obtenerProfesorId(@PathVariable int id){
		Profesor profesorporId = profesorServicio.obtenerPorId(id);
		
		return ResponseEntity.ok(profesorporId);
	}
	

	
	@PutMapping("/profesor/{id}")
	public ResponseEntity<Profesor> actualizar(@PathVariable int id, @RequestBody Profesor profesor){
		Profesor profesorPorId = profesorServicio.obtenerPorId(id);
		profesorPorId.setNombreProfesor(profesor.getNombreProfesor());
		profesorPorId.setApellidoProfesor(profesor.getApellidoProfesor());
		profesorPorId.setEmailProfesor(profesor.getEmailProfesor());
		
		Profesor profesor_actualizado = profesorServicio.guardar(profesorPorId);
		return new ResponseEntity<>(profesor_actualizado,HttpStatus.CREATED);
		
	}
	
	
	@DeleteMapping("/profesor/{id}")
	public ResponseEntity<HashMap<String, Boolean>> eliminarProfesor(@PathVariable int id) {
		this.profesorServicio.eliminar(id);
		
		HashMap<String, Boolean> estadoProfesorEliminado = new HashMap<>();
		estadoProfesorEliminado.put("profesor eliminado", true);
		return ResponseEntity.ok(estadoProfesorEliminado);
		
	}
	
	
	

}
