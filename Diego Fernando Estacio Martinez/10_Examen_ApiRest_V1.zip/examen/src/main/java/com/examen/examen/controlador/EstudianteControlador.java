package com.examen.examen.controlador;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examen.examen.modelos.Estudiante;
import com.examen.examen.servicios.EstudianteServicioImpl;

@RestController
@RequestMapping("/api/v1")
public class EstudianteControlador {
	
	@Autowired
	EstudianteServicioImpl estudianteServicio;
	
	
	@GetMapping("/estudiantes")
	public List<Estudiante> obtenerEstudiantes(){
		return estudianteServicio.obtenerTodo();
	}
	
	
	@PostMapping("/guardares")
	public ResponseEntity<Estudiante> guardarEstudiante(@RequestBody Estudiante estudiante){
		Estudiante nuevoEstudiante = estudianteServicio.guardar(estudiante);
		return new ResponseEntity<>(nuevoEstudiante,HttpStatus.CREATED);
	}
	
	@GetMapping("/estudiante/{id}")
	public ResponseEntity<Estudiante> obtenerEstudianteId(@PathVariable int id){
		Estudiante estudianteporId = estudianteServicio.obtenerPorId(id);
		
		return ResponseEntity.ok(estudianteporId);
	}
	

	
	@PutMapping("/estudiante/{id}")
	public ResponseEntity<Estudiante> actualizar(@PathVariable int id, @RequestBody Estudiante estudiante){
		Estudiante estudiantePorId = estudianteServicio.obtenerPorId(id);
		estudiantePorId.setNombreEstudiante(estudiante.getNombreEstudiante());
		estudiantePorId.setApellidoEstudiante(estudiante.getApellidoEstudiante());
		estudiantePorId.setEmailEstudiante(estudiante.getEmailEstudiante());
		
		Estudiante estudiante_actualizado = estudianteServicio.guardar(estudiantePorId);
		return new ResponseEntity<>(estudiante_actualizado,HttpStatus.CREATED);
		
	}
	
	
	@DeleteMapping("/estudiante/{id}")
	public ResponseEntity<HashMap<String, Boolean>> eliminarEstudiante(@PathVariable int id) {
		this.estudianteServicio.eliminar(id);
		
		HashMap<String, Boolean> estadoEstudianteEliminado = new HashMap<>();
		estadoEstudianteEliminado.put("estudiante eliminado", true);
		return ResponseEntity.ok(estadoEstudianteEliminado);
		
	}
	
	
	

}
