package com.examen.examen.modelos;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tbl_profesor")
public class Profesor implements Serializable {

	private static final long serialVersionUID=1L;
	
	private int idProfesor;
	private String nombreProfesor;
	private String apellidoProfesor;
	private String emailProfesor;
	
	public Profesor() {
		
	}
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id_profesor")
	public int getIdProfesor() {
		return idProfesor;
	}

	public void setIdProfesor(int idProfesor) {
		this.idProfesor = idProfesor;
	}

	public String getNombreProfesor() {
		return nombreProfesor;
	}

	public void setNombreProfesor(String nombreProfesor) {
		this.nombreProfesor = nombreProfesor;
	}

	public String getApellidoProfesor() {
		return apellidoProfesor;
	}

	public void setApellidoProfesor(String apellidoProfesor) {
		this.apellidoProfesor = apellidoProfesor;
	}

	public String getEmailProfesor() {
		return emailProfesor;
	}

	public void setEmailProfesor(String emailProfesor) {
		this.emailProfesor = emailProfesor;
	}

	@Override
	public String toString() {
		return "Profesor [idProfesor=" + idProfesor + ", nombreProfesor=" + nombreProfesor
				+ ", apellidoProfesor=" + apellidoProfesor + ", emailProfesor=" + emailProfesor + "]";
	}
	
	

	
	
	
}
