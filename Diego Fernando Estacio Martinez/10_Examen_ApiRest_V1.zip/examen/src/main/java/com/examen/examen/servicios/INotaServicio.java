package com.examen.examen.servicios;

import java.util.List;

import com.examen.examen.modelos.Nota;

public interface INotaServicio {

	public List<Nota> obtenerTodo();
	public Nota guardar(Nota nota);
	public Nota obtenerPorId(int id);
	public void eliminar(int id);
}
