package com.examen.examen.servicios;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.examen.examen.modelos.RegistroNota;
import com.examen.examen.repositorio.RegistroNotaRepositorio;

@Service
public class RegistroNotaImp implements IRegistroNotaServicio{
	
	@Autowired
	RegistroNotaRepositorio registroNotaRepositorio;

	@Override
	public List<RegistroNota> obtenerTodo() {
		return registroNotaRepositorio.findAll();
	}

	@Override
	public RegistroNota guardar(RegistroNota registroNota) {
		return registroNotaRepositorio.save(registroNota);
	}

	@Override
	public RegistroNota obtenerPorId(int id) {
		return registroNotaRepositorio.findById(id).orElse(null);
	}

	@Override
	public void eliminar(int id) {
		registroNotaRepositorio.deleteById(id);
		
	}

}
