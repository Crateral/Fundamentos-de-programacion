package com.examen.examen.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import com.examen.examen.modelos.RegistroNota;

public interface RegistroNotaRepositorio extends JpaRepository<RegistroNota,Integer> {

}



