package com.examen.examen.modelos;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_estudiante")
public class Estudiante implements Serializable {

	private static final long serialVersionUID = 1L;

	private int idEstudiante;
	@Column(name = "nombre_estudiante", nullable = false)
	private String nombreEstudiante;
	@Column(name = "apellido_estudiante", nullable = false)
	private String apellidoEstudiante;
	@Column(name = "email_estudiante", nullable = false)
	private String emailEstudiante;

	@ManyToMany(mappedBy = "estudiantes")
	private List<Clase> clases;
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "estudiante")
	private List<RegistroNota> registroNotas;

	public Estudiante() {

	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_estudiante")
	public int getIdEstudiante() {
		return idEstudiante;
	}

	public void setIdEstudiante(int idEstudiante) {
		this.idEstudiante = idEstudiante;
	}

	public String getNombreEstudiante() {
		return nombreEstudiante;
	}

	public void setNombreEstudiante(String nombreEstudiante) {
		this.nombreEstudiante = nombreEstudiante;
	}

	public String getApellidoEstudiante() {
		return apellidoEstudiante;
	}

	public void setApellidoEstudiante(String apellidoEstudiante) {
		this.apellidoEstudiante = apellidoEstudiante;
	}

	public String getEmailEstudiante() {
		return emailEstudiante;
	}

	public void setEmailEstudiante(String emailEstudiante) {
		this.emailEstudiante = emailEstudiante;
	}

	@Override
	public String toString() {
		return "Estudiante [idEstudiante=" + idEstudiante + ", nombreEstudiante=" + nombreEstudiante
				+ ", apellidoEstudiante=" + apellidoEstudiante + ", emailEstudiante=" + emailEstudiante + "]";
	}

}
