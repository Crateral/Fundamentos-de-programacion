package com.examen.examen.servicios;

import java.util.List;

import com.examen.examen.modelos.Clase;

public interface IClaseServicio {

	public List<Clase> obtenerTodo();
	public Clase guardar(Clase clase);
	public Clase obtenerPorId(int id);
	public void eliminar(int id);
}
