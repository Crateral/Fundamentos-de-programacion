package com.examen.examen.modelos;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tbl_nota_final")
public class Nota implements Serializable {

	private static final long serialVersionUID=1L;
	
	private int idNota;
	@Column(name = "id_clase", nullable = false)
	private int idClase;
	@Column(name = "id_estudiante", nullable = false)
	private int idEstudiante;
	@Column(name = "nota_final", nullable = false)
	private double notaFinal;
	
	public Nota() {
		
	}
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id_nota_final")
	public int getIdNota() {
		return idNota;
	}

	public void setIdNota(int idNota) {
		this.idNota = idNota;
	}


	public int getIdClase() {
		return idClase;
	}


	public void setIdClase(int idClase) {
		this.idClase = idClase;
	}


	public int getIdEstudiante() {
		return idEstudiante;
	}


	public void setIdEstudiante(int idEstudiante) {
		this.idEstudiante = idEstudiante;
	}


	public double getNotaFinal() {
		return notaFinal;
	}


	public void setNotaFinal(double notaFinal) {
		this.notaFinal = notaFinal;
	}

	
	

	
	
	
}
