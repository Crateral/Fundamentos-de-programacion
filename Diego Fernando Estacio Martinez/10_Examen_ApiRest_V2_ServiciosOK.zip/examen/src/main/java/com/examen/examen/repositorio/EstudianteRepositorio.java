package com.examen.examen.repositorio;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.examen.examen.modelos.Estudiante;


public interface EstudianteRepositorio extends JpaRepository<Estudiante,Integer> {
	
/*
	@Query(value = "SELECT e FROM Estudiante e WHERE e.apellido_estudiante LIKE%:ape%")
	  List<Estudiante> findByConsulta(@Param("ape")String ape);
*/
	
	@Query(value = "SELECT * FROM tbl_estudiante WHERE apellido_estudiante LIKE %:ape%", nativeQuery=true)
	  List<Estudiante> findByConsulta(@Param("ape")String ape);
	
	/*
	 

	@Query(value = "SELECT * FROM tbl_nota_final WHERE id_clase=:id", nativeQuery = true)
	  List<Nota> findByConsulta2(@Param("id")int id);
	 */
}
