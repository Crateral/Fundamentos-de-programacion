package com.examen.examen.modelos;

import java.io.Serializable;
import java.util.Date;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_registro_notas")
public class RegistroNota implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id_registro_notas")
	private int idRegistroNotas;

	@Column(name = "nota_registro", nullable = false)
	private double notaRegistro;

	@Column(name = "observacion_registro", nullable = false)
	private String observacionRegistroNotas;

	@Column(name = "fecha_registro", nullable = false)
	private Date fechaRegistro;

	@Column(name = "estado_nota", nullable = false)
	private boolean estadoNota;

	@Column(name = "tbl_curso_id_curso", nullable = false)
	private int idClaseRegistroNotas;

	@Column(name = "tbl_curso_tbl_profesor_id_profesor", nullable = false)
	private int idProfesorRegistroNotas;

	@Column(name = "tbl_estudiante_id_estudiante", nullable = false)
	private int idEstudianteRegistroNOtas;

	@JoinColumn(name = "tbl_curso_id_curso", referencedColumnName = "id_clase", nullable = false, insertable = false, updatable = false)
	@ManyToOne(optional = false)
	private Clase clase;
	@JoinColumn(name = "tbl_estudiante_id_estudiante", referencedColumnName = "id_estudiante", nullable = false, insertable = false, updatable = false)
	@ManyToOne(optional = false)
	private Estudiante estudiante;

	
	public RegistroNota() {
    }


	public int getIdRegistroNotas() {
		return idRegistroNotas;
	}


	public void setIdRegistroNotas(int idRegistroNotas) {
		this.idRegistroNotas = idRegistroNotas;
	}


	public double getNotaRegistro() {
		return notaRegistro;
	}


	public void setNotaRegistro(double notaRegistro) {
		this.notaRegistro = notaRegistro;
	}


	public String getObservacionRegistroNotas() {
		return observacionRegistroNotas;
	}


	public void setObservacionRegistroNotas(String observacionRegistroNotas) {
		this.observacionRegistroNotas = observacionRegistroNotas;
	}


	public Date getFechaRegistro() {
		return fechaRegistro;
	}


	public void setFechaRegistro(Date fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}


	public boolean isEstadoNota() {
		return estadoNota;
	}


	public void setEstadoNota(boolean estadoNota) {
		this.estadoNota = estadoNota;
	}


	public int getIdClaseRegistroNotas() {
		return idClaseRegistroNotas;
	}


	public void setIdClaseRegistroNotas(int idClaseRegistroNotas) {
		this.idClaseRegistroNotas = idClaseRegistroNotas;
	}


	public int getIdProfesorRegistroNotas() {
		return idProfesorRegistroNotas;
	}


	public void setIdProfesorRegistroNotas(int idProfesorRegistroNotas) {
		this.idProfesorRegistroNotas = idProfesorRegistroNotas;
	}


	public int getIdEstudianteRegistroNOtas() {
		return idEstudianteRegistroNOtas;
	}


	public void setIdEstudianteRegistroNOtas(int idEstudianteRegistroNOtas) {
		this.idEstudianteRegistroNOtas = idEstudianteRegistroNOtas;
	}


	public Clase getClase() {
		return clase;
	}


	public void setClase(Clase clase) {
		this.clase = clase;
	}


	public Estudiante getEstudiante() {
		return estudiante;
	}


	public void setEstudiante(Estudiante estudiante) {
		this.estudiante = estudiante;
	}


	@Override
	public String toString() {
		return "RegistroNota [idRegistroNotas=" + idRegistroNotas + ", notaRegistro=" + notaRegistro
				+ ", observacionRegistroNotas=" + observacionRegistroNotas + ", fechaRegistro=" + fechaRegistro
				+ ", estadoNota=" + estadoNota + ", idClaseRegistroNotas=" + idClaseRegistroNotas
				+ ", idProfesorRegistroNotas=" + idProfesorRegistroNotas + ", idEstudianteRegistroNOtas="
				+ idEstudianteRegistroNOtas + ", clase=" + clase + ", estudiante=" + estudiante + "]";
	}
	
	
	

	

}
