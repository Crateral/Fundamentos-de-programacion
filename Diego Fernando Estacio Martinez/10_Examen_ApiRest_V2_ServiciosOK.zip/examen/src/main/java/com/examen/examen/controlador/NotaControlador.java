package com.examen.examen.controlador;


import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examen.examen.modelos.Nota;
import com.examen.examen.servicios.NotaServicioImpl;

@RestController
@RequestMapping("/api/v1")
public class NotaControlador {
	
	@Autowired
	NotaServicioImpl notaServicio;
	
	
	@GetMapping("/notas")
	public List<Nota> obtenerNotas(){
	
		return notaServicio.obtenerTodo();

	}
	
	@GetMapping("/notasconsultaestudiante/{id}")
	public List<Nota> obtenerNotasConsulta(@PathVariable int id){
		return notaServicio.consulta(id);
	}
	
	@GetMapping("/notasconsultaclase/{id}")
	public List<Nota> obtenerNotasConsulta2(@PathVariable int id){
		return notaServicio.consulta2(id);
	}
	
	/*
	@GetMapping("/notas2/{id}")
	public List<Nota> obtenerNotas(@RequestBody int id){
		List<Nota> lnaux=new ArrayList();		
		List<Nota> ln = notaServicio.obtenerTodo();
		for(int i=0;i<ln.size();i++){
			
			if(ln.get(i).getIdEstudiante()==id)
			lnaux.add(ln.get(i));
					
		}
			
		return lnaux;		
		//return notaServicio.obtenerTodo();
	}*/
	
	
	@PostMapping("/guardarno")
	public ResponseEntity<Nota> guardarNota(@RequestBody Nota nota){
		Nota nuevoNota = notaServicio.guardar(nota);
		return new ResponseEntity<>(nuevoNota,HttpStatus.CREATED);
	}
	
	@GetMapping("/nota/{id}")
	public ResponseEntity<Nota> obtenerNotaId(@PathVariable int id){
		Nota notaporId = notaServicio.obtenerPorId(id);
		
		return ResponseEntity.ok(notaporId);
	}
	
/*	@GetMapping("/notasconsulta")
	public List<Nota> obtenerNotaConsulta(){
		return notaServicio.consulta();
	}*/

	
	@PutMapping("/nota/{id}")
	public ResponseEntity<Nota> actualizar(@PathVariable int id, @RequestBody Nota nota){
		Nota notaPorId = notaServicio.obtenerPorId(id);
		notaPorId.setIdClase(nota.getIdClase());
		notaPorId.setIdEstudiante(nota.getIdEstudiante());
		notaPorId.setNotaFinal(nota.getIdNota());

		Nota nota_actualizado = notaServicio.guardar(notaPorId);
		return new ResponseEntity<>(nota_actualizado,HttpStatus.CREATED);
		
	}
	
	
	@DeleteMapping("/nota/{id}")
	public ResponseEntity<HashMap<String, Boolean>> eliminarNota(@PathVariable int id) {
		this.notaServicio.eliminar(id);
		
		HashMap<String, Boolean> estadoNotaEliminado = new HashMap<>();
		estadoNotaEliminado.put("nota eliminado", true);
		return ResponseEntity.ok(estadoNotaEliminado);
		
	}
	
	
	
	

}
