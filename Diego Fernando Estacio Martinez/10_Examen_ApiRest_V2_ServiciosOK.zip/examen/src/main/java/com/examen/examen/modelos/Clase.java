package com.examen.examen.modelos;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="tbl_clase")
public class Clase implements Serializable {

	private static final long serialVersionUID=1L;
	
	private int idClase;
	
	@Column(name = "nombre_clase", nullable = false)
	private String nombreClase;
	@Column(name = "cantidad_estudiantes", nullable = false)
	private int cantidadEstudiantes;
	@Column(name = "tbl_profesor_id_profesor", nullable = false)
	private int idProfesor;
	
	
	
	public Clase() {
		
	}
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id_clase")
	public int getIdClase() {
		return idClase;
	}

	public void setIdClase(int idClase) {
		this.idClase = idClase;
	}

	public String getNombreClase() {
		return nombreClase;
	}

	public void setNombreClase(String nombreClase) {
		this.nombreClase = nombreClase;
	}


	public int getCantidadEstudiantes() {
		return cantidadEstudiantes;
	}


	public void setCantidadEstudiantes(int cantidadEstudiantes) {
		this.cantidadEstudiantes = cantidadEstudiantes;
	}


	public int getIdProfesor() {
		return idProfesor;
	}


	public void setIdProfesor(int idProfesor) {
		this.idProfesor = idProfesor;
	}


	@Override
	public String toString() {
		return "Clase [idClase=" + idClase + ", nombreClase=" + nombreClase + ", cantidadEstudiantes="
				+ cantidadEstudiantes + ", idProfesor=" + idProfesor + "]";
	}

	
	

	
	
	
}
