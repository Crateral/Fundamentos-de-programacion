package com.examen.examen.servicios;

import java.util.List;


import com.examen.examen.modelos.Profesor;

public interface IProfesorServicio {

	public List<Profesor> obtenerTodo();
	public Profesor guardar(Profesor profesor);
	public Profesor obtenerPorId(int id);
	public void eliminar(int id);
}
