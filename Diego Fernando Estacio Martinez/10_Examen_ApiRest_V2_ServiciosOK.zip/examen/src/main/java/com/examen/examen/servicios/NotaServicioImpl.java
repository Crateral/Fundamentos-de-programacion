package com.examen.examen.servicios;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.examen.examen.modelos.Nota;
import com.examen.examen.repositorio.NotaRepositorio;


@Service
public class NotaServicioImpl implements INotaServicio{

	
	@Autowired
	NotaRepositorio notaRepositorio;
	
	@Override
	public List<Nota> obtenerTodo() {
		return notaRepositorio.findAll();
	}

	@Override
	public Nota guardar(Nota nota) {
		return notaRepositorio.save(nota);
		
	}

	@Override
	public Nota obtenerPorId(int id) {
		return notaRepositorio.findById(id).orElse(null);
		
	}

	@Override
	public void eliminar(int id) {
		notaRepositorio.deleteById(id);
		
	}

	@Override
	public List<Nota> consulta(int id) {
		return notaRepositorio.findByConsulta(id);
	}
	
	

	@Override
	public List<Nota> consulta2(int id) {
		return notaRepositorio.findByConsulta(id);
	}
	
	

	

}
