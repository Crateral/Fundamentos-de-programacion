package com.examen.examen.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;

import com.examen.examen.modelos.Clase;

public interface ClaseRepositorio extends JpaRepository<Clase,Integer> {

}
