package com.examen.examen.repositorio;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.examen.examen.modelos.Nota;

public interface NotaRepositorio extends JpaRepository<Nota,Integer> {

	@Query(value = "SELECT * FROM tbl_nota_final WHERE id_estudiante=:id", nativeQuery = true)
	  List<Nota> findByConsulta(@Param("id")int id);
	

	@Query(value = "SELECT * FROM tbl_nota_final WHERE id_clase=:id", nativeQuery = true)
	  List<Nota> findByConsulta2(@Param("id")int id);
}
