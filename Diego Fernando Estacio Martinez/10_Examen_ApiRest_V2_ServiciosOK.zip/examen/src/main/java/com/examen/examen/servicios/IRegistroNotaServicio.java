package com.examen.examen.servicios;

import java.util.List;

import com.examen.examen.modelos.RegistroNota;

public interface IRegistroNotaServicio {
	
	public List<RegistroNota> obtenerTodo();
	public RegistroNota guardar(RegistroNota registroNota);
	public RegistroNota obtenerPorId(int id);
	public void eliminar(int id);

}




/*

package com.examen.examen.servicios;

import java.util.List;

import com.examen.examen.modelos.Estudiante;

public interface IEstudianteServicio {

	public List<Estudiante> obtenerTodo();
	public Estudiante guardar(Estudiante estudiante);
	public Estudiante obtenerPorId(int id);
	public void eliminar(int id);
}

*/