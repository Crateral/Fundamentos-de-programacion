package com.examen.examen.servicios;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.examen.examen.modelos.Estudiante;
import com.examen.examen.repositorio.EstudianteRepositorio;


@Service
public class EstudianteServicioImpl implements IEstudianteServicio{

	
	@Autowired
	EstudianteRepositorio estudianteRepositorio;
	
	@Override
	public List<Estudiante> obtenerTodo() {
		return estudianteRepositorio.findAll();
	}

	@Override
	public Estudiante guardar(Estudiante estudiante) {
		return estudianteRepositorio.save(estudiante);
		
	}

	@Override
	public Estudiante obtenerPorId(int id) {
		return estudianteRepositorio.findById(id).orElse(null);
		
	}

	@Override
	public void eliminar(int id) {
		estudianteRepositorio.deleteById(id);
		
	}

	@Override
	public List<Estudiante> consulta(String ape) {
		estudianteRepositorio.findByConsulta(ape);
		return null;
	}

	

}
