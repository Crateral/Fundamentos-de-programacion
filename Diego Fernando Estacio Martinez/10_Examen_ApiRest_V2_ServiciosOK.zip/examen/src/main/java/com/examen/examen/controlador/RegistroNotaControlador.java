package com.examen.examen.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.examen.examen.modelos.RegistroNota;
import com.examen.examen.servicios.RegistroNotaImp;


@RestController
@RequestMapping("/api/v1")
public class RegistroNotaControlador {
	
	@Autowired
	RegistroNotaImp registroNotaServicio;
	
	@GetMapping("/registronotas")
	public List<RegistroNota> obtenerRegistroNotas(){
		return registroNotaServicio.obtenerTodo();
	}
	
	

}
