/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo.dao;

import java.util.ArrayList;
import java.util.List;
import modelo.beans.Producto;

/**
 *
 * @author F3R_OM
 */
public class ProductoDAO {
    
     private List<Producto> productos;

    public ProductoDAO() {
        productos = new ArrayList<>();
    }
    
    public int buscar(String nombre) {
        int n = -1;
        for (int i = 0; i < productos.size(); i++) {
            if (productos.get(i).getNombre().equals(nombre)) {
                n = i;
                break;
            }
        }
        return n;
    }
    
    
        public boolean insertar(Producto producto) {
        if (buscar(producto.getNombre()) == -1) {
            productos.add(producto);
            return true;
        } else {
            return false;
        }
    }
        
        
          public boolean modificar(Producto producto) {
        if (buscar(producto.getNombre()) != -1) {
            Producto productoAux = obtener(producto.getNombre());

            productoAux.setId(producto.getId());
            productoAux.setNombre(producto.getNombre());
            productoAux.setCategoria(producto.getCategoria());
            productoAux.setPrecio(producto.getPrecio());

            return true;
        } else {
            return false;
        }
    } 
          
          public boolean eliminar(String nombre) {
        if (buscar(nombre) != -1) {
            productos.remove(buscar(nombre));

            return true;
        } else {
            return false;
        }
    }

    public Producto obtener(String nombre) {
        if (buscar(nombre) != -1) {
            return productos.get(buscar(nombre));

        } else {
            return null;
        }
    }
    
    
              public String imprime(){
                for (Producto x : productos) {
            System.out.println(x.imprime());
        }
        return null;
    }
          
          
        
        
        
        
        
        
        
        
    
    
    
}
