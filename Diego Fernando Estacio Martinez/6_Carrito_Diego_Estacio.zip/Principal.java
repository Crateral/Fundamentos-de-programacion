/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package carrito;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author F3R_OM
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        List<Producto> productos = new ArrayList<>();
        // List<Producto> productost = new ArrayList<>();
        int numindice = (int) (Math.random() * 3);
        double numprecio = (double) (Math.random() * 5000);
        DecimalFormat formato1 = new DecimalFormat("#.##");
        int op1 = 0;
        Scanner teclado = new Scanner(System.in);

        Producto pt = new Producto();

        do {

            System.out.println(" \n Digita el numero indicado - Para salir presione el numero 6 \n ");

            System.out.println("1 - AÑADE");
            System.out.println("2 - CONSULTA TODOS");
            System.out.println("3 - CONSULTA POR CATEGORIA");
            System.out.println("4 - ORDENAR POR NOMBRE");
            System.out.println("5 - ELIMINA LISTA");
            System.out.println("6 - SALIR");
            op1 = Integer.parseInt(teclado.next());

            switch (op1) {
                case 1:
                    System.out.println("Cuantos productos ingresara \n");
                    int n = 0;
                    n = Integer.parseInt(teclado.next());

                    Producto[] productos2 = new Producto[n];

                    for (int i = 0; i < n; i++) {
                        numindice = (int) (Math.random() * 3);
                        numprecio = (double) (Math.random() * 5000);

                        productos2[i] = new Producto(i, numindice, numindice, numprecio);
                        productos.add(productos2[i]);
                    }
            }

            switch (op1) {
                case 2:
                    System.out.println("\n Listado de Productos \n");
                    for (Producto x : productos) {
                        System.out.println(x.imprime());
                    }
            }

            switch (op1) {
                case 3:
                    String busca;
                    Scanner teclado2 = new Scanner(System.in);

                    System.out.println("Buscar : nino : nina : hombre : mujer \n");
                    busca = teclado2.nextLine();

                    System.out.println(" - Busca categoria " + busca + "\n");
                    int i = 0;
                    while (i < productos.size()) {
                        if (productos.get(i).getCategoria().equals(busca)) {//  if (productos.get(i).getCategoria() == "mujer") {
                            System.out.println(" Producto " + productos.get(i).getId() + " nombre  " + productos.get(i).getNombre() + " - " + "      Categoria  " + productos.get(i).getCategoria() + " Precio  " + formato1.format(productos.get(i).getPrecio()));
                            i++;
                        } else {
                            i++;
                        }
                    }
            }

            switch (op1) {
                case 4:

                    /*
                     
        Collections.sort(students, new Comparator<>() {
            @Override
            public int compare(Student o1, Student o2) {
                return ComparisonChain.start()
                        .compare(o1.getName(), o2.getName())
                        .compare(o1.getAge(), o2.getAge())
                        .result();
            }
                     */
                    Collections.sort(productos);

                    System.out.println("");
                    System.out.println("\n productos ordenados nombre \n");
                    for (Producto x : productos) {
                        System.out.println(x.imprime());
                    }
            }

            switch (op1) {
                case 5:
                    System.out.println(" - ELEMENTOS BORRADOS - ");
                    productos.clear();
            }

        } while (op1 != 6);
    }
}

//REVISAR
//Collections.sort(productos);
//  public double comparteTo(Producto pr){
//}
//        System.out.println("  ");
//        System.out.println(" - Ordenar Precio - ");
//        i = 0;
//        int j = 0;
//        while (i < productos.size()) {
//            while (j  < productos.size() - i) {
//                if (productos.get(j-1).getPrecio()>productos.get(j).getPrecio()) {
//                    pt=productos.get(j-1);
//                    
//                    
//                    System.out.println(" Producto " + productos.get(i).getId() + " nombre  " + productos.get(i).getNombre() + " Categoriae  " + productos.get(i).getCategoria() + " Precio  " + productos.get(i).getPrecio());
//                    i++;
//                } else {
//                    i++;
//                }
//            }
//        }
