/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package carrito;

import java.text.DecimalFormat;

/**
 *
 * @author F3R_OM
 */
public class Producto implements Comparable<Producto> {

    DecimalFormat formato1 = new DecimalFormat("#.##");

    private final String[] nombres = {"camiseta", "pantalon", "gaban   ", "medias", "bujanda",};
    private final String[] categorias = {"mujer", "hombre", "nino", "nina"};
    //private final Double[] precios={10000,20000,30000,40000,50000,60000,700000};

    int id;
    String nombre, categoria;
    double precio;

    public Producto(int id, int indiceNombre, int indiceCategoria, double precio) {
        this.id = id;
        this.nombre = this.nombres[indiceNombre];
        this.categoria = this.categorias[indiceCategoria];
        this.precio = precio;
    }

    Producto() {

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String imprime() {

        return " Producto   \t " + id + " \tnombre:  \t" + nombre + "  \t categoria:  \t " + categoria + " \t precio:  \t" + formato1.format(precio);

    }

    @Override
    public String toString() {
        return "Producto{" + "nombres=" + nombres + ", categorias=" + categorias + ", id=" + id + ", nombre=" + nombre + ", categoria=" + categoria + ", precio=" + formato1.format(precio) + '}';
    }

    @Override
    public int compareTo(Producto t) {
   
        return nombre.compareTo(t.getNombre());

    }
    
      
        

}
