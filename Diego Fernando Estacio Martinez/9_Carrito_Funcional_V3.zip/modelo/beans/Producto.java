/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo.beans;

//import java.text.DecimalFormat;

/**
 *
 * @author F3R_OM
 */
public class Producto implements Comparable<Producto> {
    
   //  DecimalFormat formato1 = new DecimalFormat("#.##");

    private final String[] nombres = {"camiseta", "pantalon", "gaban   ", "medias  ", "bufanda "};
    private final String[] categorias = {"mujer   ", "hombre  ", "nino    ", "nina    ","mascota "};
    private final String[] precios= {"10000","20000","30000","40000","50000"};
    
    
   // int id;
    private String id, nombre, categoria,precio;
   // private int precio;

    public Producto(String id, int indiceNombre, int indiceCategoria, int indicePrecio) {
        this.id = id;
        this.nombre = this.nombres[indiceNombre];
        this.categoria = this.categorias[indiceCategoria];
        this.precio = this.precios[indiceCategoria];
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }

    public String imprime() {

        return " Producto   \t " + id + " \tnombre:  \t" + nombre + "  \t categoria:  \t " + categoria + " \t precio:  \t" + precio;

    }

    @Override
    public String toString() {
        return "Producto{" + "nombres=" + nombres + ", categorias=" + categorias + ", id=" + id + ", nombre=" + nombre + ", categoria=" + categoria + ", precio=" + precio + '}';
    }

    @Override
    public int compareTo(Producto t) {
   
        return nombre.compareTo(t.getNombre());

    }
    
    
    
}
