/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo.logic;

import modelo.beans.Producto;
import modelo.dao.ProductoDAO;

/**
 *
 * @author F3R_OM
 */
public class ProductoLogic {
    
     private static ProductoDAO productodao = new ProductoDAO();
    
  public static boolean insertar(Producto producto) {
        return productodao.insertar(producto);
    }

    public static boolean modificar(Producto producto) {
        return productodao.modificar(producto);
    }

    public static boolean eliminar(String nombre) {
        return productodao.eliminar(nombre);
    }

    public static Producto obtener(String producto) {
        return productodao.obtener(producto);
    }
    
    public static String imprime(){
        return productodao.imprime();
    }  
    
        public static String factura(){
        return productodao.factura();
    }  
        
        
    
        
        
    
    
    
    
    
    
    
}
