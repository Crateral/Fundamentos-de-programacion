/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo.dao;

//import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import modelo.beans.Producto;

/**
 *
 * @author F3R_OM
 */
public class ProductoDAO {
 //DecimalFormat formato1 = new DecimalFormat("#.##");
    private List<Producto> productos;

    public ProductoDAO() {
        productos = new ArrayList<>();
    }

    public int buscar(String id) {
        int n = -1;
        for (int i = 0; i < productos.size(); i++) {
            if (productos.get(i).getId().equals(id)) {
                n = i;
                break;
            }
        }
        return n;
    }

    public boolean insertar(Producto producto) {
        if (buscar(producto.getId()) == -1) {
            productos.add(producto);
            return true;
        } else {
            return false;
        }
    }

    public boolean modificar(Producto producto) {
        if (buscar(producto.getId()) != -1) {
            Producto productoAux = obtener(producto.getNombre());

            productoAux.setNombre(producto.getNombre());
            productoAux.setCategoria(producto.getCategoria());
            productoAux.setPrecio(producto.getPrecio());

            return true;
        } else {
            return false;
        }
    }

    public boolean eliminar(String id) {
        if (buscar(id) != -1) {
            productos.remove(buscar(id));

            return true;
        } else {
            return false;
        }
    }

    public Producto obtener(String id) {
        if (buscar(id) != -1) {
            return productos.get(buscar(id));

        } else {
            return null;
        }
    }

    public String imprime() {
        for (Producto x : productos) {
            System.out.println(x.imprime());
        }
        return null;
    }

    public String factura() {
        
        double subtotal=0;
        System.out.println("");
        for (Producto x : productos) {
            System.out.println(x.imprime());
            subtotal=subtotal+Integer.parseInt(x.getPrecio());
        }
        double iva=subtotal*0.19;
        double total=subtotal;
        System.out.println(" \n");
        System.out.println("Subtotal \t"+subtotal);
        System.out.println("Iva     \t"+iva);
        System.out.println("Total   \t"+total);
        
        return null;
    }
    
    
    


}
