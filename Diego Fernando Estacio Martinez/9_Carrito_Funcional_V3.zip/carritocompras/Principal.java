/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package carritocompras;

import java.util.InputMismatchException;
import java.util.Scanner;
import modelo.beans.Usuario;
import modelo.beans.Producto;
import modelo.dao.UsuarioDAO;
import modelo.dao.ProductoDAO;
import modelo.logic.ProductoLogic;
import modelo.logic.UsuarioLogic;

/**
 *
 * @author F3R_OM
 */
public class Principal {

    static int ban = 0;
    static int z = 0;

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        Scanner teclado = new Scanner(System.in);
        int op = 200;
        System.out.println("Digita Opcion deseada");
        do {
            try {
                //inicia do
                System.out.println("1 - Login");
                System.out.println("2 - Registra Usuario");
                System.out.println("3 - Elimina Usuario");
                System.out.println("4 - Consulta Todos los Usuarios");
                System.out.println("5 - Modificar Contraseña Usuario");
                System.out.println("6 - Salir");

                op = teclado.nextInt();

                //InputMismatchException
                switch (op) {
                    case 1:
                        login();
                }

                switch (op) {
                    case 2:
                        registra();
                }

                switch (op) {
                    case 3:
                        elimina();
                }

                switch (op) {
                    case 4:
                        UsuarioLogic.imprime();
                }
                switch (op) {
                    case 5:

                }
            } catch (InputMismatchException e) {
                System.out.println(" Debe digitar numeros 1 a 5 no letras ni otros caracteres ");
            } finally {
               // break;
            }
        } while (op != 6);//termina do

        //llamar usuario - contraseña
    }

    public static void login() {
        Scanner teclado = new Scanner(System.in);
        System.out.println("Digita Usuario");
        String tusu = teclado.nextLine();
        System.out.println("Digita Contraseña");
        String tcon = teclado.nextLine();

        if (UsuarioLogic.autenticar(tusu, tcon)) {
            System.out.println("BIENVENIDO: " + tusu);

            //
            //menu logueo opciones para compra de carrito
            int op1 = 200;
            do {
                System.out.println("");
                System.out.println("1 - Agregar Producto");
                System.out.println("2 - Consulta Productos");
                System.out.println("3 - Elimina Productos");
                System.out.println("4 - Facturar");
                System.out.println("5 - Cambia Contraseña");
                System.out.println("6 - Logout");

                op1 = teclado.nextInt();

                switch (op1) {
                    case 1:
                        registrap();
                }

                switch (op1) {
                    case 2:
                        ProductoLogic.imprime();
                }

                switch (op1) {
                    case 3:
                        eliminap();
                }

                switch (op1) {
                    case 4:
                        factura();
                }
                switch (op1) {
                    case 5:
                        Scanner teclado2 = new Scanner(System.in);
                        System.out.println("Digita nueva contrasenia para usuario:  " + tusu + " ");
                        String tconnew = teclado2.nextLine();
                        System.out.println("Su nueva contrasenia sera: " + tconnew + "\n Esta operacion cierra Sesion  Esta seguro del cambio 1 SI - 2 NO");
                        int top = teclado.nextInt();
                        if (top == 1) {

                            cambioContrasenia(tusu, tconnew);
                            System.out.println("-CERRANDO SESION -");
                            op1 = 6;
                        } else {
                            break;
                        }

                }

            } while (op1 != 6);

            // termina menu logueo
        } else {
            System.out.println("usuario y contraseña incorrectos");
        }

    }

    public static void registra() {
        Scanner teclado = new Scanner(System.in);
        System.out.println("Digita Usuario");
        String tusu = teclado.nextLine();
        System.out.println("Digita contraseña");
        String tcon = teclado.nextLine();
        System.out.println("Digita Nombres");
        String tnom = teclado.nextLine();
        System.out.println("Digita Apellidos");
        String tape = teclado.nextLine();
        System.out.println("Digita Correo");
        String tcorr = teclado.nextLine();

        Usuario usuario = new Usuario(tusu, tcon, tnom, tape, tcorr);
        if (UsuarioLogic.insertar(usuario)) {
            System.out.println("Usuario Registrado \n");
        } else {
            System.out.println("Usuario Existente \n");
        }

    }

    public static void elimina() {
        Scanner teclado = new Scanner(System.in);
        System.out.println("Digita Usuario");
        String tusu = teclado.nextLine();

        if (UsuarioLogic.eliminar(tusu)) {
            System.out.println("Usuario Eliminado");
        } else {
            System.out.println("Usuario No Encontrado");
        }
    }

    public static void buscar() {
        System.out.println("Busca");
    }

    private static void registrap() {

        int numindice = (int) (Math.random() * 3);
        Producto producto = new Producto(Integer.toString(z), numindice, numindice, numindice);
        z++;
        if (ProductoLogic.insertar(producto)) {
            System.out.println("Producto Registrado \n");
        } else {
            System.out.println("ID Producto Compra Existente \n");
        }

    }

    private static void eliminap() {
        System.out.println("Elimina productos");
        Scanner teclado = new Scanner(System.in);
        System.out.println("Digita ID a eliminar");
        String tid = teclado.nextLine();

        if (ProductoLogic.eliminar(tid)) {
            System.out.println("Producto Eliminado");
        } else {
            System.out.println("Id Producto No Encontrado");
        }

    }

    private static void factura() {

        ProductoLogic.factura();

    }

    private static void cambioContrasenia(String tusu, String contrasenia) {
        if (UsuarioLogic.modificarContrasenia(tusu, contrasenia)) {
            System.out.println("Su contrasenia fue cambiada satisfactoriamente");
        } else {
            System.out.println("No se encontro usuario - Error 414 ");
        }

    }

}
