package logica;

import entidades.Nota;
import interfaces.IGestionNotas;

import java.util.ArrayList;
import java.util.List;

public class GestionNotas implements IGestionNotas {

    public List<Nota> notas;

    public GestionNotas() {
        notas = new ArrayList<>();
    }

    public List<Nota> getNotas() {
        return notas;
    }

    public void setNotas(List<Nota> notas) {
        this.notas = notas;
    }

    public void ingresaNota(int valorNota, String observacionNota){
        Nota n = new Nota(valorNota,observacionNota);
        notas.add(n);
    }

    public void limpiar(){
       notas.clear();
    }

    @Override
    public String toString() {
        return "GestionNotas{" +
                "notas=" + notas +
                '}';
    }
}
