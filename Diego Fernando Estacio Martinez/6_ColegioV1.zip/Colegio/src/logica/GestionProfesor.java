package logica;

public class GestionProfesor {

}
