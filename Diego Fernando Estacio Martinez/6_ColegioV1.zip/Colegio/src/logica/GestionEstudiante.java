package logica;

import entidades.Estudiante;
import interfaces.IGestionEstudiante;

import java.util.ArrayList;
import java.util.List;

public class GestionEstudiante implements IGestionEstudiante {

    public List<Estudiante> estudiantes;

    public GestionEstudiante() {
        estudiantes = new ArrayList<>();
    }

    public void insertar(Estudiante estudiante){
        estudiantes.add(estudiante);
    }
    public void limpiar(){
        estudiantes.clear();
    }

    public List<Estudiante> getEstudiantes() {
        return estudiantes;
    }

    public void setEstudiantes(List<Estudiante> estudiantes) {
        this.estudiantes = estudiantes;
    }

    @Override
    public String toString() {
        return "GestionEstudiante{" +
                "estudiantes=" + estudiantes +
                '}';
    }
}
