package logica;

import com.csvreader.CsvWriter;
import entidades.RegistroNota;
import interfaces.IGestionRegistroNotas;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class GestionRegistroNotas implements IGestionRegistroNotas {

   // int ban=0;
    public List<RegistroNota> registroNotas;

    public GestionRegistroNotas(){
        registroNotas =new ArrayList<>();
    }

    public void insertar(RegistroNota registroNota){
        registroNotas.add(registroNota);

    }




    public void ExportarCSVRegistroNotas() {

        String salidaArchivo = "RegistroNotas.csv";
        boolean existe = new File(salidaArchivo).exists();

        if (existe) {
            File archivoProductos = new File(salidaArchivo);
            //archivoProductos.delete();
        }

        /*	    public RegistroNotas(int idRegistroNotas, int idClase, int idEstudiante, List<Nota> notas, double notaFinal) */
        try {
            //crea archivo
            CsvWriter salidaCSV = new CsvWriter(new FileWriter(salidaArchivo, true), ',');
/*
            if(ban==0)
            salidaCSV.write("idRegistroNotas");
            salidaCSV.write("idClase");
            salidaCSV.write("idEstudiante");
            salidaCSV.write("ListaNotas");
            ban=1;


            salidaCSV.endRecord();*/
           // DecimalFormat formato1= new DecimalFormat("");

            for (RegistroNota rn : registroNotas) {
                salidaCSV.write(rn.getIdRegistroNotas() + "");
                salidaCSV.write(rn.getIdClase() + "");
                salidaCSV.write(rn.getIdEstudiante() + "");
                salidaCSV.write(rn.getNotas()+"");

                salidaCSV.endRecord();

            }

            salidaCSV.close();


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void ExportarCSVRegistroNotasCabeceras() {

        String salidaArchivo = "RegistroNotas.csv";
        boolean existe = new File(salidaArchivo).exists();

        if (existe) {
            File archivoProductos = new File(salidaArchivo);
            archivoProductos.delete();
        }

        /*	    public RegistroNotas(int idRegistroNotas, int idClase, int idEstudiante, List<Nota> notas, double notaFinal) */
        try {
            //crea archivo
            CsvWriter salidaCSV = new CsvWriter(new FileWriter(salidaArchivo, true), ',');


            salidaCSV.write("idRegistroNotas");
            salidaCSV.write("idClase");
            salidaCSV.write("idEstudiante");
            salidaCSV.write("ListaNotas");



            salidaCSV.endRecord();


            salidaCSV.close();


        } catch (IOException e) {
            e.printStackTrace();
        }
    }




}
