package entidades;

import java.util.List;

public class RegistroNota {
    private int idRegistroNotas;
   /* private Clase clase;
    private Estudiante estudiante;
    private Profesor profesor;*/
    private int idClase;
    private int idEstudiante;
    private List<Nota> notas;

    private double notaFinal;

    public RegistroNota(int idRegistroNotas, int idClase, int idEstudiante, List<Nota> notas, double notaFinal) {
        this.idRegistroNotas = idRegistroNotas;
        this.idClase = idClase;
        this.idEstudiante = idEstudiante;
        this.notas = notas;
        this.notaFinal = notaFinal;
    }

    public int getIdRegistroNotas() {
        return idRegistroNotas;
    }

    public void setIdRegistroNotas(int idRegistroNotas) {
        this.idRegistroNotas = idRegistroNotas;
    }

    public int getIdClase() {
        return idClase;
    }

    public void setIdClase(int idClase) {
        this.idClase = idClase;
    }

    public int getIdEstudiante() {
        return idEstudiante;
    }

    public void setIdEstudiante(int idEstudiante) {
        this.idEstudiante = idEstudiante;
    }

    public List<Nota> getNotas() {
        return notas;
    }

    public void setNotas(List<Nota> notas) {
        this.notas = notas;
    }

    public double getNotaFinal() {
        return notaFinal;
    }

    public void setNotaFinal(double notaFinal) {
        this.notaFinal = notaFinal;
    }
}
