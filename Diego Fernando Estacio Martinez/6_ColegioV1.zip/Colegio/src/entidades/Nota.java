package entidades;

public class Nota {

    private double nota;
    private String observacionNota;

    public Nota(double nota, String observacionNota) {
        this.nota = nota;
        this.observacionNota = observacionNota;
    }

    public double getNota() {
        return nota;
    }

    public void setNota(double nota) {
        this.nota = nota;
    }

    public String getObservacionNota() {
        return observacionNota;
    }

    public void setObservacionNota(String observacionNota) {
        this.observacionNota = observacionNota;
    }

    @Override
    public String toString() {
        return "Nota{" +
                "nota=" + nota +
                ", observacionNota='" + observacionNota + '\'' +
                '}';
    }
}
