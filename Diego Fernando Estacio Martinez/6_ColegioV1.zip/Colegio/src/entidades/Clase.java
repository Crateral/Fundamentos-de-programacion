package entidades;

import java.util.List;

public class Clase {
    private int idClase;
    private String periodoAcademico;
    private Materia materia;
    private int cantidadEstudiantes;
    private String descripcion;

    private Profesor profesor;

    private List<Estudiante> estudiantes;


    public Clase(int idClase, String periodoAcademico, Materia materia, int cantidadEstudiantes, String descripcion, Profesor profesor, List<Estudiante> estudiantes) {
        this.idClase = idClase;
        this.periodoAcademico = periodoAcademico;
        this.materia = materia;
        this.cantidadEstudiantes = cantidadEstudiantes;
        this.descripcion = descripcion;
        this.profesor = profesor;
        this.estudiantes = estudiantes;
    }



    public int getIdClase() {
        return idClase;
    }

    public void setIdClase(int idClase) {
        this.idClase = idClase;
    }

    public String getPeriodoAcademico() {
        return periodoAcademico;
    }

    public void setPeriodoAcademico(String periodoAcademico) {
        this.periodoAcademico = periodoAcademico;
    }

    public Materia getMateria() {
        return materia;
    }

    public void setMateria(Materia materia) {
        this.materia = materia;
    }

    public int getCantidadEstudiantes() {
        return cantidadEstudiantes;
    }

    public void setCantidadEstudiantes(int cantidadEstudiantes) {
        this.cantidadEstudiantes = cantidadEstudiantes;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Profesor getProfesor() {
        return profesor;
    }

    public void setProfesor(Profesor profesor) {
        this.profesor = profesor;
    }

    public List<Estudiante> getEstudiantes() {
        return estudiantes;
    }

    public void setEstudiantes(List<Estudiante> estudiantes) {
        this.estudiantes = estudiantes;
    }

    @Override
    public String toString() {
        return "Clase{" +
                "idClase=" + idClase +
                ", periodoAcademico='" + periodoAcademico + '\'' +
                ", materia=" + materia +
                ", cantidadEstudiantes=" + cantidadEstudiantes +
                ", descripcion='" + descripcion + '\'' +
                ", profesor=" + profesor +
                ", estudiantes=" + estudiantes +
                '}';
    }
}
