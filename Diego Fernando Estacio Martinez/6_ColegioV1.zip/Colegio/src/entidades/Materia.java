package entidades;

public enum Materia {

    MATEMATICASB1(1,"MATEMATICAS BASICAS 1"),
    LENGUAJEB1(1,"LENGUAJE BASICO 1"),
    PROGRAMACIONF1(1,"FUNDAMENTOS PROGRAMACION 1");

    private int idMateria;
    private String descripcionMateria;

    private Materia(int idMateria,String descripcionMateria){
        this.idMateria =idMateria;
        this.descripcionMateria=descripcionMateria;
    }

    public int getIdMateria() {
        return idMateria;
    }

    public void setIdMateria(int idMateria) {
        this.idMateria = idMateria;
    }


    public String getDescripcionMateria() {
        return descripcionMateria;
    }

    public void setDescripcionMateria(String descripcionMateria) {
        this.descripcionMateria = descripcionMateria;
    }

    @Override
    public String toString() {
        return "Materia{" +
                "idMateria=" + idMateria +
                ", descripcionMateria='" + descripcionMateria + '\'' +
                '}';
    }
}
