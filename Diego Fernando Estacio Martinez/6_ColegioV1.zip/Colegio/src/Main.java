import entidades.*;
import interfaces.IGestionClase;
import interfaces.IGestionEstudiante;
import interfaces.IGestionNotas;
import interfaces.IGestionRegistroNotas;
import logica.GestionClase;
import logica.GestionEstudiante;
import logica.GestionNotas;
import logica.GestionRegistroNotas;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {


        IGestionEstudiante ge=new GestionEstudiante();
        IGestionClase gc=new GestionClase();
        IGestionRegistroNotas grn= new GestionRegistroNotas();
        IGestionNotas gn = new GestionNotas();

        Estudiante e1=new Estudiante(1,"pedro","calle 1", "711","pedro@correo.com");
        Estudiante e2=new Estudiante(2,"maria","calle 2", "722","maria@correo.com");
        Estudiante e3=new Estudiante(3,"juan","calle 3", "733","juan@correo.com");
        Estudiante e4=new Estudiante(4,"carlos","calle 4", "744","carlos@correo.com");
        Estudiante e5=new Estudiante(5,"jorge","calle 5", "755","estiven@correo.com");
        Estudiante e6=new Estudiante(5,"gerson","calle 6", "766","gerson@correo.com");
        Estudiante e7=new Estudiante(5,"elvis","calle 7", "777","elvis@correo.com");
        Estudiante e8=new Estudiante(5,"daniel","calle 8", "788","daniel@correo.com");
        Estudiante e9=new Estudiante(5,"fabio","calle 9", "799","fabio@correo.com");
        Estudiante e10=new Estudiante(5,"alejandro","calle 10", "7100","alejandro@correo.com");

        Profesor p1=new Profesor(1,"profe1","601","profe1@correo.com");
        Profesor p2=new Profesor(2,"profe2","602","profe2@correo.com");
        Profesor p3=new Profesor(3,"profe3","603","profe3@correo.com");

        ge.insertar(e1);
        ge.insertar(e2);
        ge.insertar(e3);
        List<Estudiante> lista1 =new ArrayList<>();
        lista1.addAll(ge.getEstudiantes());
        Clase c1 = new Clase(1,"202202", Materia.MATEMATICASB1,20,"Jornada pm blooque 5",p1,lista1);
        ge.limpiar();
        System.out.println(c1.toString());

        gn.ingresaNota(5,"Excelente");
        gn.ingresaNota(3,"Mejore");
        gn.ingresaNota(2,"Mal");
        List<Nota> notas1 =new ArrayList<>();
        notas1.addAll(gn.getNotas());
      //  gn.limpiar();

        RegistroNota rn1= new RegistroNota(1,1,1,notas1,0);


        grn.insertar(rn1);
        grn.ExportarCSVRegistroNotasCabeceras();
        grn.ExportarCSVRegistroNotas();
        grn.ExportarCSVRegistroNotas();
        grn.ExportarCSVRegistroNotas();



        ge.insertar(e4);
        ge.insertar(e5);
        ge.insertar(e6);
        List<Estudiante> lista2 =new ArrayList<>();
        lista2.addAll(ge.getEstudiantes());



        Clase c2 = new Clase(2,"202202", Materia.LENGUAJEB1,10,"Jornada pm blooque 9",p2,lista2);
        ge.limpiar();
        System.out.println(c2.toString());

        ge.insertar(e7);
        ge.insertar(e8);
        ge.insertar(e9);
        List<Estudiante> lista3 =new ArrayList<>();
        lista3.addAll(ge.getEstudiantes());

        Clase c3 = new Clase(3,"202202", Materia.PROGRAMACIONF1,30,"Jornada pm blooque 1",p3,lista3);
        ge.limpiar();
        System.out.println(c3.toString());

        /*	    public RegistroNotas(int idRegistroNotas, int idClase, int idEstudiante, List<Nota> notas, double notaFinal) */





    }
}