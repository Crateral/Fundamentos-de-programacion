package interfaces;

import entidades.Estudiante;

import java.util.List;

public interface IGestionEstudiante {


    public void insertar(Estudiante estudiante);
    public List<Estudiante> getEstudiantes();
    public void limpiar();

}
