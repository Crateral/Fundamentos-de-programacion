package interfaces;

public interface IGestionProfesor {
}
