package interfaces;

import entidades.Nota;

import java.util.List;

public interface IGestionNotas {
    public List<Nota> getNotas();
    public void ingresaNota(int valorNota, String observacionNota);

    public void limpiar();

}
