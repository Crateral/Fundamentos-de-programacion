package interfaces;

import entidades.RegistroNota;

public interface IGestionRegistroNotas {
    public void ExportarCSVRegistroNotas();
    public void insertar(RegistroNota registroNota);
    public void ExportarCSVRegistroNotasCabeceras();
}
