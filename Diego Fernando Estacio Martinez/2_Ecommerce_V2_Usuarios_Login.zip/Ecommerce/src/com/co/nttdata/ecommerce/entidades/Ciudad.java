package com.co.nttdata.ecommerce.entidades;

public enum Ciudad {

    BOGOTA(1, "DISTRITO CAPITAL");

    private int idCiudad;
    private String descripcion;

    private Ciudad(int idCiudad, String descripcion){
        this.idCiudad=idCiudad;
        this.descripcion=descripcion;
    }

    public int getIdCiudad() {
        return idCiudad;
    }

    public void setIdCiudad(int idCiudad) {
        this.idCiudad = idCiudad;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
