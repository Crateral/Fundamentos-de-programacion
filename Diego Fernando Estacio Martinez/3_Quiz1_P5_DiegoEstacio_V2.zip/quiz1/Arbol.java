/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package quiz1;

/**
 *
 * @author DIEGO ESTACIO
 */
public class Arbol extends Planta{
    private double altura;
    private int flor;
    private int fruto;
    private String fechaNacimiento;

    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }


    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public int getFlor() {
        return flor;
    }

    public void setFlor(int flor) {
        this.flor = flor;
    }

    public int getFruto() {
        return fruto;
    }

    public void setFruto(int fruto) {
        this.fruto = fruto;
    }

   
    public Arbol(double altura, boolean daFruto, boolean tieneFlores, String fechaNacimiento) {
        super(altura, daFruto, tieneFlores, fechaNacimiento);
    }
    

}
