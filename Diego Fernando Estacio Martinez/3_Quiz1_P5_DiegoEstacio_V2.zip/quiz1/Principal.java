/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package quiz1;

import static java.time.Clock.system;
import static java.time.InstantSource.system;

/**
 *
 * @author DIEGO ESTACIO
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    
    
    public static void main(String[] args) {
        // TODO code application logic here
        
            
    /*
    La fecha de nacimiento del arbol se la puso en string para luego convertirla a date
        estaba consultando como hacerlo pero me fallo el procedimiento.
    */
      
        Arbol arbol1= new Arbol (11,true,true,"2022/09/30");
            System.out.println(arbol1);
            
        Arbusto arbusto1= new Arbusto (11,true,true,"2022/09/30");
            System.out.println(arbusto1);    
        
        Hierba hierba1= new Hierba (11,true,true,"2022/09/30");
            System.out.println(hierba1);    
        
            
        Mata mata1= new Mata (11,true,true,"2022/09/30");
            System.out.println(mata1);    
        
            
        /*
         public Arbol(double altura, boolean daFruto, boolean tieneFlores, String fechaNacimiento) {
        super(altura, daFruto, tieneFlores, fechaNacimiento);
            }
    

        */
    }
    
}
