
package proyecto;



import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class Proyecto{
    public static void main(String[] args) {
        
        List<Registro>baseusuarios =new ArrayList<>();
        
        int opcion;
             String nombre;
             String correo;
             String contraseña;
         Scanner entrada= new Scanner(System.in);
        
        
        
        System.out.println("Ecommerce");
        System.out.println("=========");
        System.out.println("1. Registrarse ");
        System.out.println("2. Iniciar Sesion");
        System.out.println("3. Olvidaste tu contrasena ");
        System.out.println("4. Cerrar Sesion");
        
        
        System.out.println("Ingrese la opcion: ");
        opcion = entrada.nextInt();
      
                   
                
        
            switch ((opcion)) {
                case 1:
                    Registro contadorRegistro = new Registro();
                    
                    System.out.println("\nIngreso de usuario: ");
                    System.out.println("\nNombre: ");
                    nombre = entrada.next();
                    contadorRegistro.setNombre(nombre);
                    System.out.println("\nCorreo:");
                    correo = entrada.next();
                    contadorRegistro.setCorreo(correo);
                    System.out.println("\nContraseña:");
                    contraseña = entrada.next();
                    contadorRegistro.setContraseña(contraseña);
                    
                    for (Registro baseusuario : baseusuarios) {
                        System.out.println(baseusuario.toString());
                        
                                                              }
                    
                    baseusuarios.add(contadorRegistro);
                    
                   break;

                case 2:
                    System.out.println("Ingrese su usuario");
                    System.out.println("usuario");
                    correo = entrada.next();
                    System.out.println("Contraseña:");
                    contraseña = entrada.next();
                    
                    for (Registro regusuario : baseusuarios) {
                        if (regusuario.getCorreo().equals(correo) && regusuario.getContraseña().equals(contraseña)) {
                        } else {
                            System.out.println("Informacion Invalida");
                        }

                    }
                   break;
                case 3:
                    System.out.println("Cambiar Contraseña: si [1], no [2]");
                        int cambiocon = entrada.nextInt();
                        int restablecido = 0;
                        
                        if (cambiocon==1) {
                            System.out.println("Ingrese su correo");
                            correo = entrada.next(); 
                            
                            for ( Registro cambiocon1 : baseusuarios ) {
                                if(cambiocon1.getCorreo().equals(correo))
                                    restablecido = baseusuarios.indexOf(cambiocon1.getCorreo()); }
                                    
                                    if(restablecido !=0){
                                        System.out.println("Ingrese la nueva contraseña");
                                        contraseña = entrada.next();
                                        cambiocon.setContraseña(contraseña);}
                                    }
                                    
                 break;     
     
                case 4:
                     
                    System.out.println("\n Finalizado");
                   break;
                default:
                    System.out.println("Opcion equivocada");
                   break; 
                                       
                                    
                                   
                                
                            }   
                                
                        
                    }

    private static void indexOf(String correo) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
                    
                   
                   
        
            } 
            
               
        
     

