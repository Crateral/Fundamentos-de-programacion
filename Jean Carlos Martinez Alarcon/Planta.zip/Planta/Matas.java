public class Matas extends Hierbas {

        public Matas(int calcularAltura, String crearFlor, String crearFruto) {
        super(calcularAltura,crearFlor,crearFruto);
        this.calcularAltura = calcularAltura;
        this.crearFlor = crearFlor;
        this.crearFruto = crearFruto;

    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public boolean isDaFruto() {
        return daFruto;
    }

    public void setDaFruto(boolean daFruto) {
        this.daFruto = daFruto;
    }

    public boolean isDaFlores() {
        return daFlores;
    }

    public void setDaFlores(boolean daFlores) {
        this.daFlores = daFlores;
    }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("Matas{calcularAltura=").append(calcularAltura);
            sb.append(",crearFlor=").append(crearFlor);
            sb.append(",crearFruto=").append(crearFruto);
            sb.append(", ").append(super.toString());
            sb.append('}')
            return sb.toString();


        }

}
