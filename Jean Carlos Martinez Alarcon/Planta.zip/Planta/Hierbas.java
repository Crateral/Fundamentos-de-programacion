import java.util.Scanner;

public class Hierbas extends Planta {

        protected int calcularAltura;
        protected String crearFlor;
        protected String crearFruto;

        public Hierbas(int calcularAltura, String crearFlor, String crearFruto) {
                this.calcularAltura = calcularAltura;
                this.crearFlor = crearFlor;
                this.crearFruto = crearFruto;
        }

        public int getCalcularAltura() {
                return calcularAltura;
        }

        public void setCalcularAltura(int calcularAltura) {
                this.calcularAltura = calcularAltura;
        }

        public String getCrearFlor() {
                return crearFlor;
        }

        public void setCrearFlor(String crearFlor) {
                this.crearFlor = crearFlor;
        }

        public String getCrearFruto() {
                return crearFruto;
        }

        public void setCrearFruto(String crearFruto) {
                this.crearFruto = crearFruto;
        }

        @Override
        public String toString() {
                return "Hierbas{" +
                        "calcularAltura=" + calcularAltura +
                        ", crearFlor='" + crearFlor + '\'' +
                        ", crearFruto='" + crearFruto + '\'' +
                        '}';
        }


}


        public static void main(String[] args) {
                Scanner sc= new Scanner(System.in);

                System.out.println("Ingrese altura");
                float altura = sc.nextFloat()
        }
