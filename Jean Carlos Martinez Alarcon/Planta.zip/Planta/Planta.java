public class Planta
{
        protected double altura
        protected boolean daFruto;
        protected boolean daFlores;

        public Planta()

        public double getAltura() {
               return altura;
        }

        public void setAltura(double altura) {
                this.altura = altura;
        }

        public boolean isDaFruto() {
                return daFruto;
        }

        public void setDaFruto(boolean daFruto) {
                this.daFruto = daFruto;
        }

        public boolean isDaFlores() {
                return daFlores;
        }

        public void setDaFlores(boolean daFlores) {
                this.daFlores = daFlores;
        }

        @Override
        public String toString() {
                return "Planta{" +
                        "altura=" + altura +
                        ", daFruto=" + daFruto +
                        ", daFlores=" + daFlores +
                        '}';
        }

        public Planta()
        {


        }
}
