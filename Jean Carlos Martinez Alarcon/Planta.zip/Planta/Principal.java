import java.text.MessageFormat;
import java.util.TimerTask;
import java.util.Timer;
import java.util.Date;


public class Principal
{
    public static void main(String[] args)
    {
        Timer timer = new Timer ();

        TimerTask tarea =new TimerTask() {
            @Override
            public void run()
            {

            }
                System.out.println(MessageFormat.format("Tiempo de vida {0}", new Date()));
                timer.schedule(tarea, 60000,60000);

            }

        };


    }
}
