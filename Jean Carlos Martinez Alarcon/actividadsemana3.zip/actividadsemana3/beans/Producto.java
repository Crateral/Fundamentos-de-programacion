
package com.my.actividadsemana3.beans;

import java.io.Serializable;


public class Producto implements Serializable{

        private double precio;
        private String nombreProducto;
        private String categoria;

    public Producto(String Nombreproducto,String categoria, double precio) {
        this.precio = precio;
        this.nombreProducto = Nombreproducto;
        this.categoria = categoria;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Producto{");
        sb.append("precio=").append(precio);
        sb.append(", nombreProducto=").append(nombreProducto);
        sb.append(", categoria=").append(categoria);
        sb.append('}');
        return sb.toString();
    }
    
    
    

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = (int) precio;
    }

    public String getNombreproducto() {
        return nombreProducto;
    }

    public void setNombreproducto(String Nombreproducto) {
        this.nombreProducto = Nombreproducto;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    
}