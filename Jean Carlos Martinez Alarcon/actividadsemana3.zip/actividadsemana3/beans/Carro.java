
package com.my.actividadsemana3.beans;

import com.my.actividadsemana3.logica.PorCategoria;
import com.my.actividadsemana3.logica.PorPrecio;
import com.my.actividadsemana3.logica.Pornombre;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.stream.Collectors;

public class Carro implements Serializable{
        
            private double caja;
                
        private ArrayList<Producto> compra =new ArrayList<>();
        
        public Carro(){
        
            compra.add(new Producto("zanahorias 1kg","Alimentos",1.700));
            compra.add(new Producto("Toallitas humedas","Higiene",3.000));    
            compra.add(new Producto("tomate 1lb","Alimentos",4.500));
            compra.add(new Producto("Coca cola 3lt","Bebidas",3.400));
            compra.add(new Producto("Sprite 1lt","Bebidas",4.548));
            compra.add(new Producto("Suavitel 500ml","Aseo",6.150));
            compra.add(new Producto("Mr musculo 500ml ","Aseo",4.520));
            compra.add(new Producto("Pechuga de pollo 1 lb","Carnes",8.000));
             
        }
        
            public void addProducto(Producto p){
            compra.add(p);
            
                                                }
            
                
             public void listarCompra() {
             System.out.println("\n\t\tLista de compras\n");
             compra.forEach(System.out::println);
            
                                        }
             public void ListarPornombre() { // Stream: contendra solo los objetos que coincidan con el filtro//
             System.out.println("\n\t\tOrdenados por Nombre\n");
             compra.stream().sorted(new Pornombre()).forEach(System.out::println);
            
                                         }
             public void ListarPorCategoria() { // Stream: contendra solo los objetos que coincidan con el filtro//
             System.out.println("\n\t\tOrdenados por Categoria\n");
             compra.stream().sorted(new PorCategoria()).forEach(System.out::println);
            
                                         }
             public void ListarPorPrecio() { // Stream: contendra solo los objetos que coincidan con el filtro//
             System.out.println("\n\t\tOrdenados por Precio\n");
             compra.stream().sorted(new PorPrecio()).forEach(System.out::println);
                                           }
             
             public void valorProducto (){
                 System.out.println("\n\t\tRegistrado : \n");
                 compra.forEach(System.out::println);
             }
                 
                public void comprar (){
     
                    double importe=0;
                    for (Producto prod: compra)// 1.Tipo de dato 2. nombre 3. nombre del arreglo 
                     importe += prod.getPrecio();
                 double iva = +importe * 0.19; 
                 System.out.println("\n\t\tEl total de la caja es:  ");
                 System.out.printf("\n\t\tTotal de la compra: "+ importe);
                 System.out.printf("\n\t\tIva: "+ iva);
                 System.out.printf("\n\t\tTotal de la compra: "+ (importe + iva));
                    
            }   
            
             public void filtrarporCategoria(String categoria){
                 
                 System.out.println("\n\tFiltrado por : "+ categoria + "\n");
                   ArrayList<Producto> filtrado = (ArrayList<Producto>) compra.stream().filter(producto-> producto.getCategoria().equals(categoria)).collect(Collectors.toList());
             
                   if (filtrado.isEmpty())
                       System.out.println("\n\tNo hay productos para esta categoria.");
                   else 
                       filtrado.stream().forEach(System.out::println);
             }
             
             
      }
