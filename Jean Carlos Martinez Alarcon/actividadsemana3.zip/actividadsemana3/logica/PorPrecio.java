
package com.my.actividadsemana3.logica;


import com.my.actividadsemana3.beans.Producto;
import java.util.Comparator;


public class PorPrecio  implements Comparator <Producto>{

    @Override
    public int compare(Producto o1, Producto o2) {
            return Double.compare(o1.getPrecio(), o2.getPrecio());
            
}
    
}
