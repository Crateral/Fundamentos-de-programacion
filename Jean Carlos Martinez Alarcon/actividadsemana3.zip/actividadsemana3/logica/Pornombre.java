
package com.my.actividadsemana3.logica;


import com.my.actividadsemana3.beans.Producto;
import java.util.Comparator;


public class Pornombre  implements Comparator <Producto>{

    @Override
    public int compare(Producto o1, Producto o2) {
            return o1.getNombreproducto().compareTo(o2.getNombreproducto());   }
}
