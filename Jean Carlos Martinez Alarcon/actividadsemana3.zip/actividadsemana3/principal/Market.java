
package com.my.actividadsemana3.principal;

import com.my.actividadsemana3.beans.Carro;
import com.my.actividadsemana3.beans.Producto;
import java.util.Scanner;


public class Market {
    
           private static   Carro carroDeCompra = new Carro();
           private static  Scanner teclado =new Scanner(System.in);
            
                

public static void main(String[]args){
                
            String opcion="";
            
            
            do{
                System.out.println("\n\t Supermercado  ");
                System.out.println("\n\t ------------\n");
                System.out.println("[1] -- Anadir producto: ");
                System.out.println("[2] -- Lista de compras: ");
                System.out.println("[3] -- Ordenar por Nombre: ");
                System.out.println("[4] -- Ordenar por Categoria:");
                System.out.println("[5] -- Ordenar por Precio: ");
                System.out.println("[6] -- Consulta por Categoria: ");
                System.out.println("[7] -- Anadido a carro ");
                System.out.println("[8] -- Comprar");
                System.out.println("[9] -- Salir");
                System.out.println("Opcion: ");
                opcion=teclado.nextLine();
                
                switch (opcion) {

                   case "0":
                        System.out.println("\n\t Fin");
                        break;
                   case "1":
                        System.out.println("\n\t Añadir Producto");
                        System.out.print("\n\t Nombre");
                        String Nombreproducto = teclado.nextLine();
                        System.out.print("\n\t Categoria: ");
                        String categoria = teclado.nextLine();
                        System.out.print("\n\t Precio: ");
                        double precio = Double.parseDouble(teclado.nextLine());
                        carroDeCompra.addProducto(new Producto(Nombreproducto,categoria,precio));
                        break;
                   case "2":
                        carroDeCompra.listarCompra();
                        break;
                   case "3":
                        carroDeCompra.ListarPornombre();
                        break;
                   case "4":
                        carroDeCompra.ListarPorCategoria();
                        break;
                   case "5":
                        carroDeCompra.ListarPorPrecio();
                        break;    
                   case "6":
                         System.out.println("\n\tConsultar por categoria");
                         System.out.println("Categoria: ");
                         String filtro = teclado.nextLine();
                         carroDeCompra.filtrarporCategoria(filtro);
                        break;
                   case "7":
                        System.out.println( "\n\t Productos registrados");  
                        carroDeCompra.listarCompra();
                        
                        break;
                   case "8":
                        System.out.println( "\n\t Caja");  
                        carroDeCompra.comprar();
                        
                        break;
                   case "9":
                        System.out.println("\n---Gracias por usar el carrito.---");  
                        break;      
                   default:
                        System.out.println("\n---Opcion erronea---");   
                        
                }   
        }    while (!opcion.equals("0"));                     
    } 
}
 
