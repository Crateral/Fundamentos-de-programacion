
package Clases;


public class Clase {
    
    private int codClase;
    private String categoria;
    private String nombreClase;
    
    public void reservarClases (){}
    public void modificarClases (){}
      
}
