
package Clases;


public class Cliente extends Registro {

    public Cliente(String nombre, int cedula, int edad, int telefono, String direccion, String correo) {
        super(nombre, cedula, edad, telefono, direccion,correo);
    }
    
    
    
    
    
    
    
    public void mostrarDatos(){
       
            
        System.out.println("El nombre del usuario es: "+nombre);
        System.out.println("La CC es: "+ cedula);
        System.out.println("El Telefono es: "+ telefono);
        System.out.println("La edad es: "+ edad);

        
        }
        
     
    
    }
            
    
    
    

