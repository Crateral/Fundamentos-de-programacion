
package Clases;


public class Coach extends Registro {
    
    
    private String especialidad;

    public Coach(String nombre, int cedula, int edad, int telefono, String direccion, String correo, String especialidad) {
        super(nombre, cedula, edad, telefono, direccion, correo);
        this.especialidad = especialidad;
       
    }

     public void mostrarDatosCoach(){
       
            
        System.out.println("\nEl nombre del Entrenador es: "+nombre+ 
                            "\n\tLa CC es: "+ cedula+
                             "\n\tEl Telefono es: "+ telefono+
                              "\n\tLa edad es: "+ edad+
                                "\n\tLa especialidad es: "+ especialidad);
        
        
        }
        
    public void consultarClases (){}
    public void modificarClases (){}
    
    
    
}
