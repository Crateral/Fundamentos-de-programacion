package Clases;


public class Administrador extends Registro {
    
    public Administrador(String nombre, int cedula, int edad, int telefono, String direccion, String correo) {
        super(nombre, cedula, edad, telefono, direccion, correo);
    }
    
    
    public void consultaMembresias (){}
    public void consultaUsuarios (){}
    public void actualizarInfoUsuarios (){}
    
    
}
