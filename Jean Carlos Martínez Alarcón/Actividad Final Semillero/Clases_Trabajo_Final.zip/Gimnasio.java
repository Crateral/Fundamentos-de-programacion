

package Clases;


public class Gimnasio {
 
       public static void main (String [] args){
       Cliente usuario = new Cliente ("juan", 52472,32,205,"Cl 2", "carl@hot.es");
   
        usuario.mostrarDatos(); 
        
        Coach Entrenador = new Coach("Andres", 56321,25,365,"Cl 5", "Andres@hot.es", "Pilates");
        Entrenador.mostrarDatosCoach();
        
   }
}
