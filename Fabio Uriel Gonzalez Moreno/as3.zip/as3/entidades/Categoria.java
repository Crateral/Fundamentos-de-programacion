package com.co.nttdata.as3.entidades;

import java.io.Serializable;
import java.util.ArrayList;

public class Categoria implements Serializable {


    private String nombreCategoria;
    public ArrayList<Producto> listaProductos = new ArrayList<>();

    public Categoria() {

    }

    public Categoria(String nombreCategoria) {
        this.nombreCategoria = nombreCategoria;
    }

    public void agregarProductoCarro(Producto producto1) {
        listaProductos.add(producto1);



    }

    public void eliminarProducto() {

        for (int i = 0; i < listaProductos.size(); i++) {

            System.out.println((i + 1) + ". Categoria: " + nombreCategoria + (i + 1) + "---Producto: " + listaProductos.get(i).getNombreProducto()
                    + " ---Precio: " + listaProductos.get(i).getPrecioProducto());
        }
    }


    public void mostrarProductos() {
        for (int i = 0; i < listaProductos.size(); i++) {

            System.out.println("|-----------------------------------------------------------------------------------------|");
            System.out.println("|-- Categoria: " + nombreCategoria + "---Producto: " + listaProductos.get(i).getNombreProducto()
                    + " ---Precio: " + listaProductos.get(i).getPrecioProducto() + "----------------------------------------|");
            System.out.println("|-----------------------------------------------------------------------------------------|");

        }
    }

    public int guardarPrecioProductos() {
        int valor = 0;
        int resultado = 0;
        for (int i = 0; i < listaProductos.size(); i++) {
            valor = listaProductos.get(i).getPrecioProducto();
            resultado = valor + resultado;

            System.out.println("|-----------------------------------------------------------------------------------------|");
            System.out.println("|-- Producto: " + listaProductos.get(i).getNombreProducto() + " ---- Precio: " + valor + "---------------------------------------------------|");
            System.out.println("|-----------------------------------------------------------------------------------------|");

        }
        return resultado;
    }

    public String getNombreCategoria() {
        return nombreCategoria;
    }

    public void setNombreCategoria(String nombreCategoria) {
        this.nombreCategoria = nombreCategoria;
    }

    @Override
    public String toString() {
        return "Categoria{" +
                "categoria='" + nombreCategoria + '\'' +
                ", listaProductos=" + listaProductos +
                '}';
    }
}
