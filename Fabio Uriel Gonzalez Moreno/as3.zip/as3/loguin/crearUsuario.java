package com.co.nttdata.as3.loguin;

import com.co.nttdata.as3.entidades.Categoria;
import com.co.nttdata.as3.entidades.Producto;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class crearUsuario {

    static List<Categoria> listaCategorias = new ArrayList<>();// se crea lista donde se crearan las categorias
    static List<Registro> UsuariosRegistrados = new ArrayList<>();// lista donde se guardaran los usuarios registrados

    static List<Producto> listaProductos = new ArrayList<>();

    public static void main(String[] args) {
        //Quemado de datos a las categorias con constructor con parametros
        Categoria categorias2 = new Categoria("Frutas");
        Categoria categorias3 = new Categoria("Lacteos");
        Categoria categorias4 = new Categoria("Carnes");
        Categoria categorias5 = new Categoria("Verduras");
        //Se agregan a la lista
        listaCategorias.add(categorias2);
        listaCategorias.add(categorias3);
        listaCategorias.add(categorias4);
        listaCategorias.add(categorias5);

        // Se invoca metodo de primer menu


        menuLogin();
    }

    public static void menuLogin() {

        Scanner entrada = new Scanner(System.in);

        String nombre, email, contrasena;
        int opcion = 0;


        System.out.println("------------------------------------");
        System.out.println("      👨‍REGISTRO DE USUARIO👩       ");
        System.out.println("------------------------------------|");
        System.out.println("|  1. Crear usuarios                |");
        System.out.println("|  2. Consultar usuarios            |");
        System.out.println("|  3. Iniciar Sesion                |");
        System.out.println("|  4. Cambiar Contraseña            |");
        System.out.println("|  5. Recuperar Contraseña          |");
        System.out.println("|  6. Agregar Productos al Carrito  |");
        System.out.println("|  7. Salir                         |");
        System.out.println("|-------Digite una Opcion-----------|");
        System.out.println("|-----------------------------------|");
        try {
            opcion = entrada.nextInt();

            switch ((opcion)) {

                case 1:
                    Registro contadorRegistro = new Registro();
                    System.out.println("REGISTRO DE USUARIO: ");
                    System.out.println("nombre: ");
                    nombre = entrada.next();
                    contadorRegistro.setNombre(nombre);

                    System.out.println("CONTRASEÑA: ");
                    contrasena = entrada.next();
                    contadorRegistro.setContrasena(contrasena);

                    System.out.println("CORREO ELECTRONICO: ");
                    email = entrada.next();
                    contadorRegistro.setCorreo(email);

                    for (int i = 0; i < UsuariosRegistrados.size(); i++) {
                        if (contadorRegistro.getCorreo() == email) {
                            System.out.println("Correo ya registrado");
                        } else {
                            UsuariosRegistrados.add(contadorRegistro);
                        }

                    }
                    UsuariosRegistrados.add(contadorRegistro);
                    menuLogin();
                    break;

                case 2:

                    if (UsuariosRegistrados.size() != 0) {

                        for (Registro registroUsua : UsuariosRegistrados) {
                            System.out.println(registroUsua.toString());

                        }
                    } else {
                        System.out.println("no hay usuarios registrados");
                    }
                    menuLogin();
                    break;
                case 3:
                    System.out.println("Digite sus credenciales");
                    System.out.println("usuario");
                    email = entrada.next();
                    System.out.println("contraseña");
                    contrasena = entrada.next();

                    for (Registro registroUsua : UsuariosRegistrados) {
                        if (registroUsua.getCorreo().equals(email) && registroUsua.getContrasena().equals(contrasena)) {
                            System.out.println("Sesion iniciada");
                        } else {
                            System.out.println("los datos ingresados no son validos");
                        }

                    }
                    menuLogin();
                    break;
                case 4:

                    System.out.println("estas seguro que quieres cambiar contraseña 1 para si, 2 para no");
                    int cambioContra = entrada.nextInt();
                    if (cambioContra == 1) {
                        System.out.println("digite su correo");
                        email = entrada.next();

                        for (Registro camContra : UsuariosRegistrados) {
                            if (camContra.getCorreo().equals(email)) {
                                int indice = UsuariosRegistrados.indexOf(camContra.getCorreo());

                                if (indice != 0) {
                                    System.out.println("ingresa tu nueva contraseña");
                                    contrasena = entrada.next();
                                    camContra.setContrasena(contrasena);
                                }
                            }

                        }
                    } else {
                        System.out.println("Ingrese otra opcion");
                    }
                    menuLogin();


                    break;
                case 5:
                    System.out.println("Quiere recuperar su contraseña: 1 (si); 2 (no)  ");
                    int olvidoCon = entrada.nextInt();
                    if (olvidoCon == 1) {
                        System.out.println("digite su correo");
                        email = entrada.next();

                        for (Registro olvidoCon1 : UsuariosRegistrados) {
                            if (olvidoCon1.getCorreo().equals(email)) {
                                int Recuperarcon = UsuariosRegistrados.indexOf(olvidoCon1.getCorreo());

                                if (Recuperarcon != 0) {
                                    System.out.println("ingresa tu nueva contraseña");
                                    contrasena = entrada.next();
                                    olvidoCon1.setContrasena(contrasena);
                                }
                            }

                        }


                    }
                    menuLogin();

                    break;
                case 6:
                    menu();


                    break;


                case 7:
                    System.out.println("Adios");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Opcion no valida");
                    menuLogin();
                    break;


            }

        } catch (Exception e) {
            System.out.println("opcion no valida");
            menuLogin();

        }
    }

    public static void menu() {
        try {
            Scanner entrada2 = new Scanner(System.in);

            int condicion = 0;


            System.out.println("-------------------------------------");
            System.out.println("|      🛒CARRITO DE COMPRAS🛒       |");
            System.out.println("------------------------------------|");
            System.out.println("|  1. Agregar Producto              |");
            System.out.println("|  2. Consultar Productos           |");
            System.out.println("|  3. Eliminar Productos            |");
            System.out.println("|  4. Generar Factura               |");
            System.out.println("|  5. Menu principal                |");
            System.out.println("|-------Digite una Opcion-----------|");
            System.out.println("|-----------------------------------|");


            condicion = entrada2.nextInt();

            Categoria categoria = new Categoria();
            switch (condicion) {

                case 1:
                    System.out.println("|-----------------------------------|");
                    System.out.println("| Ingrese el nombre del producto    |");
                    System.out.println("|-----------------------------------|");
                    entrada2.nextLine();
                    String[] nombreArreglo = entrada2.nextLine().split(" ");


                    System.out.println("|-----------------------------------|");
                    System.out.println("| Ingrese Precio del producto       |");
                    System.out.println("|-----------------------------------|");

                    int precio = entrada2.nextInt();

                    Producto productos2 = new Producto(nombreArreglo[0], precio);

                    int numeroCategoria = 0;
                    String nombreCategoria = "";
                    if (listaCategorias.isEmpty()) {

                        System.out.println("|-----------------------------------|");
                        System.out.println("| Digite la nueva categoria         |");
                        System.out.println("|-----------------------------------|");

                        nombreCategoria = entrada2.next();
                        categoria.setNombreCategoria(nombreCategoria);
                        listaCategorias.add(categoria);
                    } else {
                        for (int i = 0; i < listaCategorias.size(); i++) {

                            System.out.println(i + " --->" + listaCategorias.get(i).getNombreCategoria());
                        }
                        System.out.println(listaCategorias.size() + "--> Categoria Disponible");

                        System.out.println("|-------------------------------------|");
                        System.out.println("| Seleccione el numero de la categoria|");
                        System.out.println("|-------------------------------------|");


                        numeroCategoria = entrada2.nextInt();
                        nombreCategoria = listaCategorias.get(numeroCategoria).getNombreCategoria();

                    }
                    crearProducto(numeroCategoria, nombreCategoria, productos2);
                    break;


                case 2:

                    for (int i = 0; i < listaCategorias.size(); i++) {
                        listaCategorias.get(i).mostrarProductos();

                    }
                    menu();
                    break;

                case 3:Prueba();


                    String nombreProducto;
                    for (int i = 0; i < listaCategorias.size(); i++) {
                        listaCategorias.get(i).eliminarProducto();
                    }


                    System.out.println("|-------------------------------------------------|");
                    System.out.println("| Escriba el nombre de producto que va a eliminar|");
                    System.out.println("|-------------------------------------------------|");
                    nombreProducto = entrada2.next();

                    System.out.println();

                    listaCategorias.removeIf(p -> p.listaProductos.equals(nombreProducto));

                    System.out.println("|-------------------------------------------------|");
                    System.out.println("|-----------El producto se ha elimino-------------|");
                    System.out.println("|-------------------------------------------------|");


                    break;


                case 4:
                    facturas();
                    break;

                case 5:
                    menuLogin();
                    break;

                default:
                    System.out.println("|-------------------------------------------------|");
                    System.out.println("|---------------Opcion no valida------------------|");
                    System.out.println("|-------------------------------------------------|");

                    break;

            }
        } catch (Exception e) {
            System.out.println("Opcion no valida");
        }
        menu();
    }

    public static void crearProducto(int numeroCategoria, String nombreCategoria, Producto producto1) {
        if (numeroCategoria < listaCategorias.size()) {
            listaCategorias.get(numeroCategoria).agregarProductoCarro(producto1);
        } else {
            Categoria categorias2 = new Categoria(nombreCategoria);
            categorias2.agregarProductoCarro(producto1);
            listaCategorias.add(categorias2);
        }
        for (int i = 0; i < listaCategorias.size(); i++) {
            listaCategorias.get(i).mostrarProductos();
        }
        menu();
    }

    public static void facturas() {
        int valor = 0;
        double valor2 = 0;
        for (int i = 0; i < UsuariosRegistrados.size(); i++) {
            UsuariosRegistrados.get(i).getCorreo();

            System.out.println(i);
        }
        System.out.println("|-------------------------------------------------|");
        System.out.println("|-------------- Total Factura --------------------|");
        System.out.println("|-------------------------------------------------|");


        for (int i = 0; i < listaCategorias.size(); i++) {
            valor = listaCategorias.get(i).guardarPrecioProductos() + valor;
        }
        System.out.println("|-------------------------------------------------|");
        System.out.println("|-Total de compra: " + valor + "----------------------|");
        System.out.println("|-------------------------------------------------|");

        valor2 = valor * 0.19;

        System.out.println("|-------------------------------------------------|");
        System.out.println("|--iva " + valor2 + "---------------------------------|");
        System.out.println("|-------------------------------------------------|");

        System.out.println("|-------------------------------------------------|");
        System.out.println("|-Total Compra mas iva " + (valor + valor2) + "--------|");
        System.out.println("|-------------------------------------------------|");


        menu();
    }
    public static void Prueba(){
        if(listaProductos.size()!=0){
            for (Producto producto:listaProductos){
                System.out.println(producto.toString());
            }
        }else{
            System.out.println("NO HAY PRODUCTOS");
        }



    }
}




