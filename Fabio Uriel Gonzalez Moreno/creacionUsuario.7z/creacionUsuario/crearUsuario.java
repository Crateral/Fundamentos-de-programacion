package miniMarquet;

import java.util.*;
import java.util.stream.Collectors;

public class crearUsuario {
    public static void main(String[] args) {

        List<Registro> UsuariosRegistrados = new ArrayList<>();

        Scanner entrada = new Scanner(System.in);
        String nombre, email, contrasena;
        int opcion = 0;

        while (true) {
            System.out.println("👀REGISTRO DE USUARIO😎");
            System.out.println("1. Crear Usuario");
            System.out.println("2. consultar usuario");
            System.out.println("3. iniciar sesion");
            System.out.println("4. Cambiar Contraseña");
            System.out.println("5. Recuperar contraseña");
            System.out.println("6. salir");

            System.out.println("Digita la opcion que deseas realizar: ");
            opcion = entrada.nextInt();

            switch ((opcion)) {

                case 1:
                    Registro contadorRegistro = new Registro();
                    System.out.println("REGISTRO DE USUARIO: ");
                    System.out.println("nombre: ");
                    nombre = entrada.next();
                    contadorRegistro.setNombre(nombre);
                    System.out.println("CONTRASEÑA: ");
                    contrasena = entrada.next();
                    contadorRegistro.setContrasena(contrasena);
                    System.out.println("CORREO ELECTRONICO: ");
                    email = entrada.next();
                    contadorRegistro.setCorreo(email);



                    //for (int i=0; i<UsuariosRegistrados.size();i++){
                      //  if(contadorRegistro.getCorreo()==email){
                        //    System.out.println("correo electronico ya usado en un registro");



                       // }
                    //}
                    UsuariosRegistrados.add(contadorRegistro);

                    break;
                case 2:

                    if (UsuariosRegistrados.size() != 0) {
                        for (Registro registroUsua : UsuariosRegistrados) {
                            System.out.println(registroUsua.toString());

                        }
                    } else {
                        System.out.println("no hay usuarios registrados");

                    }
                    break;
                case 3:
                    System.out.println("Digite sus credenciales");
                    System.out.println("usuario");
                    email = entrada.next();
                    System.out.println("contraseña");
                    contrasena = entrada.next();

                    for (Registro registroUsua : UsuariosRegistrados) {
                        if (registroUsua.getCorreo().equals(email) && registroUsua.getContrasena().equals(contrasena)) {
                        } else {
                            System.out.println("los datos ingresados no son validos");
                        }

                    }
                        break;
                        case 4:

                            System.out.println("estas seguro que quieres cambiar contraseña 1 para si, 2 para no");
                            int cambioContra=entrada.nextInt();
                            if (cambioContra==1) {
                                System.out.println("digite su correo");
                                email = entrada.next();

                                for (Registro camContra : UsuariosRegistrados) {
                                    if (camContra.getCorreo().equals(email)) {
                                        int indice =UsuariosRegistrados.indexOf(camContra.getCorreo());

                                        if(indice != 0){
                                            System.out.println("ingresa tu nueva contraseña");
                                            contrasena = entrada.next();
                                        camContra.setContrasena(contrasena);}
                                    }

                                }
                            }



                            break;
                        case 5:
                            System.out.println("Quiere recuperar su contraseña: 1 (si); 2 (no)  ");
                            int olvidoCon=entrada.nextInt();
                            if (olvidoCon==1){
                                System.out.println("digite su correo");
                                email = entrada.next();

                                for (Registro olvidoCon1 : UsuariosRegistrados) {
                                    if (olvidoCon1.getCorreo().equals(email)) {
                                        int Recuperarcon =UsuariosRegistrados.indexOf(olvidoCon1.getCorreo());

                                        if(Recuperarcon != 0){
                                            System.out.println("ingresa tu nueva contraseña");
                                            contrasena = entrada.next();
                                            olvidoCon1.setContrasena(contrasena);}
                                    }

                                }


                            }


                            break;
                        case 6:System.exit(0);

                            break;
                        default:
                            System.out.println("Opcion no valida");

                    }
            }
        }
    }

