package carritoDeCompras;

import java.util.ArrayList;
import java.util.Scanner;

public class carritoDeCompras {
    static ArrayList<Categoria>categorias = new ArrayList<>();
    static Scanner entrada =new Scanner(System.in);
    static Scanner entrada1 =new Scanner(System.in);

    public static void main(String[] args) {
        int opcion=0;

        do {
            System.out.println("1. Agregar producto");
            System.out.println("2. consultar productos");
            System.out.println("3. salir");

            System.out.println(" Ingresar una opcion: ");
            opcion= entrada.nextInt();

            switch (opcion){

                case 1:
                    System.out.println("Ingrese datos del producto:  ");
                    entrada.nextLine();
                    String[] datos = entrada.nextLine().split(" ");

                    System.out.println("ingrese precio ");
                    int datos1 = entrada1.nextInt();

                    Producto producto= new Producto(datos[0],datos1);

                    int numeroCategoria =0;
                    String nombreCategoria="";

                    if (categorias.isEmpty()){
                        nombreCategoria="";
                        System.out.println("ingrese nombre de la categoria");
                        nombreCategoria=entrada.nextLine();

                    }else {
                        for (int i=0; i<categorias.size();i++){
                            System.out.println(i+ " --->"+categorias.get(i).getNombreCategoria());
                        }
                        System.out.println(categorias.size()+ "--> Categoria Disponible");
                        System.out.println("Seleccione el numero del categoria");
                        numeroCategoria= entrada.nextInt();

                    if (numeroCategoria <=categorias.size()) {
                        System.out.println("Ingrese el nombre de la catergoria: ");
                        entrada.nextLine();
                        nombreCategoria = entrada.nextLine();

                    }
                    }

                    crearProducto(numeroCategoria,nombreCategoria,producto);

                   break;
                case 2:
                    int contador= 0;
                    for (Categoria categoria : categorias) {
                        for (int i = 0; i < categorias.size(); i++) {
                            System.out.println((i+1)+". Las productos son "+ categoria.listaProductos);

                            contador=contador;
                        }
                    }


                    break;
                case 3:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Producto no existente");
                    break;

            }



        }while(opcion!= 3);
    }
    public static  void crearProducto(int numeroCategoria,String nombreCategoria,Producto producto1){
        if (numeroCategoria<categorias.size()){
            categorias.get(numeroCategoria).agregarProductoCarro(producto1);
        }else{
            Categoria categoria1 =new Categoria(nombreCategoria);
            categoria1.agregarProductoCarro(producto1);
            categorias.add(categoria1);
        }
        System.out.println(categorias);
        for (int i = 0; i < categorias.size(); i++) {
            categorias.get(i).mostrarProductos();


        }

    }

}
